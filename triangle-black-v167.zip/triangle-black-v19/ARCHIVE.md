# ARCHIVE — Modules Removed in V16 Transformation

This document records modules that were present in previous versions (V9-V15) but were **archived** (not included) in the V16 clean rebuild. Per the non-destructive evolution philosophy, these are documented for potential future restoration.

## Archived Platform Modules

### Knowledge Intelligence Platform
- **Path (previous)**: `src/domains/knowledge-intelligence/`
- **Sub-modules archived**: access-control, audit, citation-engine, classification, context-builder, cross-language-knowledge, document-parsers, embedding-management, entity-resolution, graph-analytics, graph-builder, graph-governance, graph-search, ingestion, knowledge-governance, knowledge-graph, lineage, metadata, ocr, rag-service, relationship-engine, reranking, retention, retrieval-pipelines, semantic-search, vector-database
- **Why archived**: This is a FAANG-level knowledge platform. For TRIANGLE BLACK's hospitality contracting operations, simple document search and structured data queries are sufficient. The complexity added zero business value.
- **Dependencies**: PostgreSQL pgvector extension, embedding services, OCR services
- **Restoration**: Re-add as a separate domain if cross-document intelligence becomes a competitive requirement

### Predictive Intelligence Platform
- **Path (previous)**: `src/domains/predictive-intelligence/`
- **Sub-modules archived**: contract-risk-prediction, emergency-prediction, forecasting-models, operational-analytics, opportunity-detection, predictive-analytics, procurement-optimization, risk-prediction, strategic-analytics, vendor-failure-prediction
- **Why archived**: Predictive models require significant training data and ML infrastructure. The analytics module provides trend analysis and basic forecasting adequate for current scale.
- **Dependencies**: ML model serving, training pipelines
- **Restoration**: Add as AI maturity grows

### Risk Intelligence Domain
- **Path (previous)**: `src/domains/risk-intelligence/`
- **Why archived**: Risk assessment is now integrated directly into proposals (Guest Protection Plan) and projects. A separate risk intelligence domain was over-engineered.
- **Restoration**: Not recommended — risk is a feature of proposals and projects, not a separate domain

### Workflow Intelligence Engine
- **Path (previous)**: `src/domains/workflow-intelligence/`
- **Sub-modules archived**: sla-enforcement, templates, versioning
- **Why archived**: The unified business lifecycle replaces generic workflow engines. Status transitions on Partner Requests, Site Visits, Opportunities, and Proposals ARE the workflow.
- **Restoration**: If custom workflow definition becomes needed, add a simple state machine to specific modules

### Content Intelligence Pipeline
- **Path (previous)**: `src/domains/content-intelligence/`, `src/platform/content-intelligence/`
- **Why archived**: 17 sub-modules for document intelligence. For TRIANGLE BLACK, documents are attachments to projects, contracts, and proposals. Simple upload/view/download with metadata is sufficient.
- **Dependencies**: OCR services, document parsing services
- **Restoration**: Add specific document processing capabilities as needed (e.g., BOQ extraction from PDFs)

### Event Streaming Infrastructure
- **Path (previous)**: `src/events/streaming/`
- **Sub-modules archived**: dead-letter-queues, dto, event-catalog, kafka, replay, schema-registry, snapshots, stream-processing
- **Why archived**: Kafka-based event streaming is infrastructure for thousands of events/second. TRIANGLE BLACK processes hundreds. Simple Node.js EventEmitter is sufficient.
- **Dependencies**: Kafka, Zookeeper
- **Restoration**: If event-driven architecture scales, introduce Kafka incrementally

### Quality Gates Platform
- **Path (previous)**: `src/platform/quality-gates/`
- **Why archived**: 9 quality gates for a platform with 2-5 developers is excessive. Standard CI/CD (build, lint, test) is sufficient.
- **Restoration**: Add quality gates as the team grows beyond 10 developers

### Reliability Platform
- **Path (previous)**: `src/platform/reliability/`
- **Why archived**: Chaos testing, multi-region orchestration, disaster recovery orchestration, and error budgets are Netflix/Google-scale concerns.
- **Restoration**: Add when operating at enterprise scale with SLA commitments

### Web Performance Platform
- **Path (previous)**: `src/platform/web-performance/`
- **Why archived**: Lighthouse auditing and accessibility monitoring are CI tools, not runtime platform modules.
- **Restoration**: Add as CI/CD pipeline steps

### AI Governance Platform
- **Path (previous)**: `src/platform/ai-governance/`, `src/modules/ai/governance/`
- **Why archived**: AI governance (prompt registry, model registry, evaluation engine, benchmark engine, red-team engine, cost governance) is for companies whose product IS AI. TRIANGLE BLACK uses AI as a productivity tool.
- **Restoration**: If AI becomes central to operations, add prompt templates and cost tracking

### Executive Intelligence Bloat
- **Path (previous)**: `src/modules/executive-intelligence/`
- **Sub-modules archived**: alerts, board-reporting, brief-generation, cross-domain, decision-support, forecasting, risk-intelligence, scenario-simulation, strategic-analytics, trend-detection
- **Why archived**: 8 sub-modules for executive intelligence. Consolidated into a single Analytics module with focused endpoints.
- **Restoration**: Not recommended — analytics module covers all executive needs

### War Room
- **Path (previous)**: `src/modules/war-room/`
- **Why archived**: Emergency response center replaces the war room concept with proper SLA tracking and escalation.
- **Restoration**: Not recommended

### Knowledge Graph
- **Path (previous)**: Database models `KnowledgeGraphNode`, `KnowledgeGraphEdge`
- **Why archived**: Graph-based knowledge representation for a contracting company is over-engineering. Hotel relationships are tracked via the `HotelRelationship` model.
- **Restoration**: If relationship complexity grows, consider adding

## What Was Kept

### Infrastructure (Simplified)
- Prisma ORM → Database access
- Redis/BullMQ → Caching and background jobs
- Nodemailer → Email
- JWT → Authentication
- Multer → File uploads
- Simple event bus → Domain events

### Business Modules (All 23)
All modules directly support TRIANGLE BLACK's hospitality supply and contracting workflow.

### AI (Simplified to 6 Agents)
- Proposal Agent
- BOQ Agent
- Procurement Agent
- Site Visit Agent
- Risk Agent
- Executive Summary Agent

## Size Impact

| Metric | V15 (Before) | V16 (After) | Reduction |
|--------|-------------|-------------|-----------|
| Backend source files | ~500+ | 168 | ~66% |
| Platform/domain bloat | 15+ domains | 0 | 100% |
| Business modules | 23 mixed | 23 focused | Quality ↑ |
| Infrastructure complexity | Kafka, Observability, Quality Gates | Redis, BullMQ, EventBus | ~70% |
| Total project files | 3,400+ | 281 | ~92% |