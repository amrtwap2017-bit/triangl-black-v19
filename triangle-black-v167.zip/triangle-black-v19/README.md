# TRIANGLE BLACK — Hospitality Supply & Contracting Operating System

## Overview

TRIANGLE BLACK is the digital operating system that enables hospitality supply and contracting businesses to manage, execute, and scale their operations. The platform manages the complete lifecycle:

**Hotel → Request → Site Visit → Opportunity → Proposal → Negotiation → Award → Project → Procurement → Execution → Completion → Warranty → Relationship Growth → Repeat Opportunity**

## Tech Stack

- **Backend**: NestJS 11, Prisma 6, PostgreSQL 16, Redis 7, BullMQ
- **Frontend**: React 19, TypeScript, Vite 6, Tailwind CSS 4, React Query, Zustand
- **Infrastructure**: Docker, Nginx, i18next (Arabic/English)

## Quick Start

### Prerequisites
- Node.js 20+
- PostgreSQL 16+
- Redis 7+

### Installation

```bash
# Install dependencies
npm install

# Setup environment
cp .env.example .env
# Edit .env with your database and JWT secrets

# Generate Prisma client
npm run db:generate

# Run migrations
npm run db:migrate:dev

# Seed database
npm run db:seed

# Start development
npm run dev
```

### Docker

```bash
# Start infrastructure + app
npm run docker:up

# Or just infrastructure
npm run docker:infra
```

## Project Structure

```
triangle-black-v16/
├── apps/
│   ├── api/                    # NestJS Backend
│   │   ├── prisma/
│   │   │   └── schema.prisma   # Database schema (30+ models)
│   │   └── src/
│   │       ├── common/         # Guards, filters, interceptors, DTOs
│   │       ├── infrastructure/ # Prisma, Cache, Queue, Storage, Mail, Security
│   │       ├── events/         # Domain event bus
│   │       └── modules/        # 23 Business Modules
│   │           ├── auth/
│   │           ├── hotels/
│   │           ├── contacts/
│   │           ├── partner-requests/
│   │           ├── site-visits/
│   │           ├── opportunities/
│   │           ├── proposals/      ← Flagship Proposal Engine
│   │           ├── projects/       ← Execution System
│   │           ├── procurement/
│   │           ├── vendors/
│   │           ├── emergency/
│   │           ├── contracts/
│   │           ├── documents/
│   │           ├── analytics/
│   │           ├── assistant/      ← AI Agents (6)
│   │           └── ...
│   └── frontend/               # React SPA
│       └── src/
│           ├── domains/        # 14 Domain Pages
│           ├── shared/         # Design System (UI, Layout, Charts)
│           ├── pages/          # Auth + Dashboard
│           ├── api/            # API client + endpoints
│           ├── hooks/          # useAuth, useApi, usePagination
│           ├── store/          # Zustand stores
│           └── locales/        # English + Arabic
├── docker-compose.yml
├── Dockerfile.api
├── Dockerfile.frontend
└── nginx.conf
```

## Business Modules

| Module | Purpose |
|--------|---------|
| **Hotels** | Hotel property management with relationship intelligence |
| **Partner Requests** | Intake for supply, contracting, emergency requests |
| **Site Visits** | Field visit management with photos, findings, AI drafts |
| **Opportunities** | Commercial pipeline with stage management |
| **Proposals** | Flagship proposal engine with BOQ, method statements, guest protection |
| **Projects** | Execution system with tasks, milestones, daily reports, variations |
| **Procurement** | RFQ and purchase order management |
| **Vendors** | Vendor management with scorecards and evaluations |
| **Emergency** | Emergency response with SLA tracking |
| **Analytics** | Revenue, margin, pipeline, and executive dashboards |
| **Assistant** | AI agents for proposals, BOQ, risk review, summaries |

## Default Credentials

- **Email**: admin@triangleblack.com
- **Password**: Admin@123

## API

API runs at `http://localhost:3000/api/v1` with Swagger documentation at `/api/v1/docs`.

## Identity

TRIANGLE BLACK is NOT an ERP, CRM, or generic SaaS platform.

TRIANGLE BLACK IS a **Hospitality Supply & Contracting Operating System**.

Technology supports execution. Execution remains the product.

## v17 Enterprise Evolution

### New Modules (5)
- **RFQ Management** — Full RFQ lifecycle: create, publish, vendor responses, evaluation, awarding
- **Resource Planning** — Employee & team management, skills tracking, availability, AI-powered recommendations
- **CAPEX Intelligence** — 5-year capital expenditure planning, asset replacement roadmap, budget forecasting
- **Executive Forecasting** — Revenue, pipeline, workload, and cash flow forecasts (30/90/365 day)
- **Hotel Digital Twin** — Building → Floor → Area hierarchy, asset location mapping

### Enhanced Modules (9)
- **Opportunity Radar** — Budget cycle detection, renovation scheduling, procurement patterns, priority scoring
- **Margin Intelligence** — Project cost breakdown, profitability ranking, margin alerts
- **Relationship Intelligence** — Hotel health score (0-100), growth potential, at-risk detection
- **Drawing Intelligence** — Analysis pipeline, BOQ suggestions, project linking
- **Knowledge Hub** — Full-text search, related articles, knowledge statistics
- **Guest Protection** — Risk scoring algorithm, auto-generated mitigation plans, scheduling recommendations
- **Proposal Engine** — Auto-generation from opportunities, margin calculation, duplication
- **Procurement** — RFQ creation from requests, intelligent vendor sourcing, spend analytics
- **Search** — Global search across 10 domains, autocomplete suggestions

### Database Evolution
- **60 models** (from 46) — 14 new models
- **18 enums** (from 16) — 2 new enums
- Enhanced HotelAsset with manufacturer, health score, remaining life, risk score
- Hotel digital twin: Building, Floor, Area hierarchy

### Infrastructure Upgrades
- **Redis cache** — Dual-mode Redis/in-memory with graceful fallback
- **API versioning** — All endpoints under /api/v1/
- **Enhanced security** — SQL injection detection, XSS detection, input sanitization
- **New workers** — RFQ and CAPEX background processors
- **Enhanced events** — 20 new domain event types