import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { BullModule } from '@nestjs/bullmq';
import { OcrWorkerModule } from './workers/ocr/ocr.module';
import { ExtractionWorkerModule } from './workers/extraction/extraction.module';
import { EmbeddingWorkerModule } from './workers/embedding/embedding.module';
import { IndexingWorkerModule } from './workers/indexing/indexing.module';
import { AiChatWorkerModule } from './workers/ai-chat/ai-chat.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    BullModule.registerQueue(
      { name: 'document-ocr' },
      { name: 'document-extraction' },
      { name: 'document-embedding' },
      { name: 'document-indexing' },
      { name: 'ai-chat' },
    ),
    OcrWorkerModule,
    ExtractionWorkerModule,
    EmbeddingWorkerModule,
    IndexingWorkerModule,
    AiChatWorkerModule,
  ],
})
export class AppModule {}
