import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { AiChatProcessor } from './ai-chat.processor';

@Module({
  imports: [BullModule.registerQueue({ name: 'ai-chat' })],
  providers: [AiChatProcessor],
})
export class AiChatWorkerModule {}
