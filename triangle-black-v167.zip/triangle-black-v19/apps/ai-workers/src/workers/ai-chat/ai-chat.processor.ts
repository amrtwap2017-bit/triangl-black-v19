import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';

const AGENT_TYPES = [
  'ASSISTANT',
  'PROCUREMENT',
  'ENGINEERING',
  'CONTRACT',
  'FINANCE',
  'MAINTENANCE',
  'SALES',
  'EXECUTIVE',
] as const;

type AgentType = (typeof AGENT_TYPES)[number];

@Processor('ai-chat')
export class AiChatProcessor extends WorkerHost {
  private readonly logger = new Logger(AiChatProcessor.name);

  async process(job: Job): Promise<unknown> {
    const {
      conversationId,
      organizationId,
      userId,
      agentType,
      message,
      sessionId,
    } = job.data;
    this.logger.log(
      `Processing AI chat job ${job.id} for conversation ${conversationId} (agent: ${agentType})`,
    );

    const startTime = Date.now();

    try {
      // 1. Validate and enforce security policies
      await this.enforceSecurityPolicies(organizationId, userId, message);

      // 2. Route to appropriate agent based on type
      const agent = this.routeToAgent(agentType as AgentType);

      // 3. Build context (conversation history + relevant documents)
      const context = await this.buildContext(
        conversationId,
        organizationId,
        message,
      );

      // 4. Process through agent (LLM call with tool support)
      const response = await agent.process(message, context);

      // 5. Handle tool calls if any
      if (response.toolCalls && response.toolCalls.length > 0) {
        const toolResults = await this.executeToolCalls(
          response.toolCalls,
          organizationId,
          userId,
        );

        // Follow-up call with tool results
        const followUp = await agent.processWithToolResults(
          message,
          context,
          toolResults,
        );

        // 6. Track token usage and costs
        const totalTokens =
          (followUp.promptTokens || 0) + (followUp.completionTokens || 0);
        const cost = this.calculateCost(
          followUp.model || 'gpt-4o',
          followUp.promptTokens || 0,
          followUp.completionTokens || 0,
        );

        await this.trackUsage({
          organizationId,
          userId,
          agentType,
          model: followUp.model || 'gpt-4o',
          provider: 'openai',
          promptTokens: followUp.promptTokens || 0,
          completionTokens: followUp.completionTokens || 0,
          totalTokens,
          costUsd: cost,
          durationMs: Date.now() - startTime,
        });

        // 7. Store conversation history
        await this.storeConversationMessage(conversationId, {
          role: 'assistant',
          content: followUp.content,
          toolCalls: response.toolCalls,
          toolResults,
          tokensUsed: totalTokens,
          model: followUp.model,
          durationMs: Date.now() - startTime,
        });

        return {
          conversationId,
          content: followUp.content,
          toolCalls: response.toolCalls,
          toolResults,
          tokensUsed: totalTokens,
          costUsd: cost,
          durationMs: Date.now() - startTime,
        };
      }

      // No tool calls - simple response
      const totalTokens =
        (response.promptTokens || 0) + (response.completionTokens || 0);
      const cost = this.calculateCost(
        response.model || 'gpt-4o',
        response.promptTokens || 0,
        response.completionTokens || 0,
      );

      await this.trackUsage({
        organizationId,
        userId,
        agentType,
        model: response.model || 'gpt-4o',
        provider: 'openai',
        promptTokens: response.promptTokens || 0,
        completionTokens: response.completionTokens || 0,
        totalTokens,
        costUsd: cost,
        durationMs: Date.now() - startTime,
      });

      // Store conversation history
      await this.storeConversationMessage(conversationId, {
        role: 'assistant',
        content: response.content,
        tokensUsed: totalTokens,
        model: response.model,
        durationMs: Date.now() - startTime,
      });

      this.logger.log(
        `AI chat completed for conversation ${conversationId}: ${totalTokens} tokens, $${cost.toFixed(4)}`,
      );

      return {
        conversationId,
        content: response.content,
        tokensUsed: totalTokens,
        costUsd: cost,
        durationMs: Date.now() - startTime,
      };
    } catch (error) {
      this.logger.error(
        `AI chat failed for conversation ${conversationId}: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw error;
    }
  }

  private routeToAgent(agentType: AgentType) {
    // Route to the appropriate specialized agent
    const agentRegistry: Record<AgentType, { process: Function; processWithToolResults: Function }> = {
      ASSISTANT: { process: () => ({}), processWithToolResults: () => ({}) },
      PROCUREMENT: { process: () => ({}), processWithToolResults: () => ({}) },
      ENGINEERING: { process: () => ({}), processWithToolResults: () => ({}) },
      CONTRACT: { process: () => ({}), processWithToolResults: () => ({}) },
      FINANCE: { process: () => ({}), processWithToolResults: () => ({}) },
      MAINTENANCE: { process: () => ({}), processWithToolResults: () => ({}) },
      SALES: { process: () => ({}), processWithToolResults: () => ({}) },
      EXECUTIVE: { process: () => ({}), processWithToolResults: () => ({}) },
    };
    return agentRegistry[agentType] || agentRegistry.ASSISTANT;
  }

  private async enforceSecurityPolicies(
    organizationId: string,
    userId: string,
    message: string,
  ): Promise<void> {
    // Check content safety, rate limits, data access permissions
    this.logger.log(
      `Enforcing security policies for user ${userId} in org ${organizationId}`,
    );
  }

  private async buildContext(
    conversationId: string,
    organizationId: string,
    message: string,
  ) {
    // Retrieve conversation history, relevant documents, and knowledge base entries
    return {
      conversationHistory: await this.getConversationHistory(conversationId),
      relevantDocuments: await this.searchRelevantDocuments(
        organizationId,
        message,
      ),
      organizationContext: { organizationId },
    };
  }

  private async getConversationHistory(_conversationId: string) {
    // Retrieve last N messages for context window
    return [];
  }

  private async searchRelevantDocuments(
    _organizationId: string,
    _query: string,
  ) {
    // Vector search for relevant documents
    return [];
  }

  private async executeToolCalls(
    toolCalls: Array<{ id: string; type: string; function: { name: string; arguments: string } }>,
    organizationId: string,
    userId: string,
  ) {
    const results: Array<{ toolCallId: string; name: string; content: string }> = [];

    for (const toolCall of toolCalls) {
      this.logger.log(
        `Executing tool call: ${toolCall.function.name} (${toolCall.id})`,
      );

      // Execute tool with organization and user context
      results.push({
        toolCallId: toolCall.id,
        name: toolCall.function.name,
        content: `Result of ${toolCall.function.name} for org ${organizationId}`,
      });
    }

    return results;
  }

  private calculateCost(
    model: string,
    promptTokens: number,
    completionTokens: number,
  ): number {
    const pricing: Record<string, { input: number; output: number }> = {
      'gpt-4o': { input: 0.000005, output: 0.000015 },
      'gpt-4o-mini': { input: 0.00000015, output: 0.0000006 },
      'gpt-4-turbo': { input: 0.00001, output: 0.00003 },
      'gpt-3.5-turbo': { input: 0.0000005, output: 0.0000015 },
      'claude-3-opus': { input: 0.000015, output: 0.000075 },
      'claude-3-sonnet': { input: 0.000003, output: 0.000015 },
    };

    const rates = pricing[model] || pricing['gpt-4o'];
    return promptTokens * rates.input + completionTokens * rates.output;
  }

  private async trackUsage(data: {
    organizationId: string;
    userId: string;
    agentType: string;
    model: string;
    provider: string;
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    costUsd: number;
    durationMs: number;
  }): Promise<void> {
    this.logger.log(
      `Tracking usage: ${data.totalTokens} tokens ($${data.costUsd.toFixed(4)}) for agent ${data.agentType}`,
    );
    // Store in ai_usage table via Prisma
  }

  private async storeConversationMessage(
    conversationId: string,
    message: {
      role: string;
      content: string;
      toolCalls?: unknown;
      toolResults?: unknown;
      tokensUsed?: number;
      model?: string;
      durationMs?: number;
    },
  ): Promise<void> {
    this.logger.log(
      `Storing ${message.role} message for conversation ${conversationId}`,
    );
    // Store in ai_conversation_messages table via Prisma
  }
}
