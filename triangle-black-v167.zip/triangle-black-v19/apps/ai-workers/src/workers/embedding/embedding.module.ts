import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { EmbeddingProcessor } from './embedding.processor';

@Module({
  imports: [BullModule.registerQueue({ name: 'document-embedding' })],
  providers: [EmbeddingProcessor],
})
export class EmbeddingWorkerModule {}
