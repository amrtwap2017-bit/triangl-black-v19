import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';

const EMBEDDING_BATCH_SIZE = 100;
const EMBEDDING_MODEL = 'text-embedding-3-small';
const EMBEDDING_DIMENSIONS = 1536;

@Processor('document-embedding')
export class EmbeddingProcessor extends WorkerHost {
  private readonly logger = new Logger(EmbeddingProcessor.name);

  async process(job: Job): Promise<unknown> {
    const { documentId, organizationId, chunks } = job.data;
    this.logger.log(
      `Processing embedding job ${job.id} for document ${documentId} (${chunks?.length || 0} chunks)`,
    );

    try {
      if (!chunks || chunks.length === 0) {
        this.logger.warn(`No chunks provided for document ${documentId}`);
        return { documentId, status: 'SKIPPED', embeddingsGenerated: 0 };
      }

      const totalChunks = chunks.length;
      const embeddings: Array<{
        chunkIndex: number;
        content: string;
        embedding: number[];
      }> = [];

      // Process chunks in batches
      for (let i = 0; i < totalChunks; i += EMBEDDING_BATCH_SIZE) {
        const batch = chunks.slice(i, i + EMBEDDING_BATCH_SIZE);
        this.logger.log(
          `Processing batch ${Math.floor(i / EMBEDDING_BATCH_SIZE) + 1}/${Math.ceil(totalChunks / EMBEDDING_BATCH_SIZE)} for document ${documentId}`,
        );

        // Simulated embedding generation
        for (const chunk of batch) {
          const embedding = this.generateMockEmbedding(EMBEDDING_DIMENSIONS);
          embeddings.push({
            chunkIndex: chunk.index,
            content: chunk.content,
            embedding,
          });
        }

        // Store batch embeddings in vector database (pgvector)
        await this.storeEmbeddings(
          organizationId,
          documentId,
          embeddings.slice(i),
        );

        // Update progress
        await job.updateProgress(
          Math.round(((i + batch.length) / totalChunks) * 100),
        );
      }

      const result = {
        documentId,
        organizationId,
        embeddingsGenerated: embeddings.length,
        model: EMBEDDING_MODEL,
        dimensions: EMBEDDING_DIMENSIONS,
        totalChunks,
      };

      this.logger.log(
        `Embedding completed for document ${documentId}: ${embeddings.length} embeddings generated`,
      );

      return result;
    } catch (error) {
      this.logger.error(
        `Embedding failed for document ${documentId}: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw error;
    }
  }

  private async storeEmbeddings(
    organizationId: string,
    documentId: string,
    embeddings: Array<{ chunkIndex: number; content: string; embedding: number[] }>,
  ): Promise<void> {
    // Store in pgvector via raw SQL or ORM
    this.logger.log(
      `Storing ${embeddings.length} embeddings for document ${documentId} in pgvector`,
    );
    // Actual implementation would use Prisma raw SQL or pg client
    // INSERT INTO document_embeddings (organization_id, document_id, content, chunk_index, embedding, metadata)
    // VALUES ($1, $2, $3, $4, $5, $6)
  }

  private generateMockEmbedding(dimensions: number): number[] {
    // Generate a normalized mock embedding vector
    const vector: number[] = [];
    for (let i = 0; i < dimensions; i++) {
      vector.push((Math.random() - 0.5) * 2);
    }
    // Normalize
    const magnitude = Math.sqrt(
      vector.reduce((sum, v) => sum + v * v, 0),
    );
    return vector.map((v) => v / magnitude);
  }
}
