import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { ExtractionProcessor } from './extraction.processor';

@Module({
  imports: [BullModule.registerQueue({ name: 'document-extraction' })],
  providers: [ExtractionProcessor],
})
export class ExtractionWorkerModule {}
