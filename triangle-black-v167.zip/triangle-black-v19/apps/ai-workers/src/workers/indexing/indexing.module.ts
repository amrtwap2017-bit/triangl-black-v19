import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { IndexingProcessor } from './indexing.processor';

@Module({
  imports: [BullModule.registerQueue({ name: 'document-indexing' })],
  providers: [IndexingProcessor],
})
export class IndexingWorkerModule {}
