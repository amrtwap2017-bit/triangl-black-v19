import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { OcrProcessor } from './ocr.processor';

@Module({
  imports: [BullModule.registerQueue({ name: 'document-ocr' })],
  providers: [OcrProcessor],
})
export class OcrWorkerModule {}
