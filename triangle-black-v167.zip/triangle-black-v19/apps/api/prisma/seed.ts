import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // ── 1. Organization ──────────────────────────────────────────────
  const org = await prisma.organization.upsert({
    where: { slug: 'triangle-black' },
    update: {},
    create: {
      name: 'TRIANGLE BLACK',
      nameAr: 'ترايانجل بلاك',
      slug: 'triangle-black',
      domain: 'triangleblack.com',
      isActive: true,
    },
  });

  // ── 2. System Roles (all 4 portals) ──────────────────────────────
  const roles = [
    { name: 'ADMIN', description: 'Full system access across all portals' },
    { name: 'MANAGEMENT', description: 'Management access with reports and approvals' },
    { name: 'SALES', description: 'Sales pipeline, proposals, and site visits' },
    { name: 'PROCUREMENT', description: 'Procurement and vendor management' },
    { name: 'PROJECT_MANAGER', description: 'Project execution management' },
    { name: 'SITE_ENGINEER', description: 'Site engineering and daily reports' },
    { name: 'HOTEL_USER', description: 'Hotel portal access — view work orders and documents' },
    { name: 'VENDOR_USER', description: 'Vendor portal access — submit quotes and track POs' },
    { name: 'VIEWER', description: 'Read-only access across all modules' },
  ];

  for (const role of roles) {
    await prisma.role.upsert({
      where: { name_organizationId: { name: role.name, organizationId: org.id } },
      update: {},
      create: { ...role, organizationId: org.id, isSystem: true },
    });
  }

  // ── 3. Permissions (core + new modules) ──────────────────────────
  const resources = [
    // Original modules
    'hotels', 'contacts', 'partner-requests', 'site-visits',
    'opportunities', 'proposals', 'projects', 'procurement',
    'vendors', 'emergency', 'contracts', 'documents',
    'analytics', 'assistant', 'users', 'roles', 'audit',
    // New V16 modules
    'hotel-intelligence', 'warranty', 'drawing-intelligence',
    'knowledge-hub', 'guest-protection', 'relationships',
    'margin-intelligence', 'search', 'proposal-templates',
    'inspections', 'handover', 'opportunity-radar',
  ];
  const actions = ['create', 'read', 'update', 'delete'];

  let permissionCount = 0;
  for (const resource of resources) {
    for (const action of actions) {
      await prisma.permission.upsert({
        where: { name: `${resource}:${action}` },
        update: {},
        create: {
          name: `${resource}:${action}`,
          resource,
          action,
          description: `${action.charAt(0).toUpperCase() + action.slice(1)} ${resource}`,
        },
      });
      permissionCount++;
    }
  }

  // ── 4. Admin User (with portal field) ────────────────────────────
  const bcrypt = await import('bcryptjs');
  const passwordHash = await bcrypt.hash('Admin@123', 12);

  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@triangleblack.com' },
    update: {},
    create: {
      email: 'admin@triangleblack.com',
      passwordHash,
      name: 'System Admin',
      organizationId: org.id,
      portal: 'operations',
      isActive: true,
    },
  });

  // ── 5. Assign admin role + all permissions ───────────────────────
  const adminRole = await prisma.role.findFirst({
    where: { name: 'ADMIN', organizationId: org.id },
  });

  if (adminRole) {
    await prisma.userRole.upsert({
      where: { userId_roleId: { userId: adminUser.id, roleId: adminRole.id } },
      update: {},
      create: { userId: adminUser.id, roleId: adminRole.id },
    });

    const allPermissions = await prisma.permission.findMany();
    for (const perm of allPermissions) {
      await prisma.rolePermission.upsert({
        where: { roleId_permissionId: { roleId: adminRole.id, permissionId: perm.id } },
        update: {},
        create: { roleId: adminRole.id, permissionId: perm.id },
      });
    }
  }

  // ── 6. Sample Proposal Templates ─────────────────────────────────
  const templates = [
    {
      name: 'HVAC Replacement Proposal',
      projectType: 'HVAC',
      description: 'Standard template for HVAC system replacement projects in hospitality environments.',
      executiveSummary:
        'TRIANGLE BLACK proposes a comprehensive HVAC replacement solution tailored for your property. Our approach minimises guest disruption while delivering energy-efficient, code-compliant systems backed by industry-leading warranties.',
      scopeOfWork:
        '1. Site survey and load calculation\n2. Dismantling of existing HVAC units\n3. Installation of new energy-efficient units\n4. Ductwork modification as required\n5. Controls integration with BMS\n6. Commissioning and performance testing',
      methodStatement:
        'All works shall be carried out in phases to minimise guest impact. Noise-generating activities restricted to 10:00–16:00. Dust containment barriers erected per our Guest Protection Protocol.',
      guestProtection: {
        guestImpact: 'LOW',
        noise: 'MEDIUM',
        dust: 'LOW',
        odor: 'LOW',
        shutdown: false,
        mitigation: [
          'Phased installation per floor/wing',
          'Acoustic barriers during cutting operations',
          'HEPA filtration on demolition zones',
          'Guest notification 48h in advance',
        ],
      },
      assumptions:
        '- Existing electrical infrastructure can support new units\n- Access to mechanical rooms available 24/7\n- Hotel provides as-built drawings',
      exclusions:
        '- Structural modifications\n- Electrical panel upgrades\n- Building Management System reprogramming',
      commercialTerms: {
        paymentTerms: '30% advance, 40% mid-progress, 30% upon completion',
        validityDays: 30,
        warrantyMonths: 24,
        currency: 'SAR',
      },
    },
    {
      name: 'Electrical Systems Upgrade',
      projectType: 'ELECTRICAL',
      description: 'Template for electrical distribution panel upgrades and rewiring in hotel properties.',
      executiveSummary:
        'This proposal covers a full electrical upgrade to meet current Saudi Arabia SEC/SBC standards, improve safety, and support increased load demands from modern hospitality operations.',
      scopeOfWork:
        '1. Load analysis and single-line diagram update\n2. Main distribution panel replacement\n3. Sub-panel installations per floor\n4. Emergency lighting and fire alarm integration\n5. Cable tray and conduit routing\n6. Testing and certification',
      methodStatement:
        'Work executed in building sections. Temporary power supplies arranged for each section before cut-over. All live work prohibited — full isolation procedures enforced.',
      assumptions:
        '- Existing cable routes accessible\n- Temporary power for each zone agreed with hotel engineering',
      exclusions:
        '- Generator replacement\n- UPS systems\n- Low-voltage data cabling',
    },
    {
      name: 'Plumbing & Water Systems Proposal',
      projectType: 'PLUMBING',
      description: 'Template for hotel plumbing system renovation including water supply, drainage, and hot water systems.',
      executiveSummary:
        'Comprehensive plumbing renovation designed for zero-downtime guest experience. Includes water-saving fixtures, hot water recirculation optimisation, and leak detection systems.',
      scopeOfWork:
        '1. Water supply pipe replacement (PPR/Copper)\n2. Drainage system overhaul\n3. Hot water recirculation system\n4. Water-saving fixture installation\n5. Leak detection sensors\n6. Hydrostatic testing',
      methodStatement:
        'Room-by-room approach. Each room out of service for maximum 8 hours. Pre-fabricated assemblies used off-site to minimise in-room work duration.',
    },
    {
      name: 'Waterproofing & Envelope Proposal',
      projectType: 'WATERPROOFING',
      description: 'Proposal template for building envelope waterproofing — roofs, terraces, wet areas, and below-grade structures.',
      executiveSummary:
        'Specialised waterproofing solution using premium membrane systems with extended warranties. Prevents water ingress that causes structural damage and guest complaints in hospitality environments.',
      scopeOfWork:
        '1. Surface preparation and repair\n2. Primer application\n3. Membrane system installation\n4. Protection layer\n5. Drainage system review\n6. Flood testing and quality assurance',
      methodStatement:
        'Weather-dependent works. Minimum 48h dry forecast required for membrane application. Access via external scaffolding — no guest area disruption expected.',
      assumptions:
        '- Scaffolding permit obtained by hotel\n- Roof areas cleared of MEP equipment obstruction',
    },
    {
      name: 'Hotel Renovation & Fit-Out',
      projectType: 'RENOVATION',
      description: 'Master template for full or partial hotel renovation including FF&E, finishes, and MEP coordination.',
      executiveSummary:
        'End-to-end renovation management by TRIANGLE BLACK. From design coordination through construction, FF&E procurement, and final handover — all while maintaining guest operations.',
      scopeOfWork:
        '1. Demolition and strip-out\n2. MEP rough-in modifications\n3. Finishes (flooring, walls, ceilings)\n4. Joinery and millwork\n5. FF&E supply and installation\n6. Snagging and handover',
      methodStatement:
        'Floor-by-floor phasing. Minimum 30% rooms available at all times. Noise, dust, and vibration monitoring with automatic shutdown triggers.',
      guestProtection: {
        guestImpact: 'HIGH',
        noise: 'HIGH',
        dust: 'MEDIUM',
        odor: 'MEDIUM',
        shutdown: false,
        mitigation: [
          'Dedicated construction hoist',
          'Floor isolation barriers',
          'Negative air pressure in work zones',
          'Real-time noise monitoring',
          'Guest relocation protocol for adjacent rooms',
        ],
      },
    },
  ];

  for (const tpl of templates) {
    await prisma.proposalTemplate.upsert({
      where: { id: 'tpl-' + tpl.projectType.toLowerCase() },
      update: {},
      create: {
        id: 'tpl-' + tpl.projectType.toLowerCase(),
        organizationId: org.id,
        ...tpl,
        isActive: true,
        createdBy: adminUser.id,
      },
    });
  }

  // ── 7. Sample Vendor Alternatives ────────────────────────────────
  const alternatives = [
    { category: 'CHILLER', name: 'Carrier 30XA Air-Cooled Chiller', specification: '500 TR, 415V, 50Hz', unitPrice: 285000, leadTimeDays: 90, quality: 'PREMIUM' },
    { category: 'CHILLER', name: 'York YVWA Water-Cooled Chiller', specification: '500 TR, 380V, 50Hz', unitPrice: 310000, leadTimeDays: 100, quality: 'PREMIUM' },
    { category: 'CHILLER', name: 'Daikin Inverter Scroll Chiller', specification: '200 TR, 415V, 50Hz', unitPrice: 145000, leadTimeDays: 60, quality: 'STANDARD' },
    { category: 'AHU', name: 'Daikin AHU Custom Build', specification: '10000 CFM, VFD, DX coil', unitPrice: 42000, leadTimeDays: 45, quality: 'PREMIUM' },
    { category: 'AHU', name: 'SAMCO Standard AHU', specification: '10000 CFM, Belt drive', unitPrice: 28000, leadTimeDays: 30, quality: 'STANDARD' },
    { category: 'PANEL', name: 'Schneider PrismaSet G Distribution Board', specification: '3200A, 415V, Form 4b', unitPrice: 65000, leadTimeDays: 35, quality: 'PREMIUM' },
    { category: 'PANEL', name: 'ABB MNS Distribution Board', specification: '3200A, 415V, Form 4b', unitPrice: 62000, leadTimeDays: 40, quality: 'PREMIUM' },
    { category: 'WATERPROOFING', name: 'Sika RoofPro Waterproofing System', specification: 'SBS modified bitumen, 4mm', unitPrice: 85, leadTimeDays: 14, quality: 'PREMIUM' },
    { category: 'WATERPROOFING', name: 'BASF MasterSeal Membrane', specification: 'Polyurethane liquid applied', unitPrice: 95, leadTimeDays: 14, quality: 'PREMIUM' },
    { category: 'WATERPROOFING', name: 'GCP Applied Tech Bituthene', specification: 'Self-adhesive, 2mm', unitPrice: 65, leadTimeDays: 7, quality: 'STANDARD' },
  ];

  for (const alt of alternatives) {
    await prisma.vendorAlternative.create({
      data: {
        organizationId: org.id,
        ...alt,
        isActive: true,
        createdBy: adminUser.id,
      },
    });
  }

  // ── Summary ──────────────────────────────────────────────────────
  console.log('Seed completed successfully.');
  console.log(`Organization: ${org.name} (${org.id})`);
  console.log(`Admin User: admin@triangleblack.com (portal: operations)`);
  console.log(`Roles created: ${roles.length}`);
  console.log(`Permissions created: ${permissionCount}`);
  console.log(`Proposal templates created: ${templates.length}`);
  console.log(`Vendor alternatives created: ${alternatives.length}`);
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());