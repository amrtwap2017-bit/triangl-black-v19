import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD, APP_INTERCEPTOR, APP_FILTER } from '@nestjs/core';

// Configuration
import configuration from './infrastructure/config/configuration';
import { validateEnv } from '@triangleblack/config';

// Validate environment at module load time — fail fast
validateEnv();

// Infrastructure Modules
import { PrismaModule } from './infrastructure/prisma/prisma.module';
import { CacheModule } from './infrastructure/cache/cache.module';
import { QueueModule } from './infrastructure/queue/queue.module';
import { StorageModule } from './infrastructure/storage/storage.module';
import { MailModule } from './infrastructure/mail/mail.module';
import { SecurityModule } from './infrastructure/security/security.module';
import { LoggerModule } from './infrastructure/logging/logger.module';
import { MonitoringModule } from './infrastructure/monitoring/monitoring.module';
import { SearchModule } from './infrastructure/search/search.module';

// Events
import { EventBusModule } from './events/event-bus.module';

// Common - Guards
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { RolesGuard } from './common/guards/roles.guard';
import { PermissionsGuard } from './common/guards/permissions.guard';
import { TenantGuard } from './common/guards/tenant.guard';

// Common - Interceptors
import { TransformInterceptor } from './common/interceptors/transform.interceptor';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor';
import { AuditInterceptor } from './common/interceptors/audit.interceptor';

// Common - Filters
import { HttpExceptionFilter } from './common/filters/http-exception.filter';
import { PrismaExceptionFilter } from './common/filters/prisma-exception.filter';

// Feature Modules
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { OrganizationsModule } from './modules/organizations/organizations.module';
import { RolesModule } from './modules/roles/roles.module';
import { PermissionsModule } from './modules/permissions/permissions.module';
import { HotelsModule } from './modules/hotels/hotels.module';
import { ContactsModule } from './modules/contacts/contacts.module';
import { PartnerRequestsModule } from './modules/partner-requests/partner-requests.module';
import { SiteVisitsModule } from './modules/site-visits/site-visits.module';
import { OpportunitiesModule } from './modules/opportunities/opportunities.module';
import { ProposalsModule } from './modules/proposals/proposals.module';
import { ProjectsModule } from './modules/projects/projects.module';
import { ProcurementModule } from './modules/procurement/procurement.module';
import { VendorsModule } from './modules/vendors/vendors.module';
import { EmergencyModule } from './modules/emergency/emergency.module';
import { ContractsModule } from './modules/contracts/contracts.module';
import { DocumentsModule } from './modules/documents/documents.module';
import { AnalyticsModule } from './modules/analytics/analytics.module';
import { AssistantModule } from './modules/assistant/assistant.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { AuditModule } from './modules/audit/audit.module';
import { HealthModule } from './modules/health/health.module';
import { AdministrationModule } from './modules/administration/administration.module';
import { HotelIntelligenceModule } from './modules/hotel-intelligence/hotel-intelligence.module';
import { WarrantyModule } from './modules/warranty/warranty.module';
import { DrawingIntelligenceModule } from './modules/drawing-intelligence/drawing-intelligence.module';
import { KnowledgeHubModule } from './modules/knowledge-hub/knowledge-hub.module';
import { GuestProtectionModule } from './modules/guest-protection/guest-protection.module';
import { RelationshipsModule } from './modules/relationships/relationships.module';
import { MarginIntelligenceModule } from './modules/margin-intelligence/margin-intelligence.module';
import { SearchModule } from './modules/search/search.module';
import { ProposalTemplatesModule } from './modules/proposal-templates/proposal-templates.module';
import { InspectionsModule } from './modules/inspections/inspections.module';
import { HandoverModule } from './modules/handover/handover.module';
import { OpportunityRadarModule } from './modules/opportunity-radar/opportunity-radar.module';
import { RfqModule } from './modules/rfq/rfq.module';
import { ResourcePlanningModule } from './modules/resource-planning/resource-planning.module';
import { CapexIntelligenceModule } from './modules/capex-intelligence/capex-intelligence.module';
import { ForecastingModule } from './modules/forecasting/forecasting.module';
import { HotelDigitalTwinModule } from './modules/hotel-digital-twin/hotel-digital-twin.module';

@Module({
  imports: [
    // ── Configuration ──────────────────────────────────────────────
    ConfigModule.forRoot({
      isGlobal: true,
      load: [configuration],
      envFilePath: ['.env.local', '.env'],
      validationSchema: undefined, // handled by validateEnv()
    }),

    // ── Rate Limiting ──────────────────────────────────────────────
    ThrottlerModule.forRoot([
      { name: 'short', ttl: 1000, limit: 20 },
      { name: 'medium', ttl: 10000, limit: 100 },
      { name: 'long', ttl: 60000, limit: 500 },
    ]),

    // ── Infrastructure ───────────────────────────────────────────────
    PrismaModule,
    CacheModule,
    QueueModule,
    StorageModule,
    MailModule,
    SecurityModule,
    LoggerModule,
    MonitoringModule,
    SearchModule,

    // ── Events ─────────────────────────────────────────────────────
    EventBusModule,

    // ── Feature Modules ────────────────────────────────────────────
    AuthModule,
    UsersModule,
    OrganizationsModule,
    RolesModule,
    PermissionsModule,
    HotelsModule,
    ContactsModule,
    PartnerRequestsModule,
    SiteVisitsModule,
    OpportunitiesModule,
    ProposalsModule,
    ProjectsModule,
    ProcurementModule,
    VendorsModule,
    EmergencyModule,
    ContractsModule,
    DocumentsModule,
    AnalyticsModule,
    AssistantModule,
    NotificationsModule,
    AuditModule,
    HealthModule,
    AdministrationModule,
    HotelIntelligenceModule,
    WarrantyModule,
    DrawingIntelligenceModule,
    KnowledgeHubModule,
    GuestProtectionModule,
    RelationshipsModule,
    MarginIntelligenceModule,
    ProposalTemplatesModule,
    InspectionsModule,
    HandoverModule,
    OpportunityRadarModule,
    RfqModule,
    ResourcePlanningModule,
    CapexIntelligenceModule,
    ForecastingModule,
    HotelDigitalTwinModule,
  ],
  providers: [
    // ── Global Guards (order matters) ────────────────────────────────
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: TenantGuard },
    { provide: APP_GUARD, useClass: RolesGuard },
    { provide: APP_GUARD, useClass: PermissionsGuard },

    // ── Global Interceptors ─────────────────────────────────────────
    { provide: APP_INTERCEPTOR, useClass: LoggingInterceptor },
    { provide: APP_INTERCEPTOR, useClass: TransformInterceptor },
    { provide: APP_INTERCEPTOR, useClass: AuditInterceptor },

    // ── Global Exception Filters ────────────────────────────────────
    { provide: APP_FILTER, useClass: HttpExceptionFilter },
    { provide: APP_FILTER, useClass: PrismaExceptionFilter },
  ],
})
export class AppModule {}
