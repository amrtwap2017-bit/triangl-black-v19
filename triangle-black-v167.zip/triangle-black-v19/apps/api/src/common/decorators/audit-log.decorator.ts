import { SetMetadata } from '@nestjs/common';

/**
 * Decorator to mark an endpoint for audit logging.
 * Usage: @AuditLog('CREATE_USER')
 */
export const AuditLog = (action: string) => SetMetadata('auditAction', action);
