import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export interface PaginationParams {
  page: number;
  limit: number;
}

/**
 * Parameter decorator that extracts pagination parameters from query string.
 * Defaults: page=1, limit=20, maxLimit=100
 * Usage: @Pagination() pagination: PaginationParams
 */
export const Pagination = createParamDecorator(
  (data: { maxLimit?: number } | undefined, ctx: ExecutionContext): PaginationParams => {
    const request = ctx.switchToHttp().getRequest();
    const query = request.query;

    const maxLimit = data?.maxLimit ?? 100;

    const page = Math.max(1, parseInt(query.page ?? '1', 10) || 1);
    const rawLimit = parseInt(query.limit ?? '20', 10) || 20;
    const limit = Math.min(Math.max(1, rawLimit), maxLimit);

    return { page, limit };
  },
);
