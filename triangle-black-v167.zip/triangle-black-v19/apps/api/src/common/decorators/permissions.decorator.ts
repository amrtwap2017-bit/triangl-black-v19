import { SetMetadata } from '@nestjs/common';

/**
 * Decorator to require specific permissions for an endpoint.
 * Usage: @RequirePermissions('users:create', 'users:update')
 */
export const RequirePermissions = (...permissions: string[]) =>
  SetMetadata('permissions', permissions);
