import { SetMetadata } from '@nestjs/common';

/**
 * Mark an endpoint as public (bypasses JWT authentication).
 * Usage: @Public()
 */
export const Public = () => SetMetadata('isPublic', true);
