import { SetMetadata } from '@nestjs/common';

/**
 * Decorator to restrict access to users with specific roles.
 * Usage: @Roles('ADMIN', 'SUPER_ADMIN')
 */
export const Roles = (...roles: string[]) => SetMetadata('roles', roles);
