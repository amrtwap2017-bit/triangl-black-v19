import { IsOptional, IsNumber, IsString, Min, IsBoolean } from 'class-validator';

export class PaginationMetaDto {
  @IsNumber()
  @Min(0)
  total: number;

  @IsNumber()
  @Min(1)
  page: number;

  @IsNumber()
  @Min(1)
  limit: number;

  @IsNumber()
  @Min(0)
  totalPages: number;
}

export class ApiResponseDto<T> {
  @IsBoolean()
  success: boolean;

  @IsOptional()
  data?: T;

  @IsOptional()
  @IsString()
  message?: string;

  @IsOptional()
  meta?: PaginationMetaDto;

  constructor(partial: Partial<ApiResponseDto<T>>) {
    Object.assign(this, partial);
  }

  static success<T>(data: T, message?: string, meta?: PaginationMetaDto): ApiResponseDto<T> {
    return new ApiResponseDto<T>({ success: true, data, message, meta });
  }

  static error<T = unknown>(message: string, data?: T): ApiResponseDto<T> {
    return new ApiResponseDto<T>({ success: false, message, data });
  }
}

/**
 * Helper function to create a standardized success response.
 */
export function createResponse<T>(data: T, message?: string): ApiResponseDto<T> {
  return new ApiResponseDto<T>({ success: true, data, message });
}

/**
 * Helper function to create a standardized paginated response.
 * Supports both (data, meta) and (data, total, page, limit) signatures.
 */
export function createPaginatedResponse<T>(
  data: T[],
  totalOrMeta: PaginationMetaDto | number,
  page?: number,
  limit?: number,
): ApiResponseDto<T[]> {
  let meta: PaginationMetaDto;

  if (typeof totalOrMeta === 'number') {
    meta = {
      total: totalOrMeta,
      page: page ?? 1,
      limit: limit ?? 20,
      totalPages: Math.ceil(totalOrMeta / (limit ?? 20)),
    };
  } else {
    meta = totalOrMeta;
  }

  return new ApiResponseDto<T[]>({ success: true, data, meta });
}
