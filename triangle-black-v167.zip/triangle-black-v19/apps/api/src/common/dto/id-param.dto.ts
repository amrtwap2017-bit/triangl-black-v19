import { IsString, IsUUID } from 'class-validator';

export class IdParamDto {
  @IsString()
  @IsUUID('4')
  id: string;
}
