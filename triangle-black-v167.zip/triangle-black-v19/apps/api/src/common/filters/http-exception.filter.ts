import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';

@Catch(HttpException)
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: HttpException, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();
    const status = exception.getStatus();

    const exceptionResponse = exception.getResponse();
    const message =
      typeof exceptionResponse === 'string'
        ? exceptionResponse
        : (exceptionResponse as Record<string, unknown>).message ?? exception.message;

    // Handle class-validator array of errors
    const errors = Array.isArray(message) ? message : [message];

    const body = {
      success: false,
      statusCode: status,
      message: Array.isArray(message) ? 'Validation failed' : (message as string),
      errors: Array.isArray(message) ? errors : undefined,
      timestamp: new Date().toISOString(),
      path: request.url,
    };

    this.logger.warn(
      `HTTP ${status} ${request.method} ${request.url} - ${JSON.stringify(errors)}`,
    );

    response.status(status).json(body);
  }
}
