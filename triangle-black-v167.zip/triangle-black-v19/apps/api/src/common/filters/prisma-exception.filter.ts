import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { Response } from 'express';

@Catch(Prisma.PrismaClientKnownRequestError)
export class PrismaExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(PrismaExceptionFilter.name);

  catch(exception: Prisma.PrismaClientKnownRequestError, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'An unexpected database error occurred';
    let errors: string[] | undefined;

    switch (exception.code) {
      case 'P2002': {
        // Unique constraint violation
        status = HttpStatus.CONFLICT;
        const target = (exception.meta?.target as string[]) ?? [];
        message = `A record with this ${target.join(', ')} already exists`;
        errors = target;
        break;
      }
      case 'P2025': {
        // Record not found
        status = HttpStatus.NOT_FOUND;
        message = 'The requested record was not found';
        break;
      }
      case 'P2003': {
        // Foreign key constraint violation
        status = HttpStatus.BAD_REQUEST;
        const field = (exception.meta?.field_name as string) ?? 'related resource';
        message = `Referenced ${field} does not exist or is invalid`;
        break;
      }
      case 'P2000': {
        // Value too long for column
        status = HttpStatus.BAD_REQUEST;
        message = 'The provided value is too long for the field';
        break;
      }
      case 'P2011': {
        // Null constraint violation
        status = HttpStatus.BAD_REQUEST;
        const nullField = (exception.meta?.constraint as string) ?? 'field';
        message = `The field "${nullField}" is required and cannot be null`;
        break;
      }
      case 'P2012': {
        // Missing a required value
        status = HttpStatus.BAD_REQUEST;
        message = 'A required field is missing';
        break;
      }
      case 'P2013': {
        // Missing required argument
        status = HttpStatus.BAD_REQUEST;
        const missingFields = (exception.meta?.fields as string[]) ?? [];
        message = `Missing required fields: ${missingFields.join(', ')}`;
        errors = missingFields;
        break;
      }
      case 'P2021': {
        // Table does not exist
        status = HttpStatus.INTERNAL_SERVER_ERROR;
        message = 'Internal database configuration error';
        break;
      }
      case 'P2024': {
        // Query timeout
        status = HttpStatus.REQUEST_TIMEOUT;
        message = 'The database query timed out. Please try again';
        break;
      }
      default: {
        this.logger.error(
          `Unhandled Prisma error [${exception.code}]: ${exception.message}`,
          exception.stack,
        );
      }
    }

    this.logger.warn(
      `Prisma ${exception.code} on ${request.method} ${request.url}: ${message}`,
    );

    response.status(status).json({
      success: false,
      statusCode: status,
      message,
      errors,
      timestamp: new Date().toISOString(),
      path: request.url,
    });
  }
}
