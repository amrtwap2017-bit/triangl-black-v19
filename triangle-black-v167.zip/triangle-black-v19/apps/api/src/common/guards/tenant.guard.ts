import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';

/**
 * Guard that ensures the authenticated user belongs to an organization.
 * Extracts organizationId from the user and verifies it exists.
 */
@Injectable()
export class TenantGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('Authentication required');
    }

    if (!user.organizationId) {
      throw new ForbiddenException(
        'User is not associated with any organization. Please contact support.',
      );
    }

    // Attach organizationId to request for downstream use
    request.organizationId = user.organizationId;

    return true;
  }
}
