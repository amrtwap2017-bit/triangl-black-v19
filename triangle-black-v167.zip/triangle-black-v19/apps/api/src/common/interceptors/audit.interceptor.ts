import { Injectable, Logger, ExecutionContext } from '@nestjs/common';
import { NestInterceptor, CallHandler } from '@nestjs/common';
import { Request } from 'express';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { JwtPayload } from '../interfaces';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

/**
 * Extend Express Request with our custom properties attached by guards/auth.
 */
interface AuthenticatedRequest extends Request {
  user?: JwtPayload;
  auditAction?: string;
}

/**
 * Interceptor that creates audit log entries for mutating operations (POST, PUT, PATCH, DELETE).
 */
@Injectable()
export class AuditInterceptor implements NestInterceptor {
  private readonly logger = new Logger(AuditInterceptor.name);

  constructor(private readonly prisma: PrismaService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();
    const { method, url, user, body, auditAction } = request;
    const mutatingMethods = ['POST', 'PUT', 'PATCH', 'DELETE'];

    if (!mutatingMethods.includes(method)) {
      return next.handle();
    }

    const auditActionValue = auditAction ?? `${method} ${url}`;
    const startTime = Date.now();

    return next.handle().pipe(
      tap(async () => {
        try {
          // Only log if user is authenticated
          if (user && user.sub) {
            await this.prisma.auditLog.create({
              data: {
                action: auditActionValue,
                resource: this.extractEntityType(url),
                resourceId: this.extractEntityId(url),
                userId: user.sub,
                organizationId: user.organizationId ?? null,
                metadata: JSON.parse(
                  JSON.stringify({
                    method,
                    url,
                    body: this.sanitizeBody(body),
                    timestamp: new Date().toISOString(),
                    duration: Date.now() - startTime,
                  }),
                ),
              },
            });
          }
        } catch (error) {
          this.logger.error(
            `Failed to create audit log: ${error instanceof Error ? error.message : String(error)}`,
          );
          // Don't throw - audit logging should not break requests
        }
      }),
    );
  }

  private extractEntityType(url: string): string {
    const parts = url.split('/').filter(Boolean);
    // Skip 'api' and 'v1' prefix
    const entityIndex = parts[0] === 'api' && parts[1] === 'v1' ? 2 : 0;
    return parts[entityIndex] ?? 'unknown';
  }

  private extractEntityId(url: string): string | null {
    const parts = url.split('/').filter(Boolean);
    const idIndex = parts[0] === 'api' && parts[1] === 'v1' ? 3 : 1;
    const potentialId = parts[idIndex];
    // Check if it looks like a UUID
    if (
      potentialId &&
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
        potentialId,
      )
    ) {
      return potentialId;
    }
    return null;
  }

  private sanitizeBody(body: Record<string, unknown>): Record<string, unknown> {
    if (!body || typeof body !== 'object') return {};

    const sanitized: Record<string, unknown> = {};
    const sensitiveFields = ['password', 'passwordHash', 'token', 'secret', 'creditCard'];

    for (const [key, value] of Object.entries(body)) {
      if (sensitiveFields.some((f) => key.toLowerCase().includes(f.toLowerCase()))) {
        sanitized[key] = '[REDACTED]';
      } else {
        sanitized[key] = value;
      }
    }

    return sanitized;
  }
}
