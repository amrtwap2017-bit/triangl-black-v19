/**
 * Generate a sequential number with a prefix.
 * @param prefix - The prefix string (e.g., 'PR', 'SV')
 * @param counter - The current counter value (defaults to random 4-digit number)
 * @param digits - Number of digits to pad (default: 4)
 * @returns Formatted string like "PR-0001"
 */
export function generateSequentialNumber(
  prefix: string,
  counter?: number,
  digits: number = 4,
): string {
  const num = counter ?? Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${String(num).padStart(digits, '0')}`;
}

/**
 * Basic HTML sanitization to prevent XSS attacks.
 * Removes script tags, event handlers, and dangerous attributes.
 * For production, consider using a library like DOMPurify.
 *
 * @param text - The text to sanitize
 * @returns Sanitized text
 */
export function sanitizeHtml(text: string): string {
  if (!text) return '';

  return text
    // Remove script tags
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    // Remove event handlers
    .replace(/\s*on\w+\s*=\s*(['"]?)[^'"]*\1/gi, '')
    // Remove javascript: URLs
    .replace(/javascript\s*:\s*/gi, '')
    // Remove vbscript: URLs
    .replace(/vbscript\s*:\s*/gi, '')
    // Remove data: URLs (potential XSS)
    .replace(/data\s*:\s*text\/html/gi, '')
    // Basic HTML entity encoding for special chars
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;');
}

/**
 * Calculate pagination values for Prisma queries.
 * @param page - Current page (1-based)
 * @param limit - Items per page
 * @param total - Total number of items
 * @returns Object with skip, take, and totalPages
 */
export function calculatePagination(
  page: number,
  limit: number,
  total?: number,
): { skip: number; take: number; totalPages: number } {
  const safePage = Math.max(1, page);
  const safeLimit = Math.max(1, Math.min(limit, 100));
  const totalPages = total !== undefined ? Math.ceil(total / safeLimit) : 0;

  return {
    skip: (safePage - 1) * safeLimit,
    take: safeLimit,
    totalPages,
  };
}
