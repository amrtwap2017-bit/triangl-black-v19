import { Module, Global, Injectable } from '@nestjs/common';
import { EventEmitter } from 'events';

@Injectable()
export class EventBusService extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(20);
  }
}

/**
 * Module that provides an event bus for domain events.
 * Uses Node.js built-in EventEmitter for lightweight pub/sub.
 * Upgrade to @nestjs/event-emitter when more features are needed.
 */
@Global()
@Module({
  providers: [EventBusService],
  exports: [EventBusService],
})
export class EventBusModule {}
