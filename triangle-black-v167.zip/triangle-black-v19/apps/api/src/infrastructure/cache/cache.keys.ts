/**
 * Centralized cache key registry for TRIANGLE BLACK V16.
 *
 * All cache keys MUST go through these helpers so that:
 *  1. Keys are namespaced by domain → no collisions.
 *  2. The orgId is always embedded → tenant isolation.
 *  3. TTL values are consistent and discoverable in one place.
 */

// ─── Cache Key Builders ────────────────────────────────────────────────

export const CacheKeys = {
  // Auth & Permissions
  USER_PERMISSIONS: (userId: string, orgId: string) =>
    `user:${orgId}:${userId}:permissions`,
  USER_ROLES: (userId: string, orgId: string) =>
    `user:${orgId}:${userId}:roles`,

  // Hotels
  HOTEL: (id: string, orgId: string) => `hotel:${orgId}:${id}`,
  HOTEL_RELATIONSHIP: (hotelId: string, orgId: string) =>
    `hotel:${orgId}:${hotelId}:relationship`,
  HOTEL_ASSETS: (hotelId: string, orgId: string) =>
    `hotel:${orgId}:${hotelId}:assets`,
  HOTELS_LIST: (orgId: string, page: number) =>
    `hotels:${orgId}:page:${page}`,

  // Dashboard
  DASHBOARD_SUMMARY: (orgId: string) => `dashboard:${orgId}:summary`,
  DASHBOARD_KPI: (orgId: string) => `dashboard:${orgId}:kpi`,
  PIPELINE_DATA: (orgId: string) => `dashboard:${orgId}:pipeline`,

  // Analytics
  REVENUE_ANALYTICS: (orgId: string, period: string) =>
    `analytics:${orgId}:revenue:${period}`,
  MARGIN_ANALYTICS: (orgId: string, period: string) =>
    `analytics:${orgId}:margin:${period}`,
  EXECUTIVE_SUMMARY: (orgId: string) =>
    `analytics:${orgId}:executive-summary`,

  // Vendor
  VENDOR_SCORECARD: (vendorId: string, orgId: string) =>
    `vendor:${orgId}:${vendorId}:scorecard`,
  VENDOR_ALTERNATIVES: (category: string, orgId: string) =>
    `vendor:${orgId}:alternatives:${category}`,

  // Search
  SEARCH_RESULTS: (query: string, scope: string) =>
    `search:${scope}:${query}:results`,

  // Knowledge
  KNOWLEDGE_CATEGORIES: (orgId: string) =>
    `knowledge:${orgId}:categories`,
  KNOWLEDGE_ARTICLE: (id: string, orgId: string) =>
    `knowledge:${orgId}:${id}`,

  // Proposal
  PROPOSAL_TEMPLATE: (id: string, orgId: string) =>
    `proposal:${orgId}:template:${id}`,
} as const;

// ─── TTL Constants (seconds) ───────────────────────────────────────────

export const CacheTTL = {
  SHORT: 60,           // 1 minute
  MEDIUM: 300,         // 5 minutes
  LONG: 900,           // 15 minutes
  VERY_LONG: 3600,     // 1 hour
  DASHBOARD: 120,      // 2 minutes
  PERMISSIONS: 1800,   // 30 minutes
  ANALYTICS: 600,      // 10 minutes
} as const;