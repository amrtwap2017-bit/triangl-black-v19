import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { Redis as RedisType, default as RedisCtor } from 'ioredis';
import { CacheKeys, CacheTTL } from './cache.keys';

// Attempt to import ioredis — will be undefined if not installed
let RedisConstructor: typeof RedisCtor | undefined;
try {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  RedisConstructor = require('ioredis');
} catch {
  RedisConstructor = undefined;
}

interface CacheEntry<T = unknown> {
  data: T;
  expiresAt: number | null;
}

@Injectable()
export class CacheService implements OnModuleDestroy {
  private readonly logger = new Logger(CacheService.name);
  private readonly cache = new Map<string, CacheEntry>();
  private readonly defaultTtlSeconds = CacheTTL.MEDIUM;
  private cleanupInterval: ReturnType<typeof setInterval> | null = null;

  private redis: RedisType | null = null;
  private useRedis = false;

  constructor() {
    this.initRedis();

    // Periodically clean up expired entries (every 60 s) — needed for in-memory fallback
    this.cleanupInterval = setInterval(() => this.cleanup(), 60_000);
  }

  // ─── Redis Initialization ───────────────────────────────────────────

  private initRedis(): void {
    if (!RedisConstructor) {
      this.logger.warn('ioredis not available — using in-memory Map cache as fallback');
      return;
    }

    const host = process.env.REDIS_HOST ?? 'localhost';
    const port = parseInt(process.env.REDIS_PORT ?? '6379', 10);
    const password = process.env.REDIS_PASSWORD ?? undefined;

    try {
      this.redis = new RedisConstructor!({
        host,
        port,
        password,
        // Lazy connect so boot doesn't hang if Redis is down
        lazyConnect: true,
        retryStrategy: (times: number) => {
          if (times > 3) {
            this.logger.warn(`Redis connection failed after ${times} retries — falling back to in-memory cache`);
            this.useRedis = false;
            return null; // stop retrying
          }
          return Math.min(times * 500, 2000);
        },
      });

      this.redis.on('connect', () => {
        this.useRedis = true;
        this.logger.log(`Redis connected at ${host}:${port}`);
      });

      this.redis.on('error', (err: Error) => {
        this.logger.error(`Redis error: ${err.message}`);
        this.useRedis = false;
      });

      this.redis.on('close', () => {
        this.useRedis = false;
        this.logger.warn('Redis connection closed — falling back to in-memory cache');
      });

      // Attempt initial connection
      this.redis.connect().catch((err: Error) => {
        this.logger.error(`Failed to connect to Redis: ${err.message}`);
        this.useRedis = false;
      });
    } catch (err) {
      this.logger.error(`Redis initialization failed: ${(err as Error).message} — using in-memory fallback`);
      this.useRedis = false;
    }
  }

  // ─── Public API ─────────────────────────────────────────────────────

  /**
   * Get a value from the cache. Returns null if not found or expired.
   */
  async get<T = unknown>(key: string): Promise<T | null> {
    if (this.useRedis && this.redis) {
      try {
        const raw = await this.redis.get(key);
        if (raw === null || raw === undefined) return null;
        return JSON.parse(raw) as T;
      } catch (err) {
        this.logger.error(`Redis GET error for key "${key}": ${(err as Error).message}`);
        // Fall back to in-memory
      }
    }

    const entry = this.cache.get(key);
    if (!entry) return null;

    if (entry.expiresAt !== null && Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    return entry.data as T;
  }

  /**
   * Set a value in the cache with an optional TTL in seconds.
   * Defaults to CacheTTL.MEDIUM (5 minutes).
   */
  async set<T = unknown>(key: string, data: T, ttlSeconds?: number): Promise<void> {
    const ttl = ttlSeconds ?? this.defaultTtlSeconds;

    if (this.useRedis && this.redis) {
      try {
        const serialized = JSON.stringify(data);
        if (ttl > 0) {
          await this.redis.set(key, serialized, 'EX', ttl);
        } else {
          await this.redis.set(key, serialized);
        }
        return;
      } catch (err) {
        this.logger.error(`Redis SET error for key "${key}": ${(err as Error).message}`);
        // Fall back to in-memory
      }
    }

    const expiresAt = ttl > 0 ? Date.now() + ttl * 1000 : null;
    this.cache.set(key, { data, expiresAt });
  }

  /**
   * Delete a single key from the cache.
   */
  async del(key: string): Promise<void> {
    if (this.useRedis && this.redis) {
      try {
        await this.redis.del(key);
        return;
      } catch (err) {
        this.logger.error(`Redis DEL error for key "${key}": ${(err as Error).message}`);
      }
    }

    this.cache.delete(key);
  }

  /**
   * Delete all keys that match the given pattern string.
   * With Redis, uses SCAN with MATCH for safe iteration over large key spaces.
   * With in-memory fallback, uses simple `includes`.
   */
  async delByPattern(pattern: string): Promise<void> {
    if (this.useRedis && this.redis) {
      try {
        // Use SCAN with MATCH to safely find matching keys
        const stream = this.redis.scanStream({
          match: `*${pattern}*`,
          count: 100,
        });

        const keys: string[] = [];
        stream.on('data', (resultKeys: string[]) => {
          keys.push(...resultKeys);
        });

        return new Promise<void>((resolve) => {
          stream.on('end', async () => {
            if (keys.length > 0) {
              try {
                await this.redis.del(...keys);
                this.logger.debug(`Redis: deleted ${keys.length} keys matching pattern "${pattern}"`);
              } catch (delErr) {
                this.logger.error(`Redis DEL error during pattern delete: ${(delErr as Error).message}`);
              }
            }
            resolve();
          });

          stream.on('error', (err: Error) => {
            this.logger.error(`Redis SCAN error for pattern "${pattern}": ${err.message}`);
            resolve();
          });
        });
      } catch (err) {
        this.logger.error(`Redis delByPattern error: ${(err as Error).message}`);
        // Fall through to in-memory cleanup
      }
    }

    // In-memory fallback
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }

  /**
   * Clear all cache entries.
   */
  async reset(): Promise<void> {
    if (this.useRedis && this.redis) {
      try {
        await this.redis.flushdb();
        this.logger.log('Redis cache flushed');
        return;
      } catch (err) {
        this.logger.error(`Redis FLUSHDB error: ${(err as Error).message}`);
      }
    }

    this.cache.clear();
    this.logger.log('Cache cleared');
  }

  // ─── Internal Helpers ──────────────────────────────────────────────

  /**
   * Remove all expired entries (in-memory only).
   */
  private cleanup(): void {
    const now = Date.now();
    let expiredCount = 0;

    for (const [key, entry] of this.cache.entries()) {
      if (entry.expiresAt !== null && now > entry.expiresAt) {
        this.cache.delete(key);
        expiredCount++;
      }
    }

    if (expiredCount > 0) {
      this.logger.debug(`Cleaned up ${expiredCount} expired cache entries`);
    }
  }

  /**
   * Stop the cleanup interval and disconnect Redis — call on module destroy.
   */
  onModuleDestroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }

    if (this.redis) {
      this.redis.disconnect();
      this.logger.log('Redis disconnected');
    }
  }
}
