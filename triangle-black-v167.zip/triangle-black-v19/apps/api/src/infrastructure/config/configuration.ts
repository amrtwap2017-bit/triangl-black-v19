import { registerAs } from '@nestjs/config';

export default registerAs('appConfig', () => ({
  port: parseInt(process.env.PORT ?? '3000', 10),
  database: {
    url: process.env.DATABASE_URL ?? 'postgresql://postgres:postgres@localhost:5432/triangleblack',
  },
  jwt: {
    secret: process.env.JWT_SECRET ?? 'changeme-jwt-secret',
    expiresIn: process.env.JWT_EXPIRES_IN ?? '15m',
    refreshSecret: process.env.JWT_REFRESH_SECRET ?? 'changeme-refresh-secret',
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN ?? '7d',
  },
  redis: {
    host: process.env.REDIS_HOST ?? 'localhost',
    port: parseInt(process.env.REDIS_PORT ?? '6379', 10),
  },
  storage: {
    driver: (process.env.STORAGE_DRIVER ?? 'local') as 'local' | 's3',
    localPath: process.env.STORAGE_LOCAL_PATH ?? './uploads',
  },
  smtp: {
    host: process.env.SMTP_HOST ?? 'localhost',
    port: parseInt(process.env.SMTP_PORT ?? '1025', 10),
    user: process.env.SMTP_USER ?? '',
    pass: process.env.SMTP_PASS ?? '',
    from: process.env.SMTP_FROM ?? 'noreply@triangleblack.com',
  },
  ai: {
    openaiApiKey: process.env.OPENAI_API_KEY ?? '',
    defaultModel: process.env.AI_DEFAULT_MODEL ?? 'gpt-4',
  },
  app: {
    url: process.env.APP_URL ?? 'http://localhost:3000',
    apiUrl: process.env.APP_API_URL ?? 'http://localhost:3000/api/v1',
    orgSlug: process.env.APP_ORG_SLUG ?? 'default',
  },
}));
