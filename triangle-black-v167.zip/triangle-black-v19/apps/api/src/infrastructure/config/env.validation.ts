/**
 * Environment validation using plain JS (no external deps).
 * Validates that critical environment variables are present.
 */
export interface ValidatedEnv {
  DATABASE_URL: string;
  JWT_SECRET: string;
  JWT_REFRESH_SECRET: string;
}

export function validateEnv(env: Record<string, string | undefined>): ValidatedEnv {
  const errors: string[] = [];

  const requiredVars: Record<string, string> = {
    DATABASE_URL: 'DATABASE_URL is required. Set it in your .env file.',
    JWT_SECRET: 'JWT_SECRET is required and must be at least 16 characters.',
    JWT_REFRESH_SECRET: 'JWT_REFRESH_SECRET is required and must be at least 16 characters.',
  };

  const validated: Partial<Record<string, string>> = {};

  for (const [key, message] of Object.entries(requiredVars)) {
    const value = env[key];
    if (!value || value.trim().length === 0) {
      errors.push(message);
    } else if (
      (key === 'JWT_SECRET' || key === 'JWT_REFRESH_SECRET') &&
      value.length < 16
    ) {
      errors.push(`${key} must be at least 16 characters long.`);
    } else {
      validated[key] = value;
    }
  }

  if (errors.length > 0) {
    throw new Error(
      `Environment validation failed:\n${errors.map((e) => `  - ${e}`).join('\n')}`,
    );
  }

  return {
    DATABASE_URL: validated.DATABASE_URL!,
    JWT_SECRET: validated.JWT_SECRET!,
    JWT_REFRESH_SECRET: validated.JWT_REFRESH_SECRET!,
  };
}
