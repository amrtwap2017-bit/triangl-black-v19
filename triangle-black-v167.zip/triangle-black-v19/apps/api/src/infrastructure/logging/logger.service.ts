import { Injectable, Logger, Scope } from '@nestjs/common';
import { AsyncLocalStorage } from 'async_hooks';
import { env } from '@triangleblack/config';

// ── Types ────────────────────────────────────────────────────────────────

interface LogContext {
  requestId?: string;
  traceId?: string;
  organizationId?: string;
  userId?: string;
}

interface LogEntry {
  timestamp: string;
  level: string;
  requestId?: string;
  traceId?: string;
  organizationId?: string;
  userId?: string;
  module: string;
  action?: string;
  message: string;
  metadata?: Record<string, unknown>;
  stack?: string;
}

interface LogWithActionContext extends LogContext {
  action?: string;
  metadata?: Record<string, unknown>;
}

// ── AsyncLocalStorage for correlation propagation ─────────────────────────

export const correlationStore = new AsyncLocalStorage<LogContext>();

// ── ANSI colour codes for pretty-printing (development) ──────────────────

const colors = {
  reset: '\x1b[0m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  green: '\x1b[32m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
  bold: '\x1b[1m',
};

@Injectable({ scope: Scope.TRANSIENT })
export class LoggerService extends Logger {
  private readonly isProduction: boolean;
  private readonly minLevel: number;

  private static readonly LEVEL_MAP: Record<string, number> = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3,
  };

  constructor(context?: string) {
    super(context ?? 'LoggerService');
    this.isProduction = env.NODE_ENV === 'production';
    this.minLevel =
      LoggerService.LEVEL_MAP[env.LOG_LEVEL] ??
      LoggerService.LEVEL_MAP.info;
  }

  // ── Context helpers ──────────────────────────────────────────────────

  /**
   * Run a callback inside a new correlation context.
   * All logs emitted within the callback will carry this context.
   */
  setContext(ctx: LogContext): LogContext {
    const store = correlationStore.getStore() ?? {};
    const merged: LogContext = { ...store, ...ctx };
    return merged;
  }

  /**
   * Run a callback inside a new correlation context.
   */
  runWithContext<T>(ctx: LogContext, fn: () => T): T {
    const current = correlationStore.getStore() ?? {};
    return correlationStore.run({ ...current, ...ctx }, fn);
  }

  /**
   * Create a child context by merging overrides into the current store.
   */
  childContext(overrides: Partial<LogContext>): LogContext {
    const current = correlationStore.getStore() ?? {};
    return { ...current, ...overrides };
  }

  // ── Structured logging methods ─────────────────────────────────────────

  log(message: string, ...optionalParams: unknown[]): void {
    this.emitLog('info', message, optionalParams);
  }

  error(message: string, trace?: string, ...optionalParams: unknown[]): void {
    this.emitLog('error', message, optionalParams, trace);
  }

  warn(message: string, ...optionalParams: unknown[]): void {
    this.emitLog('warn', message, optionalParams);
  }

  debug(message: string, ...optionalParams: unknown[]): void {
    this.emitLog('debug', message, optionalParams);
  }

  /**
   * Log with structured context fields.
   */
  logWithContext(
    message: string,
    context?: LogWithActionContext,
  ): void {
    const ctx = this.resolveContext(context);
    this.emitLog('info', message, [], undefined, {
      action: context?.action,
      metadata: context?.metadata,
    }, ctx);
  }

  /**
   * Log an error with structured context fields.
   */
  errorWithContext(
    message: string,
    trace?: string,
    context?: LogWithActionContext,
  ): void {
    const ctx = this.resolveContext(context);
    this.emitLog('error', message, [], trace, {
      action: context?.action,
      metadata: context?.metadata,
    }, ctx);
  }

  /**
   * Flush any buffered logs (no-op in JSON mode, useful for tests / shutdown).
   */
  flush(): Promise<void> | void {
    // JSON mode is unbuffered; this is a hook for future transport support
    return;
  }

  // ── Internal helpers ──────────────────────────────────────────────────

  private resolveContext(ctx?: LogWithActionContext): LogContext {
    const store = correlationStore.getStore() ?? {};
    return {
      requestId: ctx?.requestId ?? store.requestId,
      traceId: ctx?.traceId ?? store.traceId,
      organizationId: ctx?.organizationId ?? store.organizationId,
      userId: ctx?.userId ?? store.userId,
    };
  }

  private emitLog(
    level: string,
    message: string,
    optionalParams: unknown[],
    trace?: string,
    extra?: { action?: string; metadata?: Record<string, unknown> },
    ctx?: LogContext,
  ): void {
    const numericLevel = LoggerService.LEVEL_MAP[level] ?? 0;
    if (numericLevel < this.minLevel) return;

    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      requestId: ctx?.requestId,
      traceId: ctx?.traceId,
      organizationId: ctx?.organizationId,
      userId: ctx?.userId,
      module: this.context ?? 'LoggerService',
      action: extra?.action,
      message,
      metadata: extra?.metadata,
      ...(trace ? { stack: trace } : {}),
    };

    if (this.isProduction) {
      // Pure JSON — parseable by Loki / Grafana
      process.stdout.write(JSON.stringify(entry) + '\n');
    } else {
      // Pretty-print with colours for local development
      this.prettyPrint(entry);
    }

    // Delegate to parent for NestJS internal integration
    const parentLevel = level === 'debug' ? 'debug' : level === 'warn' ? 'warn' : level === 'error' ? 'error' : 'log';
    super[parentLevel === 'log' ? 'log' : parentLevel as 'error' | 'warn' | 'debug'](message, ...optionalParams);
  }

  private prettyPrint(entry: LogEntry): void {
    const ts = entry.timestamp.replace('T', ' ').replace('Z', '');
    const levelColor =
      entry.level === 'error'
        ? colors.red
        : entry.level === 'warn'
          ? colors.yellow
          : entry.level === 'debug'
            ? colors.gray
            : colors.green;

    const parts = [
      `${colors.gray}${ts}${colors.reset}`,
      `${levelColor}${entry.level.toUpperCase().padEnd(5)}${colors.reset}`,
      `${colors.cyan}[${entry.module}]${colors.reset}`,
    ];

    if (entry.requestId) {
      parts.push(`${colors.gray}req=${entry.requestId}${colors.reset}`);
    }
    if (entry.traceId) {
      parts.push(`${colors.gray}trace=${entry.traceId}${colors.reset}`);
    }
    if (entry.organizationId) {
      parts.push(`org=${entry.organizationId}`);
    }
    if (entry.userId) {
      parts.push(`user=${entry.userId}`);
    }

    parts.push(`${colors.reset}${entry.message}`);

    process.stdout.write(parts.join(' ') + '\n');

    if (entry.metadata && Object.keys(entry.metadata).length > 0) {
      process.stdout.write(
        `  ${colors.gray}${JSON.stringify(entry.metadata, null, 2)}${colors.reset}\n`,
      );
    }

    if (entry.stack) {
      process.stdout.write(
        `  ${colors.red}${entry.stack}${colors.reset}\n`,
      );
    }
  }
}
