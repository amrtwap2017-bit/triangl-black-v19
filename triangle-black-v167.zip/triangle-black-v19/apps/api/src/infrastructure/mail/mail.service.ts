import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import type { Transporter, SendMailOptions } from 'nodemailer';

@Injectable()
export class MailService {
  private readonly logger = new Logger(MailService.name);
  private transporter: Transporter | null = null;

  constructor() {
    this.initializeTransporter();
  }

  private initializeTransporter(): void {
    const host = process.env.SMTP_HOST ?? 'localhost';
    const port = parseInt(process.env.SMTP_PORT ?? '1025', 10);
    const user = process.env.SMTP_USER ?? '';
    const pass = process.env.SMTP_PASS ?? '';

    this.transporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: user ? { user, pass } : undefined,
    });

    this.logger.log(`Mail transporter configured for ${host}:${port}`);
  }

  /**
   * Send a plain HTML email.
   */
  async sendMail(to: string, subject: string, html: string): Promise<void> {
    if (!this.transporter) {
      this.logger.warn('Mail transporter not configured. Skipping email send.');
      return;
    }

    const from = process.env.SMTP_FROM ?? 'noreply@triangleblack.com';

    try {
      await this.transporter.sendMail({
        from,
        to,
        subject,
        html,
      });
      this.logger.log(`Email sent to ${to}: "${subject}"`);
    } catch (error) {
      this.logger.error(`Failed to send email to ${to}: ${error instanceof Error ? error.message : String(error)}`);
      throw error;
    }
  }

  /**
   * Send a templated email. Currently supports basic string interpolation.
   * In production, integrate with a template engine like Handlebars or EJS.
   */
  async sendTemplatedMail(
    to: string,
    template: string,
    data: Record<string, string>,
  ): Promise<void> {
    // Simple template interpolation: replace {{key}} with values
    let html = template;
    for (const [key, value] of Object.entries(data)) {
      html = html.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value);
    }

    // Extract subject from first line if it starts with "Subject:"
    const lines = html.split('\n');
    let subject = 'Notification from TRIANGLE BLACK';
    if (lines[0] && lines[0].startsWith('Subject:')) {
      subject = lines[0].replace('Subject:', '').trim();
      html = lines.slice(1).join('\n').trim();
    }

    await this.sendMail(to, subject, html);
  }

  /**
   * Verify SMTP connection is working.
   */
  async verifyConnection(): Promise<boolean> {
    if (!this.transporter) return false;
    try {
      await this.transporter.verify();
      return true;
    } catch {
      return false;
    }
  }
}
