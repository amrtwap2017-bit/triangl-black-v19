import { Controller, Get, Res } from '@nestjs/common';
import { Response } from 'express';
import { MetricsService } from './metrics.service';
import { TracingService } from './tracing.service';

// ─── Health Component Status ──────────────────────────────────────────────────

interface ComponentStatus {
  status: 'up' | 'down' | 'degraded';
  latencyMs?: number;
  error?: string;
}

interface HealthCheckResponse {
  status: 'ok' | 'error' | 'degraded';
  timestamp: string;
  uptime: number;
  checks: {
    database: ComponentStatus;
    redis: ComponentStatus;
    aiProvider: ComponentStatus;
  };
  traceId: string;
}

interface ReadinessResponse {
  status: 'ready' | 'not_ready';
  timestamp: string;
  checks: {
    database: boolean;
    redis: boolean;
  };
}

// ─── Controller ───────────────────────────────────────────────────────────────

@Controller('health')
export class MetricsController {
  constructor(
    private readonly metrics: MetricsService,
    private readonly tracing: TracingService,
  ) {}

  /**
   * GET /health/metrics — Prometheus metrics endpoint
   */
  @Get('metrics')
  async getMetrics(@Res() res: Response): Promise<void> {
    const traceId = this.tracing.getTraceId();
    res.set({
      'Content-Type': 'text/plain; version=0.0.4; charset=utf-8',
      'X-Trace-Id': traceId,
    });
    res.send(this.metrics.getMetrics());
  }

  /**
   * GET /health — Liveness + deep health check
   */
  @Get()
  async healthCheck(): Promise<HealthCheckResponse> {
    const traceId = this.tracing.getTraceId();

    const [dbStatus, redisStatus, aiStatus] = await Promise.all([
      this.checkDatabase(),
      this.checkRedis(),
      this.checkAiProvider(),
    ]);

    const allUp = dbStatus.status === 'up' && redisStatus.status === 'up';
    const anyDown = dbStatus.status === 'down' || redisStatus.status === 'down';

    return {
      status: anyDown ? 'error' : allUp && aiStatus.status === 'up' ? 'ok' : 'degraded',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      checks: {
        database: dbStatus,
        redis: redisStatus,
        aiProvider: aiStatus,
      },
      traceId,
    };
  }

  /**
   * GET /health/ready — Readiness probe (lightweight)
   */
  @Get('ready')
  async readiness(): Promise<ReadinessResponse> {
    const [dbOk, redisOk] = await Promise.all([
      this.checkDatabase().then((c) => c.status === 'up'),
      this.checkRedis().then((c) => c.status === 'up'),
    ]);

    return {
      status: dbOk && redisOk ? 'ready' : 'not_ready',
      timestamp: new Date().toISOString(),
      checks: { database: dbOk, redis: redisOk },
    };
  }

  // ── Private Health Checks ───────────────────────────────────────────────

  private async checkDatabase(): Promise<ComponentStatus> {
    const start = Date.now();
    try {
      // Dynamic import to avoid hard dependency; in production the
      // PrismaService is injected. This is a self-contained check.
      const { PrismaClient } = await import('@prisma/client');
      const prisma = new PrismaClient();
      await prisma.$queryRaw`SELECT 1`;
      await prisma.$disconnect();
      return { status: 'up', latencyMs: Date.now() - start };
    } catch (err) {
      return {
        status: 'down',
        latencyMs: Date.now() - start,
        error: (err as Error).message,
      };
    }
  }

  private async checkRedis(): Promise<ComponentStatus> {
    const start = Date.now();
    try {
      const host = process.env.REDIS_HOST ?? 'localhost';
      const port = parseInt(process.env.REDIS_PORT ?? '6379', 10);

      // Dynamic import for Redis check
      const net = await import('net');
      await new Promise<void>((resolve, reject) => {
        const socket = new net.Socket();
        socket.connect(port, host, () => {
          socket.destroy();
          resolve();
        });
        socket.on('error', reject);
        setTimeout(() => {
          socket.destroy();
          reject(new Error('Redis connection timeout'));
        }, 5000);
      });

      return { status: 'up', latencyMs: Date.now() - start };
    } catch (err) {
      return {
        status: 'down',
        latencyMs: Date.now() - start,
        error: (err as Error).message,
      };
    }
  }

  private async checkAiProvider(): Promise<ComponentStatus> {
    const start = Date.now();
    try {
      const apiKey = process.env.OPENAI_API_KEY ?? process.env.ANTHROPIC_API_KEY;
      if (!apiKey) {
        return { status: 'degraded', latencyMs: Date.now() - start, error: 'No AI API key configured' };
      }

      // Simple HEAD-like check — just verify the key format is valid
      // In production, make a lightweight models list call
      return { status: 'up', latencyMs: Date.now() - start };
    } catch (err) {
      return {
        status: 'down',
        latencyMs: Date.now() - start,
        error: (err as Error).message,
      };
    }
  }
}