import { Injectable, Logger } from '@nestjs/common';

// ─── Metric Types ────────────────────────────────────────────────────────────

type LabelValues = Record<string, string | number>;

interface CounterEntry {
  value: number;
  labels: string;
}

interface GaugeEntry {
  value: number;
  labels: string;
}

interface HistogramEntry {
  buckets: number[];
  counts: Record<number, number>;
  sum: number;
  count: number;
  labels: string;
}

interface HistogramDef {
  name: string;
  help: string;
  labelNames: string[];
  buckets: number[];
}

interface MetricDef {
  name: string;
  help: string;
  type: 'counter' | 'gauge' | 'histogram';
  labelNames: string[];
  buckets?: number[];
}

// ─── Prometheus Text Format Helpers ───────────────────────────────────────────

function escapeLabelValue(s: string): string {
  return s.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
}

function labelKey(labelValues: LabelValues, labelNames: string[]): string {
  if (labelNames.length === 0) return '';
  const pairs = labelNames
    .map((n) => `${n}="${escapeLabelValue(String(labelValues[n] ?? ''))}"`)
    .join(',');
  return `{${pairs}}`;
}

// ─── Metrics Service ─────────────────────────────────────────────────────────

@Injectable()
export class MetricsService {
  private readonly logger = new Logger(MetricsService.name);

  // ── Metric Definitions ────────────────────────────────────────────────

  private readonly defs = new Map<string, MetricDef>();
  private readonly counters = new Map<string, CounterEntry[]>();
  private readonly gauges = new Map<string, GaugeEntry[]>();
  private readonly histograms = new Map<string, HistogramEntry[]>();

  constructor() {
    // ── HTTP ─────────────────────────────────────────────────────────
    this.defineHistogram('http_request_duration_seconds', 'HTTP request duration in seconds', ['method', 'route', 'status'], [
      0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10,
    ]);
    this.defineCounter('http_request_total', 'Total HTTP requests', ['method', 'route', 'status']);

    // ── Database ──────────────────────────────────────────────────────
    this.defineHistogram('db_query_duration_seconds', 'Database query duration', ['query_type'], [
      0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1,
    ]);

    // ── AI ────────────────────────────────────────────────────────────
    this.defineHistogram('ai_request_duration_seconds', 'AI request duration', ['model', 'agent_type'], [
      0.5, 1, 2.5, 5, 10, 20, 30, 60,
    ]);
    this.defineCounter('ai_token_usage_total', 'AI token usage', ['model', 'type']);
    this.defineCounter('ai_cost_usd_total', 'AI cost in USD', ['model', 'agent_type', 'organization_id']);

    // ── Connections ────────────────────────────────────────────────────
    this.defineGauge('active_connections', 'Currently active connections', []);

    // ── Queue ─────────────────────────────────────────────────────────
    this.defineHistogram('queue_job_duration_seconds', 'Queue job duration', ['queue', 'job', 'status'], [
      0.1, 0.5, 1, 2.5, 5, 10, 30, 60, 120, 300,
    ]);

    // ── Document Processing ───────────────────────────────────────────
    this.defineHistogram('document_processing_duration_seconds', 'Document processing stage duration', ['stage'], [
      0.5, 1, 2.5, 5, 10, 30, 60, 120,
    ]);

    // ── Business Metrics ──────────────────────────────────────────────
    this.defineGauge('business_opportunities_count', 'Total opportunities', ['organization_id']);
    this.defineGauge('business_proposals_count', 'Total proposals', ['organization_id']);
    this.defineGauge('business_projects_count', 'Total projects', ['organization_id']);
    this.defineGauge('business_revenue_usd', 'Total revenue in USD', ['organization_id']);

    this.logger.log('Metrics service initialized with Prometheus-compatible registry');
  }

  // ── Definition Helpers ─────────────────────────────────────────────────

  private defineCounter(name: string, help: string, labelNames: string[]) {
    this.defs.set(name, { name, help, type: 'counter', labelNames });
    this.counters.set(name, []);
  }

  private defineGauge(name: string, help: string, labelNames: string[]) {
    this.defs.set(name, { name, help, type: 'gauge', labelNames });
    this.gauges.set(name, []);
  }

  private defineHistogram(name: string, help: string, labelNames: string[], buckets: number[]) {
    this.defs.set(name, { name, help, type: 'histogram', labelNames, buckets });
    this.histograms.set(name, []);
  }

  // ── Public API ─────────────────────────────────────────────────────────

  /**
   * Increment a counter metric.
   */
  incrementCounter(name: string, labels: LabelValues = {}, value = 1): void {
    const entries = this.counters.get(name);
    const def = this.defs.get(name);
    if (!entries || !def) return;

    const key = labelKey(labels, def.labelNames);
    let entry = entries.find((e) => e.labels === key);
    if (!entry) {
      entry = { value: 0, labels: key };
      entries.push(entry);
    }
    entry.value += value;
  }

  /**
   * Record a value in a histogram.
   */
  recordHistogram(name: string, value: number, labels: LabelValues = {}): void {
    const entries = this.histograms.get(name);
    const def = this.defs.get(name) as HistogramDef | undefined;
    if (!entries || !def) return;

    const key = labelKey(labels, def.labelNames);
    let entry = entries.find((e) => e.labels === key);
    if (!entry) {
      entry = { buckets: def.buckets, counts: {}, sum: 0, count: 0, labels: key };
      for (const b of def.buckets) entry.counts[b] = 0;
      entry.counts[Infinity] = 0;
      entries.push(entry);
    }

    entry.sum += value;
    entry.count++;
    for (const b of entry.buckets) {
      if (value <= b) entry.counts[b]++;
    }
    entry.counts[Infinity]++;
  }

  /**
   * Set a gauge value (absolute, not delta).
   */
  setGauge(name: string, value: number, labels: LabelValues = {}): void {
    const entries = this.gauges.get(name);
    const def = this.defs.get(name);
    if (!entries || !def) return;

    const key = labelKey(labels, def.labelNames);
    let entry = entries.find((e) => e.labels === key);
    if (!entry) {
      entry = { value, labels: key };
      entries.push(entry);
    } else {
      entry.value = value;
    }
  }

  // ── Prometheus Output ──────────────────────────────────────────────────

  /**
   * Render all registered metrics in Prometheus text exposition format.
   */
  getMetrics(): string {
    const lines: string[] = [];

    // HELP + TYPE headers
    for (const def of this.defs.values()) {
      lines.push(`# HELP ${def.name} ${def.help}`);
      lines.push(`# TYPE ${def.name} ${def.type}`);
    }

    // Counters
    for (const [name, entries] of this.counters) {
      for (const e of entries) {
        lines.push(`${name}${e.labels} ${e.value}`);
      }
    }

    // Gauges
    for (const [name, entries] of this.gauges) {
      for (const e of entries) {
        lines.push(`${name}${e.labels} ${e.value}`);
      }
    }

    // Histograms: _bucket, _sum, _count
    for (const [name, entries] of this.histograms) {
      for (const e of entries) {
        for (const b of e.buckets) {
          lines.push(`${name}_bucket{le="${b}"${e.labels ? ', ' + e.labels.slice(1, -1) : ''}} ${e.counts[b]}`);
        }
        lines.push(`${name}_bucket{le="+Inf"${e.labels ? ', ' + e.labels.slice(1, -1) : ''}} ${e.counts[Infinity]}`);
        lines.push(`${name}_sum${e.labels} ${e.sum}`);
        lines.push(`${name}_count${e.labels} ${e.count}`);
      }
    }

    return lines.join('\n') + '\n';
  }
}