import { Injectable, Logger } from '@nestjs/common';
import { AsyncLocalStorage } from 'async_hooks';

// ─── Span Types ───────────────────────────────────────────────────────────────

export interface Span {
  name: string;
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  attributes: Record<string, string | number | boolean>;
  startTime: number; // ms
  endTime?: number; // ms
  status: 'active' | 'completed' | 'error';
  error?: string;
}

// ─── Trace Context ────────────────────────────────────────────────────────────

interface TraceContext {
  traceId: string;
  activeSpans: Span[];
}

// ─── Tracing Service ─────────────────────────────────────────────────────────

@Injectable()
export class TracingService {
  private readonly logger = new Logger(TracingService.name);

  /** AsyncLocalStorage for automatic context propagation across async boundaries */
  private readonly storage = new AsyncLocalStorage<TraceContext>();

  constructor() {
    this.logger.log('Tracing service initialized with AsyncLocalStorage');
  }

  // ── Trace ID ────────────────────────────────────────────────────────────

  /**
   * Set the trace ID from incoming request headers.
   * Accepts X-Trace-Id or X-Request-Id.
   */
  setTraceId(traceId: string): void {
    const ctx = this.storage.getStore();
    if (ctx) {
      ctx.traceId = traceId;
    }
  }

  /**
   * Get the current trace ID from context.
   */
  getTraceId(): string {
    const ctx = this.storage.getStore();
    if (ctx?.traceId) return ctx.traceId;

    // Fallback: generate a new trace ID if none exists
    const newTraceId = this.generateId();
    if (ctx) {
      ctx.traceId = newTraceId;
    }
    return newTraceId;
  }

  // ── Span Management ─────────────────────────────────────────────────────

  /**
   * Start a new span. If no trace context exists, a new one is created.
   */
  startSpan(name: string, attributes?: Record<string, string | number | boolean>): Span {
    let ctx = this.storage.getStore();

    if (!ctx) {
      ctx = { traceId: this.generateId(), activeSpans: [] };
    }

    const traceId = ctx.traceId;
    const parentSpan = ctx.activeSpans[ctx.activeSpans.length - 1];

    const span: Span = {
      name,
      traceId,
      spanId: this.generateId(),
      parentSpanId: parentSpan?.spanId,
      attributes: attributes ?? {},
      startTime: Date.now(),
      status: 'active',
    };

    ctx.activeSpans.push(span);

    // If we just created the context, run the rest of the async chain inside it
    if (!this.storage.getStore()) {
      this.storage.enterWith(ctx);
    }

    this.logger.debug(`[Trace:${traceId}] Span started: ${name} (${span.spanId})`);
    return span;
  }

  /**
   * End a span, marking it as completed or errored.
   */
  endSpan(span: Span, error?: Error): void {
    span.endTime = Date.now();
    span.status = error ? 'error' : 'completed';
    if (error) span.error = error.message;

    const ctx = this.storage.getStore();
    if (ctx) {
      const idx = ctx.activeSpans.indexOf(span);
      if (idx !== -1) ctx.activeSpans.splice(idx, 1);
    }

    const duration = span.endTime - span.startTime;
    this.logger.debug(
      `[Trace:${span.traceId}] Span ended: ${span.name} (${span.status}, ${duration}ms)`,
    );
  }

  /**
   * Run a function within a trace context.
   * Automatically creates/ends a span around the callback.
   */
  async withSpan<T>(
    name: string,
    fn: () => Promise<T>,
    attributes?: Record<string, string | number | boolean>,
  ): Promise<T> {
    const span = this.startSpan(name, attributes);
    try {
      const result = await fn();
      this.endSpan(span);
      return result;
    } catch (err) {
      this.endSpan(span, err as Error);
      throw err;
    }
  }

  // ── Active Spans ────────────────────────────────────────────────────────

  /**
   * Get all currently active spans in the current context.
   */
  getActiveSpans(): Span[] {
    const ctx = this.storage.getStore();
    return ctx?.activeSpans ? [...ctx.activeSpans] : [];
  }

  // ── Header Injection ────────────────────────────────────────────────────

  /**
   * Inject trace headers onto an outgoing request headers object.
   * Adds X-Trace-Id and X-Request-Id.
   */
  injectTraceHeaders(headers: Record<string, string>): void {
    const traceId = this.getTraceId();
    headers['X-Trace-Id'] = traceId;
    headers['X-Request-Id'] = traceId;
  }

  // ── Run in Context ──────────────────────────────────────────────────────

  /**
   * Run a callback inside a trace context (used by middleware/guards).
   */
  runInContext<T>(traceId: string, fn: () => T): T {
    const ctx: TraceContext = {
      traceId,
      activeSpans: [],
    };
    return this.storage.run(ctx, fn);
  }

  // ── Utility ─────────────────────────────────────────────────────────────

  private generateId(): string {
    const chars = '0123456789abcdef';
    let id = '';
    for (let i = 0; i < 16; i++) {
      id += chars[Math.floor(Math.random() * 16)];
    }
    return id;
  }
}