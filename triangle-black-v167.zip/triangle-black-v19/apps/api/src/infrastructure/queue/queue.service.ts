import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { Queue, Job, type JobState } from 'bullmq';
import { createHash } from 'crypto';
import {
  JOB_DEFINITIONS,
  getJobDefinition,
  resolveIdempotencyKey,
  buildBullMQRetryOptions,
  QUEUE_NAMES,
  type JobPayload,
} from '@triangleblack/queue';

// ─── Types ───────────────────────────────────────────────────────────────────

interface AddJobOptions {
  priority?: number;
  delay?: number;
  /** Override the auto-generated idempotency key */
  idempotencyKey?: string;
}

interface JobStatusResult {
  status: string;
  progress: number;
  result?: unknown;
  error?: string;
}

interface QueueStats {
  waiting: number;
  active: number;
  completed: number;
  failed: number;
  delayed: number;
}

// ─── Service ─────────────────────────────────────────────────────────────────

@Injectable()
export class QueueService implements OnModuleDestroy {
  private readonly logger = new Logger(QueueService.name);

  private readonly connectionOpts = {
    host: process.env.REDIS_HOST ?? 'localhost',
    port: parseInt(process.env.REDIS_PORT ?? '6379', 10),
    password: process.env.REDIS_PASSWORD ?? undefined,
    db: parseInt(process.env.REDIS_DB ?? '0', 10),
  };

  private readonly queues = new Map<string, Queue>();
  private readonly progressCallbacks = new Map<
    string,
    (progress: number) => void
  >();

  constructor() {
    // Pre-register all queues from job definitions
    for (const queueName of QUEUE_NAMES) {
      this.getQueue(queueName);
    }
    this.logger.log(
      `Queue service initialized with ${QUEUE_NAMES.size} queues: ${[...QUEUE_NAMES].join(', ')}`,
    );
  }

  // ── Queue Access ─────────────────────────────────────────────────────────

  /**
   * Get or create a BullMQ Queue by name.
   */
  getQueue(queueName: string): Queue {
    if (!this.queues.has(queueName)) {
      const queue = new Queue(queueName, {
        connection: this.connectionOpts,
        defaultJobOptions: {
          removeOnComplete: { count: 1000 },
          removeOnFail: { count: 5000 },
        },
      });
      this.queues.set(queueName, queue);
      this.logger.log(`Queue "${queueName}" initialized`);
    }
    return this.queues.get(queueName)!;
  }

  // ── Job Submission ───────────────────────────────────────────────────────

  /**
   * Add a job to the appropriate queue based on its definition.
   * Generates an idempotency key from jobName + data hash to prevent duplicates.
   */
  async addJob(
    jobName: string,
    data: JobPayload,
    options?: AddJobOptions,
  ): Promise<{ jobId: string }> {
    const definition = getJobDefinition(jobName);
    const queueName = definition?.queue ?? 'default';
    const queue = this.getQueue(queueName);

    // Idempotency key
    let jobId: string | undefined;
    if (options?.idempotencyKey) {
      jobId = options.idempotencyKey;
    } else if (definition?.idempotencyKey) {
      jobId = resolveIdempotencyKey(definition.idempotencyKey, data as Record<string, unknown>);
    } else {
      // Fallback: SHA-256 hash of jobName + stable data representation
      jobId = createHash('sha256')
        .update(`${jobName}:${JSON.stringify(data)}`)
        .digest('hex')
        .slice(0, 32);
    }

    const retryOpts = buildBullMQRetryOptions(definition, jobName);

    const job = await queue.add(jobName, data, {
      jobId,
      timeout: definition?.timeout ?? 60_000,
      priority: options?.priority ?? definition?.priority ?? 5,
      delay: options?.delay,
      attempts: retryOpts.attempts,
      backoff: retryOpts.backoff,
      removeOnComplete: { count: 1000 },
      removeOnFail: { count: 5000 },
    });

    this.logger.log(`Job "${job.id}" (${jobName}) added to queue "${queueName}"`);
    return { jobId: job.id ?? jobId };
  }

  // ── Job Status ──────────────────────────────────────────────────────────

  /**
   * Get the current status, progress, result, and error of a job.
   */
  async getJobStatus(jobId: string): Promise<JobStatusResult> {
    // Search all queues for the job
    for (const [, queue] of this.queues) {
      const job = await queue.getJob(jobId);
      if (job) {
        const state = await job.getState();
        return {
          status: state,
          progress: job.progress as number ?? 0,
          result: job.returnvalue,
          error: job.failedReason ?? undefined,
        };
      }
    }
    throw new Error(`Job "${jobId}" not found in any queue`);
  }

  // ── Queue Statistics ────────────────────────────────────────────────────

  /**
   * Get aggregate counts for a queue.
   */
  async getQueueStats(queueName: string): Promise<QueueStats> {
    const queue = this.getQueue(queueName);
    const [waiting, active, completed, failed, delayed] = await Promise.all([
      queue.getWaitingCount(),
      queue.getActiveCount(),
      queue.getCompletedCount(),
      queue.getFailedCount(),
      queue.getDelayedCount(),
    ]);
    return { waiting, active, completed, failed, delayed };
  }

  // ── Progress Tracking ───────────────────────────────────────────────────

  /**
   * Register a progress callback for a long-running job.
   * The callback is invoked whenever the worker calls `job.progress(n)`.
   */
  addProgressCallback(
    jobId: string,
    callback: (progress: number) => void,
  ): void {
    this.progressCallbacks.set(jobId, callback);

    // Listen for progress events on all queues (BullMQ events)
    for (const [, queue] of this.queues) {
      queue.on('progress', (job: Job, progress: number | object) => {
        if (job.id === jobId && typeof progress === 'number') {
          const cb = this.progressCallbacks.get(jobId);
          if (cb) cb(progress);
        }
      });
    }
  }

  // ── Job Cancellation ────────────────────────────────────────────────────

  /**
   * Cancel a pending or delayed job.
   */
  async cancelJob(jobId: string): Promise<boolean> {
    for (const [, queue] of this.queues) {
      const job = await queue.getJob(jobId);
      if (job) {
        const state = await job.getState();
        if (state === 'waiting' || state === 'delayed') {
          await job.remove();
          this.logger.log(`Job "${jobId}" cancelled`);
          this.progressCallbacks.delete(jobId);
          return true;
        }
        throw new Error(
          `Job "${jobId}" is in "${state}" state and cannot be cancelled`,
        );
      }
    }
    throw new Error(`Job "${jobId}" not found in any queue`);
  }

  // ── Job Retry ───────────────────────────────────────────────────────────

  /**
   * Retry a failed job by re-adding it to its original queue.
   */
  async retryJob(jobId: string): Promise<{ jobId: string }> {
    for (const [, queue] of this.queues) {
      const job = await queue.getJob(jobId);
      if (job) {
        const state = await job.getState();
        if (state === 'failed') {
          await job.retry();
          this.logger.log(`Job "${jobId}" re-queued for retry`);
          return { jobId };
        }
        throw new Error(
          `Job "${jobId}" is in "${state}" state — only failed jobs can be retried`,
        );
      }
    }
    throw new Error(`Job "${jobId}" not found in any queue`);
  }

  // ── Lifecycle ───────────────────────────────────────────────────────────

  async onModuleDestroy() {
    for (const [name, queue] of this.queues) {
      await queue.close();
      this.logger.log(`Queue "${name}" connection closed`);
    }
    this.progressCallbacks.clear();
    this.logger.log('Queue service shut down');
  }
}