import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

export interface SearchResult {
  type: string;
  id: string;
  title: string;
  subtitle?: string;
  url: string;
}

@Injectable()
export class SearchService {
  constructor(private readonly prisma: PrismaService) {}

  async globalSearch(
    organizationId: string,
    query: string,
    scope?: string,
    limit: number = 20,
  ): Promise<{ results: SearchResult[]; total: number }> {
    const results: SearchResult[] = [];
    const allScopes = [
      'hotels',
      'contacts',
      'opportunities',
      'projects',
      'vendors',
      'documents',
      'proposals',
      'knowledge',
    ];
    const scopes =
      scope && scope !== 'all' ? [scope] : allScopes;

    for (const s of scopes) {
      switch (s) {
        case 'hotels': {
          const hotels = await this.prisma.hotel.findMany({
            where: {
              organizationId,
              deletedAt: null,
              OR: [
                { name: { contains: query, mode: 'insensitive' } },
                { city: { contains: query, mode: 'insensitive' } },
              ],
            },
            take: 5,
            select: { id: true, name: true, city: true },
          });
          results.push(
            ...hotels.map((h) => ({
              type: 'hotel',
              id: h.id,
              title: h.name,
              subtitle: h.city ?? undefined,
              url: `/hotels/${h.id}`,
            })),
          );
          break;
        }

        case 'contacts': {
          const hotelContacts = await this.prisma.hotelContact.findMany({
            where: {
              hotel: { organizationId },
              OR: [
                { firstName: { contains: query, mode: 'insensitive' } },
                { lastName: { contains: query, mode: 'insensitive' } },
                { email: { contains: query, mode: 'insensitive' } },
                { position: { contains: query, mode: 'insensitive' } },
              ],
            },
            take: 5,
            select: {
              id: true,
              firstName: true,
              lastName: true,
              position: true,
              hotelId: true,
            },
          });
          results.push(
            ...hotelContacts.map((c) => ({
              type: 'contact',
              id: c.id,
              title: `${c.firstName} ${c.lastName}`,
              subtitle: c.position ?? undefined,
              url: `/hotels/${c.hotelId}`,
            })),
          );
          break;
        }

        case 'opportunities': {
          const opps = await this.prisma.opportunity.findMany({
            where: {
              organizationId,
              deletedAt: null,
              title: { contains: query, mode: 'insensitive' },
            },
            take: 5,
            select: { id: true, title: true, value: true },
          });
          results.push(
            ...opps.map((o) => ({
              type: 'opportunity',
              id: o.id,
              title: o.title,
              subtitle: o.value ? `${o.value} SAR` : undefined,
              url: `/opportunities/${o.id}`,
            })),
          );
          break;
        }

        case 'projects': {
          const projects = await this.prisma.project.findMany({
            where: {
              organizationId,
              deletedAt: null,
              name: { contains: query, mode: 'insensitive' },
            },
            take: 5,
            select: { id: true, name: true, status: true },
          });
          results.push(
            ...projects.map((p) => ({
              type: 'project',
              id: p.id,
              title: p.name,
              subtitle: p.status,
              url: `/projects/${p.id}`,
            })),
          );
          break;
        }

        case 'vendors': {
          const vendors = await this.prisma.vendor.findMany({
            where: {
              organizationId,
              deletedAt: null,
              name: { contains: query, mode: 'insensitive' },
            },
            take: 5,
            select: { id: true, name: true, category: true },
          });
          results.push(
            ...vendors.map((v) => ({
              type: 'vendor',
              id: v.id,
              title: v.name,
              subtitle: v.category ?? undefined,
              url: `/vendors/${v.id}`,
            })),
          );
          break;
        }

        case 'documents': {
          const docs = await this.prisma.document.findMany({
            where: {
              organizationId,
              deletedAt: null,
              title: { contains: query, mode: 'insensitive' },
            },
            take: 5,
            select: { id: true, title: true, category: true },
          });
          results.push(
            ...docs.map((d) => ({
              type: 'document',
              id: d.id,
              title: d.title,
              subtitle: d.category ?? undefined,
              url: `/documents`,
            })),
          );
          break;
        }

        case 'proposals': {
          const props = await this.prisma.proposal.findMany({
            where: {
              organizationId,
              deletedAt: null,
              title: { contains: query, mode: 'insensitive' },
            },
            take: 5,
            select: {
              id: true,
              title: true,
              status: true,
              totalValue: true,
            },
          });
          results.push(
            ...props.map((p) => ({
              type: 'proposal',
              id: p.id,
              title: p.title,
              subtitle: `${p.status} | ${p.totalValue ?? 0} SAR`,
              url: `/proposals/${p.id}`,
            })),
          );
          break;
        }

        case 'knowledge': {
          const articles = await this.prisma.knowledgeArticle.findMany({
            where: {
              organizationId,
              deletedAt: null,
              OR: [
                { title: { contains: query, mode: 'insensitive' } },
                { content: { contains: query, mode: 'insensitive' } },
              ],
            },
            take: 5,
            select: { id: true, title: true, category: true },
          });
          results.push(
            ...articles.map((a) => ({
              type: 'knowledge',
              id: a.id,
              title: a.title,
              subtitle: a.category,
              url: `/knowledge-hub`,
            })),
          );
          break;
        }
      }
    }

    return { results: results.slice(0, limit), total: results.length };
  }
}