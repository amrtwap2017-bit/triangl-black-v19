import { Injectable } from '@nestjs/common';
import * as crypto from 'crypto';

/**
 * AES-256-GCM encryption service for sensitive field-level encryption.
 *
 * Usage:
 *   const encrypted = encryptionService.encrypt('sensitive-data');
 *   const plain     = encryptionService.decrypt(encrypted);
 *
 * ENCRYPTION_KEY env var is derived at startup via scrypt.
 * In production this MUST be set to a strong, unique secret (≥ 32 chars).
 */
@Injectable()
export class EncryptionService {
  private readonly algorithm = 'aes-256-gcm';
  private readonly key: Buffer;

  constructor() {
    const secret = process.env.ENCRYPTION_KEY || 'default-encryption-key-32bytes!';
    // Derive a 32-byte key from the secret so arbitrary-length secrets work
    this.key = crypto.scryptSync(secret, 'triangleblack-salt-v16', 32);
  }

  /**
   * Encrypt plaintext → `iv:authTag:ciphertext` (hex-encoded).
   */
  encrypt(text: string): string {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(this.algorithm, this.key, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    const authTag = cipher.getAuthTag();
    return iv.toString('hex') + ':' + authTag.toString('hex') + ':' + encrypted;
  }

  /**
   * Decrypt `iv:authTag:ciphertext` (hex) → plaintext.
   */
  decrypt(encrypted: string): string {
    const [ivHex, authTagHex, encryptedText] = encrypted.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    const decipher = crypto.createDecipheriv(this.algorithm, this.key, iv);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }
}