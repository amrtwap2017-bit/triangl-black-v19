import { Global, Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { SecurityService } from './security.service';
import { EncryptionService } from './encryption.service';

@Global()
@Module({
  imports: [
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        secret: configService.get<string>('appConfig.jwt.secret', 'changeme-jwt-secret'),
        signOptions: {
          expiresIn: configService.get<string>('appConfig.jwt.expiresIn', '15m') as unknown as number,
        },
      }),
    }),
  ],
  providers: [SecurityService, EncryptionService],
  exports: [SecurityService, EncryptionService, JwtModule],
})
export class SecurityModule {}