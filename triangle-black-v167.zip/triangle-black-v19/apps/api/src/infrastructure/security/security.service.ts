import { Injectable, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import type { JwtPayload } from '../../common/types';

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
}

@Injectable()
export class SecurityService {
  private readonly saltRounds = 12;
  private readonly logger = new Logger(SecurityService.name);

  // ─── Rate limit presets (ttl in seconds, limit = max requests) ──────
  private readonly rateLimitPresets: Record<string, { ttl: number; limit: number }> = {
    'auth.login':           { ttl: 60,   limit: 5 },
    'auth.register':        { ttl: 60,   limit: 3 },
    'auth.forgot-password': { ttl: 60,   limit: 3 },
    'api.general':          { ttl: 60,   limit: 100 },
    'api.search':           { ttl: 60,   limit: 30 },
    'api.upload':           { ttl: 60,   limit: 10 },
    'api.export':           { ttl: 60,   limit: 5 },
  };

  constructor(private readonly jwtService: JwtService) {}

  /**
   * Hash a plain-text password using bcrypt.
   */
  async hashPassword(plain: string): Promise<string> {
    return bcrypt.hash(plain, this.saltRounds);
  }

  /**
   * Compare a plain-text password against a bcrypt hash.
   */
  async comparePasswords(plain: string, hash: string): Promise<boolean> {
    return bcrypt.compare(plain, hash);
  }

  /**
   * Generate an access token for a given payload.
   */
  async generateToken(payload: JwtPayload): Promise<TokenPair> {
    const accessToken = this.jwtService.sign(payload, {
      secret: process.env.JWT_SECRET ?? 'changeme-jwt-secret',
      expiresIn: (process.env.JWT_EXPIRES_IN ?? '15m') as unknown as number,
    });

    const refreshToken = this.generateRefreshJwt(payload.sub);

    return { accessToken, refreshToken };
  }

  /**
   * Generate a standalone access token.
   */
  generateAccessToken(payload: JwtPayload): string {
    return this.jwtService.sign(payload, {
      secret: process.env.JWT_SECRET ?? 'changeme-jwt-secret',
      expiresIn: (process.env.JWT_EXPIRES_IN ?? '15m') as unknown as number,
    });
  }

  /**
   * Generate a refresh JWT token.
   * Accepts either a userId string, a JwtPayload object, or no args.
   */
  generateRefreshJwt(userIdOrPayload?: string | JwtPayload): string {
    const sub = typeof userIdOrPayload === 'string'
      ? userIdOrPayload
      : userIdOrPayload?.sub ?? '';
    return this.jwtService.sign(
      { sub, type: 'refresh' },
      {
        secret: process.env.JWT_REFRESH_SECRET ?? 'changeme-refresh-secret',
        expiresIn: (process.env.JWT_REFRESH_EXPIRES_IN ?? '7d') as unknown as number,
      },
    );
  }

  /**
   * Generate a refresh token (alias for generateRefreshJwt).
   * Accepts either a userId string, a JwtPayload object, or no args.
   */
  generateRefreshToken(userIdOrPayload?: string | JwtPayload): string {
    return this.generateRefreshJwt(userIdOrPayload);
  }

  /**
   * Verify and decode a token. Returns null on failure.
   */
  async verifyToken(token: string): Promise<JwtPayload | null> {
    try {
      const decoded = this.jwtService.verify<JwtPayload>(token, {
        secret: process.env.JWT_SECRET ?? 'changeme-jwt-secret',
      });
      return decoded;
    } catch {
      return null;
    }
  }

  /**
   * Verify a refresh token.
   */
  async verifyRefreshToken(token: string): Promise<{ sub: string; type: string } | null> {
    try {
      const decoded = this.jwtService.verify<{ sub: string; type: string }>(token, {
        secret: process.env.JWT_REFRESH_SECRET ?? 'changeme-refresh-secret',
      });
      return decoded;
    } catch {
      return null;
    }
  }

  /**
   * Verify and extract payload from a refresh token. Alias for verifyRefreshToken.
   */
  async verifyRefreshTokenPayload(token: string): Promise<{ sub: string; type: string } | null> {
    return this.verifyRefreshToken(token);
  }

  // ─── Input Sanitization & Threat Detection ──────────────────────────

  /**
   * Strip HTML tags and normalize whitespace in user input.
   */
  sanitizeInput(input: string): string {
    if (!input || typeof input !== 'string') return '';
    return input
      // Strip HTML tags
      .replace(/<[^>]*>/g, '')
      // Normalize whitespace (collapse multiple spaces/newlines into single space)
      .replace(/\s+/g, ' ')
      // Trim leading/trailing whitespace
      .trim();
  }

  /**
   * Detect common SQL injection patterns in user input.
   */
  detectSqlInjection(input: string): boolean {
    if (!input || typeof input !== 'string') return false;
    const sqlPatterns = [
      /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|EXEC|EXECUTE|UNION|CREATE|GRANT|REVOKE)\b)/i,
      /(--|;|\/\*|\*\/|xp_|sp_|0x)/,
      /(\b(OR|AND)\b\s+\d+\s*=\s*\d+)/i,
      /('\s*(OR|AND)\s+.*=)/i,
      /(\bWAITFOR\b\s+\bDELAY\b)/i,
      /(\bBENCHMARK\b\s*\()/i,
      /(%27|%22|%3D|%3B)/i, // URL-encoded quotes, equals, semicolons
    ];
    return sqlPatterns.some((pattern) => pattern.test(input));
  }

  /**
   * Detect common XSS (Cross-Site Scripting) patterns in user input.
   */
  detectXss(input: string): boolean {
    if (!input || typeof input !== 'string') return false;
    const xssPatterns = [
      /<script[\s>]/i,
      /<\/script>/i,
      /javascript\s*:/i,
      /on\w+\s*=\s*/i,               // event handlers like onclick=
      /<iframe[\s>]/i,
      /<object[\s>]/i,
      /<embed[\s>]/i,
      /<form[\s>]/i,
      /expression\s*\(/i,             // CSS expressions
      /url\s*\(\s*(['"]?\s*javascript)/i,
      /<\s*img[^>]+src\s*=\s*['"]?\s*javascript/i,
      /<\s*svg[^>]+onload/i,
      /<\s*body[^>]+onload/i,
      /document\.cookie/i,
      /document\.write/i,
    ];
    return xssPatterns.some((pattern) => pattern.test(input));
  }

  /**
   * Validate a file's MIME type against an allowed list.
   */
  validateFileType(mimeType: string, allowedTypes: string[]): boolean {
    if (!mimeType || !Array.isArray(allowedTypes) || allowedTypes.length === 0) {
      return false;
    }
    const normalized = mimeType.toLowerCase().trim();
    return allowedTypes.some((type) => type.toLowerCase().trim() === normalized);
  }

  /**
   * Get rate limit configuration for a given endpoint.
   * Returns default config if no specific preset matches.
   */
  getRateLimitConfig(endpoint: string): { ttl: number; limit: number } {
    // Try to find the most specific match first
    const parts = endpoint.split('.');
    for (let i = parts.length; i > 0; i--) {
      const prefix = parts.slice(0, i).join('.');
      if (this.rateLimitPresets[prefix]) {
        return { ...this.rateLimitPresets[prefix] };
      }
    }

    // Default fallback: 100 requests per 60 seconds
    return { ttl: 60, limit: 100 };
  }
}
