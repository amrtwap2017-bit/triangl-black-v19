import { Injectable, Logger } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';

export interface UploadResult {
  key: string;
  url: string;
  originalName: string;
  mimeType: string;
  size: number;
}

@Injectable()
export class StorageService {
  private readonly logger = new Logger(StorageService.name);
  private readonly driver: 'local' | 's3';
  private readonly localPath: string;

  constructor() {
    this.driver = (process.env.STORAGE_DRIVER ?? 'local') as 'local' | 's3';
    this.localPath = process.env.STORAGE_LOCAL_PATH ?? './uploads';

    // Ensure upload directory exists
    if (this.driver === 'local') {
      const fullPath = path.resolve(this.localPath);
      if (!fs.existsSync(fullPath)) {
        fs.mkdirSync(fullPath, { recursive: true });
        this.logger.log(`Created upload directory: ${fullPath}`);
      }
    }
  }

  /**
   * Upload a file to storage.
   * @param file - Express.Multer.File object
   * @param category - Category subfolder (e.g., 'avatars', 'documents', 'projects')
   */
  async upload(
    file: Express.Multer.File,
    category: string,
  ): Promise<UploadResult> {
    const ext = path.extname(file.originalname);
    const key = `${category}/${uuidv4()}${ext}`;
    const filePath = path.join(this.localPath, key);

    // Ensure category directory exists
    const dirPath = path.dirname(filePath);
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }

    // Write file to disk
    fs.writeFileSync(filePath, file.buffer);

    this.logger.log(`File uploaded: ${key} (${file.size} bytes)`);

    return {
      key,
      url: `/files/${key}`,
      originalName: file.originalname,
      mimeType: file.mimetype,
      size: file.size,
    };
  }

  /**
   * Download / read a file from storage. Returns buffer.
   */
  async download(key: string): Promise<Buffer> {
    const filePath = path.join(this.localPath, key);

    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${key}`);
    }

    return fs.readFileSync(filePath);
  }

  /**
   * Delete a file from storage.
   */
  async delete(key: string): Promise<void> {
    const filePath = path.join(this.localPath, key);

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      this.logger.log(`File deleted: ${key}`);
    } else {
      this.logger.warn(`File not found for deletion: ${key}`);
    }
  }

  /**
   * Get a signed URL for temporary access (local driver returns the direct URL).
   */
  async getSignedUrl(key: string, _expiresIn: number = 3600): Promise<string> {
    // For local driver, just return the public URL
    // In production with S3, this would generate a pre-signed URL
    return `/files/${key}`;
  }

  /**
   * Check if a file exists in storage.
   */
  async exists(key: string): Promise<boolean> {
    const filePath = path.join(this.localPath, key);
    return fs.existsSync(filePath);
  }
}
