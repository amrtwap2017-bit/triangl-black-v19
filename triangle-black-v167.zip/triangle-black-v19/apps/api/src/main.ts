import { NestFactory } from '@nestjs/core';
import { ValidationPipe, VersioningType } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { LoggerService } from './infrastructure/logging/logger.service';
import { env } from '@triangleblack/config';
import { PrismaService } from './infrastructure/prisma/prisma.service';

async function bootstrap() {
  const logger = new LoggerService('Bootstrap');

  const app = await NestFactory.create(AppModule, {
    bufferLogs: true,
  });

  // ── Structured logging ─────────────────────────────────────────────
  app.useLogger(app.get(LoggerService));

  // ── Global prefix & versioning ─────────────────────────────────────
  app.setGlobalPrefix('api/v1');

  // ── Security headers ──────────────────────────────────────────────
  app.use(
    helmet({
      contentSecurityPolicy: env.NODE_ENV === 'production' ? undefined : false,
      hsts: env.NODE_ENV === 'production'
        ? { maxAge: 31536000, includeSubDomains: true, preload: true }
        : false,
    }),
  );

  // ── CORS ───────────────────────────────────────────────────────────
  app.enableCors({
    origin: env.CORS_ORIGIN,
    credentials: true,
  });

  // ── Validation ─────────────────────────────────────────────────────
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
      forbidNonWhitelisted: true,
    }),
  );

  // ── Shutdown hooks ────────────────────────────────────────────────
  app.enableShutdownHooks();

  // ── Swagger ──────────────────────────────────────────────────────
  const config = new DocumentBuilder()
    .setTitle('Triangle Black Hospitality Supply & Contracting OS')
    .setDescription(
      'API for TRIANGLE BLACK Operating System — Hospitality Supply & Contracting',
    )
    .setVersion('19.0.0')
    .addBearerAuth()
    .addTag('Auth')
    .addTag('Users')
    .addTag('Organizations')
    .addTag('Roles')
    .addTag('Permissions')
    .addTag('Hotels')
    .addTag('Contacts')
    .addTag('Partner Requests')
    .addTag('Site Visits')
    .addTag('Opportunities')
    .addTag('Proposals')
    .addTag('Projects')
    .addTag('Procurement')
    .addTag('Purchase Orders')
    .addTag('Vendors')
    .addTag('Emergency')
    .addTag('Contracts')
    .addTag('Documents')
    .addTag('Analytics')
    .addTag('Assistant')
    .addTag('Notifications')
    .addTag('Audit')
    .addTag('Health')
    .addTag('Administration')
    .addTag('RFQ')
    .addTag('Resource Planning')
    .addTag('CAPEX Intelligence')
    .addTag('Forecasting')
    .addTag('Hotel Digital Twin')
    .addTag('AI Copilot')
    .addTag('AI Usage')
    .addTag('File Processing')
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/v1/docs', app, document);

  // ── Start listening ────────────────────────────────────────────────
  const port = env.PORT;
  await app.listen(port);

  logger.logWithContext('TRIANGLE BLACK API started', {
    action: 'api.startup',
    metadata: {
      version: '19.0.0',
      port,
      nodeEnv: env.NODE_ENV,
      swaggerUrl: `http://localhost:${port}/api/v1/docs`,
    },
  });

  // ── Graceful shutdown ──────────────────────────────────────────────
  const shutdown = async (signal: string): Promise<void> => {
    logger.logWithContext(`Received ${signal} — shutting down gracefully`, {
      action: 'shutdown.initiated',
      metadata: { signal },
    });

    try {
      const prisma = app.get(PrismaService);
      await prisma.$disconnect();
      logger.logWithContext('Database connection closed', {
        action: 'shutdown.db_closed',
      });
    } catch (err) {
      logger.errorWithContext(
        'Error closing database connection',
        err instanceof Error ? err.stack : undefined,
        { action: 'shutdown.db_error' },
      );
    }

    try {
      await app.close();
      logger.logWithContext('NestJS application closed', {
        action: 'shutdown.app_closed',
      });
    } catch (err) {
      logger.errorWithContext(
        'Error closing application',
        err instanceof Error ? err.stack : undefined,
        { action: 'shutdown.app_error' },
      );
    }

    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

bootstrap().catch((err) => {
  // Fallback logging before NestJS is available
  process.stderr.write(
    `FATAL: bootstrap failed — ${err instanceof Error ? err.stack : String(err)}\n`,
  );
  process.exit(1);
});
