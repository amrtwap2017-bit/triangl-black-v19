import { Controller, Get, Post, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AdministrationService } from './administration.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { createResponse } from '../../common/dto/api-response.dto';

@ApiTags('Administration')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('admin')
export class AdministrationController {
  constructor(private readonly administrationService: AdministrationService) {}

  @Get('system-info')
  @ApiOperation({ summary: 'Get system information' })
  async getSystemInfo() {
    const result = await this.administrationService.getSystemInfo();
    return createResponse(result);
  }

  @Get('roles/permissions-matrix')
  @ApiOperation({ summary: 'Get roles-permissions matrix' })
  async getPermissionsMatrix() {
    const result = await this.administrationService.getPermissionsMatrix();
    return createResponse(result);
  }

  @Post('seed-permissions')
  @ApiOperation({ summary: 'Seed default permissions' })
  async seedPermissions() {
    const result = await this.administrationService.seedPermissions();
    return createResponse(result, 'Permissions seeded');
  }
}
