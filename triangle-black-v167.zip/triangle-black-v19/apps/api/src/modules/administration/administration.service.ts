import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';

@Injectable()
export class AdministrationService {
  private readonly logger = new Logger(AdministrationService.name);

  constructor(private readonly prisma: PrismaService) {}

  async getSystemInfo() {
    const [users, hotels, projects, opportunities, emergencies] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.hotel.count(),
      this.prisma.project.count(),
      this.prisma.opportunity.count(),
      this.prisma.emergencyCase.count(),
    ]);

    return {
      version: '16.0.0',
      environment: process.env.NODE_ENV || 'development',
      database: { status: 'connected', totalRecords: users + hotels + projects + opportunities + emergencies },
      counts: { users, hotels, projects, opportunities, emergencies },
    };
  }

  async getPermissionsMatrix() {
    const roles = await this.prisma.role.findMany({
      include: {
        rolePermissions: {
          include: { permission: true },
        },
      },
    });

    const permissions = await this.prisma.permission.findMany();
    const resources = [...new Set(permissions.map((p) => p.resource))];

    const matrix = roles.map((role) => {
      const permissionMap: Record<string, Record<string, boolean>> = {};
      for (const resource of resources) {
        permissionMap[resource] = {};
      }
      for (const rp of role.rolePermissions) {
        if (rp.permission.resource && permissionMap[rp.permission.resource]) {
          permissionMap[rp.permission.resource][rp.permission.action] = true;
        }
      }
      return {
        roleId: role.id,
        roleName: role.name,
        isSystem: role.isSystem,
        permissions: permissionMap,
      };
    });

    return { roles: matrix, resources };
  }

  async seedPermissions() {
    const resources = [
      'users', 'organizations', 'roles', 'permissions', 'hotels', 'contacts',
      'partner_requests', 'site_visits', 'opportunities', 'proposals',
      'projects', 'procurement_requests', 'purchase_orders', 'vendors',
      'emergencies', 'contracts', 'documents', 'analytics', 'assistant',
      'notifications', 'audit_logs', 'administration',
    ];
    const actions = ['create', 'read', 'update', 'delete', 'manage'];

    const created = [];
    for (const resource of resources) {
      for (const action of actions) {
        try {
          const permission = await this.prisma.permission.upsert({
            where: { name: `${resource}:${action}` },
            update: {},
            create: { name: `${resource}:${action}`, resource, action, description: `${action} ${resource}` },
          });
          created.push(permission);
        } catch (error) {
          this.logger.error(`Failed to create permission ${resource}:${action}`, error);
        }
      }
    }

    return { success: true, message: `Seeded ${created.length} permissions`, count: created.length };
  }
}
