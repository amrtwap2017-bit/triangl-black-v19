import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { AnalyticsService } from './services/analytics.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse } from '../../common/dto/api-response.dto';

@ApiTags('Analytics')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('analytics')
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

  @Get('revenue')
  @ApiOperation({ summary: 'Get revenue analytics' })
  @ApiQuery({ name: 'period', required: false })
  @ApiQuery({ name: 'hotelId', required: false })
  @ApiQuery({ name: 'projectType', required: false })
  async getRevenue(
    @CurrentUser('organizationId') orgId: string,
    @Query('period') period?: string,
    @Query('hotelId') hotelId?: string,
    @Query('projectType') projectType?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    const result = await this.analyticsService.getRevenue(orgId, { period, hotelId, projectType, startDate, endDate });
    return createResponse(result);
  }

  @Get('margins')
  @ApiOperation({ summary: 'Get margin analytics' })
  @ApiQuery({ name: 'hotelId', required: false })
  async getMargins(
    @CurrentUser('organizationId') orgId: string,
    @Query('hotelId') hotelId?: string,
    @Query('projectId') projectId?: string,
    @Query('period') period?: string,
  ) {
    const result = await this.analyticsService.getMargins(orgId, { hotelId, projectId, period });
    return createResponse(result);
  }

  @Get('pipeline')
  @ApiOperation({ summary: 'Get opportunity pipeline metrics' })
  async getPipeline(@CurrentUser('organizationId') orgId: string) {
    const result = await this.analyticsService.getPipelineMetrics(orgId);
    return createResponse(result);
  }

  @Get('hotel-relationships')
  @ApiOperation({ summary: 'Get hotel relationship scores' })
  async getHotelRelationships(@CurrentUser('organizationId') orgId: string) {
    const result = await this.analyticsService.getHotelRelationships(orgId);
    return createResponse(result);
  }

  @Get('emergency-metrics')
  @ApiOperation({ summary: 'Get emergency response metrics' })
  async getEmergencyMetrics(@CurrentUser('organizationId') orgId: string) {
    const result = await this.analyticsService.getEmergencyMetrics(orgId);
    return createResponse(result);
  }

  @Get('procurement-performance')
  @ApiOperation({ summary: 'Get procurement performance metrics' })
  async getProcurementPerformance(@CurrentUser('organizationId') orgId: string) {
    const result = await this.analyticsService.getProcurementPerformance(orgId);
    return createResponse(result);
  }

  @Get('executive-summary')
  @ApiOperation({ summary: 'Get executive summary KPIs' })
  async getExecutiveSummary(@CurrentUser('organizationId') orgId: string) {
    const result = await this.analyticsService.getExecutiveSummary(orgId);
    return createResponse(result);
  }
}
