export class AnalyticsRevenueQueryDto {
  period?: string;
  hotelId?: string;
  projectType?: string;
  startDate?: string;
  endDate?: string;
}

export class AnalyticsMarginsQueryDto {
  hotelId?: string;
  projectId?: string;
  period?: string;
}

export class AnalyticsPipelineQueryDto {
  hotelId?: string;
  startDate?: string;
  endDate?: string;
}
