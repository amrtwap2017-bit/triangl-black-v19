import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';

@Injectable()
export class AnalyticsService {
  private readonly logger = new Logger(AnalyticsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async getRevenue(organizationId: string, filters?: { period?: string; hotelId?: string; projectType?: string; startDate?: string; endDate?: string }) {
    const where: any = { organizationId, status: 'COMPLETED' };
    if (filters?.hotelId) where.hotelId = filters.hotelId;
    if (filters?.projectType) where.type = filters.projectType;
    if (filters?.startDate && filters?.endDate) {
      where.endDate = { gte: new Date(filters.startDate), lte: new Date(filters.endDate) };
    }

    const result = await this.prisma.project.aggregate({
      where,
      _sum: { revenue: true, actualCost: true },
      _count: true,
    });

    const monthlyRevenue = await this.prisma.project.groupBy({
      by: ['endDate'],
      where,
      _sum: { revenue: true },
    });

    return {
      totalRevenue: result._sum.revenue || 0,
      totalCost: result._sum.actualCost || 0,
      projectCount: result._count,
      monthlyBreakdown: monthlyRevenue.map((m) => ({
        month: m.endDate,
        revenue: m._sum.revenue || 0,
      })),
    };
  }

  async getMargins(organizationId: string, filters?: { hotelId?: string; projectId?: string; period?: string }) {
    const where: any = { organizationId };
    if (filters?.hotelId) where.hotelId = filters.hotelId;

    const projects = await this.prisma.project.findMany({
      where,
      select: { id: true, name: true, revenue: true, actualCost: true, hotelId: true },
    });

    const margins = projects.map((p) => {
      const revenue = p.revenue || 0;
      const cost = p.actualCost || 0;
      const margin = revenue - cost;
      return {
        projectId: p.id,
        projectName: p.name,
        revenue,
        cost,
        margin,
        marginPercent: revenue > 0 ? ((margin / revenue) * 100) : 0,
      };
    });

    const avgMargin = margins.length > 0
      ? margins.reduce((sum, m) => sum + m.marginPercent, 0) / margins.length
      : 0;

    return { projects: margins, averageMargin: avgMargin };
  }

  async getPipelineMetrics(organizationId: string) {
    const opportunities = await this.prisma.opportunity.findMany({
      where: { organizationId },
    });

    const byStatus: Record<string, { count: number; totalValue: number; weightedValue: number }> = {};
    for (const status of ['PROSPECTING', 'QUALIFICATION', 'PROPOSAL', 'NEGOTIATION', 'CLOSED_WON', 'CLOSED_LOST']) {
      const items = opportunities.filter((o) => o.status === status);
      byStatus[status] = {
        count: items.length,
        totalValue: items.reduce((s, o) => s + (o.value || 0), 0),
        weightedValue: items.reduce((s, o) => s + ((o.value || 0) * ((o.probability || 0) / 100)), 0),
      };
    }

    const openOpportunities = opportunities.filter((o) => !['CLOSED_WON', 'CLOSED_LOST'].includes(o.status));
    const winRate = opportunities.length > 0
      ? opportunities.filter((o) => o.status === 'CLOSED_WON').length / opportunities.length
      : 0;

    return { byStatus, totalOpenValue: openOpportunities.reduce((s, o) => s + (o.value || 0), 0), winRate };
  }

  async getHotelRelationships(organizationId: string) {
    const relationships = await this.prisma.hotelRelationship.findMany({
      where: { organizationId },
      include: { hotel: true },
      orderBy: { relationshipScore: 'desc' },
    });
    return relationships;
  }

  async getEmergencyMetrics(organizationId: string) {
    const emergencies = await this.prisma.emergencyCase.findMany({
      where: { organizationId },
    });

    const avgResponseTime = emergencies.filter((e) => e.responseTime).length > 0
      ? emergencies.filter((e) => e.responseTime).reduce((s, e) => s + (e.responseTime || 0), 0) / emergencies.filter((e) => e.responseTime).length
      : 0;

    const avgResolutionTime = emergencies.filter((e) => e.resolutionTime).length > 0
      ? emergencies.filter((e) => e.resolutionTime).reduce((s, e) => s + (e.resolutionTime || 0), 0) / emergencies.filter((e) => e.resolutionTime).length
      : 0;

    const SLA_TARGETS: Record<string, number> = { CRITICAL: 30, HIGH: 60, MEDIUM: 120, LOW: 240 };
    const slaCompliant = emergencies.filter((e) => e.responseTime && e.responseTime <= (SLA_TARGETS[e.severity] || 120)).length;
    const slaComplianceRate = emergencies.length > 0 ? slaCompliant / emergencies.length : 0;

    return {
      totalCases: emergencies.length,
      openCases: emergencies.filter((e) => ['OPEN', 'IN_PROGRESS', 'CONTAINED'].includes(e.status)).length,
      resolvedCases: emergencies.filter((e) => e.status === 'RESOLVED').length,
      avgResponseTime,
      avgResolutionTime,
      slaComplianceRate,
    };
  }

  async getProcurementPerformance(organizationId: string) {
    const purchaseOrders = await this.prisma.purchaseOrder.findMany({
      where: { organizationId },
      include: { vendor: true },
    });

    const totalPOs = purchaseOrders.length;
    const completedPOs = purchaseOrders.filter((po) => po.status === 'RECEIVED');
    const avgQualityRating = completedPOs.filter((po) => po.qualityRating).length > 0
      ? completedPOs.filter((po) => po.qualityRating).reduce((s, po) => s + (po.qualityRating || 0), 0) / completedPOs.filter((po) => po.qualityRating).length
      : 0;

    const totalAmount = purchaseOrders.reduce((s, po) => s + po.amount, 0);

    const byVendor = purchaseOrders.reduce<Record<string, { name: string; count: number; totalAmount: number; avgRating: number }>>((acc, po) => {
      const vendorName = po.vendor?.name || 'Unknown';
      if (!acc[po.vendorId || 'unknown']) {
        acc[po.vendorId || 'unknown'] = { name: vendorName, count: 0, totalAmount: 0, avgRating: 0 };
      }
      acc[po.vendorId || 'unknown'].count++;
      acc[po.vendorId || 'unknown'].totalAmount += po.amount;
      return acc;
    }, {});

    return { totalPOs, completedPOs: completedPOs.length, avgQualityRating, totalAmount, byVendor: Object.values(byVendor) };
  }

  async getExecutiveSummary(organizationId: string) {
    const [hotels, projects, opportunities, emergencies, revenue] = await Promise.all([
      this.prisma.hotel.count({ where: { organizationId } }),
      this.prisma.project.count({ where: { organizationId } }),
      this.prisma.opportunity.count({ where: { organizationId } }),
      this.prisma.emergencyCase.count({ where: { organizationId, status: { in: ['OPEN', 'IN_PROGRESS', 'CONTAINED'] } } }),
      this.prisma.project.aggregate({ where: { organizationId, status: 'COMPLETED' }, _sum: { revenue: true } }),
    ]);

    const openProposals = await this.prisma.proposal.count({ where: { organizationId, status: { in: ['DRAFT', 'SENT', 'PRESENTED'] } } });
    const activeProjects = await this.prisma.project.count({ where: { organizationId, status: 'ACTIVE' } });

    return {
      totalHotels: hotels,
      totalProjects: projects,
      activeProjects,
      openOpportunities: opportunities,
      openProposals,
      activeEmergencies: emergencies,
      totalRevenue: revenue._sum.revenue || 0,
    };
  }
}
