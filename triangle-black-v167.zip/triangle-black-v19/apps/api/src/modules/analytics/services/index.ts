import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';

@Injectable()
export class AnalyticsBusinessService {
  private readonly logger = new Logger(AnalyticsBusinessService.name);

  constructor(private readonly prisma: PrismaService) {}

  async generateSnapshot(organizationId: string, period: string, metric: string, value: number, metadata?: any) {
    return this.prisma.analyticsSnapshot.create({
      data: {
        organizationId,
        period,
        periodDate: new Date(),
        metric,
        value,
        metadata,
      },
    });
  }
}
