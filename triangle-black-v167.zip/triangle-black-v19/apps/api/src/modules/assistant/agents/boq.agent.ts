import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';

@Injectable()
export class BoqAgent {
  private readonly logger = new Logger(BoqAgent.name);
  private readonly agentType = 'BOQ';
  private readonly model = 'placeholder-model';

  constructor(private readonly prisma: PrismaService) {}

  async generate(organizationId: string, userId: string, data: any) {
    const prompt = `Generate BOQ for: ${JSON.stringify(data)}`;
    const response = JSON.stringify({
      items: [
        { item: 'Material Supply', description: data.description, quantity: 1, unit: 'LOT', unitPrice: 0, total: 0 },
        { item: 'Installation Labor', description: 'Standard installation', quantity: 1, unit: 'LOT', unitPrice: 0, total: 0 },
        { item: 'Quality Assurance', description: 'Testing and commissioning', quantity: 1, unit: 'LOT', unitPrice: 0, total: 0 },
      ],
      note: 'Prices to be updated based on actual quotation',
    });

    await this.log(organizationId, userId, prompt, response);
    return JSON.parse(response);
  }

  private async log(organizationId: string, userId: string, prompt: string, response: string) {
    await this.prisma.aIInteraction.create({
      data: { organizationId, userId, agentType: this.agentType, prompt, response, model: this.model, promptTokens: prompt.length, completionTokens: response.length },
    });
  }
}
