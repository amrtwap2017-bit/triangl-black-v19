import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';

@Injectable()
export class ProposalAgent {
  private readonly logger = new Logger(ProposalAgent.name);
  private readonly agentType = 'PROPOSAL';
  private readonly model = 'placeholder-model';

  constructor(private readonly prisma: PrismaService) {}

  async generate(organizationId: string, userId: string, data: any) {
    const prompt = `Generate proposal draft for: ${JSON.stringify(data)}`;
    const response = JSON.stringify({
      title: `Proposal for ${data.hotelName || 'Client'}`,
      executiveSummary: 'AI-generated executive summary placeholder',
      scopeOfWork: data.scope || 'Full scope to be defined based on site assessment',
      assumptions: 'Standard industry assumptions apply',
      exclusions: 'To be defined in detailed scope review',
    });

    await this.logInteraction(organizationId, userId, prompt, response);
    return JSON.parse(response);
  }

  private async logInteraction(organizationId: string, userId: string, prompt: string, response: string) {
    await this.prisma.aIInteraction.create({
      data: {
        organizationId,
        userId,
        agentType: this.agentType,
        prompt,
        response,
        model: this.model,
        promptTokens: prompt.length,
        completionTokens: response.length,
      },
    });
  }
}
