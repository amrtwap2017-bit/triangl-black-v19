import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';

@Injectable()
export class SummaryAgent {
  private readonly agentType = 'SUMMARY';
  private readonly model = 'placeholder-model';

  constructor(private readonly prisma: PrismaService) {}

  async generate(organizationId: string, userId: string, data: any) {
    const prompt = `Generate executive summary for: ${JSON.stringify(data)}`;
    const response = JSON.stringify({
      highlights: ['Strong pipeline growth', 'Emergency response times within SLA targets', 'Project margin improvements'],
      concerns: ['Resource utilization needs optimization', 'Vendor lead times trending upward'],
      recommendations: ['Invest in project management capacity', 'Diversify vendor base'],
      nextSteps: ['Review pipeline for Q2 opportunities', 'Schedule vendor performance reviews'],
    });

    await this.prisma.aIInteraction.create({
      data: { organizationId, userId, agentType: this.agentType, prompt, response, model: this.model, promptTokens: prompt.length, completionTokens: response.length },
    });
    return JSON.parse(response);
  }
}
