/**
 * Triangle Black v19 — AI Copilot Controller
 *
 * REST endpoints for the AI Copilot with JWT auth, tenant guard,
 * and comprehensive Swagger documentation.
 */

import {
  Controller,
  Post,
  Get,
  Delete,
  Body,
  Query,
  Param,
  UseGuards,
  Res,
  Sse,
  Logger,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery, ApiResponse } from '@nestjs/swagger';
import { Response } from 'express';
import { Observable } from 'rxjs';
import { AssistantService } from './assistant.service';
import { ChatDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('AI Copilot')
@ApiBearerAuth()
@Controller('assistant')
@UseGuards(JwtAuthGuard, TenantGuard)
export class AssistantController {
  private readonly logger = new Logger(AssistantController.name);

  constructor(private readonly assistantService: AssistantService) {}

  @Post('chat')
  @ApiOperation({ summary: 'Chat with AI Copilot' })
  @ApiResponse({ status: 200, description: 'AI response with metadata' })
  @ApiResponse({ status: 403, description: 'Blocked by security system' })
  async chat(
    @CurrentUser('organizationId') organizationId: string,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') role: string,
    @Body() dto: ChatDto,
  ) {
    return this.assistantService.chat(organizationId, userId, dto);
  }

  @Get('chat/stream')
  @ApiOperation({ summary: 'Stream AI chat via SSE' })
  @Sse()
  @ApiResponse({ status: 200, description: 'SSE stream of AI response chunks' })
  streamChat(
    @Query('message') message: string,
    @Query('agentType') agentType?: string,
    @Query('conversationId') conversationId?: string,
  ): Observable<string> {
    // Note: In production this would be a proper Observable wrapping the async generator.
    // For now, returning a simple Observable.
    const dto: ChatDto = { message, agentType: agentType as any, conversationId };
    const gen = this.assistantService.streamChat('default', 'default', dto);

    return new Observable<string>((subscriber) => {
      (async () => {
        try {
          for await (const chunk of gen) {
            subscriber.next(chunk);
          }
          subscriber.complete();
        } catch (err) {
          subscriber.error(err);
        }
      })();
    });
  }

  @Get('conversations')
  @ApiOperation({ summary: 'List conversations' })
  @ApiQuery({ name: 'page', required: false, type: Number })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  async getConversations(
    @CurrentUser('organizationId') organizationId: string,
    @CurrentUser('id') userId: string,
    @Query('page') page = 1,
    @Query('limit') limit = 20,
  ) {
    return this.assistantService.getConversations(organizationId, userId, +page, +limit);
  }

  @Get('conversations/:id')
  @ApiOperation({ summary: 'Get conversation with messages' })
  async getConversation(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
  ) {
    return this.assistantService.getConversationMessages(id, userId);
  }

  @Delete('conversations/:id')
  @ApiOperation({ summary: 'Delete a conversation (soft delete)' })
  async deleteConversation(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
  ) {
    await this.assistantService.deleteConversation(id, userId);
    return { success: true };
  }

  @Get('usage')
  @ApiOperation({ summary: 'Get current user AI usage' })
  async getUserUsage(
    @CurrentUser('organizationId') organizationId: string,
    @CurrentUser('id') userId: string,
    @Query('period') period: string,
  ) {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1); // Current month
    return this.assistantService.getUsageSummary(organizationId, { start, end: now });
  }

  @Get('usage/summary')
  @ApiOperation({ summary: 'Get organization usage summary (admin only)' })
  @UseGuards(PermissionsGuard)
  @Roles('ADMIN')
  @Permissions('analytics.read')
  @ApiQuery({ name: 'startDate', required: false, type: String })
  @ApiQuery({ name: 'endDate', required: false, type: String })
  async getUsageSummary(
    @CurrentUser('organizationId') organizationId: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    const start = startDate ? new Date(startDate) : new Date(new Date().getFullYear(), 0, 1);
    const end = endDate ? new Date(endDate) : new Date();
    return this.assistantService.getUsageSummary(organizationId, { start, end });
  }
}
