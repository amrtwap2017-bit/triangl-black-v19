import { Module } from '@nestjs/common';
import { AssistantController } from './assistant.controller';
import { AssistantService } from './assistant.service';
import { ProposalAgent } from './agents/proposal.agent';
import { BoqAgent } from './agents/boq.agent';
import { ProcurementAgent } from './agents/procurement.agent';
import { SiteVisitAgent } from './agents/site-visit.agent';
import { RiskAgent } from './agents/risk.agent';
import { SummaryAgent } from './agents/summary.agent';

@Module({
  controllers: [AssistantController],
  providers: [AssistantService, ProposalAgent, BoqAgent, ProcurementAgent, SiteVisitAgent, RiskAgent, SummaryAgent],
  exports: [AssistantService],
})
export class AssistantModule {}
