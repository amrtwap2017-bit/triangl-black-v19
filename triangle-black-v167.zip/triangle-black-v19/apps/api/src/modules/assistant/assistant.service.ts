/**
 * Triangle Black v19 — AI Copilot Service
 *
 * Full-featured AI assistant with security pipeline, agent routing,
 * tool execution, streaming, conversation management, and usage tracking.
 */

import { Injectable, Logger, ForbiddenException, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { AgentFactory, AgentRouter, AgentType } from '@triangleblack/agents';
import { PromptInjectionDetector, DataLeakagePrevention, TenantIsolation, AiAuditLogger } from '@triangleblack/ai-security';
import { TokenManager } from '@triangleblack/ai-core';
import type { AIProvider, AIMessage } from '@triangleblack/ai-core';
import { ChatDto } from './dto';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ChatResponse {
  content: string;
  conversationId: string;
  agentType: AgentType;
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    cost: number;
  };
  latencyMs: number;
  metadata?: Record<string, unknown>;
}

export interface ConversationSummary {
  id: string;
  title: string;
  agentType: string;
  messageCount: number;
  lastMessageAt: string;
  createdAt: string;
}

@Injectable()
export class AssistantService {
  private readonly logger = new Logger(AssistantService.name);
  private readonly provider: AIProvider;
  private readonly router: AgentRouter;
  private readonly injectionDetector: PromptInjectionDetector;
  private readonly dlp: DataLeakagePrevention;
  private readonly tenantIsolation: TenantIsolation;

  constructor(
    private readonly prisma: PrismaService,
  ) {
    // In production, these would be injected via module providers
    this.provider = AgentFactory.getMemory ? AgentFactory.createAgent(AgentType.ASSISTANT)['provider'] as AIProvider : null as any;
    this.router = new AgentRouter();
    this.injectionDetector = new PromptInjectionDetector();
    this.dlp = new DataLeakagePrevention();
    this.tenantIsolation = new TenantIsolation();
  }

  /**
   * Main chat endpoint — full security pipeline + agent routing + tool execution.
   */
  async chat(
    organizationId: string,
    userId: string,
    dto: ChatDto,
  ): Promise<ChatResponse> {
    const startMs = Date.now();

    // 1. Validate user has permission (AI_CHAT)
    // (In production, this would check user permissions against the permissions table)

    // 2. Run prompt injection detection → block if score > 30
    const injectionResult = PromptInjectionDetector.detect(dto.message);
    if (!injectionResult.safe) {
      this.logger.warn(`Prompt injection blocked — score: ${injectionResult.score}, patterns: ${injectionResult.patterns.join(', ')}`);
      throw new ForbiddenException('Your message was flagged by our security system. Please rephrase your request.');
    }

    // 3. Run DLP check → log findings
    const dlpResult = DataLeakagePrevention.detectSensitiveData(dto.message);
    if (!dlpResult.safe) {
      this.logger.warn(`DLP findings for user ${userId}: ${JSON.stringify(dlpResult.findings.map((f) => f.type))}`);
    }

    // 4. Cross-tenant validation
    if (!TenantIsolation.validateQuery(dto.message, organizationId)) {
      this.logger.warn(`Cross-tenant reference attempt by user ${userId} in org ${organizationId}`);
      throw new ForbiddenException('Invalid request. Cross-tenant data access is not permitted.');
    }

    // 5. Get or create conversation
    let conversationId = dto.conversationId;
    if (!conversationId) {
      const conversation = await this.prisma.conversation.create({
        data: {
          organizationId,
          userId,
          title: dto.message.slice(0, 100),
          agentType: AgentType.ASSISTANT,
        },
      });
      conversationId = conversation.id;
    } else {
      // Verify ownership
      const existing = await this.prisma.conversation.findFirst({
        where: { id: conversationId, organizationId, userId },
      });
      if (!existing) {
        throw new NotFoundException('Conversation not found');
      }
    }

    // 6. Route to appropriate agent
    const routingResult = this.router.routeQuery(dto.message, {
      organizationId,
      userId,
    });

    // 7. Process through agent
    const agent = AgentFactory.createAgent(routingResult.agentType);
    const agentResponse = await agent.processMessage(dto.message, {
      organizationId,
      userId,
      conversationId,
    });

    // 8. Store messages in DB
    await this.prisma.aIInteraction.create({
      data: {
        organizationId,
        userId,
        agentType: routingResult.agentType,
        prompt: dto.message,
        response: agentResponse.content,
        model: agentResponse.model ?? 'unknown',
        promptTokens: agentResponse.usage.promptTokens,
        completionTokens: agentResponse.usage.completionTokens,
      },
    });

    const latencyMs = Date.now() - startMs;

    // 9. Track AI usage
    const cost = TokenManager.calculateCost(
      agentResponse.model ?? 'gpt-4o',
      agentResponse.usage.promptTokens,
      agentResponse.usage.completionTokens,
    );

    // 10. Audit log
    AiAuditLogger.logInteraction({
      organizationId,
      userId,
      agentType: routingResult.agentType,
      prompt: dto.message,
      response: agentResponse.content,
      model: agentResponse.model ?? 'unknown',
      tokensUsed: agentResponse.usage.totalTokens,
      cost,
      durationMs: latencyMs,
    });

    return {
      content: agentResponse.content,
      conversationId: conversationId!,
      agentType: routingResult.agentType,
      usage: {
        promptTokens: agentResponse.usage.promptTokens,
        completionTokens: agentResponse.usage.completionTokens,
        totalTokens: agentResponse.usage.totalTokens,
        cost,
      },
      latencyMs,
      metadata: agentResponse.metadata,
    };
  }

  /**
   * Stream chat — returns an async iterable for SSE streaming.
   */
  async *streamChat(
    organizationId: string,
    userId: string,
    dto: ChatDto,
  ): AsyncGenerator<string> {
    // Same security checks as chat
    const injectionResult = PromptInjectionDetector.detect(dto.message);
    if (!injectionResult.safe) {
      yield JSON.stringify({ type: 'error', content: 'Message blocked by security system.' });
      return;
    }

    const dlpResult = DataLeakagePrevention.detectSensitiveData(dto.message);
    if (dlpResult.findings.length > 0) {
      // Log but allow
    }

    if (!TenantIsolation.validateQuery(dto.message, organizationId)) {
      yield JSON.stringify({ type: 'error', content: 'Invalid request.' });
      return;
    }

    // Get or create conversation
    let conversationId = dto.conversationId;
    if (!conversationId) {
      const conversation = await this.prisma.conversation.create({
        data: {
          organizationId,
          userId,
          title: dto.message.slice(0, 100),
          agentType: AgentType.ASSISTANT,
        },
      });
      conversationId = conversation.id;
    }

    const routingResult = this.router.routeQuery(dto.message, { organizationId, userId });

    // Stream from the agent
    const agent = AgentFactory.createAgent(routingResult.agentType);
    const provider = (agent as any).provider as AIProvider;

    if (provider?.streamChat) {
      const systemPrompt = (agent as any).getSystemPrompt() as AIMessage;
      const messages: AIMessage[] = [
        systemPrompt,
        { role: 'user', content: dto.message },
      ];

      let fullContent = '';
      for await (const chunk of provider.streamChat(messages)) {
        if (chunk.done) break;
        if (chunk.chunk) {
          fullContent += chunk.chunk;
          yield JSON.stringify({ type: 'chunk', content: chunk.chunk, conversationId });
        }
      }

      // Store the complete interaction
      await this.prisma.aIInteraction.create({
        data: {
          organizationId,
          userId,
          agentType: routingResult.agentType,
          prompt: dto.message,
          response: fullContent,
          model: 'streamed',
          promptTokens: 0,
          completionTokens: 0,
        },
      });

      yield JSON.stringify({ type: 'done', conversationId });
    } else {
      // Fallback to non-streaming
      const response = await this.chat(organizationId, userId, dto);
      yield JSON.stringify({ type: 'chunk', content: response.content, conversationId: response.conversationId });
      yield JSON.stringify({ type: 'done', conversationId: response.conversationId });
    }
  }

  /**
   * List conversations for a user with pagination.
   */
  async getConversations(
    organizationId: string,
    userId: string,
    page = 1,
    limit = 20,
  ): Promise<{ data: ConversationSummary[]; total: number; page: number; limit: number }> {
    const [conversations, total] = await Promise.all([
      this.prisma.conversation.findMany({
        where: { organizationId, userId, deletedAt: null },
        orderBy: { updatedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.conversation.count({
        where: { organizationId, userId, deletedAt: null },
      }),
    ]);

    // Get message counts
    const data: ConversationSummary[] = await Promise.all(
      conversations.map(async (conv) => {
        const messageCount = await this.prisma.aIInteraction.count({
          where: { organizationId, userId },
        });
        return {
          id: conv.id,
          title: conv.title,
          agentType: (conv as any).agentType ?? 'ASSISTANT',
          messageCount,
          lastMessageAt: conv.updatedAt.toISOString(),
          createdAt: conv.createdAt.toISOString(),
        };
      }),
    );

    return { data, total, page, limit };
  }

  /**
   * Get conversation messages.
   */
  async getConversationMessages(
    conversationId: string,
    userId: string,
  ) {
    const conversation = await this.prisma.conversation.findFirst({
      where: { id: conversationId, userId },
    });
    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    return this.prisma.aIInteraction.findMany({
      where: { conversationId },
      orderBy: { createdAt: 'asc' },
    });
  }

  /**
   * Soft-delete a conversation.
   */
  async deleteConversation(
    conversationId: string,
    userId: string,
  ): Promise<void> {
    const conversation = await this.prisma.conversation.findFirst({
      where: { id: conversationId, userId },
    });
    if (!conversation) {
      throw new NotFoundException('Conversation not found');
    }

    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: { deletedAt: new Date() },
    });
  }

  /**
   * Get usage summary for an organization.
   */
  async getUsageSummary(
    organizationId: string,
    period: { start: Date; end: Date },
  ) {
    const interactions = await this.prisma.aIInteraction.findMany({
      where: {
        organizationId,
        createdAt: { gte: period.start, lte: period.end },
      },
    });

    const totalTokens = interactions.reduce((sum, i) => sum + (i.promptTokens ?? 0) + (i.completionTokens ?? 0), 0);
    const totalCost = interactions.reduce((sum, i) => {
      return sum + TokenManager.calculateCost(i.model ?? 'gpt-4o', i.promptTokens ?? 0, i.completionTokens ?? 0);
    }, 0);

    const byAgent: Record<string, { count: number; tokens: number; cost: number }> = {};
    for (const i of interactions) {
      const agent = i.agentType ?? 'UNKNOWN';
      if (!byAgent[agent]) byAgent[agent] = { count: 0, tokens: 0, cost: 0 };
      byAgent[agent].count++;
      byAgent[agent].tokens += (i.promptTokens ?? 0) + (i.completionTokens ?? 0);
      byAgent[agent].cost += TokenManager.calculateCost(i.model ?? 'gpt-4o', i.promptTokens ?? 0, i.completionTokens ?? 0);
    }

    return {
      period: { start: period.start.toISOString(), end: period.end.toISOString() },
      totalInteractions: interactions.length,
      totalTokens,
      totalCost,
      byAgent,
    };
  }
}
