import { IsString, IsOptional, IsEnum, IsObject, IsNotEmpty, MaxLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { AgentType } from '@triangleblack/agents';

export class ChatDto {
  @ApiProperty({ description: 'User message to send to AI' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(10000)
  message: string;

  @ApiPropertyOptional({ description: 'Target agent type (auto-detected if not specified)', enum: AgentType })
  @IsOptional()
  @IsEnum(AgentType)
  agentType?: AgentType;

  @ApiPropertyOptional({ description: 'Conversation ID for context continuation' })
  @IsOptional()
  @IsString()
  conversationId?: string;

  @ApiPropertyOptional({ description: 'Additional context data' })
  @IsOptional()
  @IsObject()
  context?: Record<string, unknown>;
}
