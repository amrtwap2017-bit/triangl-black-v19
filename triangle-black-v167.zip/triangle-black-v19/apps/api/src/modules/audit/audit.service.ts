import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class AuditService {
  private readonly logger = new Logger(AuditService.name);

  constructor(private readonly prisma: PrismaService) {}

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { resource?: string; userId?: string; startDate?: string; endDate?: string }) {
    const { page, limit, sortBy, sortOrder } = pagination;
    const { skip, take } = calculatePagination(page, limit);

    const where: any = { organizationId };
    if (filters?.resource) where.resource = filters.resource;
    if (filters?.userId) where.userId = filters.userId;
    if (filters?.startDate && filters?.endDate) {
      where.createdAt = { gte: new Date(filters.startDate), lte: new Date(filters.endDate) };
    }

    const [data, total] = await Promise.all([
      this.prisma.auditLog.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder } }),
      this.prisma.auditLog.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async exportCsv(organizationId: string, filters?: { resource?: string; userId?: string; startDate?: string; endDate?: string }) {
    const where: any = { organizationId };
    if (filters?.resource) where.resource = filters.resource;
    if (filters?.userId) where.userId = filters.userId;
    if (filters?.startDate && filters?.endDate) {
      where.createdAt = { gte: new Date(filters.startDate), lte: new Date(filters.endDate) };
    }

    const logs = await this.prisma.auditLog.findMany({ where, orderBy: { createdAt: 'desc' } });

    const headers = 'ID,Action,Resource,ResourceId,UserId,CreatedAt,IPAddress\n';
    const rows = logs.map((log) =>
      `${log.id},${log.action},${log.resource},${log.resourceId || ''},${log.userId || ''},${log.createdAt.toISOString()},${log.ipAddress || ''}`
    ).join('\n');

    return { csv: headers + rows, totalRecords: logs.length };
  }
}
