import { Injectable, UnauthorizedException, ConflictException, Logger } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { SecurityService } from '../../infrastructure/security/security.service';
import { ConfigService } from '@nestjs/config';
import { LoginDto, RegisterDto, RefreshTokenDto } from './dto';
import { JwtPayload } from '../../common/interfaces';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly securityService: SecurityService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async login(dto: LoginDto) {
    try {
      const user = await this.prisma.user.findUnique({
        where: { email: dto.email },
        include: {
          userRoles: {
            include: { role: { include: { rolePermissions: { include: { permission: true } } } } },
          },
          organization: true,
        },
      });

      if (!user) {
        throw new UnauthorizedException('Invalid credentials');
      }

      if (!user.isActive) {
        throw new UnauthorizedException('Account is deactivated');
      }

      const isPasswordValid = await this.securityService.comparePasswords(dto.password, user.passwordHash);
      if (!isPasswordValid) {
        throw new UnauthorizedException('Invalid credentials');
      }

      const roles = user.userRoles.map((ur) => ur.role.name);
      const payload: JwtPayload = {
        sub: user.id,
        email: user.email,
        organizationId: user.organizationId,
        roles,
      };

      const accessToken = this.securityService.generateToken(payload);
      const refreshToken = this.securityService.generateRefreshToken();
      const refreshJwt = this.securityService.generateRefreshJwt(payload);

      const refreshTokenExpiry = new Date();
      refreshTokenExpiry.setDate(refreshTokenExpiry.getDate() + 7);

      await this.prisma.refreshToken.create({
        data: {
          token: refreshToken,
          userId: user.id,
          expiresAt: refreshTokenExpiry,
        },
      });

      await this.prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      const { passwordHash, ...userWithoutPassword } = user;

      return {
        accessToken,
        refreshToken: refreshJwt,
        user: {
          ...userWithoutPassword,
          roles,
          permissions: user.userRoles.flatMap((ur) => ur.role.rolePermissions.map((rp) => rp.permission.name)),
        },
      };
    } catch (error) {
      if (error instanceof UnauthorizedException) throw error;
      this.logger.error('Login error:', error);
      throw new UnauthorizedException('Authentication failed');
    }
  }

  async register(dto: RegisterDto) {
    try {
      const existingUser = await this.prisma.user.findUnique({ where: { email: dto.email } });
      if (existingUser) {
        throw new ConflictException('Email already registered');
      }

      const slug = dto.organizationName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

      const passwordHash = await this.securityService.hashPassword(dto.password);

      const organization = await this.prisma.organization.create({
        data: {
          name: dto.organizationName,
          slug,
          isActive: true,
        },
      });

      const user = await this.prisma.user.create({
        data: {
          email: dto.email,
          passwordHash,
          name: dto.name,
          organizationId: organization.id,
          isActive: true,
        },
      });

      const adminRole = await this.prisma.role.create({
        data: {
          name: 'ADMIN',
          description: 'Administrator with full access',
          organizationId: organization.id,
          isSystem: false,
        },
      });

      const memberRole = await this.prisma.role.create({
        data: {
          name: 'MEMBER',
          description: 'Standard member',
          organizationId: organization.id,
          isSystem: false,
        },
      });

      await this.prisma.userRole.create({
        data: { userId: user.id, roleId: adminRole.id },
      });

      const permissions = await this.prisma.permission.findMany();
      for (const permission of permissions) {
        await this.prisma.rolePermission.create({
          data: { roleId: adminRole.id, permissionId: permission.id },
        });
      }

      const roles = [adminRole.name];
      const payload: JwtPayload = {
        sub: user.id,
        email: user.email,
        organizationId: organization.id,
        roles,
      };

      const accessToken = this.securityService.generateToken(payload);
      const refreshToken = this.securityService.generateRefreshToken();
      const refreshJwt = this.securityService.generateRefreshJwt(payload);

      const refreshTokenExpiry = new Date();
      refreshTokenExpiry.setDate(refreshTokenExpiry.getDate() + 7);

      await this.prisma.refreshToken.create({
        data: {
          token: refreshToken,
          userId: user.id,
          expiresAt: refreshTokenExpiry,
        },
      });

      return {
        accessToken,
        refreshToken: refreshJwt,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          organizationId: organization.id,
          roles,
        },
      };
    } catch (error) {
      if (error instanceof ConflictException) throw error;
      this.logger.error('Registration error:', error);
      throw error;
    }
  }

  async refreshTokens(dto: RefreshTokenDto) {
    try {
      const payload = this.securityService.verifyRefreshTokenPayload(dto.refreshToken);
      if (!payload) {
        throw new UnauthorizedException('Invalid refresh token');
      }

      const user = await this.prisma.user.findUnique({
        where: { id: payload.userId },
        include: {
          userRoles: { include: { role: true } },
        },
      });

      if (!user || !user.isActive) {
        throw new UnauthorizedException('User not found or inactive');
      }

      const roles = user.userRoles.map((ur) => ur.role.name);
      const newPayload: JwtPayload = {
        sub: user.id,
        email: user.email,
        organizationId: user.organizationId,
        roles,
      };

      const accessToken = this.securityService.generateToken(newPayload);
      const newRefreshJwt = this.securityService.generateRefreshJwt(newPayload);

      return {
        accessToken,
        refreshToken: newRefreshJwt,
      };
    } catch (error) {
      if (error instanceof UnauthorizedException) throw error;
      this.logger.error('Refresh token error:', error);
      throw new UnauthorizedException('Invalid refresh token');
    }
  }

  async logout(refreshToken: string) {
    try {
      const payload = this.securityService.verifyRefreshTokenPayload(refreshToken);
      if (payload) {
        await this.prisma.refreshToken.deleteMany({
          where: { userId: payload.userId },
        });
      }
      return { success: true, message: 'Logged out successfully' };
    } catch (error) {
      this.logger.error('Logout error:', error);
      return { success: true, message: 'Logged out successfully' };
    }
  }

  async getMe(userId: string) {
    try {
      const user = await this.prisma.user.findUnique({
        where: { id: userId },
        include: {
          userRoles: {
            include: {
              role: { include: { rolePermissions: { include: { permission: true } } } },
            },
          },
          organization: true,
        },
      });

      if (!user) {
        throw new UnauthorizedException('User not found');
      }

      const { passwordHash, ...userWithoutPassword } = user;
      return {
        ...userWithoutPassword,
        roles: user.userRoles.map((ur) => ur.role),
        permissions: user.userRoles.flatMap((ur) => ur.role.rolePermissions.map((rp) => rp.permission)),
      };
    } catch (error) {
      if (error instanceof UnauthorizedException) throw error;
      this.logger.error('GetMe error:', error);
      throw error;
    }
  }
}
