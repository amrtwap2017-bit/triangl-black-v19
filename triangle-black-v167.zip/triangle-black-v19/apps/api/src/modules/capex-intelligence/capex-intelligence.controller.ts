import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { CapexIntelligenceService } from './capex-intelligence.service';
import { CreateCapexPlanDto, CreateCapexItemDto, GenerateCapexPlanDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('CAPEX Intelligence')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('capex-plans')
export class CapexIntelligenceController {
  constructor(private readonly capexService: CapexIntelligenceService) {}

  @Post()
  @ApiOperation({ summary: 'Create a CAPEX plan' })
  @Roles('admin', 'finance_manager', 'hotel_manager')
  async create(@Body() dto: CreateCapexPlanDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.capexService.create(dto);
    return createResponse(result, 'CAPEX plan created');
  }

  @Get()
  @ApiOperation({ summary: 'List all CAPEX plans' })
  async findAll(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string, @Query('status') status?: string) {
    const result = await this.capexService.findAll(orgId, pagination, { status });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('hotel/:hotelId')
  @ApiOperation({ summary: 'Get CAPEX plans for a specific hotel' })
  async findByHotel(@Param('hotelId', ParseUUIDPipe) hotelId: string) {
    const result = await this.capexService.findByHotel(hotelId);
    return createResponse(result);
  }

  @Post('generate')
  @ApiOperation({ summary: 'Generate 5-year CAPEX plan for a hotel' })
  @Roles('admin', 'finance_manager')
  async generate(@Body() dto: GenerateCapexPlanDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.capexService.generatePlan(dto);
    return createResponse(result, '5-year CAPEX plan generated');
  }

  @Get('roadmap/:hotelId')
  @ApiOperation({ summary: 'Get asset replacement roadmap for a hotel' })
  async getRoadmap(@Param('hotelId', ParseUUIDPipe) hotelId: string) {
    const result = await this.capexService.getRoadmap(hotelId);
    return createResponse(result);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get CAPEX plan by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.capexService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update CAPEX plan' })
  @Roles('admin', 'finance_manager')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateCapexPlanDto) {
    const result = await this.capexService.update(id, dto);
    return createResponse(result, 'CAPEX plan updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete CAPEX plan (soft delete)' })
  @Roles('admin', 'finance_manager')
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.capexService.remove(id);
    return createResponse(result);
  }
}
