import { Module } from '@nestjs/common';
import { CapexIntelligenceController } from './capex-intelligence.controller';
import { CapexIntelligenceService } from './capex-intelligence.service';
import { PrismaModule } from '../../infrastructure/prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [CapexIntelligenceController],
  providers: [CapexIntelligenceService],
  exports: [CapexIntelligenceService],
})
export class CapexIntelligenceModule {}
