import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateCapexPlanDto, GenerateCapexPlanDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../common/utils';

@Injectable()
export class CapexIntelligenceService {
  private readonly logger = new Logger(CapexIntelligenceService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateCapexPlanDto) {
    const planNumber = generateSequentialNumber('CAPEX');
    return this.prisma.capexPlan.create({
      data: {
        planNumber,
        title: dto.title,
        description: dto.description,
        hotelId: dto.hotelId,
        organizationId: dto.organizationId,
        fiscalYear: dto.fiscalYear,
        totalBudget: dto.totalBudget,
        approvedBudget: dto.approvedBudget,
        currency: dto.currency,
        status: dto.status ?? 'DRAFT',
        items: dto.items
          ? {
              create: dto.items.map((item) => ({
                name: item.name,
                category: item.category,
                assetId: item.assetId,
                estimatedCost: item.estimatedCost,
                priority: item.priority,
                plannedQuarter: item.plannedQuarter,
                description: item.description,
              })),
            }
          : undefined,
      },
      include: { items: true, hotel: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId, deletedAt: null };
    if (search) where.title = { contains: search, mode: 'insensitive' };
    if (filters?.status) where.status = filters.status;

    const [data, total] = await Promise.all([
      this.prisma.capexPlan.findMany({
        where, skip, take,
        orderBy: { [sortBy]: sortOrder },
        include: { items: true, hotel: true },
      }),
      this.prisma.capexPlan.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findByHotel(hotelId: string) {
    return this.prisma.capexPlan.findMany({
      where: { hotelId, deletedAt: null },
      include: { items: true },
      orderBy: { fiscalYear: 'desc' },
    });
  }

  async generatePlan(dto: GenerateCapexPlanDto) {
    const hotel = await this.prisma.hotel.findFirst({
      where: { id: dto.hotelId, organizationId: dto.organizationId, deletedAt: null },
    });
    if (!hotel) throw new NotFoundException('Hotel not found');

    // Gather assets for the hotel
    const assets = await this.prisma.hotelAsset.findMany({
      where: { organizationId: dto.organizationId, hotelId: dto.hotelId, deletedAt: null },
    });

    const currentYear = new Date().getFullYear();
    const planNumber = generateSequentialNumber('CAPEX');
    const items: any[] = [];

    for (const asset of assets) {
      // Estimate replacement year based on condition and age
      const yearsRemaining = this.estimateYearsRemaining(asset.condition, asset.installedDate);
      if (yearsRemaining <= 5) {
        items.push({
          name: `Replace ${asset.name}`,
          category: asset.assetType,
          assetId: asset.id,
          estimatedCost: this.estimateReplacementCost(asset),
          priority: yearsRemaining <= 1 ? 'CRITICAL' : yearsRemaining <= 3 ? 'HIGH' : 'MEDIUM',
          plannedQuarter: yearsRemaining <= 1 ? 'Q1' : yearsRemaining <= 3 ? 'Q2' : 'Q4',
          description: `Scheduled replacement of ${asset.name} (${asset.assetType})`,
        });
      }
    }

    const totalBudget = items.reduce((sum, item) => sum + item.estimatedCost, 0);

    return this.prisma.capexPlan.create({
      data: {
        planNumber,
        title: `5-Year CAPEX Plan - ${hotel.name}`,
        description: `Auto-generated ${dto.fiscalYear || currentYear}-${(dto.fiscalYear || currentYear) + 4} capital expenditure plan`,
        hotelId: dto.hotelId,
        organizationId: dto.organizationId,
        fiscalYear: dto.fiscalYear || currentYear,
        totalBudget,
        approvedBudget: 0,
        currency: dto.currency || 'SAR',
        status: 'DRAFT',
        items: { create: items },
      },
      include: { items: true, hotel: true },
    });
  }

  async getRoadmap(hotelId: string) {
    const hotel = await this.prisma.hotel.findFirst({ where: { id: hotelId, deletedAt: null } });
    if (!hotel) throw new NotFoundException('Hotel not found');

    const assets = await this.prisma.hotelAsset.findMany({
      where: { hotelId, deletedAt: null },
    });

    const currentYear = new Date().getFullYear();
    const roadmap: Record<string, any[]> = {};

    for (let year = currentYear; year <= currentYear + 5; year++) {
      roadmap[year] = [];
    }

    for (const asset of assets) {
      const yearsRemaining = this.estimateYearsRemaining(asset.condition, asset.installedDate);
      const targetYear = Math.min(currentYear + Math.floor(yearsRemaining), currentYear + 5);
      if (roadmap[targetYear]) {
        roadmap[targetYear].push({
          assetId: asset.id,
          name: asset.name,
          assetType: asset.assetType,
          condition: asset.condition,
          estimatedCost: this.estimateReplacementCost(asset),
          priority: yearsRemaining <= 1 ? 'CRITICAL' : yearsRemaining <= 3 ? 'HIGH' : 'MEDIUM',
        });
      }
    }

    return { hotelId, hotelName: hotel.name, currentYear, roadmap };
  }

  async findOne(id: string) {
    const plan = await this.prisma.capexPlan.findFirst({
      where: { id, deletedAt: null },
      include: { items: true, hotel: true },
    });
    if (!plan) throw new NotFoundException('CAPEX plan not found');
    return plan;
  }

  async update(id: string, dto: CreateCapexPlanDto) {
    const plan = await this.prisma.capexPlan.findFirst({ where: { id, deletedAt: null } });
    if (!plan) throw new NotFoundException('CAPEX plan not found');

    return this.prisma.capexPlan.update({
      where: { id },
      data: {
        title: dto.title,
        description: dto.description,
        fiscalYear: dto.fiscalYear,
        totalBudget: dto.totalBudget,
        approvedBudget: dto.approvedBudget,
        currency: dto.currency,
        status: dto.status,
      },
      include: { items: true, hotel: true },
    });
  }

  async remove(id: string) {
    const plan = await this.prisma.capexPlan.findFirst({ where: { id, deletedAt: null } });
    if (!plan) throw new NotFoundException('CAPEX plan not found');

    await this.prisma.capexPlan.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    return { success: true, message: 'CAPEX plan deleted' };
  }

  private estimateYearsRemaining(condition: string, installedDate: Date | null): number {
    const conditionLife: Record<string, number> = {
      EXCELLENT: 5,
      GOOD: 4,
      FAIR: 2,
      POOR: 1,
      CRITICAL: 0,
    };
    let years = conditionLife[condition] ?? 3;

    if (installedDate) {
      const ageYears = (Date.now() - new Date(installedDate).getTime()) / (365.25 * 24 * 60 * 60 * 1000);
      if (ageYears > 15) years = Math.min(years, 0);
    }

    return years;
  }

  private estimateReplacementCost(asset: any): number {
    // Rough estimation based on asset type
    const baseCosts: Record<string, number> = {
      HVAC: 150000,
      ELECTRICAL: 80000,
      PLUMBING: 60000,
      FF_E: 50000,
      KITCHEN: 120000,
      LAUNDRY: 90000,
      SECURITY: 40000,
      IT: 35000,
      ELEVATOR: 200000,
      FIRE_SAFETY: 55000,
    };
    const base = baseCosts[asset.assetType] || 50000;
    const multiplier = asset.condition === 'CRITICAL' ? 1.3 : asset.condition === 'POOR' ? 1.1 : 1.0;
    return Math.round(base * multiplier);
  }
}
