import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ContactsService } from './contacts.service';
import { CreateContactDto, UpdateContactDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Contacts')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('contacts')
export class ContactsController {
  constructor(private readonly contactsService: ContactsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a hotel contact' })
  async create(@Body() dto: CreateContactDto) {
    const result = await this.contactsService.create(dto);
    return createResponse(result, 'Contact created');
  }

  @Get()
  @ApiOperation({ summary: 'List all contacts' })
  async findAll(@Query() pagination: PaginationDto, @Query('hotelId') hotelId?: string) {
    const result = await this.contactsService.findAll(pagination, hotelId);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get contact by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.contactsService.findOne(id);
    return createResponse(result);
  }

  @Get('hotel/:hotelId')
  @ApiOperation({ summary: 'Get contacts for a hotel' })
  async getByHotel(@Param('hotelId', ParseUUIDPipe) hotelId: string, @Query() pagination: PaginationDto) {
    const result = await this.contactsService.findAll(pagination, hotelId);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update contact' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateContactDto) {
    const result = await this.contactsService.update(id, dto);
    return createResponse(result, 'Contact updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete contact' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.contactsService.remove(id);
    return createResponse(result);
  }
}
