import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateContactDto, UpdateContactDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class ContactsService {
  private readonly logger = new Logger(ContactsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateContactDto) {
    if (dto.isPrimary) {
      await this.prisma.hotelContact.updateMany({
        where: { hotelId: dto.hotelId, isPrimary: true },
        data: { isPrimary: false },
      });
    }
    return this.prisma.hotelContact.create({ data: dto });
  }

  async findAll(pagination: PaginationDto, hotelId?: string) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = {};
    if (hotelId) where.hotelId = hotelId;
    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }
    const [data, total] = await Promise.all([
      this.prisma.hotelContact.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder } }),
      this.prisma.hotelContact.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const contact = await this.prisma.hotelContact.findUnique({ where: { id } });
    if (!contact) throw new NotFoundException('Contact not found');
    return contact;
  }

  async update(id: string, dto: UpdateContactDto) {
    try {
      return this.prisma.hotelContact.update({ where: { id }, data: dto });
    } catch {
      throw new NotFoundException('Contact not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.hotelContact.delete({ where: { id } });
      return { success: true, message: 'Contact deleted' };
    } catch {
      throw new NotFoundException('Contact not found');
    }
  }
}
