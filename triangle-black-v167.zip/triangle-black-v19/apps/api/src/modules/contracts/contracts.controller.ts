import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ContractsService } from './contracts.service';
import { CreateContractDto, UpdateContractDto, CreateContractVersionDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Contracts')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('contracts')
export class ContractsController {
  constructor(private readonly contractsService: ContractsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a contract' })
  async create(@Body() dto: CreateContractDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.contractsService.create(dto);
    return createResponse(result, 'Contract created');
  }

  @Get()
  @ApiOperation({ summary: 'List all contracts' })
  async findAll(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string, @Query('status') status?: string) {
    const result = await this.contractsService.findAll(orgId, pagination, { status });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get contract by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.contractsService.findOne(id);
    return createResponse(result);
  }

  @Get(':id/versions')
  @ApiOperation({ summary: 'Get contract versions' })
  async getVersions(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.contractsService.getVersions(id);
    return createResponse(result);
  }

  @Post(':id/versions')
  @ApiOperation({ summary: 'Create a new contract version' })
  async createVersion(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateContractVersionDto, @CurrentUser('id') userId: string) {
    const result = await this.contractsService.createVersion(id, dto, userId);
    return createResponse(result, 'Version created');
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update contract' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateContractDto) {
    const result = await this.contractsService.update(id, dto);
    return createResponse(result, 'Contract updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete contract' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.contractsService.remove(id);
    return createResponse(result);
  }
}
