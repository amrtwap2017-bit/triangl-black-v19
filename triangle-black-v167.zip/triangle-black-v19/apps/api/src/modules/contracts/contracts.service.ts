import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateContractDto, UpdateContractDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class ContractsService {
  private readonly logger = new Logger(ContractsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateContractDto) {
    return this.prisma.contract.create({ data: dto, include: { vendor: true, project: true } });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) where.title = { contains: search, mode: 'insensitive' };
    if (filters?.status) where.status = filters.status;

    const [data, total] = await Promise.all([
      this.prisma.contract.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { vendor: true, project: true } }),
      this.prisma.contract.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const contract = await this.prisma.contract.findUnique({
      where: { id },
      include: { vendor: true, project: true, versions: { orderBy: { version: 'desc' } } },
    });
    if (!contract) throw new NotFoundException('Contract not found');
    return contract;
  }

  async update(id: string, dto: UpdateContractDto) {
    try {
      return this.prisma.contract.update({ where: { id }, data: dto });
    } catch {
      throw new NotFoundException('Contract not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.contract.delete({ where: { id } });
      return { success: true, message: 'Contract deleted' };
    } catch {
      throw new NotFoundException('Contract not found');
    }
  }

  async createVersion(contractId: string, dto: { content?: string; changeNote?: string }, userId?: string) {
    const contract = await this.prisma.contract.findUnique({ where: { id: contractId } });
    if (!contract) throw new NotFoundException('Contract not found');

    const versions = await this.prisma.contractVersion.findMany({ where: { contractId } });
    const nextVersion = (versions.length || 0) + 1;

    return this.prisma.contractVersion.create({
      data: {
        contractId,
        version: nextVersion,
        content: dto.content,
        changeNote: dto.changeNote,
        changedBy: userId,
      },
    });
  }

  async getVersions(contractId: string) {
    return this.prisma.contractVersion.findMany({
      where: { contractId },
      orderBy: { version: 'desc' },
    });
  }
}
