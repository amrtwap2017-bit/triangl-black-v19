import {
  Controller, Get, Post, Delete, Param, Query, UseGuards, ParseUUIDPipe,
  UseInterceptors, UploadedFile, Body, Req,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiConsumes, ApiBody } from '@nestjs/swagger';
import { FileInterceptor } from '@nestjs/platform-express';
import { DocumentsService } from './documents.service';
import { UploadDocumentDto } from './dto/upload-document.dto';
import { SearchDocumentsDto } from './dto/search-documents.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard, TenantGuard, PermissionsGuard } from '../../common/guards';
import { CurrentUser } from '../../common/decorators';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Documents')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, PermissionsGuard)
@Controller('documents')
export class DocumentsController {
  constructor(private readonly documentsService: DocumentsService) {}

  // ─── Upload ─────────────────────────────────────────────────────────────────

  @Post('upload')
  @ApiOperation({ summary: 'Upload a document' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      required: ['file', 'title'],
      properties: {
        file: { type: 'string', format: 'binary', description: 'The document file' },
        title: { type: 'string', description: 'Document title' },
        titleAr: { type: 'string', description: 'Document title in Arabic' },
        projectId: { type: 'string', format: 'uuid', description: 'Associated project ID' },
        contractId: { type: 'string', format: 'uuid', description: 'Associated contract ID' },
        category: { type: 'string', enum: ['CONTRACT', 'BOQ', 'DRAWING', 'SPECIFICATION', 'INVOICE', 'REPORT', 'OTHER'], description: 'Document category' },
        tags: { type: 'string', description: 'Comma-separated tags' },
      },
    },
  })
  @UseInterceptors(FileInterceptor('file'))
  async upload(
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: UploadDocumentDto,
    @CurrentUser('id') userId?: string,
    @CurrentUser('organizationId') orgId?: string,
  ) {
    const tags = dto.tags
      ? Array.isArray(dto.tags) ? dto.tags : String(dto.tags).split(',').map(t => t.trim()).filter(Boolean)
      : undefined;

    const result = await this.documentsService.upload(file, {
      organizationId: orgId || '',
      projectId: dto.projectId,
      contractId: dto.contractId,
      category: dto.category,
      title: dto.title,
      titleAr: dto.titleAr,
      uploadedById: userId,
      tags,
    });
    return createResponse(result, 'Document uploaded and queued for processing');
  }

  // ─── List ────────────────────────────────────────────────────────────────────

  @Get()
  @ApiOperation({ summary: 'List all documents with pagination and filters' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('projectId') projectId?: string,
    @Query('contractId') contractId?: string,
    @Query('category') category?: string,
    @Query('status') status?: string,
    @Query('fromDate') fromDate?: string,
    @Query('toDate') toDate?: string,
  ) {
    const result = await this.documentsService.findAll(orgId, pagination, {
      projectId,
      contractId,
      category,
      status,
      fromDate,
      toDate,
    });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  // ─── Get One ─────────────────────────────────────────────────────────────────

  @Get(':id')
  @ApiOperation({ summary: 'Get document by ID with processing status' })
  async findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.documentsService.findOne(id, orgId);
    return createResponse(result);
  }

  // ─── Get Chunks ──────────────────────────────────────────────────────────────

  @Get(':id/chunks')
  @ApiOperation({ summary: 'Get document chunks for RAG context' })
  async getChunks(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.documentsService.getChunks(id, orgId);
    return createResponse(result);
  }

  // ─── Download ────────────────────────────────────────────────────────────────

  @Get(':id/download')
  @ApiOperation({ summary: 'Get document download URL' })
  async download(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.documentsService.getDownloadUrl(id, orgId);
    return createResponse(result);
  }

  // ─── Semantic Search ─────────────────────────────────────────────────────────

  @Post('search')
  @ApiOperation({ summary: 'Search documents using semantic/full-text search' })
  async search(
    @Body() dto: SearchDocumentsDto,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.documentsService.search(dto.query, orgId, {
      topK: dto.topK,
      projectId: dto.projectId,
      category: dto.category,
      fromDate: dto.fromDate,
      toDate: dto.toDate,
    });
    return createResponse(result);
  }

  // ─── Reprocess ───────────────────────────────────────────────────────────────

  @Post(':id/reprocess')
  @ApiOperation({ summary: 'Reprocess a failed or outdated document' })
  async reprocess(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.documentsService.reprocess(id, orgId);
    return createResponse(result);
  }

  // ─── Soft Delete ─────────────────────────────────────────────────────────────

  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete a document' })
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.documentsService.delete(id, orgId);
    return createResponse(result);
  }

  // ─── Version History ─────────────────────────────────────────────────────────

  @Get(':id/versions')
  @ApiOperation({ summary: 'Get document version history' })
  async getVersionHistory(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.documentsService.getVersionHistory(id, orgId);
    return createResponse(result);
  }
}