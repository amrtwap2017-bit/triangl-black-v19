import { Injectable, NotFoundException, ForbiddenException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { StorageService } from '../../infrastructure/storage/storage.service';
import { LoggerService } from '../../infrastructure/logging/logger.service';
import { QueueService } from '../../infrastructure/queue/queue.service';
import {
  DocumentProcessor,
  ChecksumService,
  type DocumentProcessingResult,
  type DocumentStatus,
  type IVectorIndexService,
} from '@triangleblack/documents';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

// ─── Types ────────────────────────────────────────────────────────────────────

interface UploadInput {
  organizationId: string;
  projectId?: string;
  contractId?: string;
  category?: string;
  title: string;
  titleAr?: string;
  uploadedById?: string;
  tags?: string[];
}

interface FindAllFilters {
  projectId?: string;
  contractId?: string;
  category?: string;
  status?: string;
  fromDate?: string;
  toDate?: string;
}

// ─── Service ───────────────────────────────────────────────────────────────────

@Injectable()
export class DocumentsService {
  private readonly logger: LoggerService;
  private readonly processor: DocumentProcessor;
  private readonly checksumService: ChecksumService;

  constructor(
    private readonly prisma: PrismaService,
    private readonly storageService: StorageService,
    private readonly loggerBase: LoggerService,
    private readonly queue: QueueService,
  ) {
    this.logger = loggerBase;
    this.processor = new DocumentProcessor({
      duplicateChecker: (checksum, orgId) => this.checkDuplicateInDb(checksum, orgId),
    });
    this.checksumService = new ChecksumService();
  }

  // ─── Upload ─────────────────────────────────────────────────────────────────

  async upload(file: Express.Multer.File, data: UploadInput) {
    this.logger.logWithContext('Document upload started', { fileName: file.originalname, organizationId: data.organizationId });

    // Compute checksum before storage
    const checksum = this.checksumService.computeChecksum(file.buffer);

    // Store file
    const storageKey = await this.storageService.upload(file, `documents/${data.organizationId}`);

    // Create document record with UPLOADING status
    const document = await this.prisma.document.create({
      data: {
        organizationId: data.organizationId,
        projectId: data.projectId,
        contractId: data.contractId,
        category: data.category || null,
        title: data.title,
        titleAr: data.titleAr,
        mimeType: file.mimetype,
        fileSize: file.size,
        storageKey: storageKey.key,
        checksum: checksum.hash,
        status: 'UPLOADING',
        uploadedById: data.uploadedById,
        tags: data.tags ? { create: data.tags.map(tag => ({ name: tag })) } : undefined,
      },
    });

    this.logger.logWithContext('Document stored, queueing processing', { documentId: document.id, storageKey: storageKey.key });

    // Queue async processing
    try {
      await this.queue.addJob('document.processing', {
        documentId: document.id,
        organizationId: data.organizationId,
      });
    } catch (err) {
      this.logger.errorWithContext('Failed to queue document processing', err instanceof Error ? err.stack : undefined);
      // Update status to ERROR
      await this.prisma.document.update({
        where: { id: document.id },
        data: { status: 'ERROR', processingError: 'Failed to queue processing job' },
      });
    }

    return document;
  }

  // ─── Process Document (called by worker) ────────────────────────────────────

  async processDocument(documentId: string, organizationId: string): Promise<DocumentProcessingResult> {
    this.logger.logWithContext('Processing document', { documentId, organizationId });

    const document = await this.prisma.document.findUnique({
      where: { id: documentId },
    });

    if (!document) {
      throw new NotFoundException(`Document ${documentId} not found`);
    }

    if (document.organizationId !== organizationId) {
      throw new ForbiddenException('Document does not belong to this organization');
    }

    // Update status
    await this.prisma.document.update({
      where: { id: documentId },
      data: { status: 'VALIDATING' as DocumentStatus },
    });

    // Download file buffer
    const buffer = await this.storageService.download(document.storageKey);

    // Run the full pipeline
    const result = await this.processor.process({
      buffer,
      fileName: document.title || document.storageKey,
      mimeType: document.mimeType,
      documentId: document.id,
      organizationId: document.organizationId,
    });

    // Update document with processing results
    const updateData: any = {
      status: result.status,
      textContent: result.text || null,
      pageCount: result.metadata.pageCount ?? result.metadata.pageCountParsed ?? null,
      checksum: result.checksum.hash,
      author: result.metadata.author || null,
      category: result.classification.category,
      processingDuration: result.processingDurationMs,
      processingError: result.errors.length > 0 ? result.errors.join('; ') : null,
      processedAt: new Date(),
    };

    // Store chunks as JSON
    if (result.chunks.length > 0) {
      updateData.chunkCount = result.chunks.length;
      updateData.chunks = {
        create: result.chunks.map(chunk => ({
          text: chunk.text,
          chunkIndex: chunk.index,
          startOffset: chunk.startOffset,
          endOffset: chunk.endOffset,
          tokenCount: chunk.tokenCount,
        })),
      };
    }

    await this.prisma.document.update({
      where: { id: documentId },
      data: updateData,
    });

    this.logger.logWithContext('Document processing complete', {
      documentId,
      status: result.status,
      chunks: result.chunks.length,
      duration: result.processingDurationMs,
      errors: result.errors.length,
    });

    return result;
  }

  // ─── Find All ───────────────────────────────────────────────────────────────

  async findAll(organizationId: string, pagination: PaginationDto, filters?: FindAllFilters) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take, totalPages } = calculatePagination(page, limit);

    const where: any = {
      organizationId,
      deletedAt: null,
    };

    // Filters
    if (filters?.projectId) where.projectId = filters.projectId;
    if (filters?.contractId) where.contractId = filters.contractId;
    if (filters?.category) where.category = filters.category;
    if (filters?.status) where.status = filters.status;

    // Date range
    if (filters?.fromDate || filters?.toDate) {
      where.createdAt = {};
      if (filters.fromDate) where.createdAt.gte = new Date(filters.fromDate);
      if (filters.toDate) where.createdAt.lte = new Date(filters.toDate);
    }

    // Search
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { titleAr: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.document.findMany({
        where,
        skip,
        take,
        orderBy: { [sortBy || 'createdAt']: (sortOrder || 'DESC').toLowerCase() },
        include: {
          tags: { select: { name: true } },
          _count: { select: { chunks: true, versions: true } },
        },
      }),
      this.prisma.document.count({ where }),
    ]);

    const actualTotalPages = Math.ceil(total / take);

    this.logger.logWithContext('Documents listed', { organizationId, total, page, limit });

    return {
      data,
      meta: { total, page, limit, totalPages: actualTotalPages },
    };
  }

  // ─── Find One ───────────────────────────────────────────────────────────────

  async findOne(id: string, organizationId: string) {
    const document = await this.prisma.document.findUnique({
      where: { id, deletedAt: null },
      include: {
        tags: { select: { name: true } },
        versions: { orderBy: { version: 'desc' }, take: 20 },
        _count: { select: { chunks: true } },
      },
    });

    if (!document) {
      throw new NotFoundException('Document not found');
    }

    if (document.organizationId !== organizationId) {
      throw new ForbiddenException('Document does not belong to this organization');
    }

    this.logger.logWithContext('Document retrieved', { documentId: id, organizationId });

    return document;
  }

  // ─── Get Chunks ─────────────────────────────────────────────────────────────

  async getChunks(documentId: string, organizationId: string) {
    const document = await this.prisma.document.findUnique({
      where: { id: documentId, deletedAt: null },
      select: { id: true, organizationId: true, title: true, status: true },
    });

    if (!document) throw new NotFoundException('Document not found');
    if (document.organizationId !== organizationId) throw new ForbiddenException('Access denied');

    const chunks = await this.prisma.documentChunk.findMany({
      where: { documentId },
      orderBy: { chunkIndex: 'asc' },
    });

    this.logger.logWithContext('Document chunks retrieved', { documentId, chunkCount: chunks.length });

    return {
      documentId,
      title: document.title,
      status: document.status,
      chunks,
    };
  }

  // ─── Semantic Search ────────────────────────────────────────────────────────

  async search(
    query: string,
    organizationId: string,
    options?: {
      topK?: number;
      projectId?: string;
      category?: string;
      fromDate?: string;
      toDate?: string;
    },
  ) {
    const topK = Math.min(options?.topK || 10, 50);

    // If vector search is available, use it. Otherwise, fall back to text search.
    // For now, use Prisma full-text search as a fallback.

    const where: any = {
      organizationId,
      deletedAt: null,
      status: 'ACTIVE',
      textContent: { not: null },
    };

    if (options?.projectId) where.projectId = options.projectId;
    if (options?.category) where.category = options.category;
    if (options?.fromDate || options?.toDate) {
      where.createdAt = {};
      if (options.fromDate) where.createdAt.gte = new Date(options.fromDate);
      if (options.toDate) where.createdAt.lte = new Date(options.toDate);
    }

    // Text-based search fallback
    const documents = await this.prisma.document.findMany({
      where: {
        ...where,
        textContent: { contains: query, mode: 'insensitive' },
      },
      take: topK,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        title: true,
        category: true,
        status: true,
        createdAt: true,
        chunks: {
          where: { text: { contains: query, mode: 'insensitive' } },
          take: 3,
          select: { text: true, chunkIndex: true },
        },
      },
    });

    this.logger.logWithContext('Document search performed', { query, organizationId, results: documents.length });

    return {
      query,
      results: documents.map(doc => ({
        documentId: doc.id,
        title: doc.title,
        category: doc.category,
        score: 1.0, // placeholder — real vector search would return actual scores
        matchingChunks: doc.chunks,
      })),
      total: documents.length,
    };
  }

  // ─── Reprocess ──────────────────────────────────────────────────────────────

  async reprocess(documentId: string, organizationId: string) {
    const document = await this.prisma.document.findUnique({
      where: { id: documentId, deletedAt: null },
    });

    if (!document) throw new NotFoundException('Document not found');
    if (document.organizationId !== organizationId) throw new ForbiddenException('Access denied');

    if (!['ERROR', 'ACTIVE', 'INDEXED', 'UPLOADING'].includes(document.status)) {
      throw new BadRequestException(`Cannot reprocess document in status: ${document.status}`);
    }

    // Update status and queue reprocessing
    await this.prisma.document.update({
      where: { id: documentId },
      data: { status: 'UPLOADING', processingError: null, processedAt: null },
    });

    await this.queue.addJob('document.processing', {
      documentId,
      organizationId,
    }, { idempotencyKey: `reprocess-${documentId}-${Date.now()}` });

    this.logger.logWithContext('Document reprocessing queued', { documentId, organizationId });

    return { success: true, message: 'Document queued for reprocessing' };
  }

  // ─── Soft Delete ────────────────────────────────────────────────────────────

  async delete(id: string, organizationId: string) {
    const document = await this.prisma.document.findUnique({
      where: { id, deletedAt: null },
    });

    if (!document) throw new NotFoundException('Document not found');
    if (document.organizationId !== organizationId) throw new ForbiddenException('Access denied');

    await this.prisma.document.update({
      where: { id },
      data: {
        status: 'DELETED',
        deletedAt: new Date(),
      },
    });

    this.logger.logWithContext('Document soft-deleted', { documentId: id, organizationId });

    return { success: true, message: 'Document deleted' };
  }

  // ─── Version History ────────────────────────────────────────────────────────

  async getVersionHistory(documentId: string, organizationId: string) {
    const document = await this.prisma.document.findUnique({
      where: { id: documentId, deletedAt: null },
      select: { id: true, organizationId: true, title: true },
    });

    if (!document) throw new NotFoundException('Document not found');
    if (document.organizationId !== organizationId) throw new ForbiddenException('Access denied');

    const versions = await this.prisma.documentVersion.findMany({
      where: { documentId },
      orderBy: { version: 'desc' },
      include: {
        changedByUser: {
          select: { id: true, name: true, email: true },
        },
      },
    });

    this.logger.logWithContext('Document version history retrieved', { documentId, versions: versions.length });

    return {
      documentId,
      title: document.title,
      versions,
    };
  }

  // ─── Get Duplicate Documents ────────────────────────────────────────────────

  async getDuplicateDocuments(organizationId: string) {
    const documents = await this.prisma.document.findMany({
      where: {
        organizationId,
        deletedAt: null,
        checksum: { not: null },
      },
      select: {
        id: true,
        title: true,
        checksum: true,
        fileSize: true,
        createdAt: true,
        status: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // Group by checksum
    const byChecksum = new Map<string, typeof documents>();
    const duplicates: Array<{
      checksum: string;
      documents: typeof documents;
      count: number;
    }> = [];

    for (const doc of documents) {
      if (doc.checksum) {
        const existing = byChecksum.get(doc.checksum);
        if (existing) {
          existing.push(doc);
        } else {
          byChecksum.set(doc.checksum, [doc]);
        }
      }
    }

    for (const [checksum, docs] of byChecksum) {
      if (docs.length > 1) {
        duplicates.push({ checksum, documents: docs, count: docs.length });
      }
    }

    this.logger.logWithContext('Duplicate documents check completed', { organizationId, duplicateGroups: duplicates.length });

    return {
      duplicateGroups: duplicates,
      totalDuplicateGroups: duplicates.length,
      totalDuplicateFiles: duplicates.reduce((sum, g) => sum + g.count, 0),
    };
  }

  // ─── Download URL ───────────────────────────────────────────────────────────

  async getDownloadUrl(id: string, organizationId: string) {
    const document = await this.prisma.document.findUnique({
      where: { id, deletedAt: null },
    });

    if (!document) throw new NotFoundException('Document not found');
    if (document.organizationId !== organizationId) throw new ForbiddenException('Access denied');

    const url = await this.storageService.getSignedUrl(document.storageKey);
    return { url, document };
  }

  // ─── Private helpers ────────────────────────────────────────────────────────

  private async checkDuplicateInDb(checksum: string, organizationId?: string) {
    if (!organizationId) return { isDuplicate: false };

    const existing = await this.prisma.document.findFirst({
      where: {
        organizationId,
        checksum,
        deletedAt: null,
      },
      select: { id: true, title: true, checksum: true },
    });

    return {
      isDuplicate: !!existing,
      existingChecksum: existing?.checksum,
      existingDocumentId: existing?.id,
      existingFileName: existing?.title,
    };
  }
}