import { IsString, IsOptional, IsUUID, IsEnum, IsObject, IsInt } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateDocumentVersionDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  changeNote?: string;
}
