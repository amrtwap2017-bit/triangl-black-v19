import { IsString, IsOptional, IsUUID, IsArray, IsEnum } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';

export class UploadDocumentDto {
  @ApiProperty({ description: 'Document title' })
  @IsString()
  title: string;

  @ApiPropertyOptional({ description: 'Document title in Arabic' })
  @IsOptional()
  @IsString()
  titleAr?: string;

  @ApiPropertyOptional({ description: 'Associated project ID', format: 'uuid' })
  @IsOptional()
  @IsUUID()
  projectId?: string;

  @ApiPropertyOptional({ description: 'Associated contract ID', format: 'uuid' })
  @IsOptional()
  @IsUUID()
  contractId?: string;

  @ApiPropertyOptional({
    description: 'Document category',
    enum: ['CONTRACT', 'BOQ', 'DRAWING', 'SPECIFICATION', 'INVOICE', 'REPORT', 'OTHER'],
  })
  @IsOptional()
  @IsString()
  @IsEnum(['CONTRACT', 'BOQ', 'DRAWING', 'SPECIFICATION', 'INVOICE', 'REPORT', 'OTHER'])
  category?: string;

  @ApiPropertyOptional({ description: 'Tags (comma-separated or array)' })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @Transform(({ value }) => {
    if (typeof value === 'string') {
      return value.split(',').map(t => t.trim()).filter(Boolean);
    }
    return value;
  })
  tags?: string[];
}