import {
  Controller, Get, Post, Delete, Body, Param, Query, ParseUUIDPipe, UseInterceptors, UploadedFile,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiConsumes } from '@nestjs/swagger';
import { DrawingIntelligenceService } from './drawing-intelligence.service';
import { CreateDrawingDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Drawing Intelligence')
@ApiBearerAuth()
@Controller('drawing-intelligence')
export class DrawingIntelligenceController {
  constructor(private readonly service: DrawingIntelligenceService) {}

  @Post('upload')
  @ApiOperation({ summary: 'Upload drawing (PDF/DWG/Image)' })
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('file'))
  async upload(
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: CreateDrawingDto,
    @CurrentUser('id') userId: string,
  ) {
    const result = await this.service.upload(file, dto, userId);
    return createResponse(result, 'Drawing uploaded');
  }

  @Get()
  @ApiOperation({ summary: 'List drawings' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('hotelId') hotelId?: string,
    @Query('drawingType') drawingType?: string,
  ) {
    const result = await this.service.findAll(orgId, pagination, { hotelId, drawingType });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get drawing with analysis results' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.findOne(id);
    return createResponse(result);
  }

  @Post(':id/analyze')
  @ApiOperation({ summary: 'Queue drawing analysis (AI placeholder)' })
  async analyze(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.service.analyze(id, userId);
    return createResponse(result);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete drawing' })
  async remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.service.remove(id, userId);
    return createResponse(result);
  }
}
