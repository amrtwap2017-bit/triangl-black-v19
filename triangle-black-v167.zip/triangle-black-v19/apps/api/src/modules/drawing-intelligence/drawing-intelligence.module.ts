import { Module } from '@nestjs/common';
import { DrawingIntelligenceController } from './drawing-intelligence.controller';
import { DrawingIntelligenceService } from './drawing-intelligence.service';

@Module({
  controllers: [DrawingIntelligenceController],
  providers: [DrawingIntelligenceService],
  exports: [DrawingIntelligenceService],
})
export class DrawingIntelligenceModule {}
