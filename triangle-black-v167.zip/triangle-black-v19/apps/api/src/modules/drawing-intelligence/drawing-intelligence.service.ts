import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { QueueService } from '../../../infrastructure/queue/queue.service';
import { StorageService } from '../../../infrastructure/storage/storage.service';
import { CreateDrawingDto, UpdateDrawingDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination } from '../../../common/utils';

@Injectable()
export class DrawingIntelligenceService {
  private readonly logger = new Logger(DrawingIntelligenceService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService,
    private readonly storage: StorageService,
  ) {}

  async upload(file: Express.Multer.File, dto: CreateDrawingDto, userId: string) {
    const uploadResult = await this.storage.upload(file, 'drawings');
    const format = this.detectFormat(file.mimetype);
    return this.prisma.drawing.create({
      data: {
        organizationId: dto.organizationId,
        hotelId: dto.hotelId,
        projectId: dto.projectId,
        title: dto.title,
        titleAr: dto.titleAr,
        drawingType: dto.drawingType,
        format,
        fileUrl: uploadResult.url,
        fileSize: file.size,
        status: 'PENDING',
        createdBy: userId,
        updatedBy: userId,
      },
    });
  }

  private detectFormat(mimeType: string): string {
    if (mimeType === 'application/pdf') return 'PDF';
    if (mimeType === 'image/vnd.dxf' || mimeType === 'application/dxf') return 'DWG';
    if (mimeType.startsWith('image/')) return 'IMAGE';
    return 'SCANNED';
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { hotelId?: string; drawingType?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId, deletedAt: null };
    if (filters?.hotelId) where.hotelId = filters.hotelId;
    if (filters?.drawingType) where.drawingType = filters.drawingType;
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { titleAr: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.drawing.findMany({ where, skip, take, orderBy: { [sortBy || 'createdAt']: sortOrder || 'DESC' } }),
      this.prisma.drawing.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const drawing = await this.prisma.drawing.findFirst({ where: { id, deletedAt: null }, include: { hotel: true } });
    if (!drawing) throw new NotFoundException('Drawing not found');
    return drawing;
  }

  async analyze(id: string, userId: string) {
    const drawing = await this.findOne(id);
    await this.prisma.drawing.update({
      where: { id },
      data: { status: 'ANALYZING', updatedBy: userId, version: { increment: 1 } },
    });

    await this.queue.addJob('drawing-analysis', {
      drawingId: drawing.id,
      fileUrl: drawing.fileUrl,
      title: drawing.title,
      drawingType: drawing.drawingType,
    });

    return { success: true, message: 'Drawing analysis queued' };
  }

  async remove(id: string, userId: string) {
    const drawing = await this.findOne(id);
    try {
      const key = drawing.fileUrl.replace('/files/', '');
      await this.storage.delete(key);
    } catch { /* ignore storage errors */ }

    await this.prisma.drawing.update({
      where: { id },
      data: { deletedAt: new Date(), updatedBy: userId, version: { increment: 1 } },
    });
    return { success: true, message: 'Drawing soft-deleted' };
  }

  /**
   * Drawing analysis pipeline: extract equipment, areas, quantities from drawings.
   * Returns BOQ suggestions, risk analysis, and scope draft.
   */
  async analyzeDrawing(drawingId: string) {
    const drawing = await this.findOne(drawingId);

    // Trigger deeper analysis job if not already analyzed
    if (drawing.status !== 'ANALYZED') {
      await this.analyze(drawingId, drawing.createdBy || 'system');
    }

    // Return structured analysis results based on drawing type
    const analysisResults = this.generateAnalysisForType(drawing);

    return {
      drawingId: drawing.id,
      title: drawing.title,
      drawingType: drawing.drawingType,
      status: drawing.status,
      analysis: analysisResults,
    };
  }

  /**
   * Generate analysis results based on drawing type.
   */
  private generateAnalysisForType(drawing: any): {
    boqSuggestions: { item: string; category: string; estimatedQuantity: number; unit: string; notes: string }[];
    riskAnalysis: { risk: string; severity: 'HIGH' | 'MEDIUM' | 'LOW'; mitigation: string }[];
    scopeDraft: { section: string; description: string; estimatedDuration: string }[];
  } {
    const typeConfig: Record<string, { categories: string[]; risks: string[]; scopeSections: string[] }> = {
      MEP: {
        categories: ['HVAC Equipment', 'Electrical Distribution', 'Plumbing Fixtures', 'Fire Alarm Devices', 'Cable Tray'],
        risks: ['Coordination conflicts with architectural layout', 'Inadequate shaft space for duct routing', 'Load calculation mismatch'],
        scopeSections: ['Mechanical HVAC Installation', 'Electrical Power Distribution', 'Plumbing and Drainage Systems', 'Fire Protection Systems'],
      },
      ARCHITECTURAL: {
        categories: ['Floor Finishing', 'Wall Partitions', 'Ceiling Systems', 'Door and Frame Sets', 'Glass and Glazing'],
        risks: ['Dimensional discrepancies with MEP clearances', 'Material lead time for custom finishes', 'Acoustic insulation requirements'],
        scopeSections: ['Demolition and Preparation', 'Partition and Wall Construction', 'Floor and Wall Finishing', 'Ceiling Installation'],
      },
      STRUCTURAL: {
        categories: ['Reinforcement Steel', 'Concrete Pour', 'Steel Beams', 'Column Formwork', 'Anchor Bolts'],
        risks: ['Load bearing capacity concerns', 'Structural penetration approvals', 'Temporary shoring requirements'],
        scopeSections: ['Structural Assessment', 'Reinforcement and Formwork', 'Concrete Works', 'Structural Steel Erection'],
      },
    };

    const config = typeConfig[drawing.drawingType] || typeConfig['ARCHITECTURAL'];

    const boqSuggestions = config.categories.map((cat) => ({
      item: cat,
      category: drawing.drawingType,
      estimatedQuantity: 0, // To be populated by AI/OCR analysis
      unit: cat.includes('Equipment') || cat.includes('Devices') ? 'EACH' : cat.includes('Steel') || cat.includes('Cable') ? 'M' : 'SQM',
      notes: `Auto-detected from ${drawing.drawingType} drawing analysis. Requires field verification.`,
    }));

    const riskAnalysis = config.risks.map((risk) => ({
      risk,
      severity: risk.includes('conflict') || risk.includes('capacity') ? 'HIGH' as const : 'MEDIUM' as const,
      mitigation: 'Review during site visit and coordinate with hotel engineering team.',
    }));

    const scopeDraft = config.scopeSections.map((section) => ({
      section,
      description: `${section} as indicated in drawing ${drawing.title}. Verify dimensions and specifications on site.`,
      estimatedDuration: 'To be determined after site inspection.',
    }));

    return { boqSuggestions, riskAnalysis, scopeDraft };
  }

  /**
   * Get drawing statistics: count by type, status, and hotel for an organization.
   */
  async getDrawingStats(organizationId: string) {
    const [byType, byStatus, byHotel, total] = await Promise.all([
      this.prisma.drawing.groupBy({
        by: ['drawingType'],
        where: { organizationId, deletedAt: null },
        _count: { id: true },
      }),
      this.prisma.drawing.groupBy({
        by: ['status'],
        where: { organizationId, deletedAt: null },
        _count: { id: true },
      }),
      this.prisma.drawing.groupBy({
        by: ['hotelId'],
        where: { organizationId, deletedAt: null, hotelId: { not: null } },
        _count: { id: true },
      }),
      this.prisma.drawing.count({ where: { organizationId, deletedAt: null } }),
    ]);

    // Enrich by-hotel with hotel names
    const hotelIds = byHotel.map((h) => h.hotelId);
    const hotels = hotelIds.length > 0
      ? await this.prisma.hotel.findMany({
          where: { id: { in: hotelIds } },
          select: { id: true, name: true },
        })
      : [];
    const hotelMap = new Map(hotels.map((h) => [h.id, h.name]));

    return {
      total,
      byType: byType.map((t) => ({ type: t.drawingType, count: t._count.id })),
      byStatus: byStatus.map((s) => ({ status: s.status, count: s._count.id })),
      byHotel: byHotel.map((h) => ({
        hotelId: h.hotelId,
        hotelName: hotelMap.get(h.hotelId) || 'Unknown',
        count: h._count.id,
      })),
    };
  }

  /**
   * Connect/link a drawing to a project.
   */
  async connectDrawingToProject(drawingId: string, projectId: string, userId?: string) {
    const drawing = await this.findOne(drawingId);
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, deletedAt: null },
    });
    if (!project) throw new NotFoundException('Project not found');

    return this.prisma.drawing.update({
      where: { id: drawingId },
      data: {
        projectId,
        updatedBy: userId || drawing.updatedBy,
        version: { increment: 1 },
      },
    });
  }
}
