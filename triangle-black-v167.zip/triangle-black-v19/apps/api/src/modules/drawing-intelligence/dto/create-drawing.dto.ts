import { IsString, IsOptional, IsUUID, IsEnum, IsObject, IsInt } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateDrawingDto {
  @ApiProperty()
  @IsUUID()
  organizationId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  hotelId?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  projectId?: string;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  titleAr?: string;

  @ApiPropertyOptional({ enum: ['HVAC_LAYOUT', 'ELECTRICAL_LAYOUT', 'PLUMBING', 'ARCHITECTURAL', 'MEP_COORDINATION', 'SITE_PLAN', 'AS_BUILT'] })
  @IsOptional()
  @IsEnum(['HVAC_LAYOUT', 'ELECTRICAL_LAYOUT', 'PLUMBING', 'ARCHITECTURAL', 'MEP_COORDINATION', 'SITE_PLAN', 'AS_BUILT'])
  drawingType?: string;

  @ApiPropertyOptional({ enum: ['PDF', 'DWG', 'IMAGE', 'SCANNED'] })
  @IsOptional()
  @IsEnum(['PDF', 'DWG', 'IMAGE', 'SCANNED'])
  format?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: any;
}

export class UpdateDrawingDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  titleAr?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  drawingType?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  analysisResult?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: any;
}
