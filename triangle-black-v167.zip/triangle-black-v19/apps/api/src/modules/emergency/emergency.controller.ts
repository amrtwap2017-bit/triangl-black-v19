import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { EmergencyService } from './emergency.service';
import { CreateEmergencyDto, UpdateEmergencyDto, ResolveEmergencyDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Emergency')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('emergencies')
export class EmergencyController {
  constructor(private readonly emergencyService: EmergencyService) {}

  @Post()
  @ApiOperation({ summary: 'Create emergency case' })
  async create(@Body() dto: CreateEmergencyDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.emergencyService.create(dto);
    return createResponse(result, 'Emergency case created');
  }

  @Get()
  @ApiOperation({ summary: 'List all emergency cases' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('status') status?: string,
    @Query('severity') severity?: string,
  ) {
    const result = await this.emergencyService.findAll(orgId, pagination, { status, severity });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('sla-tracking')
  @ApiOperation({ summary: 'Get SLA compliance tracking' })
  async getSlaTracking(@CurrentUser('organizationId') orgId: string) {
    const result = await this.emergencyService.getSlaTracking(orgId);
    return createResponse(result);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get emergency case by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.emergencyService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update emergency case' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateEmergencyDto) {
    const result = await this.emergencyService.update(id, dto);
    return createResponse(result, 'Emergency case updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete emergency case' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.emergencyService.remove(id);
    return createResponse(result);
  }

  @Post(':id/assign')
  @ApiOperation({ summary: 'Assign emergency case' })
  async assign(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.emergencyService.assign(id, userId);
    return createResponse(result, 'Emergency case assigned');
  }

  @Post(':id/resolve')
  @ApiOperation({ summary: 'Resolve emergency case' })
  async resolve(@Param('id', ParseUUIDPipe) id: string, @Body() dto: ResolveEmergencyDto) {
    const result = await this.emergencyService.resolve(id, dto.rootCause, dto.resolution);
    return createResponse(result, 'Emergency case resolved');
  }

  @Post(':id/escalate')
  @ApiOperation({ summary: 'Escalate emergency case severity' })
  async escalate(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.emergencyService.escalate(id);
    return createResponse(result, 'Emergency case escalated');
  }
}
