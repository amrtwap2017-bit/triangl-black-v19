import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateEmergencyDto, UpdateEmergencyDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../common/utils';

@Injectable()
export class EmergencyService {
  private readonly logger = new Logger(EmergencyService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateEmergencyDto) {
    const caseNumber = generateSequentialNumber('EM');
    return this.prisma.emergencyCase.create({
      data: { ...dto, caseNumber, status: 'OPEN' },
      include: { hotel: true, assignedTo: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string; severity?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { caseNumber: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (filters?.status) where.status = filters.status;
    if (filters?.severity) where.severity = filters.severity;

    const [data, total] = await Promise.all([
      this.prisma.emergencyCase.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { hotel: true, assignedTo: true } }),
      this.prisma.emergencyCase.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const emergency = await this.prisma.emergencyCase.findUnique({
      where: { id },
      include: { hotel: true, assignedTo: true },
    });
    if (!emergency) throw new NotFoundException('Emergency case not found');
    return emergency;
  }

  async update(id: string, dto: UpdateEmergencyDto) {
    try {
      return this.prisma.emergencyCase.update({ where: { id }, data: dto, include: { hotel: true, assignedTo: true } });
    } catch {
      throw new NotFoundException('Emergency case not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.emergencyCase.delete({ where: { id } });
      return { success: true, message: 'Emergency case deleted' };
    } catch {
      throw new NotFoundException('Emergency case not found');
    }
  }

  async assign(id: string, userId: string) {
    const emergency = await this.prisma.emergencyCase.findUnique({ where: { id } });
    if (!emergency) throw new NotFoundException('Emergency case not found');
    return this.prisma.emergencyCase.update({ where: { id }, data: { assignedToId: userId, status: 'IN_PROGRESS' } });
  }

  async resolve(id: string, rootCause: string, resolution: string) {
    const emergency = await this.prisma.emergencyCase.findUnique({ where: { id } });
    if (!emergency) throw new NotFoundException('Emergency case not found');

    const now = new Date();
    const resolutionMinutes = emergency.createdAt ? Math.round((now.getTime() - new Date(emergency.createdAt).getTime()) / 60000) : null;

    return this.prisma.emergencyCase.update({
      where: { id },
      data: { status: 'RESOLVED', rootCause, resolution, resolvedAt: now, resolutionTime: resolutionMinutes },
    });
  }

  async escalate(id: string) {
    const emergency = await this.prisma.emergencyCase.findUnique({ where: { id } });
    if (!emergency) throw new NotFoundException('Emergency case not found');

    const severities = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
    const currentIdx = severities.indexOf(emergency.severity);
    const newSeverity = currentIdx < severities.length - 1 ? severities[currentIdx + 1] : 'CRITICAL';

    return this.prisma.emergencyCase.update({
      where: { id },
      data: { severity: newSeverity },
    });
  }

  async getSlaTracking(organizationId: string) {
    const emergencies = await this.prisma.emergencyCase.findMany({
      where: { organizationId },
      orderBy: { createdAt: 'desc' },
    });

    const SLA_TARGETS: Record<string, number> = { CRITICAL: 30, HIGH: 60, MEDIUM: 120, LOW: 240 };
    const tracking = emergencies.map((e) => {
      const targetMinutes = SLA_TARGETS[e.severity] || 120;
      const responseMinutes = e.responseTime;
      const resolutionMinutes = e.resolutionTime;
      const responseCompliant = responseMinutes ? responseMinutes <= targetMinutes : null;
      const resolutionCompliant = resolutionMinutes ? resolutionMinutes <= targetMinutes * 4 : null;
      return {
        ...e,
        slaTargetMinutes: targetMinutes,
        responseCompliant,
        resolutionCompliant,
      };
    });

    const complianceRate = tracking.filter((t) => t.responseCompliant === true).length / tracking.length || 0;

    return { cases: tracking, overallComplianceRate: complianceRate };
  }
}
