import { IsOptional, IsString, IsEnum, IsUUID } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class ForecastQueryDto {
  @ApiPropertyOptional({ enum: ['30d', '90d', '1y', '12m'], default: '90d' })
  @IsOptional()
  @IsEnum(['30d', '90d', '1y', '12m'])
  period?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  hotelId?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  category?: string;
}
