import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ForecastingService } from './forecasting.service';
import { ForecastQueryDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse } from '../../common/dto/api-response.dto';

@ApiTags('Executive Forecasting')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('forecasting')
export class ForecastingController {
  constructor(private readonly forecastingService: ForecastingService) {}

  @Get('revenue')
  @ApiOperation({ summary: 'Revenue forecast (30-day, 90-day, 12-month)' })
  async revenueForecast(@Query() query: ForecastQueryDto, @CurrentUser('organizationId') orgId: string) {
    const result = await this.forecastingService.revenueForecast(orgId, query);
    return createResponse(result);
  }

  @Get('pipeline')
  @ApiOperation({ summary: 'Pipeline forecast based on active opportunities' })
  async pipelineForecast(@Query() query: ForecastQueryDto, @CurrentUser('organizationId') orgId: string) {
    const result = await this.forecastingService.pipelineForecast(orgId, query);
    return createResponse(result);
  }

  @Get('workload')
  @ApiOperation({ summary: 'Resource workload forecast' })
  async workloadForecast(@Query() query: ForecastQueryDto, @CurrentUser('organizationId') orgId: string) {
    const result = await this.forecastingService.workloadForecast(orgId, query);
    return createResponse(result);
  }

  @Get('cash-flow')
  @ApiOperation({ summary: 'Cash flow indicators forecast' })
  async cashFlowForecast(@Query() query: ForecastQueryDto, @CurrentUser('organizationId') orgId: string) {
    const result = await this.forecastingService.cashFlowForecast(orgId, query);
    return createResponse(result);
  }
}
