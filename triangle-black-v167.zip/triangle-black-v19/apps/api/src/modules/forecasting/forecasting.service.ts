import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { ForecastQueryDto } from './dto';

@Injectable()
export class ForecastingService {
  private readonly logger = new Logger(ForecastingService.name);

  constructor(private readonly prisma: PrismaService) {}

  async revenueForecast(organizationId: string, query: ForecastQueryDto) {
    const period = query.period || '90d';
    const days = this.parsePeriod(period);
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + days);

    // Get closed-won projects in the last 90 days for baseline
    const baselineDate = new Date();
    baselineDate.setDate(baselineDate.getDate() - 90);

    const recentProjects = await this.prisma.project.findMany({
      where: {
        organizationId,
        status: 'COMPLETED',
        completedDate: { gte: baselineDate },
        deletedAt: null,
        ...(query.hotelId ? { hotelId: query.hotelId } : {}),
      },
      select: { budget: true, completedDate: true },
    });

    const baselineRevenue = recentProjects.reduce((sum, p) => sum + (p.budget || 0), 0);
    const avgMonthlyRevenue = baselineRevenue / 3;

    // Get active pipeline for projection
    const activeOpportunities = await this.prisma.opportunity.findMany({
      where: {
        organizationId,
        status: { in: ['QUALIFIED', 'PROPOSAL_SENT', 'NEGOTIATION'] },
        deletedAt: null,
        ...(query.hotelId ? { hotelId: query.hotelId } : {}),
      },
      select: { estimatedValue: true, stage: string },
    });

    const pipelineWeight = this.calculatePipelineWeight(activeOpportunities);
    const forecastedRevenue = avgMonthlyRevenue + (pipelineWeight * days / 90);

    return {
      period,
      days,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      baseline: {
        last90DaysRevenue: baselineRevenue,
        avgMonthlyRevenue: Math.round(avgMonthlyRevenue),
      },
      forecast: {
        projectedRevenue: Math.round(forecastedRevenue),
        conservative: Math.round(forecastedRevenue * 0.7),
        optimistic: Math.round(forecastedRevenue * 1.2),
        pipelineContribution: Math.round(pipelineWeight),
      },
      growthRate: avgMonthlyRevenue > 0 ? ((forecastedRevenue / avgMonthlyRevenue - 1) * 100).toFixed(1) : '0.0',
      confidence: this.calculateConfidence(recentProjects.length, activeOpportunities.length),
    };
  }

  async pipelineForecast(organizationId: string, query: ForecastQueryDto) {
    const period = query.period || '90d';
    const days = this.parsePeriod(period);

    const opportunities = await this.prisma.opportunity.findMany({
      where: {
        organizationId,
        deletedAt: null,
        ...(query.hotelId ? { hotelId: query.hotelId } : {}),
      },
      include: { hotel: { select: { id: true, name: true } } },
    });

    const byStage = this.groupByStage(opportunities);
    const totalPipeline = opportunities.filter(
      (o) => ['QUALIFIED', 'PROPOSAL_SENT', 'NEGOTIATION'].includes(o.status),
    ).reduce((sum, o) => sum + (o.estimatedValue || 0), 0);

    const expectedCloseRate = 0.25; // Industry standard
    const projectedWins = totalPipeline * expectedCloseRate;

    return {
      period,
      days,
      totalPipeline,
      totalPipelineCount: opportunities.length,
      expectedCloseRate,
      projectedWins: Math.round(projectedWins),
      projectedWinsConservative: Math.round(projectedWins * 0.7),
      projectedWinsOptimistic: Math.round(projectedWins * 1.3),
      byStage,
      topOpportunities: opportunities
        .sort((a, b) => (b.estimatedValue || 0) - (a.estimatedValue || 0))
        .slice(0, 10)
        .map((o) => ({
          id: o.id,
          title: o.title,
          hotel: o.hotel?.name,
          estimatedValue: o.estimatedValue,
          stage: o.status,
          probability: this.getStageProbability(o.status),
          weightedValue: Math.round((o.estimatedValue || 0) * this.getStageProbability(o.status)),
        })),
    };
  }

  async workloadForecast(organizationId: string, query: ForecastQueryDto) {
    const period = query.period || '90d';
    const days = this.parsePeriod(period);

    const employees = await this.prisma.employee.findMany({
      where: { organizationId, deletedAt: null },
      include: {
        assignments: { where: { active: true }, include: { project: true } },
      },
    });

    const activeProjects = await this.prisma.project.findMany({
      where: {
        organizationId,
        status: { in: ['IN_PROGRESS', 'ON_HOLD'] },
        deletedAt: null,
        ...(query.hotelId ? { hotelId: query.hotelId } : {}),
      },
    });

    let totalRequiredHours = 0;
    for (const project of activeProjects) {
      totalRequiredHours += this.estimateProjectHoursRemaining(project);
    }

    const totalAvailableCapacity = employees.reduce((sum, emp) => {
      return sum + ((emp.maxAllocation || 100) * days * 8) / 100;
    }, 0);

    const currentUtilization = employees.reduce((sum, emp) => {
      const alloc = emp.assignments.reduce((a, b) => a + (b.allocation || 100), 0);
      return sum + Math.min(alloc, emp.maxAllocation || 100);
    }, 0);

    const avgUtilization = employees.length > 0 ? currentUtilization / employees.length : 0;

    return {
      period,
      days,
      employees: {
        total: employees.length,
        avgUtilization: Math.round(avgUtilization),
        availableCapacity: Math.round(totalAvailableCapacity),
      },
      projects: {
        active: activeProjects.length,
        estimatedRemainingHours: Math.round(totalRequiredHours),
      },
      risk: {
        overload: avgUtilization > 90 ? 'HIGH' : avgUtilization > 75 ? 'MEDIUM' : 'LOW',
        staffingGap: Math.max(0, Math.round((totalRequiredHours - totalAvailableCapacity) / (days * 8))),
        recommendation: avgUtilization > 85
          ? 'Consider adding contractors or reducing project scope'
          : avgUtilization > 70
            ? 'Monitor closely as capacity is being utilized'
            : 'Capacity available for new projects',
      },
    };
  }

  async cashFlowForecast(organizationId: string, query: ForecastQueryDto) {
    const period = query.period || '90d';
    const days = this.parsePeriod(period);

    // Invoiced amounts from completed projects
    const recentRevenue = await this.prisma.project.aggregate({
      where: {
        organizationId,
        status: 'COMPLETED',
        deletedAt: null,
      },
      _sum: { budget: true },
    });

    // Pending invoices / receivables
    const activeProjects = await this.prisma.project.findMany({
      where: {
        organizationId,
        status: 'IN_PROGRESS',
        deletedAt: null,
        ...(query.hotelId ? { hotelId: query.hotelId } : {}),
      },
      select: { budget: true, startDate: true },
    });

    const pendingRevenue = activeProjects.reduce((sum, p) => sum + (p.budget || 0) * 0.4, 0); // Assume 40% milestone

    const monthlyBurnRate = activeProjects.length > 0
      ? activeProjects.reduce((sum, p) => sum + (p.budget || 0), 0) / 6
      : 0;

    return {
      period,
      days,
      cashIn: {
        recognizedRevenue: recentRevenue._sum.budget || 0,
        expectedCollections: Math.round(pendingRevenue),
      },
      cashOut: {
        estimatedMonthlyBurn: Math.round(monthlyBurnRate),
        estimatedPeriodBurn: Math.round(monthlyBurnRate * (days / 30)),
      },
      indicators: {
        netCashFlow: Math.round(pendingRevenue - monthlyBurnRate * (days / 30)),
        runwayMonths: monthlyBurnRate > 0
          ? Math.round((recentRevenue._sum.budget || 0 + pendingRevenue) / monthlyBurnRate)
          : 999,
        healthStatus: pendingRevenue > monthlyBurnRate * (days / 30) ? 'HEALTHY' : 'WARNING',
      },
    };
  }

  private parsePeriod(period: string): number {
    const map: Record<string, number> = {
      '30d': 30,
      '90d': 90,
      '1y': 365,
      '12m': 365,
    };
    return map[period] || 90;
  }

  private calculatePipelineWeight(opportunities: any[]): number {
    return opportunities.reduce((sum, o) => {
      return sum + (o.estimatedValue || 0) * this.getStageProbability(o.status);
    }, 0);
  }

  private getStageProbability(stage: string): number {
    const probabilities: Record<string, number> = {
      LEAD: 0.1,
      QUALIFIED: 0.25,
      PROPOSAL_SENT: 0.4,
      NEGOTIATION: 0.6,
      WON: 1.0,
      LOST: 0,
    };
    return probabilities[stage] || 0.2;
  }

  private groupByStage(opportunities: any[]): Record<string, { count: number; value: number }> {
    const grouped: Record<string, { count: number; value: number }> = {};
    for (const opp of opportunities) {
      if (!grouped[opp.status]) grouped[opp.status] = { count: 0, value: 0 };
      grouped[opp.status].count++;
      grouped[opp.status].value += opp.estimatedValue || 0;
    }
    return grouped;
  }

  private estimateProjectHoursRemaining(project: any): number {
    if (!project.startDate) return 160;
    const daysRunning = (Date.now() - new Date(project.startDate).getTime()) / (24 * 60 * 60 * 1000);
    const totalDays = 90; // Default project duration
    const remaining = Math.max(0, (totalDays - daysRunning) / totalDays);
    return Math.round((project.budget || 50000) / 200 * remaining); // Rough hours from budget
  }

  private calculateConfidence(historicalCount: number, pipelineCount: number): string {
    if (historicalCount >= 10 && pipelineCount >= 5) return 'HIGH';
    if (historicalCount >= 5 && pipelineCount >= 3) return 'MEDIUM';
    return 'LOW';
  }
}
