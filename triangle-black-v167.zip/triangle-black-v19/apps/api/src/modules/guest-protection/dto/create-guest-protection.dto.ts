import { IsString, IsOptional, IsEnum, IsObject, IsNumber, IsBoolean } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateGuestProtectionDto {
  @ApiProperty({ enum: ['NONE', 'LOW', 'MEDIUM', 'HIGH'] })
  @IsEnum(['NONE', 'LOW', 'MEDIUM', 'HIGH'])
  guestImpact: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  riskScore?: number;

  @ApiPropertyOptional({ enum: ['LOW', 'MEDIUM', 'HIGH', 'FULL'] })
  @IsOptional()
  @IsEnum(['LOW', 'MEDIUM', 'HIGH', 'FULL'])
  occupancyLevel?: string;

  @ApiPropertyOptional({ enum: ['NONE', 'LOW', 'MEDIUM', 'HIGH'] })
  @IsOptional()
  @IsEnum(['NONE', 'LOW', 'MEDIUM', 'HIGH'])
  noiseImpact?: string;

  @ApiPropertyOptional({ enum: ['NONE', 'LOW', 'MEDIUM', 'HIGH'] })
  @IsOptional()
  @IsEnum(['NONE', 'LOW', 'MEDIUM', 'HIGH'])
  dustImpact?: string;

  @ApiPropertyOptional({ enum: ['NONE', 'LOW', 'MEDIUM', 'HIGH'] })
  @IsOptional()
  @IsEnum(['NONE', 'LOW', 'MEDIUM', 'HIGH'])
  odorImpact?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  shutdownRequired?: boolean;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  shutdownDetails?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  mitigationMeasures?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  recommendedSchedule?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  communicationPlan?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  operationalPrecautions?: string;
}

export class UpdateMitigationDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  responsible?: string;
}

export class AssessRiskDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  projectContext?: any;
}
