import {
  Controller, Get, Post, Put, Body, Param, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { GuestProtectionService } from './guest-protection.service';
import { CreateGuestProtectionDto, UpdateMitigationDto, AssessRiskDto } from './dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Guest Protection')
@ApiBearerAuth()
@Controller('guest-protection')
export class GuestProtectionController {
  constructor(private readonly service: GuestProtectionService) {}

  @Get('checklist')
  @ApiOperation({ summary: 'Get guest protection checklist template' })
  async getChecklist() {
    const result = await this.service.getChecklist();
    return createResponse(result);
  }

  @Get(':projectId')
  @ApiOperation({ summary: 'Get protection plan for project' })
  async getPlan(@Param('projectId', ParseUUIDPipe) projectId: string) {
    const result = await this.service.getPlan(projectId);
    return createResponse(result);
  }

  @Post(':projectId')
  @ApiOperation({ summary: 'Create or update protection plan' })
  async createOrUpdate(
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Body() dto: CreateGuestProtectionDto,
    @CurrentUser('id') userId: string,
  ) {
    const result = await this.service.createOrUpdate(projectId, dto, userId);
    return createResponse(result, 'Protection plan saved');
  }

  @Post(':projectId/assess')
  @ApiOperation({ summary: 'AI-assisted risk assessment (placeholder)' })
  async assessRisk(
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @CurrentUser('id') userId: string,
    @Body() dto?: AssessRiskDto,
  ) {
    const result = await this.service.assessRisk(projectId, userId);
    return createResponse(result, 'Risk assessment complete');
  }

  @Put(':projectId/mitigation/:measureIndex')
  @ApiOperation({ summary: 'Update a mitigation measure status' })
  async updateMitigation(
    @Param('projectId', ParseUUIDPipe) projectId: string,
    @Param('measureIndex') measureIndex: string,
    @Body() dto: UpdateMitigationDto,
    @CurrentUser('id') userId: string,
  ) {
    const idx = parseInt(measureIndex, 10);
    const result = await this.service.updateMitigation(projectId, idx, dto, userId);
    return createResponse(result, 'Mitigation measure updated');
  }
}
