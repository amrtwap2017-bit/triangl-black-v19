import { Module } from '@nestjs/common';
import { GuestProtectionController } from './guest-protection.controller';
import { GuestProtectionService } from './guest-protection.service';

@Module({
  controllers: [GuestProtectionController],
  providers: [GuestProtectionService],
  exports: [GuestProtectionService],
})
export class GuestProtectionModule {}
