import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { QueueService } from '../../../infrastructure/queue/queue.service';
import { CreateGuestProtectionDto, UpdateMitigationDto } from './dto';

@Injectable()
export class GuestProtectionService {
  private readonly logger = new Logger(GuestProtectionService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService,
  ) {}

  async getPlan(projectId: string) {
    const plan = await this.prisma.guestProtectionPlan.findUnique({
      where: { projectId },
      include: { project: true },
    });
    return plan;
  }

  async createOrUpdate(projectId: string, dto: CreateGuestProtectionDto, userId: string) {
    const existing = await this.prisma.guestProtectionPlan.findUnique({ where: { projectId } });
    if (existing) {
      return this.prisma.guestProtectionPlan.update({
        where: { projectId },
        data: { ...dto, updatedBy: userId },
        include: { project: true },
      });
    }
    return this.prisma.guestProtectionPlan.create({
      data: { projectId, ...dto, createdBy: userId, updatedBy: userId },
      include: { project: true },
    });
  }

  async assessRisk(projectId: string, userId: string) {
    const project = await this.prisma.project.findUnique({ where: { id: projectId } });
    if (!project) throw new NotFoundException('Project not found');

    // Queue AI risk assessment (placeholder)
    await this.queue.addJob('risk-assessment', {
      projectId,
      projectType: project.type,
      hotelId: project.hotelId,
      organizationId: project.organizationId,
      requestedBy: userId,
    });

    // Return placeholder assessment
    const assessment = {
      projectId,
      riskScore: 45,
      riskLevel: 'MEDIUM',
      mitigationMeasures: [
        { risk: 'Noise disturbance to guests', measure: 'Schedule noisy work during low-occupancy hours', responsible: null, status: 'PENDING' },
        { risk: 'Dust migration to guest areas', measure: 'Install temporary barriers and HEPA filtration', responsible: null, status: 'PENDING' },
        { risk: 'Utility shutdown impact', measure: 'Coordinate with hotel engineering for temporary services', responsible: null, status: 'PENDING' },
      ],
      recommendedSchedule: {
        preferredHours: '10:00-16:00',
        preferredDays: 'Tuesday-Thursday',
        blackoutDates: [],
        noiseWindows: [],
      },
    };

    // Save assessment results
    await this.createOrUpdate(projectId, {
      guestImpact: assessment.riskScore > 70 ? 'HIGH' : assessment.riskScore > 40 ? 'MEDIUM' : 'LOW',
      riskScore: assessment.riskScore,
      mitigationMeasures: assessment.mitigationMeasures,
      recommendedSchedule: assessment.recommendedSchedule,
    }, userId);

    return assessment;
  }

  async updateMitigation(projectId: string, measureIndex: number, dto: UpdateMitigationDto, userId: string) {
    const plan = await this.prisma.guestProtectionPlan.findUnique({ where: { projectId } });
    if (!plan) throw new NotFoundException('Protection plan not found');

    const measures = (plan.mitigationMeasures as any[]) || [];
    if (measureIndex < 0 || measureIndex >= measures.length) {
      throw new NotFoundException('Mitigation measure not found at index');
    }
    measures[measureIndex] = { ...measures[measureIndex], ...dto };

    await this.prisma.guestProtectionPlan.update({
      where: { projectId },
      data: { mitigationMeasures: measures, updatedBy: userId },
    });
    return measures[measureIndex];
  }

  async getChecklist() {
    return {
      sections: [
        {
          title: 'Noise Control',
          items: [
            'Identify noise-sensitive areas and guest rooms',
            'Establish quiet hours schedule',
            'Procure noise barriers and dampening materials',
            'Notify adjacent rooms in advance of noisy work',
          ],
        },
        {
          title: 'Dust & Debris Control',
          items: [
            'Install temporary partitions with sealed joints',
            'Set up HEPA-filtered negative air machines',
            'Cover all furniture and fixtures',
            'Establish debris removal schedule and route',
          ],
        },
        {
          title: 'Safety & Access',
          items: [
            'Maintain clear emergency egress paths',
            'Secure construction zones from guest access',
            'Coordinate fire alarm temporary disconnects',
            'Provide alternative access routes for guests',
          ],
        },
        {
          title: 'Utility Management',
          items: [
            'Coordinate planned shutdowns with hotel engineering',
            'Provide temporary utility services if needed',
            'Test backup systems before project start',
            'Establish emergency utility restoration procedures',
          ],
        },
        {
          title: 'Communication',
          items: [
            'Notify front desk and guest services team',
            'Prepare guest notification letters',
            'Post signage in affected areas',
            'Establish escalation contact list',
          ],
        },
      ],
    };
  }

  /**
   * Comprehensive risk score calculation (0-100) based on multiple impact dimensions:
   * noise, dust, odor, shutdown duration, occupancy, and safety hazards.
   */
  calculateRiskScore(protectionPlanData: {
    noise?: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
    dust?: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
    odor?: 'NONE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
    shutdownRequired?: boolean;
    shutdownDurationHours?: number;
    occupancyPercent?: number;
    safetyHazards?: string[];
    workScope?: string;
    hotelFloors?: number;
    affectedFloors?: number;
  }): {
    riskScore: number;
    riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    factorScores: { factor: string; score: number; weight: number; contribution: number }[];
  } {
    const weights = {
      noise: 20,
      dust: 20,
      odor: 10,
      shutdown: 15,
      occupancy: 15,
      safety: 10,
      scope: 10,
    };

    const severityMap: Record<string, number> = { NONE: 0, LOW: 25, MEDIUM: 50, HIGH: 75, EXTREME: 100 };

    // Individual factor scores (0-100 each)
    const noiseScore = severityMap[protectionPlanData.noise || 'MEDIUM'] || 50;
    const dustScore = severityMap[protectionPlanData.dust || 'MEDIUM'] || 50;
    const odorScore = severityMap[protectionPlanData.odor || 'LOW'] || 25;

    let shutdownScore = 0;
    if (protectionPlanData.shutdownRequired) {
      const hours = protectionPlanData.shutdownDurationHours || 4;
      shutdownScore = Math.min(100, (hours / 24) * 100);
    }

    // Higher occupancy = higher risk
    const occupancyScore = protectionPlanData.occupancyPercent
      ? protectionPlanData.occupancyPercent
      : 70; // default high

    // Safety hazards: count-based scoring
    const hazardCount = protectionPlanData.safetyHazards?.length || 0;
    const safetyScore = Math.min(100, hazardCount * 25);

    // Scope impact: proportion of affected floors
    let scopeScore = 30; // default
    if (protectionPlanData.hotelFloors && protectionPlanData.affectedFloors) {
      scopeScore = Math.min(100, (protectionPlanData.affectedFloors / protectionPlanData.hotelFloors) * 100);
    }

    const factorScores = [
      { factor: 'Noise', score: noiseScore, weight: weights.noise, contribution: (noiseScore * weights.noise) / 100 },
      { factor: 'Dust', score: dustScore, weight: weights.dust, contribution: (dustScore * weights.dust) / 100 },
      { factor: 'Odor', score: odorScore, weight: weights.odor, contribution: (odorScore * weights.odor) / 100 },
      { factor: 'Shutdown', score: shutdownScore, weight: weights.shutdown, contribution: (shutdownScore * weights.shutdown) / 100 },
      { factor: 'Occupancy', score: occupancyScore, weight: weights.occupancy, contribution: (occupancyScore * weights.occupancy) / 100 },
      { factor: 'Safety', score: safetyScore, weight: weights.safety, contribution: (safetyScore * weights.safety) / 100 },
      { factor: 'Scope', score: scopeScore, weight: weights.scope, contribution: (scopeScore * weights.scope) / 100 },
    ];

    const totalScore = Math.round(factorScores.reduce((sum, f) => sum + f.contribution, 0));
    const clampedScore = Math.max(0, Math.min(100, totalScore));

    let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    if (clampedScore >= 75) riskLevel = 'CRITICAL';
    else if (clampedScore >= 50) riskLevel = 'HIGH';
    else if (clampedScore >= 25) riskLevel = 'MEDIUM';
    else riskLevel = 'LOW';

    return {
      riskScore: clampedScore,
      riskLevel,
      factorScores,
    };
  }

  /**
   * Auto-generate mitigation measures based on risk score and identified impacts.
   */
  generateMitigationPlan(
    riskScore: number,
    impacts: { type: string; description: string; severity: string }[],
  ): {
    mitigationMeasures: {
      risk: string;
      measure: string;
      priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
      responsible: string;
      status: 'PENDING';
    }[];
    estimatedSetupTime: string;
    estimatedCostRange: string;
  } {
    const mitigationMeasures: {
      risk: string;
      measure: string;
      priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
      responsible: string;
      status: 'PENDING';
    }[] = [];

    const mitigationLibrary: Record<string, string[]> = {
      noise: [
        'Install acoustic barriers and sound-absorbing panels around work zones',
        'Schedule high-noise activities during lowest occupancy hours (10:00-16:00, Tue-Thu)',
        'Provide ear protection for guests upon request at front desk',
        'Use vibration-dampened tools and equipment where possible',
      ],
      dust: [
        'Install double-layered polyethylene dust barriers with zipper access',
        'Deploy HEPA-filtered negative air machines at containment boundaries',
        'Implement wet-cutting methods for all masonry and concrete work',
        'Cover all HVAC supply/return registers in affected areas',
      ],
      odor: [
        'Ensure continuous ventilation in affected areas during work',
        'Use low-VOC materials and adhesives throughout the project',
        'Schedule painting and chemical applications during low-occupancy periods',
        'Deploy activated carbon air scrubbers as needed',
      ],
      shutdown: [
        'Coordinate shutdown schedule with hotel engineering 72 hours in advance',
        'Provide temporary utility backup (portable AC, generators, water tanks)',
        'Notify all affected departments and establish communication protocol',
        'Test all temporary systems 24 hours before planned shutdown',
      ],
      safety: [
        'Install temporary lighting and egress signage in affected areas',
        'Secure all construction zones with locked barriers after hours',
        'Conduct daily safety briefings with all on-site personnel',
        'Maintain fire watch during hot work operations',
      ],
      general: [
        'Establish dedicated construction entrance/exit separate from guest areas',
        'Cover and protect all furniture, fixtures, and floor finishes',
        'Post clear signage and barricade tapes around work zones',
        'Provide daily progress updates to hotel management',
      ],
    };

    for (const impact of impacts) {
      const mitigations = mitigationLibrary[impact.type.toLowerCase()] || mitigationLibrary.general;
      for (const measure of mitigations) {
        mitigationMeasures.push({
          risk: impact.description,
          measure,
          priority: impact.severity === 'EXTREME' || impact.severity === 'HIGH'
            ? 'CRITICAL'
            : impact.severity === 'MEDIUM'
              ? 'HIGH'
              : riskScore >= 50 ? 'HIGH' : 'MEDIUM',
          responsible: 'Site Manager',
          status: 'PENDING',
        });
      }
    }

    // Add general mitigations
    for (const measure of mitigationLibrary.general) {
      mitigationMeasures.push({
        risk: 'General guest protection',
        measure,
        priority: 'MEDIUM',
        responsible: 'Site Manager',
        status: 'PENDING',
      });
    }

    let estimatedSetupTime = '2-3 days';
    let estimatedCostRange = '5,000 - 15,000 SAR';
    if (riskScore >= 75) {
      estimatedSetupTime = '5-7 days';
      estimatedCostRange = '20,000 - 50,000 SAR';
    } else if (riskScore >= 50) {
      estimatedSetupTime = '3-5 days';
      estimatedCostRange = '10,000 - 25,000 SAR';
    }

    return { mitigationMeasures, estimatedSetupTime, estimatedCostRange };
  }

  /**
   * Get scheduling recommendations based on hotel occupancy patterns and project type.
   */
  async getSchedulingRecommendation(hotelId: string, protectionPlanData: {
    projectType?: string;
    noise?: string;
    shutdownRequired?: boolean;
    estimatedDuration?: number;
  }): Promise<{
    preferredHours: string;
    preferredDays: string;
    blackoutPeriods: { start: string; end: string; reason: string }[];
    noiseWindows: { start: string; end: string; activity: string }[];
    recommendations: string[];
  }> {
    // In a real implementation, this would query hotel occupancy data
    // For now, return intelligent defaults based on project type

    const defaultSchedule = {
      preferredHours: '10:00 - 16:00',
      preferredDays: 'Tuesday - Thursday',
      blackoutPeriods: [] as { start: string; end: string; reason: string }[],
      noiseWindows: [] as { start: string; end: string; activity: string }[],
      recommendations: [] as string[],
    };

    if (protectionPlanData.noise === 'HIGH' || protectionPlanData.noise === 'EXTREME') {
      defaultSchedule.preferredHours = '09:00 - 14:00';
      defaultSchedule.recommendations.push(
        'Noise-intensive work should be scheduled before 14:00 to allow acoustic settling before evening guest arrivals.',
        'Consider weekend mornings (10:00-13:00) for sustained noisy work when business travelers are absent.',
      );
    }

    if (protectionPlanData.shutdownRequired) {
      defaultSchedule.preferredHours = '22:00 - 06:00';
      defaultSchedule.preferredDays = 'Sunday - Thursday';
      defaultSchedule.recommendations.push(
        'Utility shutdown work should be performed during night hours to minimize guest impact.',
        'Coordinate with hotel engineering for temporary utility provision during shutdown window.',
      );
    }

    // Add seasonal blackout periods (peak seasons)
    defaultSchedule.blackoutPeriods = [
      { start: '12-20', end: '01-05', reason: 'Holiday season — high occupancy' },
      { start: '06-15', end: '08-30', reason: 'Summer peak season' },
      { start: '03-25', end: '04-15', reason: 'Ramadan — special guest considerations' },
    ];

    if (protectionPlanData.estimatedDuration && protectionPlanData.estimatedDuration > 14) {
      defaultSchedule.recommendations.push(
        'For projects exceeding 2 weeks, consider phasing work by floor/section to minimize guest displacement.',
      );
    }

    defaultSchedule.noiseWindows = [
      { start: '10:00', end: '12:00', activity: 'Demolition and heavy construction' },
      { start: '13:00', end: '15:00', activity: 'Installation and finishing work' },
    ];

    defaultSchedule.recommendations.push(
      'Verify current occupancy levels with front desk before starting work each day.',
      'Notify housekeeping to avoid cleaning rooms adjacent to active work zones.',
    );

    return defaultSchedule;
  }

  /**
   * Return a comprehensive guest protection checklist organized by risk category.
   */
  getProtectionChecklist(): {
    categories: {
      category: string;
      criticalItems: string[];
      standardItems: string[];
      verificationItems: string[];
    }[];
  } {
    return {
      categories: [
        {
          category: 'Noise Control',
          criticalItems: [
            'Acoustic barriers installed around all work zones',
            'Noise monitoring equipment deployed at guest room boundaries',
            'Quiet hours schedule communicated to all subcontractors',
          ],
          standardItems: [
            'Vibration-dampened tools used for all operations',
            'Guest notification signs posted 48 hours in advance',
            'Front desk briefed on noise schedule and escalation contacts',
          ],
          verificationItems: [
            'Sound level readings below 55dB at nearest guest room during work',
            'No noise complaints received during the previous shift',
            'All noisy equipment powered down by end of scheduled window',
          ],
        },
        {
          category: 'Dust & Containment',
          criticalItems: [
            'HEPA-filtered negative air machines operational at all containment boundaries',
            'Double-layered sealed barriers with zipper access installed',
            'HVAC registers covered and sealed in affected areas',
          ],
          standardItems: [
            'Wet-cutting methods used for all masonry and concrete',
            'Debris removal route designated and marked',
            'Cover and protection on all furniture and fixtures',
          ],
          verificationItems: [
            'Visual inspection: no dust visible outside containment zone',
            'Air quality readings within acceptable limits',
            'HEPA filters checked and replaced per schedule',
          ],
        },
        {
          category: 'Safety & Egress',
          criticalItems: [
            'Emergency egress paths maintained clear and illuminated',
            'Construction zones secured against guest access with locked barriers',
            'Fire alarm coordination completed with hotel engineering',
          ],
          standardItems: [
            'First aid kit and fire extinguisher present on-site',
            'Temporary lighting installed in transition areas',
            'Daily safety briefing conducted with all personnel',
          ],
          verificationItems: [
            'Fire drill coordination confirmed with hotel team',
            'All barriers and signage inspected at shift start',
            'Emergency contact list posted and verified',
          ],
        },
        {
          category: 'Utility Management',
          criticalItems: [
            'Planned shutdown schedule approved by hotel engineering 72 hours in advance',
            'Temporary utility backup systems tested and operational',
            'Emergency restoration procedures documented and accessible',
          ],
          standardItems: [
            'Utility isolation points clearly marked',
            'Backup power and water verified before shutdown',
            'Guest services team notified of any temporary service interruptions',
          ],
          verificationItems: [
            'All temporary systems tested 24 hours before shutdown',
            'No unexpected utility disruptions reported by guests',
            'Utility restoration confirmed before end of each shift',
          ],
        },
        {
          category: 'Odor & Air Quality',
          criticalItems: [
            'Low-VOC materials specified and verified before installation',
            'Ventilation maintained continuously in work zones',
            'Activated carbon scrubbers deployed for odor-generating activities',
          ],
          standardItems: [
            'Chemical storage away from guest areas in sealed containers',
            'Painting and adhesive work scheduled during low-occupancy windows',
            'Air quality monitoring at containment boundaries',
          ],
          verificationItems: [
            'No odor complaints from adjacent guest rooms',
            'VOC readings within acceptable limits',
            'Air handling units serving affected areas inspected weekly',
          ],
        },
      ],
    };
  }
}
