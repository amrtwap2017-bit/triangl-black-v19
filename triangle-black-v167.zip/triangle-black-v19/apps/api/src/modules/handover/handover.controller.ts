import { Controller, Get, Post, Put, Param, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { HandoverService } from './handover.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse } from '../../common/dto/api-response.dto';
import { IsString, IsOptional, IsArray, ValidateNested } from 'class-validator';

class AddPunchItemDto {
  @IsString() item!: string;
  @IsString() responsible!: string;
  @IsString() description?: string;
  @IsString() dueDate?: string;
}

class UpdatePunchItemDto {
  @IsString() status!: string;
  @IsString() notes?: string;
}

class UpsertHandoverDto {
  @IsString() @IsOptional() status?: string;
  @IsArray() @IsOptional() deliverables?: any[];
  @IsArray() @IsOptional() punchItems?: any[];
  @IsArray() @IsOptional() asBuiltDocs?: any[];
  @IsArray() @IsOptional() warranties?: any[];
  @IsString() @IsOptional() notes?: string;
}

class CompleteHandoverDto {
  @IsString() signedBy!: string;
  @IsString() acceptedBy!: string;
}

@ApiTags('Handover')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('handover')
export class HandoverController {
  constructor(private readonly handoverService: HandoverService) {}

  @Get(':projectId')
  async getHandover(@Param('projectId') projectId: string) {
    return createResponse(await this.handoverService.getHandover(projectId));
  }

  @Post(':projectId')
  async upsertHandover(@Param('projectId') projectId: string, @Body() dto: UpsertHandoverDto, @CurrentUser('sub') userId: string) {
    return createResponse(await this.handoverService.upsertHandover(projectId, dto, userId), 'Handover saved');
  }

  @Post(':projectId/complete')
  async completeHandover(@Param('projectId') projectId: string, @Body() dto: CompleteHandoverDto, @CurrentUser('sub') userId: string) {
    return createResponse(await this.handoverService.completeHandover(projectId, userId, dto), 'Handover completed');
  }

  @Post(':projectId/punch-item')
  async addPunchItem(@Param('projectId') projectId: string, @Body() dto: AddPunchItemDto, @CurrentUser('sub') userId: string) {
    return createResponse(await this.handoverService.addPunchItem(projectId, dto, userId), 'Punch item added');
  }

  @Put(':projectId/punch-item/:index')
  async updatePunchItem(@Param('projectId') projectId: string, @Param('index') index: string, @Body() dto: UpdatePunchItemDto, @CurrentUser('sub') userId: string) {
    return createResponse(await this.handoverService.updatePunchItem(projectId, parseInt(index), dto, userId), 'Punch item updated');
  }
}