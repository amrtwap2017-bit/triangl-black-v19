import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class HandoverService {
  constructor(private readonly prisma: PrismaService) {}

  async getHandover(projectId: string) {
    let handover = await this.prisma.projectHandover.findUnique({
      where: { projectId },
    });
    if (!handover) {
      handover = await this.prisma.projectHandover.create({
        data: { projectId, status: 'PENDING', deliverables: [], punchItems: [], asBuiltDocs: [], warranties: [] },
      });
    }
    return handover;
  }

  async upsertHandover(projectId: string, data: any, userId: string) {
    const project = await this.prisma.project.findUnique({ where: { id: projectId } });
    if (!project) throw new NotFoundException('Project not found');

    return this.prisma.projectHandover.upsert({
      where: { projectId },
      update: { ...data, updatedBy: userId },
      create: { projectId, ...data, createdBy: userId },
    });
  }

  async completeHandover(projectId: string, userId: string, data: { signedBy: string; acceptedBy: string }) {
    const handover = await this.prisma.projectHandover.findUnique({ where: { projectId } });
    if (!handover) throw new NotFoundException('Handover package not found');
    if (handover.status === 'COMPLETED') throw new BadRequestException('Handover already completed');

    return this.prisma.projectHandover.update({
      where: { projectId },
      data: {
        status: 'COMPLETED',
        handoverDate: new Date(),
        signedBy: data.signedBy,
        signedAt: new Date(),
        acceptedBy: data.acceptedBy,
        acceptedAt: new Date(),
        updatedBy: userId,
      },
    });
  }

  async addPunchItem(projectId: string, item: any, userId: string) {
    const handover = await this.getHandover(projectId);
    const punchItems = (handover.punchItems as any[]) || [];
    punchItems.push({ ...item, status: 'OPEN', createdAt: new Date().toISOString() });
    return this.prisma.projectHandover.update({
      where: { projectId },
      data: { punchItems, updatedBy: userId },
    });
  }

  async updatePunchItem(projectId: string, index: number, updates: any, userId: string) {
    const handover = await this.getHandover(projectId);
    const punchItems = (handover.punchItems as any[]) || [];
    if (index < 0 || index >= punchItems.length) throw new NotFoundException('Punch item not found');
    punchItems[index] = { ...punchItems[index], ...updates };
    return this.prisma.projectHandover.update({
      where: { projectId },
      data: { punchItems, updatedBy: userId },
    });
  }
}