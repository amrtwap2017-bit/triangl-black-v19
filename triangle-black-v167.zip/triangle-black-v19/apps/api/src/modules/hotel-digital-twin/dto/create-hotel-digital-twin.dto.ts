import { IsString, IsOptional, IsUUID, IsNumber, IsEnum } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateBuildingDto {
  @ApiProperty()
  @IsUUID()
  organizationId: string;

  @ApiProperty()
  @IsUUID()
  hotelId: string;

  @ApiProperty()
  @IsString()
  name: string;

  @ApiPropertyOptional({ enum: ['MAIN', 'WING', 'ANNEX', 'OUTBUILDING', 'PARKING', 'UTILITY'] })
  @IsOptional()
  @IsEnum(['MAIN', 'WING', 'ANNEX', 'OUTBUILDING', 'PARKING', 'UTILITY'])
  buildingType?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  numberOfFloors?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  totalAreaSqm?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  yearBuilt?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;
}

export class CreateFloorDto {
  @ApiProperty()
  @Type(() => Number)
  @IsNumber()
  level: number;

  @ApiProperty()
  @IsString()
  name: string;

  @ApiPropertyOptional({ enum: ['BASEMENT', 'GROUND', 'MEZZANINE', 'STANDARD', 'PENTHOUSE', 'ROOF'] })
  @IsOptional()
  @IsEnum(['BASEMENT', 'GROUND', 'MEZZANINE', 'STANDARD', 'PENTHOUSE', 'ROOF'])
  floorType?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  areaSqm?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  ceilingHeight?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;
}

export class CreateAreaDto {
  @ApiProperty()
  @IsString()
  name: string;

  @ApiPropertyOptional({ enum: ['GUEST_ROOM', 'LOBBY', 'CORRIDOR', 'RESTAURANT', 'KITCHEN', 'BAR', 'POOL', 'GYM', 'SPA', 'CONFERENCE', 'OFFICE', 'STORAGE', 'UTILITY', 'RESTROOM', 'STAIRWELL', 'ELEVATOR', 'OTHER'] })
  @IsOptional()
  @IsEnum(['GUEST_ROOM', 'LOBBY', 'CORRIDOR', 'RESTAURANT', 'KITCHEN', 'BAR', 'POOL', 'GYM', 'SPA', 'CONFERENCE', 'OFFICE', 'STORAGE', 'UTILITY', 'RESTROOM', 'STAIRWELL', 'ELEVATOR', 'OTHER'])
  areaType?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  areaSqm?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  capacity?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;
}
