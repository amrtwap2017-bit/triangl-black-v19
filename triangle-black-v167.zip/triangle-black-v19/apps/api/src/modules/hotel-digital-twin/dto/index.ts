export { CreateBuildingDto, CreateFloorDto, CreateAreaDto } from './create-hotel-digital-twin.dto';
