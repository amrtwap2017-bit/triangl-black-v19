import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { HotelDigitalTwinService } from './hotel-digital-twin.service';
import { CreateBuildingDto, CreateFloorDto, CreateAreaDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Hotel Digital Twin')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller()
export class HotelDigitalTwinController {
  constructor(private readonly twinService: HotelDigitalTwinService) {}

  // ── Buildings ──

  @Post('buildings')
  @ApiOperation({ summary: 'Create a building' })
  @Roles('admin', 'facility_manager')
  async createBuilding(@Body() dto: CreateBuildingDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.twinService.createBuilding(dto);
    return createResponse(result, 'Building created');
  }

  @Get('buildings')
  @ApiOperation({ summary: 'List buildings (filter by hotelId)' })
  async findAllBuildings(@Query() pagination: PaginationDto, @Query('hotelId') hotelId?: string, @CurrentUser('organizationId') orgId?: string) {
    const result = await this.twinService.findAllBuildings(orgId || '', pagination, hotelId);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('buildings/:id')
  @ApiOperation({ summary: 'Get building by ID' })
  async findOneBuilding(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.twinService.findOneBuilding(id);
    return createResponse(result);
  }

  @Put('buildings/:id')
  @ApiOperation({ summary: 'Update building' })
  @Roles('admin', 'facility_manager')
  async updateBuilding(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateBuildingDto) {
    const result = await this.twinService.updateBuilding(id, dto);
    return createResponse(result, 'Building updated');
  }

  @Delete('buildings/:id')
  @ApiOperation({ summary: 'Delete building (soft delete)' })
  @Roles('admin', 'facility_manager')
  async removeBuilding(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.twinService.removeBuilding(id);
    return createResponse(result);
  }

  // ── Floors (nested under building) ──

  @Post('buildings/:buildingId/floors')
  @ApiOperation({ summary: 'Create a floor in a building' })
  @Roles('admin', 'facility_manager')
  async createFloor(@Param('buildingId', ParseUUIDPipe) buildingId: string, @Body() dto: CreateFloorDto) {
    const result = await this.twinService.createFloor(buildingId, dto);
    return createResponse(result, 'Floor created');
  }

  @Get('buildings/:buildingId/floors')
  @ApiOperation({ summary: 'List floors for a building' })
  async findAllFloors(@Param('buildingId', ParseUUIDPipe) buildingId: string) {
    const result = await this.twinService.findAllFloors(buildingId);
    return createResponse(result);
  }

  @Get('floors/:id')
  @ApiOperation({ summary: 'Get floor by ID' })
  async findOneFloor(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.twinService.findOneFloor(id);
    return createResponse(result);
  }

  @Put('floors/:id')
  @ApiOperation({ summary: 'Update floor' })
  @Roles('admin', 'facility_manager')
  async updateFloor(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateFloorDto) {
    const result = await this.twinService.updateFloor(id, dto);
    return createResponse(result, 'Floor updated');
  }

  @Delete('floors/:id')
  @ApiOperation({ summary: 'Delete floor (soft delete)' })
  @Roles('admin', 'facility_manager')
  async removeFloor(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.twinService.removeFloor(id);
    return createResponse(result);
  }

  // ── Areas (nested under floor) ──

  @Post('floors/:floorId/areas')
  @ApiOperation({ summary: 'Create an area in a floor' })
  @Roles('admin', 'facility_manager')
  async createArea(@Param('floorId', ParseUUIDPipe) floorId: string, @Body() dto: CreateAreaDto) {
    const result = await this.twinService.createArea(floorId, dto);
    return createResponse(result, 'Area created');
  }

  @Get('floors/:floorId/areas')
  @ApiOperation({ summary: 'List areas for a floor' })
  async findAllAreas(@Param('floorId', ParseUUIDPipe) floorId: string) {
    const result = await this.twinService.findAllAreas(floorId);
    return createResponse(result);
  }

  @Get('areas/:id')
  @ApiOperation({ summary: 'Get area by ID' })
  async findOneArea(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.twinService.findOneArea(id);
    return createResponse(result);
  }

  @Put('areas/:id')
  @ApiOperation({ summary: 'Update area' })
  @Roles('admin', 'facility_manager')
  async updateArea(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateAreaDto) {
    const result = await this.twinService.updateArea(id, dto);
    return createResponse(result, 'Area updated');
  }

  @Delete('areas/:id')
  @ApiOperation({ summary: 'Delete area (soft delete)' })
  @Roles('admin', 'facility_manager')
  async removeArea(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.twinService.removeArea(id);
    return createResponse(result);
  }

  // ── Twin Overview ──

  @Get('twin/hotel/:hotelId/overview')
  @ApiOperation({ summary: 'Get complete digital twin overview for a hotel' })
  async getTwinOverview(@Param('hotelId', ParseUUIDPipe) hotelId: string) {
    const result = await this.twinService.getTwinOverview(hotelId);
    return createResponse(result);
  }
}
