import { Module } from '@nestjs/common';
import { HotelDigitalTwinController } from './hotel-digital-twin.controller';
import { HotelDigitalTwinService } from './hotel-digital-twin.service';
import { PrismaModule } from '../../infrastructure/prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [HotelDigitalTwinController],
  providers: [HotelDigitalTwinService],
  exports: [HotelDigitalTwinService],
})
export class HotelDigitalTwinModule {}
