import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateBuildingDto, CreateFloorDto, CreateAreaDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class HotelDigitalTwinService {
  private readonly logger = new Logger(HotelDigitalTwinService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ── Buildings ──

  async createBuilding(dto: CreateBuildingDto) {
    return this.prisma.building.create({
      data: {
        hotelId: dto.hotelId,
        organizationId: dto.organizationId,
        name: dto.name,
        buildingType: dto.buildingType,
        numberOfFloors: dto.numberOfFloors,
        totalAreaSqm: dto.totalAreaSqm,
        yearBuilt: dto.yearBuilt,
        description: dto.description,
      },
    });
  }

  async findAllBuildings(organizationId: string, pagination: PaginationDto, hotelId?: string) {
    const { page, limit, sortBy, sortOrder } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { deletedAt: null };
    if (organizationId) where.organizationId = organizationId;
    if (hotelId) where.hotelId = hotelId;

    const [data, total] = await Promise.all([
      this.prisma.building.findMany({
        where, skip, take,
        orderBy: { [sortBy]: sortOrder },
        include: { floors: { where: { deletedAt: null }, include: { areas: { where: { deletedAt: null } } } } },
      }),
      this.prisma.building.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOneBuilding(id: string) {
    const building = await this.prisma.building.findFirst({
      where: { id, deletedAt: null },
      include: {
        floors: {
          where: { deletedAt: null },
          include: { areas: { where: { deletedAt: null }, include: { assets: true } } },
          orderBy: { level: 'asc' },
        },
        hotel: true,
      },
    });
    if (!building) throw new NotFoundException('Building not found');
    return building;
  }

  async updateBuilding(id: string, dto: CreateBuildingDto) {
    const building = await this.prisma.building.findFirst({ where: { id, deletedAt: null } });
    if (!building) throw new NotFoundException('Building not found');

    return this.prisma.building.update({
      where: { id },
      data: {
        name: dto.name,
        buildingType: dto.buildingType,
        numberOfFloors: dto.numberOfFloors,
        totalAreaSqm: dto.totalAreaSqm,
        yearBuilt: dto.yearBuilt,
        description: dto.description,
      },
    });
  }

  async removeBuilding(id: string) {
    const building = await this.prisma.building.findFirst({ where: { id, deletedAt: null } });
    if (!building) throw new NotFoundException('Building not found');

    await this.prisma.building.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    return { success: true, message: 'Building deleted' };
  }

  // ── Floors ──

  async createFloor(buildingId: string, dto: CreateFloorDto) {
    const building = await this.prisma.building.findFirst({ where: { id: buildingId, deletedAt: null } });
    if (!building) throw new NotFoundException('Building not found');

    return this.prisma.floor.create({
      data: {
        buildingId,
        level: dto.level,
        name: dto.name,
        floorType: dto.floorType,
        areaSqm: dto.areaSqm,
        ceilingHeight: dto.ceilingHeight,
        description: dto.description,
      },
    });
  }

  async findAllFloors(buildingId: string) {
    const building = await this.prisma.building.findFirst({ where: { id: buildingId, deletedAt: null } });
    if (!building) throw new NotFoundException('Building not found');

    return this.prisma.floor.findMany({
      where: { buildingId, deletedAt: null },
      include: { areas: { where: { deletedAt: null } } },
      orderBy: { level: 'asc' },
    });
  }

  async findOneFloor(id: string) {
    const floor = await this.prisma.floor.findFirst({
      where: { id, deletedAt: null },
      include: {
        building: true,
        areas: { where: { deletedAt: null }, include: { assets: true } },
      },
    });
    if (!floor) throw new NotFoundException('Floor not found');
    return floor;
  }

  async updateFloor(id: string, dto: CreateFloorDto) {
    const floor = await this.prisma.floor.findFirst({ where: { id, deletedAt: null } });
    if (!floor) throw new NotFoundException('Floor not found');

    return this.prisma.floor.update({
      where: { id },
      data: {
        level: dto.level,
        name: dto.name,
        floorType: dto.floorType,
        areaSqm: dto.areaSqm,
        ceilingHeight: dto.ceilingHeight,
        description: dto.description,
      },
    });
  }

  async removeFloor(id: string) {
    const floor = await this.prisma.floor.findFirst({ where: { id, deletedAt: null } });
    if (!floor) throw new NotFoundException('Floor not found');

    await this.prisma.floor.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    return { success: true, message: 'Floor deleted' };
  }

  // ── Areas ──

  async createArea(floorId: string, dto: CreateAreaDto) {
    const floor = await this.prisma.floor.findFirst({ where: { id: floorId, deletedAt: null } });
    if (!floor) throw new NotFoundException('Floor not found');

    return this.prisma.area.create({
      data: {
        floorId,
        name: dto.name,
        areaType: dto.areaType,
        areaSqm: dto.areaSqm,
        capacity: dto.capacity,
        description: dto.description,
      },
    });
  }

  async findAllAreas(floorId: string) {
    const floor = await this.prisma.floor.findFirst({ where: { id: floorId, deletedAt: null } });
    if (!floor) throw new NotFoundException('Floor not found');

    return this.prisma.area.findMany({
      where: { floorId, deletedAt: null },
      include: { assets: true },
    });
  }

  async findOneArea(id: string) {
    const area = await this.prisma.area.findFirst({
      where: { id, deletedAt: null },
      include: {
        floor: { include: { building: true } },
        assets: true,
      },
    });
    if (!area) throw new NotFoundException('Area not found');
    return area;
  }

  async updateArea(id: string, dto: CreateAreaDto) {
    const area = await this.prisma.area.findFirst({ where: { id, deletedAt: null } });
    if (!area) throw new NotFoundException('Area not found');

    return this.prisma.area.update({
      where: { id },
      data: {
        name: dto.name,
        areaType: dto.areaType,
        areaSqm: dto.areaSqm,
        capacity: dto.capacity,
        description: dto.description,
      },
    });
  }

  async removeArea(id: string) {
    const area = await this.prisma.area.findFirst({ where: { id, deletedAt: null } });
    if (!area) throw new NotFoundException('Area not found');

    await this.prisma.area.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    return { success: true, message: 'Area deleted' };
  }

  // ── Twin Overview ──

  async getTwinOverview(hotelId: string) {
    const hotel = await this.prisma.hotel.findFirst({ where: { id: hotelId, deletedAt: null } });
    if (!hotel) throw new NotFoundException('Hotel not found');

    const buildings = await this.prisma.building.findMany({
      where: { hotelId, deletedAt: null },
      include: {
        floors: {
          where: { deletedAt: null },
          include: {
            areas: {
              where: { deletedAt: null },
              include: { assets: { where: { deletedAt: null } } },
            },
          },
          orderBy: { level: 'asc' },
        },
      },
    });

    const totalFloors = buildings.reduce((sum, b) => sum + b.floors.length, 0);
    const totalAreas = buildings.reduce((sum, b) => sum + b.floors.reduce((s, f) => s + f.areas.length, 0), 0);
    const totalAssets = buildings.reduce(
      (sum, b) => sum + b.floors.reduce((s, f) => s + f.areas.reduce((a, area) => a + area.assets.length, 0), 0), 0,
    );
    const totalAreaSqm = buildings.reduce((sum, b) => sum + (b.totalAreaSqm || 0), 0);

    // Asset condition distribution
    const allAssets = await this.prisma.hotelAsset.findMany({
      where: { hotelId, deletedAt: null },
      select: { condition: true },
    });
    const conditionDistribution: Record<string, number> = {};
    for (const asset of allAssets) {
      conditionDistribution[asset.condition] = (conditionDistribution[asset.condition] || 0) + 1;
    }

    return {
      hotel: { id: hotel.id, name: hotel.name },
      summary: {
        buildings: buildings.length,
        totalFloors,
        totalAreas,
        totalAssets,
        totalAreaSqm,
      },
      assetHealth: {
        distribution: conditionDistribution,
        critical: conditionDistribution['CRITICAL'] || 0,
        poor: conditionDistribution['POOR'] || 0,
      },
      hierarchy: buildings.map((b) => ({
        id: b.id,
        name: b.name,
        buildingType: b.buildingType,
        totalAreaSqm: b.totalAreaSqm,
        floors: b.floors.map((f) => ({
          id: f.id,
          name: f.name,
          level: f.level,
          areaSqm: f.areaSqm,
          areas: f.areas.map((a) => ({
            id: a.id,
            name: a.name,
            areaType: a.areaType,
            areaSqm: a.areaSqm,
            assetCount: a.assets.length,
          })),
        })),
      })),
    };
  }
}
