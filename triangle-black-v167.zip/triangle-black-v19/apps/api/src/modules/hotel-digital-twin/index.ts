export * from './hotel-digital-twin.module';
