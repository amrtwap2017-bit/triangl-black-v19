import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { HotelIntelligenceService } from './hotel-intelligence.service';
import { CreateAssetDto, UpdateAssetDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Hotel Intelligence')
@ApiBearerAuth()
@Controller('hotel-intelligence/assets')
export class HotelIntelligenceController {
  constructor(private readonly service: HotelIntelligenceService) {}

  @Post()
  @ApiOperation({ summary: 'Create hotel asset' })
  async create(@Body() dto: CreateAssetDto, @CurrentUser('id') userId: string) {
    const result = await this.service.create(dto, userId);
    return createResponse(result, 'Asset created');
  }

  @Get()
  @ApiOperation({ summary: 'List hotel assets with filtering' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('hotelId') hotelId?: string,
    @Query('assetType') assetType?: string,
  ) {
    const result = await this.service.findAll(orgId, pagination, { hotelId, assetType });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('expiring-warranties')
  @ApiOperation({ summary: 'Assets with warranty ending in 90 days (OPPORTUNITY RADAR)' })
  async getExpiringWarranties(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getExpiringWarranties(orgId);
    return createResponse(result);
  }

  @Get('aging-report')
  @ApiOperation({ summary: 'Assets older than X years needing replacement' })
  async getAgingReport(
    @CurrentUser('organizationId') orgId: string,
    @Query('years') years?: string,
  ) {
    const threshold = years ? parseInt(years, 10) : undefined;
    const result = await this.service.getAgingReport(orgId, threshold);
    return createResponse(result);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get asset with service history' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update asset' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateAssetDto,
    @CurrentUser('id') userId: string,
  ) {
    const result = await this.service.update(id, dto, userId);
    return createResponse(result, 'Asset updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete asset' })
  async remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.service.remove(id, userId);
    return createResponse(result);
  }
}
