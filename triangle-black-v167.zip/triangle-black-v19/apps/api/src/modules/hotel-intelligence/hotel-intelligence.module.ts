import { Module } from '@nestjs/common';
import { HotelIntelligenceController } from './hotel-intelligence.controller';
import { HotelIntelligenceService } from './hotel-intelligence.service';

@Module({
  controllers: [HotelIntelligenceController],
  providers: [HotelIntelligenceService],
  exports: [HotelIntelligenceService],
})
export class HotelIntelligenceModule {}
