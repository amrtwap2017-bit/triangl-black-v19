import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { CreateAssetDto, UpdateAssetDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination } from '../../../common/utils';

@Injectable()
export class HotelIntelligenceService {
  private readonly logger = new Logger(HotelIntelligenceService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateAssetDto, userId: string) {
    return this.prisma.hotelAsset.create({
      data: {
        ...dto,
        createdBy: userId,
        updatedBy: userId,
        status: dto.status ?? 'OPERATIONAL',
      },
      include: { hotel: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { hotelId?: string; assetType?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId, deletedAt: null };

    if (filters?.hotelId) where.hotelId = filters.hotelId;
    if (filters?.assetType) where.assetType = filters.assetType;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { brand: { contains: search, mode: 'insensitive' } },
        { model: { contains: search, mode: 'insensitive' } },
        { serialNumber: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.hotelAsset.findMany({
        where, skip, take,
        orderBy: { [sortBy || 'createdAt']: sortOrder || 'DESC' },
        include: { hotel: true },
      }),
      this.prisma.hotelAsset.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const asset = await this.prisma.hotelAsset.findFirst({
      where: { id, deletedAt: null },
      include: { hotel: true },
    });
    if (!asset) throw new NotFoundException('Asset not found');
    return asset;
  }

  async update(id: string, dto: UpdateAssetDto, userId: string) {
    await this.findOne(id);
    const existing = await this.prisma.hotelAsset.findUnique({ where: { id }, select: { version: true } });
    return this.prisma.hotelAsset.update({
      where: { id },
      data: { ...dto, updatedBy: userId, version: { increment: 1 } },
      include: { hotel: true },
    });
  }

  async remove(id: string, userId: string) {
    await this.findOne(id);
    await this.prisma.hotelAsset.update({
      where: { id },
      data: { deletedAt: new Date(), updatedBy: userId, version: { increment: 1 } },
    });
    return { success: true, message: 'Asset soft-deleted' };
  }

  async getExpiringWarranties(organizationId: string) {
    const now = new Date();
    const ninetyDaysFromNow = new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000);
    return this.prisma.hotelAsset.findMany({
      where: {
        organizationId,
        deletedAt: null,
        warrantyEnd: { gte: now, lte: ninetyDaysFromNow },
      },
      include: { hotel: true },
      orderBy: { warrantyEnd: 'ASC' },
    });
  }

  async getAgingReport(organizationId: string, yearsThreshold?: number) {
    const threshold = yearsThreshold ?? 10;
    const cutoffDate = new Date();
    cutoffDate.setFullYear(cutoffDate.getFullYear() - threshold);
    return this.prisma.hotelAsset.findMany({
      where: {
        organizationId,
        deletedAt: null,
        installDate: { lte: cutoffDate },
      },
      include: { hotel: true },
      orderBy: { installDate: 'ASC' },
    });
  }
}
