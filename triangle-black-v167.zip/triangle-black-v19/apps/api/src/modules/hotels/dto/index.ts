export { CreateHotelDto, UpdateHotelDto } from './create-hotel.dto';
