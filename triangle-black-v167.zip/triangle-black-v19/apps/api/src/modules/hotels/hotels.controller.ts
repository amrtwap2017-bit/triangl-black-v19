import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { HotelsService } from './hotels.service';
import { CreateHotelDto, UpdateHotelDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Hotels')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('hotels')
export class HotelsController {
  constructor(private readonly hotelsService: HotelsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a hotel' })
  async create(@Body() dto: CreateHotelDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.hotelsService.create(dto);
    return createResponse(result, 'Hotel created');
  }

  @Get()
  @ApiOperation({ summary: 'List all hotels in organization' })
  async findAll(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string) {
    const result = await this.hotelsService.findAll(orgId, pagination);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get hotel by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.hotelsService.findOne(id);
    return createResponse(result);
  }

  @Get(':id/contacts')
  @ApiOperation({ summary: 'Get hotel contacts' })
  async getContacts(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.hotelsService.getContacts(id);
    return createResponse(result);
  }

  @Get(':id/relationship')
  @ApiOperation({ summary: 'Get hotel relationship intelligence' })
  async getRelationship(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.hotelsService.getRelationship(id);
    return createResponse(result);
  }

  @Get(':id/statistics')
  @ApiOperation({ summary: 'Get hotel statistics' })
  async getStatistics(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.hotelsService.getStatistics(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update hotel' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateHotelDto) {
    const result = await this.hotelsService.update(id, dto);
    return createResponse(result, 'Hotel updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete hotel' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.hotelsService.remove(id);
    return createResponse(result);
  }
}
