import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateHotelDto, UpdateHotelDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class HotelsService {
  private readonly logger = new Logger(HotelsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateHotelDto) {
    return this.prisma.hotel.create({ data: dto });
  }

  async findAll(organizationId: string, pagination: PaginationDto) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { city: { contains: search, mode: 'insensitive' } },
        { country: { contains: search, mode: 'insensitive' } },
      ];
    }
    const [data, total] = await Promise.all([
      this.prisma.hotel.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder } }),
      this.prisma.hotel.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const hotel = await this.prisma.hotel.findUnique({ where: { id } });
    if (!hotel) throw new NotFoundException('Hotel not found');
    return hotel;
  }

  async update(id: string, dto: UpdateHotelDto) {
    try {
      return this.prisma.hotel.update({ where: { id }, data: dto });
    } catch {
      throw new NotFoundException('Hotel not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.hotel.delete({ where: { id } });
      return { success: true, message: 'Hotel deleted' };
    } catch {
      throw new NotFoundException('Hotel not found');
    }
  }

  async getContacts(hotelId: string) {
    return this.prisma.hotelContact.findMany({ where: { hotelId }, orderBy: { isPrimary: 'desc', createdAt: 'desc' } });
  }

  async getRelationship(hotelId: string) {
    const relationship = await this.prisma.hotelRelationship.findUnique({ where: { hotelId } });
    if (!relationship) throw new NotFoundException('Hotel relationship not found');
    return relationship;
  }

  async getStatistics(hotelId: string) {
    const [projectCount, revenue, emergencyCount] = await Promise.all([
      this.prisma.project.count({ where: { hotelId } }),
      this.prisma.project.aggregate({ where: { hotelId }, _sum: { revenue: true } }),
      this.prisma.emergencyCase.count({ where: { hotelId } }),
    ]);
    return {
      projectCount,
      totalRevenue: revenue._sum.revenue || 0,
      emergencyCount,
    };
  }
}
