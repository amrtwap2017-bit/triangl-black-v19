import { IsString, IsOptional, IsUUID, IsEnum, IsDateString, IsObject, IsArray } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateInspectionDto {
  @ApiProperty()
  @IsUUID()
  projectId: string;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  inspectorId?: string;

  @ApiProperty()
  @IsDateString()
  inspectedAt: string;

  @ApiPropertyOptional({ enum: ['PASSED', 'FAILED', 'CONDITIONAL'] })
  @IsOptional()
  @IsEnum(['PASSED', 'FAILED', 'CONDITIONAL'])
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  checklist?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  findings?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  correctiveActions?: any[];
}

export class UpdateInspectionDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  inspectedAt?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['PASSED', 'FAILED', 'CONDITIONAL'])
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  checklist?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  findings?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  correctiveActions?: any[];
}

export class SignOffInspectionDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}
