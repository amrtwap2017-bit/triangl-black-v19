import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { InspectionsService } from './inspections.service';
import { CreateInspectionDto, UpdateInspectionDto, SignOffInspectionDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Inspections')
@ApiBearerAuth()
@Controller('inspections')
export class InspectionsController {
  constructor(private readonly service: InspectionsService) {}

  @Post()
  @ApiOperation({ summary: 'Create inspection' })
  async create(@Body() dto: CreateInspectionDto, @CurrentUser('id') userId: string) {
    const result = await this.service.create(dto, userId);
    return createResponse(result, 'Inspection created');
  }

  @Get()
  @ApiOperation({ summary: 'List inspections' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('projectId') projectId?: string,
  ) {
    const result = await this.service.findAll(orgId, pagination, { projectId });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('checklist-template')
  @ApiOperation({ summary: 'Get inspection checklist template by project type' })
  async getChecklistTemplate(@Query('projectType') projectType?: string) {
    const result = await this.service.getChecklistTemplate(projectType);
    return createResponse(result);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get inspection by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update inspection' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateInspectionDto) {
    const result = await this.service.update(id, dto);
    return createResponse(result, 'Inspection updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete inspection' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.remove(id);
    return createResponse(result);
  }

  @Post(':id/sign-off')
  @ApiOperation({ summary: 'Sign off inspection' })
  async signOff(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser('id') userId: string,
    @Body() dto?: SignOffInspectionDto,
  ) {
    const result = await this.service.signOff(id, userId, dto?.notes);
    return createResponse(result, 'Inspection signed off');
  }
}
