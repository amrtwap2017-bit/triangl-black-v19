import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { CreateInspectionDto, UpdateInspectionDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination } from '../../../common/utils';

@Injectable()
export class InspectionsService {
  private readonly logger = new Logger(InspectionsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateInspectionDto, userId: string) {
    return this.prisma.projectInspection.create({
      data: {
        projectId: dto.projectId,
        title: dto.title,
        inspectorId: dto.inspectorId,
        inspectedAt: new Date(dto.inspectedAt),
        status: dto.status ?? 'PASSED',
        checklist: dto.checklist,
        findings: dto.findings,
        correctiveActions: dto.correctiveActions,
        createdBy: userId,
      },
      include: { project: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { projectId?: string }) {
    const { page, limit, sortBy, sortOrder } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = {};
    if (filters?.projectId) where.projectId = filters.projectId;

    const [data, total] = await Promise.all([
      this.prisma.projectInspection.findMany({
        where, skip, take,
        orderBy: { [sortBy || 'inspectedAt']: sortOrder || 'DESC' },
        include: { project: true },
      }),
      this.prisma.projectInspection.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const inspection = await this.prisma.projectInspection.findUnique({
      where: { id },
      include: { project: true },
    });
    if (!inspection) throw new NotFoundException('Inspection not found');
    return inspection;
  }

  async update(id: string, dto: UpdateInspectionDto) {
    await this.findOne(id);
    return this.prisma.projectInspection.update({
      where: { id },
      data: {
        ...dto,
        inspectedAt: dto.inspectedAt ? new Date(dto.inspectedAt) : undefined,
      },
      include: { project: true },
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.projectInspection.delete({ where: { id } });
    return { success: true, message: 'Inspection deleted' };
  }

  async signOff(id: string, userId: string, notes?: string) {
    const inspection = await this.findOne(id);
    return this.prisma.projectInspection.update({
      where: { id },
      data: {
        signedOffBy: userId,
        signedOffAt: new Date(),
        status: inspection.status === 'FAILED' ? inspection.status : 'PASSED',
      },
      include: { project: true },
    });
  }

  async getChecklistTemplate(projectType?: string) {
    const templates: Record<string, any[]> = {
      HVAC: [
        { item: 'Ductwork installation per specification', category: 'Installation' },
        { item: 'Chiller mounting and alignment', category: 'Equipment' },
        { item: 'Pipe welding quality check', category: 'Quality' },
        { item: 'Insulation thickness verification', category: 'Quality' },
        { item: 'Controls wiring and commissioning', category: 'Commissioning' },
        { item: 'Air balancing and flow measurement', category: 'Commissioning' },
        { item: 'Refrigerant leak test', category: 'Safety' },
        { item: 'Vibration test on rotating equipment', category: 'Testing' },
      ],
      ELECTRICAL: [
        { item: 'Cable tray and conduit installation', category: 'Installation' },
        { item: 'Panel wiring and labeling', category: 'Installation' },
        { item: 'Earth/ground continuity test', category: 'Safety' },
        { item: 'Insulation resistance test', category: 'Testing' },
        { item: 'Protective device coordination', category: 'Commissioning' },
        { item: 'Emergency lighting test', category: 'Safety' },
      ],
      PLUMBING: [
        { item: 'Pipe layout and slope verification', category: 'Installation' },
        { item: 'Pressure test on supply lines', category: 'Testing' },
        { item: 'Drainage flow test', category: 'Testing' },
        { item: 'Water heater installation check', category: 'Equipment' },
        { item: 'Backflow preventer test', category: 'Safety' },
      ],
      WATERPROOFING: [
        { item: 'Surface preparation inspection', category: 'Preparation' },
        { item: 'Membrane overlap and sealing', category: 'Installation' },
        { item: 'Flood test (72 hours)', category: 'Testing' },
        { item: 'Crack injection quality check', category: 'Quality' },
        { item: 'Drainage path verification', category: 'Installation' },
      ],
    };

    return {
      projectType: projectType || 'GENERAL',
      checklist: templates[projectType || 'HVAC'] || templates.HVAC,
    };
  }
}
