import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { KnowledgeHubService } from './knowledge-hub.service';
import { CreateKnowledgeDto, UpdateKnowledgeDto, SearchKnowledgeDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Knowledge Hub')
@ApiBearerAuth()
@Controller('knowledge')
export class KnowledgeHubController {
  constructor(private readonly service: KnowledgeHubService) {}

  @Post()
  @ApiOperation({ summary: 'Create knowledge article' })
  async create(@Body() dto: CreateKnowledgeDto, @CurrentUser('id') userId: string) {
    const result = await this.service.create(dto, userId);
    return createResponse(result, 'Knowledge article created');
  }

  @Get()
  @ApiOperation({ summary: 'List knowledge articles with category filter and search' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('category') category?: string,
    @Query('tags') tags?: string,
  ) {
    const result = await this.service.findAll(orgId, pagination, { category, tags });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('categories')
  @ApiOperation({ summary: 'List all categories with counts' })
  async getCategories(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getCategories(orgId);
    return createResponse(result);
  }

  @Get('related/:id')
  @ApiOperation({ summary: 'Find related articles by tags overlap' })
  async getRelated(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.getRelated(id);
    return createResponse(result);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get knowledge article by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update knowledge article' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateKnowledgeDto,
    @CurrentUser('id') userId: string,
  ) {
    const result = await this.service.update(id, dto, userId);
    return createResponse(result, 'Article updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete knowledge article' })
  async remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.service.remove(id, userId);
    return createResponse(result);
  }

  @Post(':id/search')
  @ApiOperation({ summary: 'AI-powered semantic search (placeholder)' })
  async search(@Param('id', ParseUUIDPipe) id: string, @Body() dto: SearchKnowledgeDto) {
    const result = await this.service.search(id, dto.query);
    return createResponse(result);
  }
}
