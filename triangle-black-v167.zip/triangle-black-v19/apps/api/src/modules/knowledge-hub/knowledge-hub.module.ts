import { Module } from '@nestjs/common';
import { KnowledgeHubController } from './knowledge-hub.controller';
import { KnowledgeHubService } from './knowledge-hub.service';

@Module({
  controllers: [KnowledgeHubController],
  providers: [KnowledgeHubService],
  exports: [KnowledgeHubService],
})
export class KnowledgeHubModule {}
