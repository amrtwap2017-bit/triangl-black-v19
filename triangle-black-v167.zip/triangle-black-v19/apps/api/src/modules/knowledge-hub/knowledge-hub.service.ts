import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { CreateKnowledgeDto, UpdateKnowledgeDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination } from '../../../common/utils';

@Injectable()
export class KnowledgeHubService {
  private readonly logger = new Logger(KnowledgeHubService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateKnowledgeDto, userId: string) {
    return this.prisma.knowledgeArticle.create({
      data: { ...dto, createdBy: userId, updatedBy: userId },
      include: { author: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { category?: string; tags?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId, deletedAt: null };
    if (filters?.category) where.category = filters.category;
    if (filters?.tags) {
      where.tags = { has: filters.tags };
    }
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { content: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.knowledgeArticle.findMany({
        where, skip, take,
        orderBy: { [sortBy || 'createdAt']: sortOrder || 'DESC' },
        include: { author: { select: { id: true, name: true, email: true } } },
      }),
      this.prisma.knowledgeArticle.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const article = await this.prisma.knowledgeArticle.findFirst({
      where: { id, deletedAt: null },
      include: { author: { select: { id: true, name: true, email: true } } },
    });
    if (!article) throw new NotFoundException('Knowledge article not found');
    return article;
  }

  async update(id: string, dto: UpdateKnowledgeDto, userId: string) {
    await this.findOne(id);
    return this.prisma.knowledgeArticle.update({
      where: { id },
      data: { ...dto, updatedBy: userId, version: { increment: 1 } },
      include: { author: true },
    });
  }

  async remove(id: string, userId: string) {
    await this.findOne(id);
    await this.prisma.knowledgeArticle.update({
      where: { id },
      data: { deletedAt: new Date(), updatedBy: userId, version: { increment: 1 } },
    });
    return { success: true, message: 'Article soft-deleted' };
  }

  async getCategories(organizationId: string) {
    const categories = await this.prisma.knowledgeArticle.groupBy({
      by: ['category'],
      where: { organizationId, deletedAt: null },
      _count: { id: true },
    });
    return categories.map((c) => ({ category: c.category, count: c._count.id }));
  }

  async search(id: string, query: string) {
    // AI-powered semantic search placeholder - uses Prisma contains for now
    const article = await this.findOne(id);
    const results = await this.prisma.knowledgeArticle.findMany({
      where: {
        organizationId: article.organizationId,
        deletedAt: null,
        id: { not: id },
        OR: [
          { title: { contains: query, mode: 'insensitive' } },
          { content: { contains: query, mode: 'insensitive' } },
          { tags: { has: query } },
        ],
      },
      take: 10,
      include: { author: { select: { id: true, name: true, email: true } } },
    });
    return { query, results };
  }

  async getRelated(id: string) {
    const article = await this.findOne(id);
    if (!article.tags || article.tags.length === 0) return [];

    return this.prisma.knowledgeArticle.findMany({
      where: {
        organizationId: article.organizationId,
        deletedAt: null,
        id: { not: id },
        tags: { hasSome: article.tags },
      },
      orderBy: { createdAt: 'DESC' },
      take: 5,
      include: { author: { select: { id: true, name: true, email: true } } },
    });
  }

  /**
   * Full-text search across knowledge articles with optional filters for category, tags, and date range.
   */
  async searchKnowledge(organizationId: string, query: string, filters?: { category?: string; tags?: string[]; fromDate?: string; toDate?: string }) {
    const where: any = {
      organizationId,
      deletedAt: null,
    };

    if (query) {
      where.OR = [
        { title: { contains: query, mode: 'insensitive' } },
        { content: { contains: query, mode: 'insensitive' } },
        { summary: { contains: query, mode: 'insensitive' } },
        { tags: { has: query } },
      ];
    }

    if (filters?.category) {
      where.category = filters.category;
    }

    if (filters?.tags && filters.tags.length > 0) {
      where.tags = { hasSome: filters.tags };
    }

    if (filters?.fromDate || filters?.toDate) {
      where.createdAt = {};
      if (filters.fromDate) where.createdAt.gte = new Date(filters.fromDate);
      if (filters.toDate) where.createdAt.lte = new Date(filters.toDate);
    }

    const results = await this.prisma.knowledgeArticle.findMany({
      where,
      orderBy: [
        { viewCount: 'DESC' },
        { createdAt: 'DESC' },
      ],
      take: 20,
      include: { author: { select: { id: true, name: true, email: true } } },
    });

    // Increment view count for matching articles (fire-and-forget)
    for (const article of results) {
      this.prisma.knowledgeArticle.update({
        where: { id: article.id },
        data: { viewCount: { increment: 1 } },
      }).catch(() => { /* ignore */ });
    }

    return {
      query,
      filters: filters || {},
      total: results.length,
      results,
    };
  }

  /**
   * Find semantically related articles by tags and category similarity.
   */
  async getRelatedArticles(articleId: string) {
    const article = await this.findOne(articleId);

    // Build related articles using multiple signals: tags, category, and content keywords
    const relatedByTags = article.tags && article.tags.length > 0
      ? await this.prisma.knowledgeArticle.findMany({
          where: {
            organizationId: article.organizationId,
            deletedAt: null,
            id: { not: articleId },
            tags: { hasSome: article.tags },
          },
          take: 10,
          include: { author: { select: { id: true, name: true, email: true } } },
        })
      : [];

    // Also find by same category
    const relatedByCategory = await this.prisma.knowledgeArticle.findMany({
      where: {
        organizationId: article.organizationId,
        deletedAt: null,
        id: { not: articleId },
        category: article.category,
      },
      take: 5,
      include: { author: { select: { id: true, name: true, email: true } } },
    });

    // Merge and deduplicate by id
    const mergedMap = new Map<string, any>();
    for (const a of [...relatedByTags, ...relatedByCategory]) {
      if (!mergedMap.has(a.id)) {
        mergedMap.set(a.id, a);
      }
    }

    // Score each article: +10 for each matching tag, +5 for same category
    const scored = Array.from(mergedMap.values()).map((a) => {
      let relevanceScore = 0;
      if (a.tags && article.tags) {
        const commonTags = a.tags.filter((t: string) => article.tags.includes(t));
        relevanceScore += commonTags.length * 10;
      }
      if (a.category === article.category) relevanceScore += 5;
      return { ...a, relevanceScore };
    });

    scored.sort((a, b) => b.relevanceScore - a.relevanceScore);

    return scored.slice(0, 10);
  }

  /**
   * Knowledge stats: articles by category, most viewed, and recently added.
   */
  async getKnowledgeStats(organizationId: string) {
    const [byCategory, mostViewed, recentlyAdded, total, totalViews] = await Promise.all([
      this.prisma.knowledgeArticle.groupBy({
        by: ['category'],
        where: { organizationId, deletedAt: null },
        _count: { id: true },
        _sum: { viewCount: true },
      }),
      this.prisma.knowledgeArticle.findMany({
        where: { organizationId, deletedAt: null },
        orderBy: { viewCount: 'DESC' },
        take: 10,
        select: { id: true, title: true, category: true, viewCount: true, createdAt: true },
      }),
      this.prisma.knowledgeArticle.findMany({
        where: { organizationId, deletedAt: null },
        orderBy: { createdAt: 'DESC' },
        take: 10,
        select: { id: true, title: true, category: true, viewCount: true, createdAt: true },
      }),
      this.prisma.knowledgeArticle.count({ where: { organizationId, deletedAt: null } }),
      this.prisma.knowledgeArticle.aggregate({
        where: { organizationId, deletedAt: null },
        _sum: { viewCount: true },
      }),
    ]);

    return {
      total,
      totalViews: totalViews._sum.viewCount || 0,
      byCategory: byCategory.map((c) => ({
        category: c.category,
        count: c._count.id,
        totalViews: c._sum.viewCount || 0,
      })),
      mostViewed,
      recentlyAdded,
    };
  }
}
