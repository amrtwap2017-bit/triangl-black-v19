export class MarginBreakdownDto {}
export class MarginFilterDto {}
