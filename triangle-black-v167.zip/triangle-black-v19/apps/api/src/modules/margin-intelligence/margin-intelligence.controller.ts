import { Controller, Get, Param, ParseUUIDPipe, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { MarginIntelligenceService } from './margin-intelligence.service';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Margin Intelligence')
@ApiBearerAuth()
@Controller('margin')
export class MarginIntelligenceController {
  constructor(private readonly service: MarginIntelligenceService) {}

  @Get('by-hotel')
  @ApiOperation({ summary: 'Margin aggregated per hotel' })
  async getByHotel(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getMarginByHotel(orgId);
    return createResponse(result);
  }

  @Get('by-type')
  @ApiOperation({ summary: 'Margin by project type' })
  async getByType(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getMarginByType(orgId);
    return createResponse(result);
  }

  @Get('by-vendor')
  @ApiOperation({ summary: 'Margin impact by vendor' })
  async getByVendor(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getMarginByVendor(orgId);
    return createResponse(result);
  }

  @Get('trends')
  @ApiOperation({ summary: 'Margin trend over time (monthly)' })
  async getTrends(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getMarginTrends(orgId);
    return createResponse(result);
  }

  @Get('project/:projectId')
  @ApiOperation({ summary: 'Full margin breakdown for a project' })
  async getProjectMargin(@Param('projectId', ParseUUIDPipe) projectId: string) {
    const result = await this.service.getProjectMargin(projectId);
    return createResponse(result);
  }
}
