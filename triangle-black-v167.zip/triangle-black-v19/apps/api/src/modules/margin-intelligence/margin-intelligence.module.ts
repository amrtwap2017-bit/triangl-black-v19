import { Module } from '@nestjs/common';
import { MarginIntelligenceController } from './margin-intelligence.controller';
import { MarginIntelligenceService } from './margin-intelligence.service';

@Module({
  controllers: [MarginIntelligenceController],
  providers: [MarginIntelligenceService],
  exports: [MarginIntelligenceService],
})
export class MarginIntelligenceModule {}
