import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';

@Injectable()
export class MarginIntelligenceService {
  private readonly logger = new Logger(MarginIntelligenceService.name);

  constructor(private readonly prisma: PrismaService) {}

  async getProjectMargin(projectId: string) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, deletedAt: null },
      include: {
        variationOrders: true,
        proposal: {
          select: {
            totalValue: true,
            materialCost: true,
            laborCost: true,
            vendorCost: true,
            proposedMargin: true,
          },
        },
      },
    });
    if (!project) throw new NotFoundException('Project not found');

    const variationImpact = project.variationOrders.reduce(
      (sum, vo) => sum + (vo.marginImpact || 0), 0,
    );
    const revenue = project.revenue || project.proposal?.totalValue || 0;
    const materialCost = project.actualCost
      ? project.actualCost * 0.45
      : project.proposal?.materialCost || 0;
    const laborCost = project.actualCost
      ? project.actualCost * 0.35
      : project.proposal?.laborCost || 0;
    const vendorCost = project.proposal?.vendorCost || 0;
    const totalCost = materialCost + laborCost + vendorCost;
    const actualMargin = revenue - totalCost + variationImpact;
    const marginPercent = revenue > 0 ? (actualMargin / revenue) * 100 : 0;

    return {
      projectId,
      projectName: project.name,
      revenue,
      materialCost,
      laborCost,
      vendorCost,
      variationImpact,
      totalCost,
      actualMargin,
      marginPercent: Math.round(marginPercent * 100) / 100,
    };
  }

  async getMarginByHotel(organizationId: string) {
    const projects = await this.prisma.project.findMany({
      where: { organizationId, deletedAt: null, revenue: { gt: 0 } },
      include: { hotel: true },
    });

    const hotelMap = new Map<string, { hotelName: string; totalRevenue: number; totalCost: number; margin: number }>();
    for (const p of projects) {
      const hotelId = p.hotelId || 'unassigned';
      const hotelName = p.hotel?.name || 'Unassigned';
      if (!hotelMap.has(hotelId)) {
        hotelMap.set(hotelId, { hotelName, totalRevenue: 0, totalCost: 0, margin: 0 });
      }
      const entry = hotelMap.get(hotelId)!;
      entry.totalRevenue += p.revenue || 0;
      entry.totalCost += p.actualCost || 0;
      entry.margin += (p.revenue || 0) - (p.actualCost || 0);
    }

    return Array.from(hotelMap.entries()).map(([hotelId, data]) => ({
      hotelId,
      ...data,
      marginPercent: data.totalRevenue > 0 ? Math.round((data.margin / data.totalRevenue) * 10000) / 100 : 0,
    }));
  }

  async getMarginByType(organizationId: string) {
    const projects = await this.prisma.project.findMany({
      where: { organizationId, deletedAt: null, revenue: { gt: 0 } },
      select: { type: true, revenue: true, actualCost: true },
    });

    const typeMap = new Map<string, { totalRevenue: number; totalCost: number; count: number; margin: number }>();
    for (const p of projects) {
      const type = p.type || 'OTHER';
      if (!typeMap.has(type)) {
        typeMap.set(type, { totalRevenue: 0, totalCost: 0, count: 0, margin: 0 });
      }
      const entry = typeMap.get(type)!;
      entry.totalRevenue += p.revenue || 0;
      entry.totalCost += p.actualCost || 0;
      entry.margin += (p.revenue || 0) - (p.actualCost || 0);
      entry.count++;
    }

    return Array.from(typeMap.entries()).map(([type, data]) => ({
      type,
      ...data,
      marginPercent: data.totalRevenue > 0 ? Math.round((data.margin / data.totalRevenue) * 10000) / 100 : 0,
    }));
  }

  async getMarginByVendor(organizationId: string) {
    const pos = await this.prisma.purchaseOrder.findMany({
      where: { organizationId, deletedAt: null },
      include: { vendor: true },
    });

    const vendorMap = new Map<string, { vendorName: string; totalSpend: number; orderCount: number }>();
    for (const po of pos) {
      const vendorId = po.vendorId || 'unknown';
      const vendorName = po.vendor?.name || 'Unknown';
      if (!vendorMap.has(vendorId)) {
        vendorMap.set(vendorId, { vendorName, totalSpend: 0, orderCount: 0 });
      }
      const entry = vendorMap.get(vendorId)!;
      entry.totalSpend += po.amount || 0;
      entry.orderCount++;
    }

    return Array.from(vendorMap.entries()).map(([vendorId, data]) => ({
      vendorId,
      ...data,
    }));
  }

  async getMarginTrends(organizationId: string) {
    const projects = await this.prisma.project.findMany({
      where: { organizationId, deletedAt: null, revenue: { gt: 0 } },
      select: { createdAt: true, revenue: true, actualCost: true },
      orderBy: { createdAt: 'ASC' },
    });

    const monthMap = new Map<string, { revenue: number; cost: number; count: number }>();
    for (const p of projects) {
      const monthKey = `${p.createdAt.getFullYear()}-${String(p.createdAt.getMonth() + 1).padStart(2, '0')}`;
      if (!monthMap.has(monthKey)) {
        monthMap.set(monthKey, { revenue: 0, cost: 0, count: 0 });
      }
      const entry = monthMap.get(monthKey)!;
      entry.revenue += p.revenue || 0;
      entry.cost += p.actualCost || 0;
      entry.count++;
    }

    return Array.from(monthMap.entries()).map(([month, data]) => ({
      month,
      ...data,
      margin: data.revenue - data.cost,
      marginPercent: data.revenue > 0 ? Math.round(((data.revenue - data.cost) / data.revenue) * 10000) / 100 : 0,
    }));
  }

  /**
   * Per-project margin tracking with detailed actual cost breakdown.
   * Breaks down costs into material, labor, vendor, and overhead components.
   */
  async getProjectCostBreakdown(projectId: string) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, deletedAt: null },
      include: {
        variationOrders: true,
        proposal: {
          select: {
            totalValue: true,
            materialCost: true,
            laborCost: true,
            vendorCost: true,
            proposedMargin: true,
            boq: true,
          },
        },
        purchaseOrders: {
          where: { deletedAt: null },
          select: { amount: true, items: true, category: true },
        },
      },
    });
    if (!project) throw new NotFoundException('Project not found');

    const revenue = project.revenue || project.proposal?.totalValue || 0;

    // Derive actual costs from purchase orders
    let actualMaterialCost = 0;
    let actualLaborCost = 0;
    let actualVendorCost = 0;
    let actualOverheadCost = 0;

    if (project.actualCost) {
      // If actualCost exists, distribute using proposal ratios
      const proposalTotal = (project.proposal?.materialCost || 0) + (project.proposal?.laborCost || 0) + (project.proposal?.vendorCost || 0);
      if (proposalTotal > 0) {
        actualMaterialCost = project.actualCost * ((project.proposal?.materialCost || 0) / proposalTotal);
        actualLaborCost = project.actualCost * ((project.proposal?.laborCost || 0) / proposalTotal);
        actualVendorCost = project.actualCost * ((project.proposal?.vendorCost || 0) / proposalTotal);
      } else {
        // Default distribution: 45% material, 35% labor, 10% vendor, 10% overhead
        actualMaterialCost = project.actualCost * 0.45;
        actualLaborCost = project.actualCost * 0.35;
        actualVendorCost = project.actualCost * 0.10;
        actualOverheadCost = project.actualCost * 0.10;
      }
    } else {
      // Fall back to proposal estimates
      actualMaterialCost = project.proposal?.materialCost || 0;
      actualLaborCost = project.proposal?.laborCost || 0;
      actualVendorCost = project.proposal?.vendorCost || 0;
      actualOverheadCost = 0;
    }

    const variationImpact = project.variationOrders.reduce(
      (sum, vo) => sum + (vo.marginImpact || 0), 0,
    );

    const totalActualCost = actualMaterialCost + actualLaborCost + actualVendorCost + actualOverheadCost;
    const actualMargin = revenue - totalActualCost + variationImpact;
    const marginPercent = revenue > 0 ? (actualMargin / revenue) * 100 : 0;

    // Analyze BOQ items for cost deviations
    const boqItems = (project.proposal?.boq as any[]) || [];
    const boqAnalysis = boqItems.map((item) => ({
      item: item.item || item.description,
      estimatedCost: item.total || (item.quantity * item.unitPrice) || 0,
      actualCost: 0, // Would be populated from actual tracking
      variance: 0,
      variancePercent: 0,
    }));

    return {
      projectId,
      projectName: project.name,
      revenue,
      costBreakdown: {
        material: { estimated: project.proposal?.materialCost || 0, actual: Math.round(actualMaterialCost), variance: Math.round(actualMaterialCost - (project.proposal?.materialCost || 0)) },
        labor: { estimated: project.proposal?.laborCost || 0, actual: Math.round(actualLaborCost), variance: Math.round(actualLaborCost - (project.proposal?.laborCost || 0)) },
        vendor: { estimated: project.proposal?.vendorCost || 0, actual: Math.round(actualVendorCost), variance: Math.round(actualVendorCost - (project.proposal?.vendorCost || 0)) },
        overhead: { estimated: 0, actual: Math.round(actualOverheadCost), variance: Math.round(actualOverheadCost) },
      },
      totalActualCost: Math.round(totalActualCost),
      variationImpact,
      actualMargin: Math.round(actualMargin),
      marginPercent: Math.round(marginPercent * 100) / 100,
      boqAnalysis,
      costPerCategory: {
        materialPercent: totalActualCost > 0 ? Math.round((actualMaterialCost / totalActualCost) * 10000) / 100 : 0,
        laborPercent: totalActualCost > 0 ? Math.round((actualLaborCost / totalActualCost) * 10000) / 100 : 0,
        vendorPercent: totalActualCost > 0 ? Math.round((actualVendorCost / totalActualCost) * 10000) / 100 : 0,
        overheadPercent: totalActualCost > 0 ? Math.round((actualOverheadCost / totalActualCost) * 10000) / 100 : 0,
      },
    };
  }

  /**
   * Group margin data by project type (HVAC, ELECTRICAL, PLUMBING, etc.).
   * Returns per-type summary with count, total revenue, total cost, and margin %.
   */
  async getMarginByProjectType(organizationId: string) {
    const projects = await this.prisma.project.findMany({
      where: { organizationId, deletedAt: null, revenue: { gt: 0 } },
      select: {
        id: true,
        type: true,
        name: true,
        revenue: true,
        actualCost: true,
        status: true,
        proposal: {
          select: { materialCost: true, laborCost: true, vendorCost: true },
        },
      },
    });

    const typeMap = new Map<string, {
      type: string;
      projectCount: number;
      completedCount: number;
      totalRevenue: number;
      totalCost: number;
      totalMargin: number;
      margins: number[]; // individual margin percentages for avg calculation
    }>();

    for (const p of projects) {
      const type = p.type || 'OTHER';
      if (!typeMap.has(type)) {
        typeMap.set(type, { type, projectCount: 0, completedCount: 0, totalRevenue: 0, totalCost: 0, totalMargin: 0, margins: [] });
      }
      const entry = typeMap.get(type)!;
      const cost = p.actualCost || (p.proposal?.materialCost || 0) + (p.proposal?.laborCost || 0) + (p.proposal?.vendorCost || 0);
      const margin = (p.revenue || 0) - cost;
      const marginPct = p.revenue > 0 ? (margin / p.revenue) * 100 : 0;

      entry.projectCount++;
      if (p.status === 'COMPLETED') entry.completedCount++;
      entry.totalRevenue += p.revenue || 0;
      entry.totalCost += cost;
      entry.totalMargin += margin;
      entry.margins.push(marginPct);
    }

    return Array.from(typeMap.values()).map((data) => ({
      type: data.type,
      projectCount: data.projectCount,
      completedCount: data.completedCount,
      totalRevenue: Math.round(data.totalRevenue),
      totalCost: Math.round(data.totalCost),
      totalMargin: Math.round(data.totalMargin),
      marginPercent: data.totalRevenue > 0 ? Math.round((data.totalMargin / data.totalRevenue) * 10000) / 100 : 0,
      averageMarginPercent: data.margins.length > 0
        ? Math.round((data.margins.reduce((s, m) => s + m, 0) / data.margins.length) * 100) / 100
        : 0,
    }));
  }

  /**
   * Profitability ranking: projects ranked by margin percentage descending.
   */
  async getProfitabilityRanking(organizationId: string) {
    const projects = await this.prisma.project.findMany({
      where: { organizationId, deletedAt: null, revenue: { gt: 0 } },
      include: {
        hotel: { select: { id: true, name: true } },
        proposal: { select: { materialCost: true, laborCost: true, vendorCost: true } },
      },
      orderBy: { createdAt: 'DESC' },
    });

    const ranked = projects.map((p) => {
      const revenue = p.revenue || 0;
      const materialCost = p.actualCost ? p.actualCost * 0.45 : (p.proposal?.materialCost || 0);
      const laborCost = p.actualCost ? p.actualCost * 0.35 : (p.proposal?.laborCost || 0);
      const vendorCost = p.proposal?.vendorCost || 0;
      const totalCost = materialCost + laborCost + vendorCost;
      const margin = revenue - totalCost;
      const marginPercent = revenue > 0 ? (margin / revenue) * 100 : 0;

      return {
        projectId: p.id,
        projectName: p.name,
        hotelName: p.hotel?.name || 'Unassigned',
        type: p.type,
        status: p.status,
        revenue: Math.round(revenue),
        totalCost: Math.round(totalCost),
        margin: Math.round(margin),
        marginPercent: Math.round(marginPercent * 100) / 100,
      };
    });

    ranked.sort((a, b) => b.marginPercent - a.marginPercent);

    return ranked.map((item, index) => ({
      rank: index + 1,
      ...item,
    }));
  }

  /**
   * Margin alerts: projects where margin falls below the 10% threshold.
   */
  async getMarginAlerts(organizationId: string) {
    const projects = await this.prisma.project.findMany({
      where: { organizationId, deletedAt: null, revenue: { gt: 0 }, status: { not: 'CANCELLED' } },
      include: {
        hotel: { select: { id: true, name: true } },
        proposal: { select: { materialCost: true, laborCost: true, vendorCost: true, proposedMargin: true } },
      },
    });

    const MARGIN_THRESHOLD = 10; // percent
    const alerts: {
      projectId: string;
      projectName: string;
      hotelName: string;
      type: string;
      status: string;
      marginPercent: number;
      revenue: number;
      totalCost: number;
      proposedMargin: number;
      deviation: number;
      severity: 'CRITICAL' | 'WARNING' | 'INFO';
    }[] = [];

    for (const p of projects) {
      const revenue = p.revenue || 0;
      const materialCost = p.actualCost ? p.actualCost * 0.45 : (p.proposal?.materialCost || 0);
      const laborCost = p.actualCost ? p.actualCost * 0.35 : (p.proposal?.laborCost || 0);
      const vendorCost = p.proposal?.vendorCost || 0;
      const totalCost = materialCost + laborCost + vendorCost;
      const margin = revenue - totalCost;
      const marginPercent = revenue > 0 ? (margin / revenue) * 100 : 0;

      if (marginPercent < MARGIN_THRESHOLD) {
        const proposedMargin = p.proposal?.proposedMargin || 0;
        const deviation = proposedMargin - marginPercent;
        let severity: 'CRITICAL' | 'WARNING' | 'INFO' = 'INFO';
        if (marginPercent < 0) severity = 'CRITICAL';
        else if (marginPercent < 5) severity = 'CRITICAL';
        else if (deviation > 10) severity = 'WARNING';

        alerts.push({
          projectId: p.id,
          projectName: p.name,
          hotelName: p.hotel?.name || 'Unassigned',
          type: p.type || 'OTHER',
          status: p.status,
          marginPercent: Math.round(marginPercent * 100) / 100,
          revenue: Math.round(revenue),
          totalCost: Math.round(totalCost),
          proposedMargin,
          deviation: Math.round(deviation * 100) / 100,
          severity,
        });
      }
    }

    return alerts.sort((a, b) => a.marginPercent - b.marginPercent);
  }
}
