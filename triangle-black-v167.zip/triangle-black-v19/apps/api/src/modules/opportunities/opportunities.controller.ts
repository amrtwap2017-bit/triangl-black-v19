import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { OpportunitiesService } from './opportunities.service';
import { CreateOpportunityDto, UpdateOpportunityDto, CloseLostDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Opportunities')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('opportunities')
export class OpportunitiesController {
  constructor(private readonly opportunitiesService: OpportunitiesService) {}

  @Post()
  @ApiOperation({ summary: 'Create an opportunity' })
  async create(@Body() dto: CreateOpportunityDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.opportunitiesService.create(dto);
    return createResponse(result, 'Opportunity created');
  }

  @Get()
  @ApiOperation({ summary: 'List all opportunities' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('status') status?: string,
    @Query('hotelId') hotelId?: string,
    @Query('assignedToId') assignedToId?: string,
  ) {
    const result = await this.opportunitiesService.findAll(orgId, pagination, { status, hotelId, assignedToId });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('pipeline')
  @ApiOperation({ summary: 'Get opportunity pipeline grouped by status' })
  async getPipeline(@CurrentUser('organizationId') orgId: string) {
    const result = await this.opportunitiesService.getPipeline(orgId);
    return createResponse(result);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get opportunity by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.opportunitiesService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update opportunity' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateOpportunityDto) {
    const result = await this.opportunitiesService.update(id, dto);
    return createResponse(result, 'Opportunity updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete opportunity' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.opportunitiesService.remove(id);
    return createResponse(result);
  }

  @Post(':id/advance-stage')
  @ApiOperation({ summary: 'Advance opportunity to next stage' })
  async advanceStage(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.opportunitiesService.advanceStage(id);
    return createResponse(result, 'Stage advanced');
  }

  @Post(':id/close-won')
  @ApiOperation({ summary: 'Close opportunity as won' })
  async closeWon(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.opportunitiesService.closeWon(id);
    return createResponse(result, 'Opportunity closed won');
  }

  @Post(':id/close-lost')
  @ApiOperation({ summary: 'Close opportunity as lost' })
  async closeLost(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CloseLostDto) {
    const result = await this.opportunitiesService.closeLost(id, dto.reason);
    return createResponse(result, 'Opportunity closed lost');
  }
}
