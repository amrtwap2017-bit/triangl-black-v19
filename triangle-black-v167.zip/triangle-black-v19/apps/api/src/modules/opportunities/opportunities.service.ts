import { Injectable, NotFoundException, Logger, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateOpportunityDto, UpdateOpportunityDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class OpportunitiesService {
  private readonly logger = new Logger(OpportunitiesService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateOpportunityDto) {
    return this.prisma.opportunity.create({
      data: { ...dto, status: 'PROSPECTING' },
      include: { hotel: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string; hotelId?: string; assignedToId?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) {
      where.OR = [{ title: { contains: search, mode: 'insensitive' } }];
    }
    if (filters?.status) where.status = filters.status;
    if (filters?.hotelId) where.hotelId = filters.hotelId;
    if (filters?.assignedToId) where.assignedToId = filters.assignedToId;

    const [data, total] = await Promise.all([
      this.prisma.opportunity.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { hotel: true } }),
      this.prisma.opportunity.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const opp = await this.prisma.opportunity.findUnique({
      where: { id },
      include: { hotel: true, partnerRequest: true, proposals: true },
    });
    if (!opp) throw new NotFoundException('Opportunity not found');
    return opp;
  }

  async update(id: string, dto: UpdateOpportunityDto) {
    try {
      return this.prisma.opportunity.update({ where: { id }, data: dto, include: { hotel: true } });
    } catch {
      throw new NotFoundException('Opportunity not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.opportunity.delete({ where: { id } });
      return { success: true, message: 'Opportunity deleted' };
    } catch {
      throw new NotFoundException('Opportunity not found');
    }
  }

  async advanceStage(id: string) {
    const opp = await this.prisma.opportunity.findUnique({ where: { id } });
    if (!opp) throw new NotFoundException('Opportunity not found');

    const stages = ['PROSPECTING', 'QUALIFICATION', 'PROPOSAL', 'NEGOTIATION', 'CLOSED_WON'];
    const currentIdx = stages.indexOf(opp.status);
    if (currentIdx === -1 || currentIdx >= stages.length - 1) {
      throw new BadRequestException('Cannot advance from current stage');
    }

    return this.prisma.opportunity.update({
      where: { id },
      data: { status: stages[currentIdx + 1] },
    });
  }

  async closeWon(id: string) {
    const opp = await this.prisma.opportunity.findUnique({ where: { id } });
    if (!opp) throw new NotFoundException('Opportunity not found');
    return this.prisma.opportunity.update({ where: { id }, data: { status: 'CLOSED_WON' } });
  }

  async closeLost(id: string, reason: string) {
    const opp = await this.prisma.opportunity.findUnique({ where: { id } });
    if (!opp) throw new NotFoundException('Opportunity not found');
    return this.prisma.opportunity.update({ where: { id }, data: { status: 'CLOSED_LOST', lostReason: reason } });
  }

  async getPipeline(organizationId: string) {
    const opportunities = await this.prisma.opportunity.findMany({
      where: { organizationId, status: { notIn: ['CLOSED_WON', 'CLOSED_LOST'] } },
    });

    const pipeline: Record<string, { count: number; totalValue: number }> = {};
    for (const status of ['PROSPECTING', 'QUALIFICATION', 'PROPOSAL', 'NEGOTIATION']) {
      const items = opportunities.filter((o) => o.status === status);
      pipeline[status] = {
        count: items.length,
        totalValue: items.reduce((sum, o) => sum + (o.value || 0), 0),
      };
    }

    return pipeline;
  }
}
