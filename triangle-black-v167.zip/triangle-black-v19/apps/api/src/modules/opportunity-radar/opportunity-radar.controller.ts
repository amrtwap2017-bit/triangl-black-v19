import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { OpportunityRadarService } from './opportunity-radar.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse } from '../../common/dto/api-response.dto';

@ApiTags('Opportunity Radar')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('opportunity-radar')
export class OpportunityRadarController {
  constructor(private readonly radarService: OpportunityRadarService) {}

  @Get('recommendations')
  @ApiOperation({ summary: 'Get AI-generated opportunity recommendations' })
  async getRecommendations(@CurrentUser('organizationId') orgId: string) {
    const recommendations = await this.radarService.getRecommendations(orgId);
    return createResponse(recommendations, `${recommendations.length} recommendations found`);
  }
}