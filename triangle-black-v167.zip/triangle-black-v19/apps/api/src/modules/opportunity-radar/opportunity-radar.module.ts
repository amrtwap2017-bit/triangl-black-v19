import { Module } from '@nestjs/common';
import { OpportunityRadarController } from './opportunity-radar.controller';
import { OpportunityRadarService } from './opportunity-radar.service';
import { PrismaModule } from '../../infrastructure/prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [OpportunityRadarController],
  providers: [OpportunityRadarService],
  exports: [OpportunityRadarService],
})
export class OpportunityRadarModule {}