import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';

interface OpportunityRecommendation {
  hotelId: string;
  hotelName: string;
  type: string;
  description: string;
  confidence: number;
  estimatedValue: number;
  hotelRelationshipScore?: number;
  priorityScore?: number;
}

interface DashboardStats {
  totalRecommendations: number;
  byType: Record<string, number>;
  byPriority: { high: number; medium: number; low: number };
  totalEstimatedValue: number;
  topHotels: { hotelId: string; hotelName: string; opportunityCount: number; totalValue: number }[];
}

@Injectable()
export class OpportunityRadarService {
  private readonly logger = new Logger(OpportunityRadarService.name);

  constructor(private readonly prisma: PrismaService) {}

  async getRecommendations(organizationId: string): Promise<OpportunityRecommendation[]> {
    const recommendations: OpportunityRecommendation[] = [];
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

    // 1. Hotels with expiring warranties → replacement opportunities
    const expiringWarranties = await this.prisma.warranty.findMany({
      where: {
        organizationId,
        status: 'ACTIVE',
        warrantyEnd: { lte: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000) },
      },
      include: { hotel: { select: { id: true, name: true } } },
      take: 20,
    });

    for (const w of expiringWarranties) {
      recommendations.push({
        hotelId: w.hotel.id,
        hotelName: w.hotel.name,
        type: 'WARRANTY_EXPIRY',
        description: `${w.equipment} warranty expires ${w.warrantyEnd.toISOString().split('T')[0]}. Recommend renewal or replacement assessment.`,
        confidence: 85,
        estimatedValue: 15000,
      });
    }

    // 2. Hotels with no recent engagement → follow-up opportunities
    const inactiveHotels = await this.prisma.hotel.findMany({
      where: {
        organizationId,
        isActive: true,
        deletedAt: null,
        projects: { none: { createdAt: { gte: ninetyDaysAgo } } },
        opportunities: { none: { createdAt: { gte: ninetyDaysAgo } } },
      },
      select: { id: true, name: true },
      take: 10,
    });

    for (const hotel of inactiveHotels) {
      recommendations.push({
        hotelId: hotel.id,
        hotelName: hotel.name,
        type: 'RE_ENGAGEMENT',
        description: `No activity in 90+ days. Recommend site visit to identify new opportunities.`,
        confidence: 70,
        estimatedValue: 25000,
      });
    }

    // 3. Hotels with repeated emergencies → equipment replacement
    const repeatedEmergencies = await this.prisma.emergencyCase.groupBy({
      by: ['hotelId'],
      where: { organizationId, status: 'RESOLVED', createdAt: { gte: ninetyDaysAgo } },
      _count: { id: true },
      having: { id: { _count: { gte: 3 } } },
      orderBy: { _count: { id: 'desc' } },
      take: 10,
    });

    for (const re of repeatedEmergencies) {
      const hotel = await this.prisma.hotel.findUnique({
        where: { id: re.hotelId },
        select: { name: true },
      });
      if (hotel) {
        recommendations.push({
          hotelId: re.hotelId,
          hotelName: hotel.name,
          type: 'REPEATED_FAILURE',
          description: `${re._count.id} emergencies in 90 days. Recommend equipment assessment and replacement proposal.`,
          confidence: 90,
          estimatedValue: 50000,
        });
      }
    }

    // 4. Assets approaching end of life
    const agingAssets = await this.prisma.hotelAsset.findMany({
      where: {
        organizationId,
        condition: { in: ['POOR', 'CRITICAL'] },
      },
      include: { hotel: { select: { id: true, name: true } } },
      take: 10,
    });

    for (const asset of agingAssets) {
      recommendations.push({
        hotelId: asset.hotel.id,
        hotelName: asset.hotel.name,
        type: 'ASSET_AGING',
        description: `${asset.name} (${asset.assetType}) condition: ${asset.condition}. Recommend replacement or major overhaul.`,
        confidence: 80,
        estimatedValue: 30000,
      });
    }

    return recommendations.sort((a, b) => b.confidence - a.confidence);
  }

  /**
   * Priority scoring algorithm: 0-100 combining confidence, estimated value, and hotel relationship.
   *   - confidence weight: 40%
   *   - estimatedValue normalized weight: 30%
   *   - hotelRelationshipScore weight: 30%
   */
  getOpportunityScore(recommendation: OpportunityRecommendation): number {
    const confidenceWeight = 0.4;
    const valueWeight = 0.3;
    const relationshipWeight = 0.3;

    // Normalize estimated value: 0-100 scale (100K+ = 100)
    const valueNormalized = Math.min(100, (recommendation.estimatedValue / 100000) * 100);

    // Relationship score: use provided or default 50
    const relationshipScore = recommendation.hotelRelationshipScore ?? 50;

    const score =
      recommendation.confidence * confidenceWeight +
      valueNormalized * valueWeight +
      relationshipScore * relationshipWeight;

    return Math.round(Math.max(0, Math.min(100, score)));
  }

  /**
   * Get enriched recommendations with priority scores, including budget cycle,
   * renovation schedule, and procurement pattern detections.
   */
  async getRecommendationsWithScoring(organizationId: string): Promise<OpportunityRecommendation[]> {
    const recommendations = await this.getRecommendations(organizationId);

    // Enrich with hotel relationship scores
    const hotelIds = [...new Set(recommendations.map((r) => r.hotelId))];
    const relationships = await this.prisma.hotelRelationship.findMany({
      where: { hotelId: { in: hotelIds } },
      select: { hotelId: true, relationshipScore: true },
    });
    const relationshipMap = new Map(relationships.map((r) => [r.hotelId, r.relationshipScore]));

    for (const rec of recommendations) {
      rec.hotelRelationshipScore = relationshipMap.get(rec.hotelId) ?? 50;
      rec.priorityScore = this.getOpportunityScore(rec);
    }

    // Append budget cycle, renovation schedule, and procurement pattern recommendations
    const budgetCycleRecs = await this.detectBudgetCycleOpportunities(organizationId);
    const renovationRecs = await this.detectRenovationScheduleOpportunities(organizationId);
    const procurementRecs = await this.detectProcurementPatterns(organizationId);

    for (const rec of [...budgetCycleRecs, ...renovationRecs, ...procurementRecs]) {
      rec.hotelRelationshipScore = relationshipMap.get(rec.hotelId) ?? 50;
      rec.priorityScore = this.getOpportunityScore(rec);
      recommendations.push(rec);
    }

    return recommendations.sort((a, b) => (b.priorityScore ?? 0) - (a.priorityScore ?? 0));
  }

  /**
   * Budget cycle detection: identify Q4 opportunities before fiscal year end.
   * Hotels with unspent budget or pending approvals in Q4 present urgency.
   */
  private async detectBudgetCycleOpportunities(organizationId: string): Promise<OpportunityRecommendation[]> {
    const recs: OpportunityRecommendation[] = [];
    const now = new Date();
    const currentMonth = now.getMonth(); // 0-indexed; Oct-Dec = 9,10,11
    const fiscalYearEnd = new Date(now.getFullYear(), 11, 31); // Dec 31

    // Only relevant in Q4 (Oct-Dec)
    if (currentMonth < 9) return recs;

    const pendingProposals = await this.prisma.proposal.findMany({
      where: {
        organizationId,
        deletedAt: null,
        status: { in: ['DRAFT', 'SENT', 'PRESENTED'] },
        createdAt: { gte: new Date(now.getFullYear(), 0, 1) },
      },
      include: { hotel: { select: { id: true, name: true } } },
      take: 20,
    });

    for (const proposal of pendingProposals) {
      if (!proposal.hotel) continue;
      const daysRemaining = Math.ceil((fiscalYearEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      recs.push({
        hotelId: proposal.hotel.id,
        hotelName: proposal.hotel.name,
        type: 'BUDGET_CYCLE',
        description: `Q4 budget cycle: ${daysRemaining} days until fiscal year end. Proposal "${proposal.title}" (${proposal.proposalNumber}) pending approval worth ${proposal.totalValue || 0} SAR.`,
        confidence: 75 + (currentMonth === 11 ? 15 : 0), // Higher urgency in December
        estimatedValue: proposal.totalValue || 20000,
      });
    }

    return recs;
  }

  /**
   * Renovation schedule detection: find hotels with upcoming renovation plans
   * or recently completed projects that may need follow-up work.
   */
  private async detectRenovationScheduleOpportunities(organizationId: string): Promise<OpportunityRecommendation[]> {
    const recs: OpportunityRecommendation[] = [];
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setDate(sixMonthsAgo.getDate() - 180);
    const sixMonthsAhead = new Date();
    sixMonthsAhead.setDate(sixMonthsAhead.getDate() + 180);

    // Hotels with recently completed renovation projects → follow-up / maintenance
    const completedRenovations = await this.prisma.project.findMany({
      where: {
        organizationId,
        deletedAt: null,
        status: 'COMPLETED',
        completedAt: { gte: sixMonthsAgo },
        type: { in: ['RENOVATION', 'FIT_OUT', 'REFURBISHMENT'] },
      },
      include: { hotel: { select: { id: true, name: true } } },
      take: 15,
    });

    for (const project of completedRenovations) {
      if (!project.hotel) continue;
      recs.push({
        hotelId: project.hotel.id,
        hotelName: project.hotel.name,
        type: 'RENOVATION_FOLLOW_UP',
        description: `Renovation "${project.name}" recently completed. Schedule post-renovation inspection, defect liability review, and maintenance contract proposal.`,
        confidence: 78,
        estimatedValue: 15000,
      });
    }

    // Hotels with metadata indicating planned renovations
    const hotelsWithRenovationPlans = await this.prisma.hotel.findMany({
      where: {
        organizationId,
        deletedAt: null,
        isActive: true,
        metadata: { path: ['plannedRenovation'], not: null },
      },
      select: { id: true, name: true, metadata: true },
      take: 10,
    });

    for (const hotel of hotelsWithRenovationPlans) {
      const plan = (hotel.metadata as any)?.plannedRenovation;
      recs.push({
        hotelId: hotel.id,
        hotelName: hotel.name,
        type: 'RENOVATION_SCHEDULED',
        description: `Planned renovation detected: ${plan?.description || 'Upcoming renovation'}. Expected: ${plan?.targetDate || 'TBD'}. Prepare early engagement and pre-qualification.`,
        confidence: 85,
        estimatedValue: 75000,
      });
    }

    return recs;
  }

  /**
   * Procurement pattern analysis: detect repeated procurement of the same category
   * across hotels → consolidate into bulk opportunity for volume discount.
   */
  private async detectProcurementPatterns(organizationId: string): Promise<OpportunityRecommendation[]> {
    const recs: OpportunityRecommendation[] = [];
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

    // Group purchase orders by category (via items metadata)
    const recentPOs = await this.prisma.purchaseOrder.findMany({
      where: {
        organizationId,
        deletedAt: null,
        createdAt: { gte: ninetyDaysAgo },
      },
      include: { vendor: { select: { id: true, name: true } } },
      take: 100,
    });

    const categoryMap = new Map<string, { totalAmount: number; orderCount: number; vendorIds: Set<string>; hotelIds: Set<string> }>();
    for (const po of recentPOs) {
      const items = (po.items as any[]) || [];
      for (const item of items) {
        const category = item.category || item.type || 'GENERAL';
        if (!categoryMap.has(category)) {
          categoryMap.set(category, { totalAmount: 0, orderCount: 0, vendorIds: new Set(), hotelIds: new Set() });
        }
        const entry = categoryMap.get(category)!;
        entry.totalAmount += item.total || 0;
        entry.orderCount++;
        if (po.vendorId) entry.vendorIds.add(po.vendorId);
      }
    }

    // Categories with high repeat order count → bulk opportunity
    for (const [category, data] of categoryMap.entries()) {
      if (data.orderCount >= 5 && data.totalAmount > 50000) {
        recs.push({
          hotelId: '', // Organization-level opportunity
          hotelName: 'Multiple Hotels',
          type: 'PROCUREMENT_PATTERN_BULK',
          description: `Category "${category}" shows ${data.orderCount} repeat orders totaling ${data.totalAmount.toFixed(0)} SAR in 90 days across ${data.vendorIds.size} vendors. Consolidate into bulk procurement for volume discounts.`,
          confidence: 88,
          estimatedValue: data.totalAmount * 0.15, // Estimated 15% savings
        });
      }
    }

    return recs;
  }

  /**
   * Dashboard stats: counts of recommendations by type, priority tier, and total value.
   */
  async getDashboardStats(organizationId: string): Promise<DashboardStats> {
    const recommendations = await this.getRecommendationsWithScoring(organizationId);

    const byType: Record<string, number> = {};
    let high = 0;
    let medium = 0;
    let low = 0;
    let totalEstimatedValue = 0;

    const hotelMap = new Map<string, { hotelName: string; opportunityCount: number; totalValue: number }>();

    for (const rec of recommendations) {
      byType[rec.type] = (byType[rec.type] || 0) + 1;
      totalEstimatedValue += rec.estimatedValue;

      const score = rec.priorityScore ?? 0;
      if (score >= 70) high++;
      else if (score >= 40) medium++;
      else low++;

      if (rec.hotelId) {
        if (!hotelMap.has(rec.hotelId)) {
          hotelMap.set(rec.hotelId, { hotelName: rec.hotelName, opportunityCount: 0, totalValue: 0 });
        }
        const entry = hotelMap.get(rec.hotelId)!;
        entry.opportunityCount++;
        entry.totalValue += rec.estimatedValue;
      }
    }

    const topHotels = Array.from(hotelMap.entries())
      .map(([hotelId, data]) => ({ hotelId, ...data }))
      .sort((a, b) => b.totalValue - a.totalValue)
      .slice(0, 10);

    return {
      totalRecommendations: recommendations.length,
      byType,
      byPriority: { high, medium, low },
      totalEstimatedValue,
      topHotels,
    };
  }
}