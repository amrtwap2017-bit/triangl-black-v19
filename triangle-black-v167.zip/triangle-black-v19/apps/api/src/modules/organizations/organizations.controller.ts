import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { OrganizationsService } from './organizations.service';
import { CreateOrganizationDto, UpdateOrganizationDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Organizations')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('organizations')
export class OrganizationsController {
  constructor(private readonly organizationsService: OrganizationsService) {}

  @Post()
  @ApiOperation({ summary: 'Create organization' })
  async create(@Body() dto: CreateOrganizationDto) {
    const result = await this.organizationsService.create(dto);
    return createResponse(result, 'Organization created');
  }

  @Get()
  @ApiOperation({ summary: 'List all organizations' })
  async findAll(@Query() pagination: PaginationDto) {
    const result = await this.organizationsService.findAll(pagination);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get organization by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.organizationsService.findOne(id);
    return createResponse(result);
  }

  @Get(':id/dashboard-summary')
  @ApiOperation({ summary: 'Get dashboard summary counts' })
  async dashboardSummary(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.organizationsService.dashboardSummary(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update organization' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateOrganizationDto) {
    const result = await this.organizationsService.update(id, dto);
    return createResponse(result, 'Organization updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete organization' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.organizationsService.remove(id);
    return createResponse(result);
  }
}
