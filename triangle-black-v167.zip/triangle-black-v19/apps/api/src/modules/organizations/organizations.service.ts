import { Injectable, NotFoundException, ConflictException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateOrganizationDto, UpdateOrganizationDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class OrganizationsService {
  private readonly logger = new Logger(OrganizationsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateOrganizationDto) {
    try {
      const slug = dto.slug || dto.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const org = await this.prisma.organization.create({ data: { ...dto, slug } });
      return org;
    } catch (error) {
      if (error.code === 'P2002') throw new ConflictException('Slug already exists');
      this.logger.error('Create org error:', error);
      throw error;
    }
  }

  async findAll(pagination: PaginationDto) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = {};
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { domain: { contains: search, mode: 'insensitive' } },
      ];
    }
    const [data, total] = await Promise.all([
      this.prisma.organization.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder } }),
      this.prisma.organization.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const org = await this.prisma.organization.findUnique({ where: { id } });
    if (!org) throw new NotFoundException('Organization not found');
    return org;
  }

  async update(id: string, dto: UpdateOrganizationDto) {
    try {
      const org = await this.prisma.organization.update({ where: { id }, data: dto });
      return org;
    } catch (error) {
      if (error.code === 'P2025') throw new NotFoundException('Organization not found');
      this.logger.error('Update org error:', error);
      throw error;
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.organization.delete({ where: { id } });
      return { success: true, message: 'Organization deleted' };
    } catch {
      throw new NotFoundException('Organization not found');
    }
  }

  async dashboardSummary(id: string) {
    const [hotels, projects, opportunities, emergencies, partnerRequests, proposals] = await Promise.all([
      this.prisma.hotel.count({ where: { organizationId: id } }),
      this.prisma.project.count({ where: { organizationId: id } }),
      this.prisma.opportunity.count({ where: { organizationId: id } }),
      this.prisma.emergencyCase.count({ where: { organizationId: id } }),
      this.prisma.partnerRequest.count({ where: { organizationId: id } }),
      this.prisma.proposal.count({ where: { organizationId: id } }),
    ]);
    return { hotels, projects, opportunities, emergencies, partnerRequests, proposals };
  }
}
