import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { PartnerRequestsService } from './partner-requests.service';
import { CreatePartnerRequestDto, UpdatePartnerRequestDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Partner Requests')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('partner-requests')
export class PartnerRequestsController {
  constructor(private readonly partnerRequestsService: PartnerRequestsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a partner request' })
  async create(@Body() dto: CreatePartnerRequestDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.partnerRequestsService.create(dto);
    return createResponse(result, 'Partner request created');
  }

  @Get()
  @ApiOperation({ summary: 'List all partner requests' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('status') status?: string,
    @Query('type') type?: string,
    @Query('hotelId') hotelId?: string,
    @Query('assignedToId') assignedToId?: string,
  ) {
    const result = await this.partnerRequestsService.findAll(orgId, pagination, { status, type, hotelId, assignedToId });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get partner request by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.partnerRequestsService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update partner request' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdatePartnerRequestDto) {
    const result = await this.partnerRequestsService.update(id, dto);
    return createResponse(result, 'Partner request updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete partner request' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.partnerRequestsService.remove(id);
    return createResponse(result);
  }

  @Post(':id/assign')
  @ApiOperation({ summary: 'Assign partner request to user' })
  async assign(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.partnerRequestsService.assign(id, userId);
    return createResponse(result, 'Partner request assigned');
  }

  @Post(':id/schedule-visit')
  @ApiOperation({ summary: 'Schedule a site visit' })
  async scheduleVisit(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.partnerRequestsService.scheduleVisit(id, userId);
    return createResponse(result, 'Site visit scheduled');
  }

  @Post(':id/convert-to-opportunity')
  @ApiOperation({ summary: 'Convert partner request to opportunity' })
  async convertToOpportunity(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.partnerRequestsService.convertToOpportunity(id);
    return createResponse(result, 'Converted to opportunity');
  }
}
