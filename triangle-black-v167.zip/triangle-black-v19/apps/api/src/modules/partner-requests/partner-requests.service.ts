import { Injectable, NotFoundException, Logger, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreatePartnerRequestDto, UpdatePartnerRequestDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../common/utils';

@Injectable()
export class PartnerRequestsService {
  private readonly logger = new Logger(PartnerRequestsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreatePartnerRequestDto) {
    const requestNumber = generateSequentialNumber('PR');
    return this.prisma.partnerRequest.create({
      data: { ...dto, requestNumber },
      include: { assignedTo: true, hotel: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string; type?: string; hotelId?: string; assignedToId?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { requestNumber: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (filters?.status) where.status = filters.status;
    if (filters?.type) where.type = filters.type;
    if (filters?.hotelId) where.hotelId = filters.hotelId;
    if (filters?.assignedToId) where.assignedToId = filters.assignedToId;

    const [data, total] = await Promise.all([
      this.prisma.partnerRequest.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { assignedTo: true, hotel: true } }),
      this.prisma.partnerRequest.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const request = await this.prisma.partnerRequest.findUnique({
      where: { id },
      include: { assignedTo: true, hotel: true, siteVisit: true, opportunity: true },
    });
    if (!request) throw new NotFoundException('Partner request not found');
    return request;
  }

  async update(id: string, dto: UpdatePartnerRequestDto) {
    try {
      return this.prisma.partnerRequest.update({ where: { id }, data: dto, include: { assignedTo: true, hotel: true } });
    } catch {
      throw new NotFoundException('Partner request not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.partnerRequest.delete({ where: { id } });
      return { success: true, message: 'Partner request deleted' };
    } catch {
      throw new NotFoundException('Partner request not found');
    }
  }

  async assign(id: string, userId: string) {
    const request = await this.prisma.partnerRequest.findUnique({ where: { id } });
    if (!request) throw new NotFoundException('Partner request not found');
    return this.prisma.partnerRequest.update({ where: { id }, data: { assignedToId: userId, status: 'IN_PROGRESS' } });
  }

  async scheduleVisit(id: string, userId: string) {
    const request = await this.prisma.partnerRequest.findUnique({ where: { id } });
    if (!request) throw new NotFoundException('Partner request not found');
    if (!request.hotelId) throw new BadRequestException('Request must have a hotel to schedule a visit');

    const visitNumber = generateSequentialNumber('SV');
    const visit = await this.prisma.siteVisit.create({
      data: {
        organizationId: request.organizationId,
        hotelId: request.hotelId,
        partnerRequestId: id,
        visitNumber,
        assignedToId: userId,
        status: 'SCHEDULED',
      },
    });

    await this.prisma.partnerRequest.update({ where: { id }, data: { status: 'SITE_VISIT_SCHEDULED' } });
    return visit;
  }

  async convertToOpportunity(id: string) {
    const request = await this.prisma.partnerRequest.findUnique({ where: { id }, include: { hotel: true } });
    if (!request) throw new NotFoundException('Partner request not found');

    const opportunity = await this.prisma.opportunity.create({
      data: {
        organizationId: request.organizationId,
        hotelId: request.hotelId,
        partnerRequestId: id,
        title: request.title,
        titleAr: request.titleAr,
        description: request.description,
        descriptionAr: request.descriptionAr,
        source: 'SITE_VISIT',
        status: 'PROSPECTING',
        assignedToId: request.assignedToId,
      },
    });

    await this.prisma.partnerRequest.update({ where: { id }, data: { status: 'CONVERTED_TO_OPPORTUNITY' } });
    return opportunity;
  }
}
