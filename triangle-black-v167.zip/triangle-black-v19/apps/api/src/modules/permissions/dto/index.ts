export { CreatePermissionDto, UpdatePermissionDto } from './create-permission.dto';
