import { Controller, Get, Post, Put, Body, Param, UseGuards, ParseUUIDPipe } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { PermissionsService } from './permissions.service';
import { CreatePermissionDto, UpdatePermissionDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { createResponse } from '../../common/dto/api-response.dto';

@ApiTags('Permissions')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('permissions')
export class PermissionsController {
  constructor(private readonly permissionsService: PermissionsService) {}

  @Get()
  @ApiOperation({ summary: 'List all permissions' })
  async findAll() {
    const result = await this.permissionsService.findAll();
    return createResponse(result);
  }

  @Post()
  @ApiOperation({ summary: 'Create a permission (system level)' })
  async create(@Body() dto: CreatePermissionDto) {
    const result = await this.permissionsService.create(dto);
    return createResponse(result, 'Permission created');
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get permission by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.permissionsService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update permission' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdatePermissionDto) {
    const result = await this.permissionsService.update(id, dto);
    return createResponse(result, 'Permission updated');
  }
}
