import { Injectable, NotFoundException, ConflictException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreatePermissionDto, UpdatePermissionDto } from './dto';

@Injectable()
export class PermissionsService {
  private readonly logger = new Logger(PermissionsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreatePermissionDto) {
    try {
      return this.prisma.permission.create({ data: dto });
    } catch (error) {
      if (error.code === 'P2002') throw new ConflictException('Permission name already exists');
      this.logger.error('Create permission error:', error);
      throw error;
    }
  }

  async findAll() {
    return this.prisma.permission.findMany({ orderBy: { resource: 'asc', action: 'asc' } });
  }

  async findOne(id: string) {
    const permission = await this.prisma.permission.findUnique({ where: { id } });
    if (!permission) throw new NotFoundException('Permission not found');
    return permission;
  }

  async update(id: string, dto: UpdatePermissionDto) {
    try {
      return this.prisma.permission.update({ where: { id }, data: dto });
    } catch {
      throw new NotFoundException('Permission not found');
    }
  }
}
