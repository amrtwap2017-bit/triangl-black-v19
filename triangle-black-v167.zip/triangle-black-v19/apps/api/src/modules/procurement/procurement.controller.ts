import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ProcurementService } from './procurement.service';
import { CreateProcurementRequestDto, UpdateProcurementRequestDto, CreatePurchaseOrderDto, UpdatePurchaseOrderStatusDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Procurement')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('procurement-requests')
export class ProcurementController {
  constructor(private readonly procurementService: ProcurementService) {}

  @Post()
  @ApiOperation({ summary: 'Create a procurement request' })
  async createRequest(@Body() dto: CreateProcurementRequestDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.procurementService.createRequest(dto);
    return createResponse(result, 'Procurement request created');
  }

  @Get()
  @ApiOperation({ summary: 'List procurement requests' })
  async findAllRequests(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string, @Query('status') status?: string) {
    const result = await this.procurementService.findAllRequests(orgId, pagination, { status });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get procurement request by ID' })
  async findOneRequest(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.procurementService.findOneRequest(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update procurement request' })
  async updateRequest(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateProcurementRequestDto) {
    const result = await this.procurementService.updateRequest(id, dto);
    return createResponse(result, 'Procurement request updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete procurement request' })
  async removeRequest(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.procurementService.removeRequest(id);
    return createResponse(result);
  }

  @Post(':id/submit')
  @ApiOperation({ summary: 'Submit procurement request' })
  async submitRequest(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.procurementService.submitRequest(id);
    return createResponse(result, 'Request submitted');
  }

  @Post(':id/approve')
  @ApiOperation({ summary: 'Approve procurement request' })
  async approveRequest(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.procurementService.approveRequest(id);
    return createResponse(result, 'Request approved');
  }
}

@ApiTags('Purchase Orders')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('purchase-orders')
export class PurchaseOrdersController {
  constructor(private readonly procurementService: ProcurementService) {}

  @Get()
  @ApiOperation({ summary: 'List purchase orders' })
  async findAll(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string, @Query('status') status?: string, @Query('vendorId') vendorId?: string) {
    const result = await this.procurementService.findAllPurchaseOrders(orgId, pagination, { status, vendorId });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Post()
  @ApiOperation({ summary: 'Create a purchase order' })
  async create(@Body() dto: CreatePurchaseOrderDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.procurementService.createPurchaseOrder(dto);
    return createResponse(result, 'Purchase order created');
  }

  @Put(':id/status')
  @ApiOperation({ summary: 'Update purchase order status' })
  async updateStatus(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdatePurchaseOrderStatusDto) {
    const result = await this.procurementService.updatePurchaseOrderStatus(id, dto);
    return createResponse(result, 'Purchase order status updated');
  }
}
