import { Module } from '@nestjs/common';
import { ProcurementController, PurchaseOrdersController } from './procurement.controller';
import { ProcurementService } from './procurement.service';

@Module({
  controllers: [ProcurementController, PurchaseOrdersController],
  providers: [ProcurementService],
  exports: [ProcurementService],
})
export class ProcurementModule {}
