import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateProcurementRequestDto, UpdateProcurementRequestDto, CreatePurchaseOrderDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../common/utils';

@Injectable()
export class ProcurementService {
  private readonly logger = new Logger(ProcurementService.name);

  constructor(private readonly prisma: PrismaService) {}

  async createRequest(dto: CreateProcurementRequestDto) {
    return this.prisma.procurementRequest.create({ data: dto });
  }

  async findAllRequests(organizationId: string, pagination: PaginationDto, filters?: { status?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) where.title = { contains: search, mode: 'insensitive' };
    if (filters?.status) where.status = filters.status;

    const [data, total] = await Promise.all([
      this.prisma.procurementRequest.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { purchaseOrders: true } }),
      this.prisma.procurementRequest.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOneRequest(id: string) {
    const request = await this.prisma.procurementRequest.findUnique({ where: { id }, include: { purchaseOrders: true } });
    if (!request) throw new NotFoundException('Procurement request not found');
    return request;
  }

  async updateRequest(id: string, dto: UpdateProcurementRequestDto) {
    try {
      return this.prisma.procurementRequest.update({ where: { id }, data: dto });
    } catch {
      throw new NotFoundException('Procurement request not found');
    }
  }

  async removeRequest(id: string) {
    try {
      await this.prisma.procurementRequest.delete({ where: { id } });
      return { success: true, message: 'Procurement request deleted' };
    } catch {
      throw new NotFoundException('Procurement request not found');
    }
  }

  async submitRequest(id: string) {
    const request = await this.prisma.procurementRequest.findUnique({ where: { id } });
    if (!request) throw new NotFoundException('Procurement request not found');
    if (request.status !== 'DRAFT') throw new BadRequestException('Only DRAFT requests can be submitted');
    return this.prisma.procurementRequest.update({ where: { id }, data: { status: 'SUBMITTED' } });
  }

  async approveRequest(id: string) {
    const request = await this.prisma.procurementRequest.findUnique({ where: { id } });
    if (!request) throw new NotFoundException('Procurement request not found');
    if (request.status !== 'SUBMITTED') throw new BadRequestException('Only SUBMITTED requests can be approved');
    return this.prisma.procurementRequest.update({ where: { id }, data: { status: 'APPROVED' } });
  }

  // Purchase Orders
  async createPurchaseOrder(dto: CreatePurchaseOrderDto) {
    const poNumber = generateSequentialNumber('PO');
    return this.prisma.purchaseOrder.create({
      data: { ...dto, poNumber, issuedAt: new Date(), status: 'PENDING' },
      include: { vendor: true, procurementRequest: true },
    });
  }

  async findAllPurchaseOrders(organizationId: string, pagination: PaginationDto, filters?: { status?: string; vendorId?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) where.poNumber = { contains: search, mode: 'insensitive' };
    if (filters?.status) where.status = filters.status;
    if (filters?.vendorId) where.vendorId = filters.vendorId;

    const [data, total] = await Promise.all([
      this.prisma.purchaseOrder.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { vendor: true } }),
      this.prisma.purchaseOrder.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async updatePurchaseOrderStatus(id: string, dto: UpdatePurchaseOrderStatusDto) {
    const po = await this.prisma.purchaseOrder.findUnique({ where: { id } });
    if (!po) throw new NotFoundException('Purchase order not found');

    const data: any = { status: dto.status };
    if (dto.status === 'RECEIVED') data.actualDelivery = new Date();
    if (dto.qualityRating !== undefined) data.qualityRating = dto.qualityRating;

    return this.prisma.purchaseOrder.update({ where: { id }, data });
  }

  /**
   * Auto-create an RFQ (Request for Quotation) from an approved procurement request.
   * Extracts items, specifications, and quantities to create RFQ entries for vendor bidding.
   */
  async createRfqFromRequest(requestId: string) {
    const request = await this.prisma.procurementRequest.findUnique({
      where: { id: requestId },
      include: {
        purchaseOrders: true,
      },
    });
    if (!request) throw new NotFoundException('Procurement request not found');
    if (request.status !== 'APPROVED') throw new BadRequestException('Only APPROVED procurement requests can generate RFQs');

    const items = (request.items as any[]) || [];
    if (items.length === 0) throw new BadRequestException('No items found in procurement request');

    // Group items by category for consolidated RFQ
    const categoryGroups = new Map<string, any[]>();
    for (const item of items) {
      const category = item.category || item.type || 'GENERAL';
      if (!categoryGroups.has(category)) categoryGroups.set(category, []);
      categoryGroups.get(category)!.push(item);
    }

    // Find vendors matching each category
    const rfqEntries = [];
    for (const [category, categoryItems] of categoryGroups.entries()) {
      const matchingVendors = await this.prisma.vendor.findMany({
        where: {
          organizationId: request.organizationId,
          deletedAt: null,
          OR: [
            { category: { contains: category, mode: 'insensitive' } },
            { specializations: { has: category } },
          ],
        },
        take: 5,
      });

      rfqEntries.push({
        category,
        items: categoryItems,
        totalEstimatedValue: categoryItems.reduce((s: number, i: any) => s + (i.total || (i.quantity * i.unitPrice) || 0), 0),
        suggestedVendors: matchingVendors.map((v) => ({
          vendorId: v.id,
          vendorName: v.name,
          rating: v.rating || null,
          matchScore: v.category?.toLowerCase().includes(category.toLowerCase()) ? 100 : 50,
        })),
      });
    }

    const totalEstimatedValue = items.reduce((s: number, i: any) => s + (i.total || (i.quantity * i.unitPrice) || 0), 0);

    return {
      requestId,
      requestTitle: request.title,
      rfqEntries,
      totalEstimatedValue,
      totalItems: items.length,
      totalCategories: categoryGroups.size,
      status: 'RFQ_DRAFT',
      nextSteps: [
        'Review suggested vendors and add/remove as needed',
        'Set RFQ deadline (recommended: 7-14 days)',
        'Send RFQ to selected vendors',
        'Collect and compare quotations',
        'Select winning vendor and create purchase order',
      ],
    };
  }

  /**
   * Intelligent vendor sourcing: suggest vendors based on category, specification, and historical performance.
   */
  async getIntelligentSourcing(category: string, specification?: string) {
    // Find vendors by category match and historical performance
    const vendors = await this.prisma.vendor.findMany({
      where: {
        deletedAt: null,
        OR: [
          { category: { contains: category, mode: 'insensitive' } },
          { specializations: { has: category } },
          { tags: { has: category } },
        ],
      },
      include: {
        purchaseOrders: {
          where: { deletedAt: null, status: 'RECEIVED' },
          select: { amount: true, qualityRating: true, actualDelivery: true, expectedDelivery: true, createdAt: true },
          take: 10,
          orderBy: { createdAt: 'DESC' },
        },
      },
      take: 20,
    });

    const scored = vendors.map((vendor) => {
      // Calculate vendor score based on multiple factors
      let categoryMatch = 50;
      if (vendor.category?.toLowerCase() === category.toLowerCase()) categoryMatch = 100;
      else if (vendor.category?.toLowerCase().includes(category.toLowerCase())) categoryMatch = 80;

      // Historical performance score
      const orders = vendor.purchaseOrders;
      const avgRating = orders.length > 0
        ? orders.reduce((s, o) => s + (o.qualityRating || 0), 0) / orders.length
        : 0;

      const onTimeDeliveries = orders.filter((o) => {
        if (!o.expectedDelivery || !o.actualDelivery) return true;
        return new Date(o.actualDelivery) <= new Date(o.expectedDelivery);
      }).length;
      const onTimeRate = orders.length > 0 ? (onTimeDeliveries / orders.length) * 100 : 50;

      const totalSpend = orders.reduce((s, o) => s + (o.amount || 0), 0);

      // Composite score: 40% category match, 30% quality rating, 30% on-time delivery
      const compositeScore = Math.round(
        categoryMatch * 0.40 +
        Math.min(100, avgRating * 20) * 0.30 +
        onTimeRate * 0.30,
      );

      return {
        vendorId: vendor.id,
        vendorName: vendor.name,
        category: vendor.category,
        location: vendor.address || vendor.city || null,
        contactInfo: {
          email: vendor.email || null,
          phone: vendor.phone || null,
        },
        performance: {
          totalOrders: orders.length,
          totalSpend: Math.round(totalSpend),
          averageQualityRating: Math.round(avgRating * 100) / 100,
          onTimeDeliveryRate: Math.round(onTimeRate),
        },
        compositeScore,
        recommendation: compositeScore >= 80 ? 'STRONGLY_RECOMMENDED' : compositeScore >= 60 ? 'RECOMMENDED' : 'CONSIDER',
      };
    });

    scored.sort((a, b) => b.compositeScore - a.compositeScore);

    return {
      category,
      specification: specification || null,
      vendorCount: scored.length,
      vendors: scored,
    };
  }

  /**
   * Procurement analytics: spend analysis by category, vendor, and time period.
   */
  async getProcurementAnalytics(organizationId: string, filters?: {
    fromDate?: string;
    toDate?: string;
    vendorId?: string;
  }) {
    const where: any = { organizationId, deletedAt: null };

    if (filters?.fromDate || filters?.toDate) {
      where.createdAt = {};
      if (filters.fromDate) where.createdAt.gte = new Date(filters.fromDate);
      if (filters.toDate) where.createdAt.lte = new Date(filters.toDate);
    }

    if (filters?.vendorId) {
      where.vendorId = filters.vendorId;
    }

    // Spend by category (derived from PO items)
    const purchaseOrders = await this.prisma.purchaseOrder.findMany({
      where,
      include: {
        vendor: { select: { id: true, name: true, category: true } },
        procurementRequest: { select: { title: true, priority: true } },
      },
      orderBy: { createdAt: 'DESC' },
    });

    // Aggregate by vendor
    const vendorMap = new Map<string, {
      vendorId: string;
      vendorName: string;
      category: string;
      orderCount: number;
      totalSpend: number;
      avgOrderValue: number;
      avgQuality: number;
    }>();

    // Aggregate by month for trends
    const monthMap = new Map<string, { spend: number; orderCount: number }>();

    // Aggregate by item category
    const itemCategoryMap = new Map<string, { spend: number; itemCount: number }>();

    let totalSpend = 0;
    let totalOrders = purchaseOrders.length;

    for (const po of purchaseOrders) {
      const amount = po.amount || 0;
      totalSpend += amount;

      // Vendor aggregation
      const vendorId = po.vendorId || 'unknown';
      const vendorName = po.vendor?.name || 'Unknown';
      const vendorCategory = po.vendor?.category || '';
      if (!vendorMap.has(vendorId)) {
        vendorMap.set(vendorId, {
          vendorId,
          vendorName,
          category: vendorCategory,
          orderCount: 0,
          totalSpend: 0,
          avgOrderValue: 0,
          avgQuality: 0,
        });
      }
      const vEntry = vendorMap.get(vendorId)!;
      vEntry.orderCount++;
      vEntry.totalSpend += amount;

      // Monthly trend
      const monthKey = `${po.createdAt.getFullYear()}-${String(po.createdAt.getMonth() + 1).padStart(2, '0')}`;
      if (!monthMap.has(monthKey)) monthMap.set(monthKey, { spend: 0, orderCount: 0 });
      const mEntry = monthMap.get(monthKey)!;
      mEntry.spend += amount;
      mEntry.orderCount++;

      // Item category aggregation
      const items = (po.items as any[]) || [];
      for (const item of items) {
        const itemCategory = item.category || item.type || 'Uncategorized';
        if (!itemCategoryMap.has(itemCategory)) {
          itemCategoryMap.set(itemCategory, { spend: 0, itemCount: 0 });
        }
        const icEntry = itemCategoryMap.get(itemCategory)!;
        icEntry.spend += item.total || 0;
        icEntry.itemCount++;
      }
    }

    // Finalize vendor stats
    const byVendor = Array.from(vendorMap.values()).map((v) => ({
      ...v,
      totalSpend: Math.round(v.totalSpend),
      avgOrderValue: Math.round(v.totalSpend / v.orderCount),
    })).sort((a, b) => b.totalSpend - a.totalSpend);

    // Monthly trend
    const monthlyTrend = Array.from(monthMap.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, data]) => ({ month, ...data, spend: Math.round(data.spend) }));

    // By item category
    const byItemCategory = Array.from(itemCategoryMap.entries())
      .map(([category, data]) => ({ category, ...data, spend: Math.round(data.spend) }))
      .sort((a, b) => b.spend - a.spend);

    return {
      summary: {
        totalSpend: Math.round(totalSpend),
        totalOrders,
        avgOrderValue: totalOrders > 0 ? Math.round(totalSpend / totalOrders) : 0,
        vendorCount: vendorMap.size,
        periodStart: filters?.fromDate || null,
        periodEnd: filters?.toDate || null,
      },
      byVendor,
      monthlyTrend,
      byItemCategory,
    };
  }
}
