import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ProjectsService } from './projects.service';
import { CreateProjectDto, UpdateProjectDto, AssignMemberDto, CreateMilestoneDto, CreateTaskDto, UpdateTaskDto, CreateDailyReportDto, CreateVariationDto, CreateGuestProtectionDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Projects')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('projects')
export class ProjectsController {
  constructor(private readonly projectsService: ProjectsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a project' })
  async create(@Body() dto: CreateProjectDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.projectsService.create(dto);
    return createResponse(result, 'Project created');
  }

  @Get()
  @ApiOperation({ summary: 'List all projects' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('status') status?: string,
    @Query('hotelId') hotelId?: string,
  ) {
    const result = await this.projectsService.findAll(orgId, pagination, { status, hotelId });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get project by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.projectsService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update project' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateProjectDto) {
    const result = await this.projectsService.update(id, dto);
    return createResponse(result, 'Project updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete project' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.projectsService.remove(id);
    return createResponse(result);
  }

  // Members
  @Post(':id/assign-members')
  @ApiOperation({ summary: 'Assign members to project' })
  async assignMembers(@Param('id', ParseUUIDPipe) id: string, @Body() dto: AssignMemberDto[]) {
    const result = await this.projectsService.assignMembers(id, dto);
    return createResponse(result);
  }

  // Milestones
  @Get(':id/milestones')
  @ApiOperation({ summary: 'Get project milestones' })
  async getMilestones(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.projectsService.getMilestones(id);
    return createResponse(result);
  }

  @Post(':id/milestones')
  @ApiOperation({ summary: 'Create project milestone' })
  async createMilestone(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateMilestoneDto) {
    const result = await this.projectsService.createMilestone(id, dto);
    return createResponse(result, 'Milestone created');
  }

  // Tasks
  @Get(':id/tasks')
  @ApiOperation({ summary: 'Get project tasks' })
  async getTasks(@Param('id', ParseUUIDPipe) id: string, @Query('status') status?: string) {
    const result = await this.projectsService.getTasks(id, status);
    return createResponse(result);
  }

  @Post(':id/tasks')
  @ApiOperation({ summary: 'Create project task' })
  async createTask(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateTaskDto) {
    const result = await this.projectsService.createTask(id, dto);
    return createResponse(result, 'Task created');
  }

  @Put(':id/tasks/:taskId')
  @ApiOperation({ summary: 'Update project task' })
  async updateTask(@Param('id', ParseUUIDPipe) id: string, @Param('taskId', ParseUUIDPipe) taskId: string, @Body() dto: UpdateTaskDto) {
    const result = await this.projectsService.updateTask(id, taskId, dto);
    return createResponse(result, 'Task updated');
  }

  // Daily Reports
  @Get(':id/daily-reports')
  @ApiOperation({ summary: 'Get project daily reports' })
  async getDailyReports(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.projectsService.getDailyReports(id);
    return createResponse(result);
  }

  @Post(':id/daily-reports')
  @ApiOperation({ summary: 'Create daily report' })
  async createDailyReport(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateDailyReportDto, @CurrentUser('id') userId: string) {
    const result = await this.projectsService.createDailyReport(id, dto, userId);
    return createResponse(result, 'Daily report created');
  }

  // Variations
  @Get(':id/variations')
  @ApiOperation({ summary: 'Get project variations' })
  async getVariations(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.projectsService.getVariations(id);
    return createResponse(result);
  }

  @Post(':id/variations')
  @ApiOperation({ summary: 'Create variation order' })
  async createVariation(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateVariationDto) {
    const result = await this.projectsService.createVariation(id, dto);
    return createResponse(result, 'Variation order created');
  }

  // Guest Protection
  @Get(':id/guest-protection-plan')
  @ApiOperation({ summary: 'Get guest protection plan' })
  async getGuestProtectionPlan(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.projectsService.getGuestProtectionPlan(id);
    return createResponse(result);
  }

  @Post(':id/guest-protection-plan')
  @ApiOperation({ summary: 'Create/update guest protection plan' })
  async createGuestProtectionPlan(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateGuestProtectionDto) {
    const result = await this.projectsService.createGuestProtectionPlan(id, dto);
    return createResponse(result, 'Guest protection plan saved');
  }

  // Margin
  @Get(':id/margin')
  @ApiOperation({ summary: 'Calculate project margin' })
  async getMargin(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.projectsService.getMargin(id);
    return createResponse(result);
  }
}
