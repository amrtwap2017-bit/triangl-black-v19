import { Module } from '@nestjs/common';
import { ProjectsController } from './projects.controller';
import { ProjectsService } from './projects.service';
import { ProjectService } from './services/project.service';

@Module({
  controllers: [ProjectsController],
  providers: [ProjectsService, ProjectService],
  exports: [ProjectsService, ProjectService],
})
export class ProjectsModule {}
