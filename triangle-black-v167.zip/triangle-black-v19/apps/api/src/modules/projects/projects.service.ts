import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateProjectDto, UpdateProjectDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../common/utils';
import { ProjectService } from './services/project.service';

@Injectable()
export class ProjectsService {
  private readonly logger = new Logger(ProjectsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly projectService: ProjectService,
  ) {}

  async create(dto: CreateProjectDto) {
    const projectNumber = generateSequentialNumber('PJ');
    return this.prisma.project.create({
      data: { ...dto, projectNumber },
      include: { hotel: true, proposal: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string; hotelId?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { projectNumber: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (filters?.status) where.status = filters.status;
    if (filters?.hotelId) where.hotelId = filters.hotelId;

    const [data, total] = await Promise.all([
      this.prisma.project.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { hotel: true, _count: { select: { members: true, tasks: true, milestones: true } } } }),
      this.prisma.project.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const project = await this.prisma.project.findUnique({
      where: { id },
      include: { hotel: true, proposal: true, members: { include: { user: true } } },
    });
    if (!project) throw new NotFoundException('Project not found');
    return project;
  }

  async update(id: string, dto: UpdateProjectDto) {
    try {
      return this.prisma.project.update({ where: { id }, data: dto, include: { hotel: true } });
    } catch {
      throw new NotFoundException('Project not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.project.delete({ where: { id } });
      return { success: true, message: 'Project deleted' };
    } catch {
      throw new NotFoundException('Project not found');
    }
  }

  async assignMembers(id: string, members: { userId: string; role: string }[]) {
    const project = await this.prisma.project.findUnique({ where: { id } });
    if (!project) throw new NotFoundException('Project not found');

    const data = members.map((m) => ({ projectId: id, userId: m.userId, role: m.role }));
    await this.prisma.projectMember.createMany({ data, skipDuplicates: true });
    return { success: true, message: `${members.length} members assigned` };
  }

  // Milestones
  async getMilestones(projectId: string) {
    return this.prisma.projectMilestone.findMany({ where: { projectId }, orderBy: { dueDate: 'asc' } });
  }

  async createMilestone(projectId: string, dto: { name: string; nameAr?: string; dueDate?: string }) {
    return this.prisma.projectMilestone.create({
      data: { projectId, name: dto.name, nameAr: dto.nameAr, dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined },
    });
  }

  // Tasks
  async getTasks(projectId: string, status?: string) {
    const where: any = { projectId };
    if (status) where.status = status;
    return this.prisma.projectTask.findMany({ where, orderBy: { createdAt: 'desc' } });
  }

  async createTask(projectId: string, dto: any) {
    return this.prisma.projectTask.create({
      data: { projectId, ...dto },
    });
  }

  async updateTask(projectId: string, taskId: string, dto: any) {
    const task = await this.prisma.projectTask.findFirst({ where: { id: taskId, projectId } });
    if (!task) throw new NotFoundException('Task not found');

    return this.prisma.projectTask.update({ where: { id: taskId }, data: dto });
  }

  // Daily Reports
  async getDailyReports(projectId: string) {
    return this.prisma.dailyReport.findMany({ where: { projectId }, orderBy: { reportDate: 'desc' } });
  }

  async createDailyReport(projectId: string, dto: any, userId: string) {
    return this.prisma.dailyReport.create({
      data: { projectId, reportedBy: userId, reportDate: new Date(dto.reportDate), ...dto },
    });
  }

  // Variations
  async getVariations(projectId: string) {
    return this.prisma.variationOrder.findMany({ where: { projectId }, orderBy: { createdAt: 'desc' } });
  }

  async createVariation(projectId: string, dto: any) {
    const voCount = await this.prisma.variationOrder.count({ where: { projectId } });
    const voNumber = `VO-${voCount + 1}`;
    return this.prisma.variationOrder.create({
      data: { projectId, voNumber, ...dto },
    });
  }

  // Guest Protection Plan
  async getGuestProtectionPlan(projectId: string) {
    const plan = await this.prisma.guestProtectionPlan.findUnique({ where: { projectId } });
    if (!plan) throw new NotFoundException('Guest protection plan not found');
    return plan;
  }

  async createGuestProtectionPlan(projectId: string, dto: any) {
    return this.prisma.guestProtectionPlan.upsert({
      where: { projectId },
      create: { projectId, ...dto },
      update: { ...dto },
    });
  }

  // Margin
  async getMargin(projectId: string) {
    return this.projectService.calculateMargin(projectId);
  }
}
