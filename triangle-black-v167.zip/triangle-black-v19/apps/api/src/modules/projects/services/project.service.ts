import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { CreateProjectDto, UpdateProjectDto } from '../dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../../common/utils';

@Injectable()
export class ProjectService {
  private readonly logger = new Logger(ProjectService.name);

  constructor(private readonly prisma: PrismaService) {}

  async calculateMargin(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: { variationOrders: true },
    });
    if (!project) throw new NotFoundException('Project not found');

    const revenue = project.revenue || 0;
    const costs = project.actualCost || 0;
    const voImpact = project.variationOrders
      .filter((vo) => vo.status === 'APPROVED')
      .reduce((sum, vo) => sum + (vo.costImpact || 0), 0);

    const totalCosts = costs + voImpact;
    const margin = revenue - totalCosts;
    const marginPercent = revenue > 0 ? ((margin / revenue) * 100) : 0;

    return {
      projectId,
      revenue,
      costs: totalCosts,
      margin,
      marginPercent,
      variationImpact: voImpact,
    };
  }

  async updateBudget(projectId: string) {
    const variations = await this.prisma.variationOrder.findMany({
      where: { projectId, status: 'APPROVED' },
    });
    const totalVOImpact = variations.reduce((sum, vo) => sum + (vo.revenueImpact || 0), 0);

    return totalVOImpact;
  }
}
