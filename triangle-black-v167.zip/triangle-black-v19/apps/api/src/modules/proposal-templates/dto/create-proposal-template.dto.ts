import { IsString, IsOptional, IsUUID, IsEnum, IsObject, IsBoolean } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateProposalTemplateDto {
  @ApiProperty()
  @IsUUID()
  organizationId: string;

  @ApiProperty()
  @IsString()
  name: string;

  @ApiProperty({ enum: ['HVAC', 'ELECTRICAL', 'PLUMBING', 'WATERPROOFING', 'RENOVATION', 'FIT_OUT', 'MEP', 'PROCUREMENT'] })
  @IsEnum(['HVAC', 'ELECTRICAL', 'PLUMBING', 'WATERPROOFING', 'RENOVATION', 'FIT_OUT', 'MEP', 'PROCUREMENT'])
  projectType: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  executiveSummary?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  scopeOfWork?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  methodStatement?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  guestProtection?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  assumptions?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  exclusions?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  commercialTerms?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}

export class UpdateProposalTemplateDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  projectType?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  executiveSummary?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  scopeOfWork?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  methodStatement?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  guestProtection?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  assumptions?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  exclusions?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  commercialTerms?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  isActive?: boolean;
}
