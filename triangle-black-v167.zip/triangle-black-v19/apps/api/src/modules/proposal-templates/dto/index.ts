export { CreateProposalTemplateDto, UpdateProposalTemplateDto } from './create-proposal-template.dto';
