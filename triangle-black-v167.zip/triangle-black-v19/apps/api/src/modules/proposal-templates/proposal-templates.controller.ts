import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ProposalTemplatesService } from './proposal-templates.service';
import { CreateProposalTemplateDto, UpdateProposalTemplateDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Proposal Templates')
@ApiBearerAuth()
@Controller('proposal-templates')
export class ProposalTemplatesController {
  constructor(private readonly service: ProposalTemplatesService) {}

  @Post()
  @ApiOperation({ summary: 'Create proposal template' })
  async create(@Body() dto: CreateProposalTemplateDto, @CurrentUser('id') userId: string) {
    const result = await this.service.create(dto, userId);
    return createResponse(result, 'Proposal template created');
  }

  @Get()
  @ApiOperation({ summary: 'List proposal templates with projectType filter' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('projectType') projectType?: string,
  ) {
    const result = await this.service.findAll(orgId, pagination, { projectType });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('types')
  @ApiOperation({ summary: 'List available project types' })
  async getTypes(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getTypes();
    return createResponse(result);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get proposal template by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update proposal template' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateProposalTemplateDto,
    @CurrentUser('id') userId: string,
  ) {
    const result = await this.service.update(id, dto, userId);
    return createResponse(result, 'Proposal template updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete proposal template' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.remove(id);
    return createResponse(result);
  }

  @Post(':id/duplicate')
  @ApiOperation({ summary: 'Duplicate template' })
  async duplicate(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.service.duplicate(id, userId);
    return createResponse(result, 'Template duplicated');
  }
}
