import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { CreateProposalTemplateDto, UpdateProposalTemplateDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination } from '../../../common/utils';

@Injectable()
export class ProposalTemplatesService {
  private readonly logger = new Logger(ProposalTemplatesService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateProposalTemplateDto, userId: string) {
    return this.prisma.proposalTemplate.create({
      data: { ...dto, createdBy: userId, updatedBy: userId },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { projectType?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (filters?.projectType) where.projectType = filters.projectType;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.proposalTemplate.findMany({ where, skip, take, orderBy: { [sortBy || 'createdAt']: sortOrder || 'DESC' } }),
      this.prisma.proposalTemplate.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const template = await this.prisma.proposalTemplate.findUnique({ where: { id } });
    if (!template) throw new NotFoundException('Proposal template not found');
    return template;
  }

  async update(id: string, dto: UpdateProposalTemplateDto, userId: string) {
    await this.findOne(id);
    return this.prisma.proposalTemplate.update({
      where: { id },
      data: { ...dto, updatedBy: userId, version: { increment: 1 } },
    });
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.proposalTemplate.delete({ where: { id } });
    return { success: true, message: 'Proposal template deleted' };
  }

  async getTypes() {
    const types = await this.prisma.proposalTemplate.groupBy({
      by: ['projectType'],
      _count: { id: true },
    });
    return types.map((t) => ({ type: t.projectType, count: t._count.id }));
  }

  async duplicate(id: string, userId: string) {
    const template = await this.findOne(id);
    const { id: _id, createdAt, updatedAt, version, ...data } = template as any;
    return this.prisma.proposalTemplate.create({
      data: {
        ...data,
        name: `${template.name} (Copy)`,
        createdBy: userId,
        updatedBy: userId,
      },
    });
  }
}
