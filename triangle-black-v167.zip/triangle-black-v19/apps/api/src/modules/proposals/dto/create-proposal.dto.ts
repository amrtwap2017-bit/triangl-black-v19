import { IsString, IsOptional, IsUUID, IsNumber, IsEnum, IsObject, IsArray, IsInt } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateProposalDto {
  @ApiProperty()
  @IsUUID()
  organizationId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  hotelId?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  opportunityId?: string;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  titleAr?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  executiveSummary?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  scopeOfWork?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  boq?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  methodStatement?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  timeline?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  assumptions?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  exclusions?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  commercialTerms?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  guestProtection?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  totalValue?: number;

  @ApiPropertyOptional({ default: 'SAR' })
  @IsOptional()
  @IsString()
  currency?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: any;
}

export class UpdateProposalDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  titleAr?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  executiveSummary?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  scopeOfWork?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  boq?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  methodStatement?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  timeline?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  assumptions?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  exclusions?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  commercialTerms?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  guestProtection?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  totalValue?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: any;
}

export class RejectProposalDto {
  @ApiProperty()
  @IsString()
  reason: string;
}

export class CreateProjectFromProposalDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  name?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  type?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  budget?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  startDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  endDate?: string;
}
