import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ProposalsService } from './proposals.service';
import { CreateProposalDto, UpdateProposalDto, RejectProposalDto, CreateProjectFromProposalDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Proposals')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('proposals')
export class ProposalsController {
  constructor(private readonly proposalsService: ProposalsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a proposal' })
  async create(@Body() dto: CreateProposalDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.proposalsService.create(dto);
    return createResponse(result, 'Proposal created');
  }

  @Get()
  @ApiOperation({ summary: 'List all proposals' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('status') status?: string,
    @Query('hotelId') hotelId?: string,
  ) {
    const result = await this.proposalsService.findAll(orgId, pagination, { status, hotelId });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get proposal by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.proposalsService.findOne(id);
    return createResponse(result);
  }

  @Get(':id/export-pdf')
  @ApiOperation({ summary: 'Export proposal as PDF' })
  async exportPdf(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.proposalsService.exportPdf(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update proposal' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateProposalDto) {
    const result = await this.proposalsService.update(id, dto);
    return createResponse(result, 'Proposal updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete proposal' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.proposalsService.remove(id);
    return createResponse(result);
  }

  @Post(':id/submit')
  @ApiOperation({ summary: 'Submit proposal (DRAFT → SENT)' })
  async submit(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.proposalsService.submit(id);
    return createResponse(result, 'Proposal submitted');
  }

  @Post(':id/present')
  @ApiOperation({ summary: 'Present proposal (DRAFT/SENT → PRESENTED)' })
  async present(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.proposalsService.present(id);
    return createResponse(result, 'Proposal presented');
  }

  @Post(':id/approve')
  @ApiOperation({ summary: 'Approve proposal (PRESENTED → APPROVED, optionally create Project)' })
  async approve(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto?: CreateProjectFromProposalDto,
  ) {
    const result = await this.proposalsService.approve(id, true, dto);
    return createResponse(result, 'Proposal approved');
  }

  @Post(':id/reject')
  @ApiOperation({ summary: 'Reject proposal' })
  async reject(@Param('id', ParseUUIDPipe) id: string, @Body() dto: RejectProposalDto) {
    const result = await this.proposalsService.reject(id, dto.reason);
    return createResponse(result, 'Proposal rejected');
  }

  @Post(':id/generate-boq')
  @ApiOperation({ summary: 'AI-generate Bill of Quantities' })
  async generateBoq(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.proposalsService.generateBoq(id);
    return createResponse(result, 'BOQ generated');
  }

  @Post(':id/generate-method-statement')
  @ApiOperation({ summary: 'AI-generate Method Statement' })
  async generateMethodStatement(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.proposalsService.generateMethodStatement(id);
    return createResponse(result, 'Method statement generated');
  }

  @Post(':id/generate-guest-protection')
  @ApiOperation({ summary: 'AI-generate Guest Protection Plan' })
  async generateGuestProtection(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.proposalsService.generateGuestProtection(id);
    return createResponse(result, 'Guest protection generated');
  }
}
