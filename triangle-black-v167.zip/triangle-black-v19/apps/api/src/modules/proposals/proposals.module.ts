import { Module } from '@nestjs/common';
import { ProposalsController } from './proposals.controller';
import { ProposalsService } from './proposals.service';
import { ProposalService } from './services/proposal.service';

@Module({
  controllers: [ProposalsController],
  providers: [ProposalsService, ProposalService],
  exports: [ProposalsService, ProposalService],
})
export class ProposalsModule {}
