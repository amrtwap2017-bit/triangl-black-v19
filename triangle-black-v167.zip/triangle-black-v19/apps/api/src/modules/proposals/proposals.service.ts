import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateProposalDto, UpdateProposalDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../common/utils';
import { ProposalService } from './services/proposal.service';

@Injectable()
export class ProposalsService {
  private readonly logger = new Logger(ProposalsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly proposalService: ProposalService,
  ) {}

  async create(dto: CreateProposalDto) {
    const proposalNumber = generateSequentialNumber('PROP');
    const totalValue = dto.totalValue ?? this.proposalService.calculateTotalValue(dto.boq || []);

    return this.prisma.proposal.create({
      data: { ...dto, proposalNumber, totalValue },
      include: { hotel: true, opportunity: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string; hotelId?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { proposalNumber: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (filters?.status) where.status = filters.status;
    if (filters?.hotelId) where.hotelId = filters.hotelId;

    const [data, total] = await Promise.all([
      this.prisma.proposal.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { hotel: true, opportunity: true } }),
      this.prisma.proposal.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const proposal = await this.prisma.proposal.findUnique({
      where: { id },
      include: { hotel: true, opportunity: true, project: true },
    });
    if (!proposal) throw new NotFoundException('Proposal not found');
    return proposal;
  }

  async update(id: string, dto: UpdateProposalDto) {
    try {
      const proposal = await this.prisma.proposal.findUnique({ where: { id } });
      if (!proposal) throw new NotFoundException('Proposal not found');

      if (dto.boq && proposal.status === 'DRAFT') {
        dto.totalValue = this.proposalService.calculateTotalValue(dto.boq);
      }

      return this.prisma.proposal.update({ where: { id }, data: dto, include: { hotel: true, opportunity: true } });
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      this.logger.error('Update proposal error:', error);
      throw error;
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.proposal.delete({ where: { id } });
      return { success: true, message: 'Proposal deleted' };
    } catch {
      throw new NotFoundException('Proposal not found');
    }
  }

  async submit(id: string) {
    return this.proposalService.submitProposal(id);
  }

  async present(id: string) {
    return this.proposalService.presentProposal(id);
  }

  async approve(id: string, createProject: boolean = false, projectData?: any) {
    return this.proposalService.approveProposal(id, createProject, projectData);
  }

  async reject(id: string, reason: string) {
    return this.proposalService.rejectProposal(id, reason);
  }

  async generateBoq(id: string) {
    const proposal = await this.prisma.proposal.findUnique({ where: { id }, include: { hotel: true, opportunity: true } });
    if (!proposal) throw new NotFoundException('Proposal not found');

    // AI placeholder
    const boq = [
      { item: 'Material Supply', description: 'As per specification', quantity: 100, unit: 'SQM', unitPrice: 50, total: 5000 },
      { item: 'Labor', description: 'Installation and finishing', quantity: 10, unit: 'MAN-DAY', unitPrice: 800, total: 8000 },
      { item: 'Equipment Rental', description: 'Specialized equipment', quantity: 5, unit: 'DAY', unitPrice: 500, total: 2500 },
    ];

    return { boq, totalValue: boq.reduce((s, i) => s + i.total, 0) };
  }

  async generateMethodStatement(id: string) {
    const proposal = await this.prisma.proposal.findUnique({ where: { id }, include: { hotel: true } });
    if (!proposal) throw new NotFoundException('Proposal not found');

    // AI placeholder
    return {
      methodStatement: `Method Statement for ${proposal.title}\n\n1. Preparatory Works\n2. Execution Phase\n3. Quality Control\n4. Completion and Handover`,
    };
  }

  async generateGuestProtection(id: string) {
    const proposal = await this.prisma.proposal.findUnique({ where: { id } });
    if (!proposal) throw new NotFoundException('Proposal not found');

    // AI placeholder
    return {
      guestProtection: {
        noise: { level: 'LOW', mitigation: 'Schedule noisy work during off-peak hours' },
        dust: { level: 'MEDIUM', mitigation: 'Use dust barriers and wet methods' },
        odor: { level: 'LOW', mitigation: 'Ensure adequate ventilation' },
        shutdown: { required: false, details: null },
      },
    };
  }

  async exportPdf(id: string) {
    const proposal = await this.prisma.proposal.findUnique({ where: { id } });
    if (!proposal) throw new NotFoundException('Proposal not found');

    // Placeholder for PDF generation
    return { url: `https://storage.example.com/proposals/${proposal.proposalNumber}.pdf`, status: 'placeholder' };
  }

  /**
   * Generate a proposal draft from an existing opportunity, including AI-suggested content
   * from site visit data, scope of work, BOQ, and guest protection.
   */
  async generateFromOpportunity(opportunityId: string) {
    const opportunity = await this.prisma.opportunity.findUnique({
      where: { id: opportunityId },
      include: {
        hotel: { select: { id: true, name: true, address: true, city: true, starRating: true } },
        contacts: { take: 3 },
        siteVisits: { where: { deletedAt: null }, take: 5, orderBy: { createdAt: 'DESC' } },
        drawings: { where: { deletedAt: null }, take: 5 },
      },
    });
    if (!opportunity) throw new NotFoundException('Opportunity not found');

    const proposalNumber = generateSequentialNumber('PROP');

    // Extract site visit observations for scope of work
    const siteVisitNotes = opportunity.siteVisits
      .map((sv) => (sv as any).notes || (sv as any).observations || '')
      .filter(Boolean)
      .join('\n');

    // Generate BOQ from opportunity value and typical distribution
    const estimatedValue = opportunity.value || 50000;
    const boq = [
      {
        item: 'Material Supply',
        description: `Materials as per specifications for ${opportunity.title || 'project scope'}`,
        quantity: Math.ceil(estimatedValue * 0.45 / 100),
        unit: 'SQM',
        unitPrice: 100,
        total: Math.round(estimatedValue * 0.45),
      },
      {
        item: 'Labor - Installation',
        description: 'Professional installation and finishing works',
        quantity: Math.ceil(estimatedValue * 0.35 / 800),
        unit: 'MAN-DAY',
        unitPrice: 800,
        total: Math.round(estimatedValue * 0.35),
      },
      {
        item: 'Project Management',
        description: 'Site supervision, coordination, and quality control',
        quantity: 1,
        unit: 'LUMP SUM',
        unitPrice: Math.round(estimatedValue * 0.10),
        total: Math.round(estimatedValue * 0.10),
      },
      {
        item: 'Guest Protection Measures',
        description: 'Temporary barriers, dust control, noise mitigation',
        quantity: 1,
        unit: 'LUMP SUM',
        unitPrice: Math.round(estimatedValue * 0.05),
        total: Math.round(estimatedValue * 0.05),
      },
      {
        item: 'Contingency',
        description: '5% contingency for unforeseen works',
        quantity: 1,
        unit: 'LUMP SUM',
        unitPrice: Math.round(estimatedValue * 0.05),
        total: Math.round(estimatedValue * 0.05),
      },
    ];

    const totalValue = boq.reduce((sum, item) => sum + item.total, 0);
    const proposedMargin = Math.round(totalValue * 0.20); // 20% target margin
    const materialCost = boq.find((i) => i.item.includes('Material'))?.total || 0;
    const laborCost = boq.find((i) => i.item.includes('Labor'))?.total || 0;
    const vendorCost = 0;

    const proposal = await this.prisma.proposal.create({
      data: {
        organizationId: opportunity.organizationId,
        hotelId: opportunity.hotelId,
        opportunityId: opportunity.id,
        proposalNumber,
        title: `Proposal: ${opportunity.title || 'New Project'}`,
        description: `Proposal generated from opportunity ${opportunity.id}`,
        scopeOfWork: siteVisitNotes || `Complete scope of works for ${opportunity.title || 'project'} at ${opportunity.hotel?.name || 'hotel'}.

Based on opportunity assessment and site visit observations, the following scope is proposed:

1. Site Preparation and Protection
2. Main Works Execution
3. Quality Control and Testing
4. Completion and Handover`,
        status: 'DRAFT',
        boq,
        totalValue,
        materialCost,
        laborCost,
        vendorCost,
        proposedMargin,
        currency: opportunity.currency || 'SAR',
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days validity
      },
      include: { hotel: true, opportunity: true },
    });

    return {
      proposal,
      message: 'Proposal draft generated from opportunity. Review and customize before submitting.',
      suggestions: {
        titleSuggestion: `Proposal for ${opportunity.title || 'Project'} - ${opportunity.hotel?.name || 'Hotel'}`,
        scopeOfWorkSuggestion: `Refer to site visit notes and opportunity description for detailed scope. Consider adding specific technical specifications.`,
        pricingNote: 'BOQ items auto-generated from opportunity value. Adjust quantities and unit prices based on actual scope.',
        nextSteps: [
          'Review and customize scope of work',
          'Adjust BOQ quantities and pricing',
          'Generate method statement',
          'Generate guest protection plan',
          'Submit for approval',
        ],
      },
    };
  }

  /**
   * Calculate margin breakdown from a proposal's BOQ.
   */
  async calculateProposalMargin(proposalId: string) {
    const proposal = await this.prisma.proposal.findUnique({
      where: { id: proposalId },
      include: { hotel: true, opportunity: true },
    });
    if (!proposal) throw new NotFoundException('Proposal not found');

    const boq = (proposal.boq as any[]) || [];
    const totalValue = proposal.totalValue || this.proposalService.calculateTotalValue(boq);

    // Sum up cost items from BOQ
    const materialItems = boq.filter((i) => /material|supply|equipment/gi.test(i.item || i.description || ''));
    const laborItems = boq.filter((i) => /labor|installation|man.day|manpower/gi.test(i.item || i.description || ''));
    const overheadItems = boq.filter((i) => /management|supervision|contingency|protection/gi.test(i.item || i.description || ''));

    const materialCost = materialItems.reduce((s, i) => s + (i.total || 0), 0);
    const laborCost = laborItems.reduce((s, i) => s + (i.total || 0), 0);
    const overheadCost = overheadItems.reduce((s, i) => s + (i.total || 0), 0);
    const totalCost = materialCost + laborCost + overheadCost;

    const grossMargin = totalValue - totalCost;
    const marginPercent = totalValue > 0 ? (grossMargin / totalValue) * 100 : 0;

    return {
      proposalId,
      proposalNumber: proposal.proposalNumber,
      title: proposal.title,
      totalValue,
      costBreakdown: {
        material: { items: materialItems.length, cost: materialCost, percentOfTotal: totalValue > 0 ? Math.round((materialCost / totalValue) * 10000) / 100 : 0 },
        labor: { items: laborItems.length, cost: laborCost, percentOfTotal: totalValue > 0 ? Math.round((laborCost / totalValue) * 10000) / 100 : 0 },
        overhead: { items: overheadItems.length, cost: overheadCost, percentOfTotal: totalValue > 0 ? Math.round((overheadCost / totalValue) * 10000) / 100 : 0 },
      },
      totalCost,
      grossMargin: Math.round(grossMargin),
      marginPercent: Math.round(marginPercent * 100) / 100,
      proposedMargin: proposal.proposedMargin || 0,
      marginHealth: marginPercent >= 20 ? 'HEALTHY' : marginPercent >= 15 ? 'ACCEPTABLE' : marginPercent >= 10 ? 'MARGINAL' : 'UNHEALTHY',
      boqItemCount: boq.length,
    };
  }

  /**
   * Duplicate/clones an existing proposal with a new number, keeping DRAFT status.
   */
  async duplicateProposal(proposalId: string) {
    const original = await this.prisma.proposal.findUnique({
      where: { id: proposalId },
      include: { hotel: true, opportunity: true },
    });
    if (!original) throw new NotFoundException('Proposal not found');

    const proposalNumber = generateSequentialNumber('PROP');

    // Strip fields that should not be duplicated
    const { id, createdAt, updatedAt, proposalNumber: _pn, approvedAt, rejectedAt, rejectedReason, ...data } = original as any;

    const duplicated = await this.prisma.proposal.create({
      data: {
        ...data,
        proposalNumber,
        title: `${original.title} (Copy)`,
        status: 'DRAFT',
        approvedAt: null,
        rejectedAt: null,
        rejectedReason: null,
      },
      include: { hotel: true, opportunity: true },
    });

    return {
      proposal: duplicated,
      originalProposalId: proposalId,
      message: 'Proposal duplicated successfully. Review and modify before submitting.',
    };
  }

  /**
   * Submit a proposal for approval — changes status to SENT.
   */
  async submitForApproval(proposalId: string) {
    return this.proposalService.submitProposal(proposalId);
  }
}
