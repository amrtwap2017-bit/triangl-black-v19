import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { CreateProposalDto, UpdateProposalDto } from '../dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../../common/utils';

@Injectable()
export class ProposalService {
  private readonly logger = new Logger(ProposalService.name);

  constructor(private readonly prisma: PrismaService) {}

  async submitProposal(id: string) {
    const proposal = await this.prisma.proposal.findUnique({ where: { id } });
    if (!proposal) throw new NotFoundException('Proposal not found');
    if (proposal.status !== 'DRAFT') throw new BadRequestException('Only DRAFT proposals can be submitted');

    return this.prisma.proposal.update({
      where: { id },
      data: { status: 'SENT', version: { increment: 1 } },
    });
  }

  async presentProposal(id: string) {
    const proposal = await this.prisma.proposal.findUnique({ where: { id } });
    if (!proposal) throw new NotFoundException('Proposal not found');
    if (!['DRAFT', 'SENT'].includes(proposal.status)) throw new BadRequestException('Proposal cannot be presented in current status');

    return this.prisma.proposal.update({
      where: { id },
      data: { status: 'PRESENTED' },
    });
  }

  async approveProposal(id: string, createProject: boolean, projectData?: any) {
    const proposal = await this.prisma.proposal.findUnique({ where: { id } });
    if (!proposal) throw new NotFoundException('Proposal not found');
    if (proposal.status !== 'PRESENTED') throw new BadRequestException('Only PRESENTED proposals can be approved');

    const updated = await this.prisma.proposal.update({
      where: { id },
      data: {
        status: 'APPROVED',
        approvedAt: new Date(),
        version: { increment: 1 },
      },
    });

    if (createProject) {
      const projectNumber = generateSequentialNumber('PJ');
      await this.prisma.project.create({
        data: {
          organizationId: proposal.organizationId,
          hotelId: proposal.hotelId,
          proposalId: id,
          projectNumber,
          name: projectData?.name || proposal.title,
          description: projectData?.description || proposal.scopeOfWork,
          type: projectData?.type,
          budget: projectData?.budget || proposal.totalValue,
          revenue: proposal.totalValue,
          currency: proposal.currency,
          startDate: projectData?.startDate ? new Date(projectData.startDate) : undefined,
          endDate: projectData?.endDate ? new Date(projectData.endDate) : undefined,
        },
      });
    }

    return updated;
  }

  async rejectProposal(id: string, reason: string) {
    const proposal = await this.prisma.proposal.findUnique({ where: { id } });
    if (!proposal) throw new NotFoundException('Proposal not found');
    if (['APPROVED', 'EXPIRED'].includes(proposal.status)) throw new BadRequestException('Proposal cannot be rejected in current status');

    return this.prisma.proposal.update({
      where: { id },
      data: { status: 'REJECTED', rejectedReason: reason },
    });
  }

  async calculateTotalValue(boq: any[]): number {
    if (!boq || boq.length === 0) return 0;
    return boq.reduce((sum: number, item: any) => sum + (item.total || (item.quantity * item.unitPrice) || 0), 0);
  }
}
