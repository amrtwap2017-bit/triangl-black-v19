import {
  Controller, Get, Post, Put, Body, Param, Query, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { RelationshipsService } from './relationships.service';
import { UpdateRelationshipDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Relationship Intelligence')
@ApiBearerAuth()
@Controller('relationships')
export class RelationshipsController {
  constructor(private readonly service: RelationshipsService) {}

  @Get()
  @ApiOperation({ summary: 'List all hotel relationships with scores, sorted by score' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.service.findAll(orgId, pagination);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('top')
  @ApiOperation({ summary: 'Top N hotels by revenue, score, or margin' })
  async getTop(
    @CurrentUser('organizationId') orgId: string,
    @Query('sortBy') sortBy?: string,
    @Query('limit') limit?: string,
  ) {
    const result = await this.service.getTop(orgId, sortBy, limit ? parseInt(limit, 10) : undefined);
    return createResponse(result);
  }

  @Get('at-risk')
  @ApiOperation({ summary: 'Hotels with declining engagement (no contact in 90+ days)' })
  async getAtRisk(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getAtRisk(orgId);
    return createResponse(result);
  }

  @Get('follow-ups')
  @ApiOperation({ summary: 'Hotels needing follow-up (nextFollowUpAt <= now)' })
  async getFollowUps(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getFollowUps(orgId);
    return createResponse(result);
  }

  @Get(':hotelId')
  @ApiOperation({ summary: 'Full relationship profile for a hotel' })
  async getProfile(@Param('hotelId', ParseUUIDPipe) hotelId: string) {
    const result = await this.service.getProfile(hotelId);
    return createResponse(result);
  }

  @Post(':hotelId/recalculate')
  @ApiOperation({ summary: 'Trigger score recalculation' })
  async recalculate(
    @Param('hotelId', ParseUUIDPipe) hotelId: string,
    @CurrentUser('id') userId: string,
  ) {
    const result = await this.service.recalculate(hotelId, userId);
    return createResponse(result, 'Relationship score recalculated');
  }
}
