import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination } from '../../../common/utils';

@Injectable()
export class RelationshipsService {
  private readonly logger = new Logger(RelationshipsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async findAll(organizationId: string, pagination: PaginationDto) {
    const { page, limit, sortBy, sortOrder } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where = { organizationId };

    const [data, total] = await Promise.all([
      this.prisma.hotelRelationship.findMany({
        where, skip, take,
        orderBy: { [sortBy || 'relationshipScore']: sortOrder || 'DESC' },
        include: { hotel: true },
      }),
      this.prisma.hotelRelationship.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async getProfile(hotelId: string) {
    return this.prisma.hotelRelationship.findUnique({
      where: { hotelId },
      include: {
        hotel: {
          include: {
            contacts: true,
            projects: { where: { deletedAt: null }, take: 5, orderBy: { createdAt: 'DESC' } },
            opportunities: { where: { deletedAt: null }, take: 5, orderBy: { createdAt: 'DESC' } },
            emergencies: { where: { deletedAt: null }, take: 5, orderBy: { createdAt: 'DESC' } },
          },
        },
      },
    });
  }

  async recalculate(hotelId: string, userId: string) {
    const hotel = await this.prisma.hotel.findUnique({ where: { id: hotelId } });
    if (!hotel) return null;

    const projects = await this.prisma.project.findMany({
      where: { hotelId, deletedAt: null, status: 'COMPLETED' },
      select: { revenue: true, actualCost: true, createdAt: true },
    });
    const opportunities = await this.prisma.opportunity.findMany({
      where: { hotelId, deletedAt: null },
      select: { status: true, value: true },
    });
    const emergencies = await this.prisma.emergencyCase.findMany({
      where: { hotelId, deletedAt: null },
      select: { createdAt: true },
    });

    const totalRevenue = projects.reduce((s, p) => s + (p.revenue || 0), 0);
    const totalProfit = projects.reduce((s, p) => s + ((p.revenue || 0) - (p.actualCost || 0)), 0);
    const totalProjects = projects.length;
    const activeProjects = await this.prisma.project.count({ where: { hotelId, deletedAt: null, status: { in: ['PLANNING', 'ACTIVE'] } } });
    const totalEmergencies = emergencies.length;
    const totalOpportunities = opportunities.length;
    const wonOpportunities = opportunities.filter((o) => o.status === 'CLOSED_WON').length;
    const winRate = totalOpportunities > 0 ? (wonOpportunities / totalOpportunities) * 100 : 0;
    const averageMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;

    // Score calculation: 0-100 based on revenue, engagement, win rate
    let score = 50;
    if (totalRevenue > 500000) score += 15;
    else if (totalRevenue > 100000) score += 10;
    if (winRate > 60) score += 15;
    else if (winRate > 30) score += 8;
    if (totalProjects > 5) score += 10;
    if (totalEmergencies < 3) score += 5;
    else if (totalEmergencies > 10) score -= 10;
    score = Math.max(0, Math.min(100, score));

    const lastEngagementAt = emergencies.length > 0 ? emergencies[emergencies.length - 1].createdAt : null;

    return this.prisma.hotelRelationship.upsert({
      where: { hotelId },
      create: {
        hotelId,
        organizationId: hotel.organizationId,
        totalRevenue, totalProfit, totalProjects, activeProjects,
        totalEmergencies, totalOpportunities, wonOpportunities,
        winRate, averageMargin, relationshipScore: score,
        lastEngagementAt,
        createdBy: userId, updatedBy: userId,
      },
      update: {
        totalRevenue, totalProfit, totalProjects, activeProjects,
        totalEmergencies, totalOpportunities, wonOpportunities,
        winRate, averageMargin, relationshipScore: score,
        lastEngagementAt,
        updatedBy: userId,
      },
    });
  }

  async getTop(organizationId: string, sortBy?: string, limit?: number) {
    const take = limit ?? 10;
    const orderBy = sortBy === 'revenue' ? { totalRevenue: 'desc' } :
      sortBy === 'margin' ? { averageMargin: 'desc' } :
      { relationshipScore: 'desc' };

    return this.prisma.hotelRelationship.findMany({
      where: { organizationId },
      orderBy: orderBy as any,
      take,
      include: { hotel: true },
    });
  }

  async getAtRisk(organizationId: string) {
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    return this.prisma.hotelRelationship.findMany({
      where: {
        organizationId,
        lastEngagementAt: { lt: ninetyDaysAgo },
      },
      include: { hotel: true },
      orderBy: { lastEngagementAt: 'ASC' },
    });
  }

  async getFollowUps(organizationId: string) {
    return this.prisma.hotelRelationship.findMany({
      where: {
        organizationId,
        nextFollowUpAt: { lte: new Date() },
      },
      include: { hotel: true },
      orderBy: { nextFollowUpAt: 'ASC' },
    });
  }

  /**
   * Hotel Health Score (0-100) based on revenue, engagement, response, and growth scores.
   * Each dimension contributes up to 25 points.
   */
  async calculateHotelHealthScore(hotelId: string): Promise<{
    healthScore: number;
    revenueScore: number;
    engagementScore: number;
    responseScore: number;
    growthScore: number;
    overallStatus: 'EXCELLENT' | 'GOOD' | 'AT_RISK' | 'CRITICAL';
  }> {
    const hotel = await this.prisma.hotel.findUnique({ where: { id: hotelId } });
    if (!hotel) throw new NotFoundException('Hotel not found');

    // Revenue Score (0-25): based on total revenue from relationship
    const relationship = await this.prisma.hotelRelationship.findUnique({ where: { hotelId } });
    const totalRevenue = relationship?.totalRevenue || 0;
    let revenueScore = 0;
    if (totalRevenue >= 1000000) revenueScore = 25;
    else if (totalRevenue >= 500000) revenueScore = 20;
    else if (totalRevenue >= 200000) revenueScore = 15;
    else if (totalRevenue >= 100000) revenueScore = 10;
    else if (totalRevenue > 0) revenueScore = 5;

    // Engagement Score (0-25): based on recent interactions
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    const recentProjects = await this.prisma.project.count({
      where: { hotelId, deletedAt: null, createdAt: { gte: ninetyDaysAgo } },
    });
    const recentOpportunities = await this.prisma.opportunity.count({
      where: { hotelId, deletedAt: null, createdAt: { gte: ninetyDaysAgo } },
    });
    const recentEmergencies = await this.prisma.emergencyCase.count({
      where: { hotelId, deletedAt: null, createdAt: { gte: ninetyDaysAgo } },
    });
    const recentInteractions = recentProjects * 3 + recentOpportunities * 2 + recentEmergencies;
    let engagementScore = 0;
    if (recentInteractions >= 10) engagementScore = 25;
    else if (recentInteractions >= 6) engagementScore = 20;
    else if (recentInteractions >= 3) engagementScore = 15;
    else if (recentInteractions >= 1) engagementScore = 8;
    else engagementScore = 0;

    // Response Score (0-25): based on win rate and follow-up responsiveness
    const winRate = relationship?.winRate || 0;
    const hasFollowUp = !!relationship?.nextFollowUpAt;
    const lastEngaged = relationship?.lastEngagementAt;
    const daysSinceEngagement = lastEngaged
      ? Math.floor((Date.now() - lastEngagement.getTime()) / (1000 * 60 * 60 * 24))
      : 999;
    let responseScore = 0;
    if (winRate >= 60) responseScore += 12;
    else if (winRate >= 40) responseScore += 8;
    else if (winRate >= 20) responseScore += 5;
    if (hasFollowUp) responseScore += 5;
    if (daysSinceEngagement < 30) responseScore += 8;
    else if (daysSinceEngagement < 60) responseScore += 5;
    else if (daysSinceEngagement < 90) responseScore += 2;
    responseScore = Math.min(25, responseScore);

    // Growth Score (0-25): based on project count trend and active projects
    const activeProjects = relationship?.activeProjects || 0;
    const totalProjects = relationship?.totalProjects || 0;
    const completedProjects = totalProjects - activeProjects;
    let growthScore = 0;
    if (activeProjects >= 3) growthScore += 12;
    else if (activeProjects >= 2) growthScore += 8;
    else if (activeProjects >= 1) growthScore += 5;
    if (totalProjects >= 8) growthScore += 13;
    else if (totalProjects >= 5) growthScore += 10;
    else if (totalProjects >= 3) growthScore += 7;
    else if (totalProjects >= 1) growthScore += 4;
    growthScore = Math.min(25, growthScore);

    const healthScore = Math.max(0, Math.min(100, revenueScore + engagementScore + responseScore + growthScore));

    let overallStatus: 'EXCELLENT' | 'GOOD' | 'AT_RISK' | 'CRITICAL';
    if (healthScore >= 80) overallStatus = 'EXCELLENT';
    else if (healthScore >= 55) overallStatus = 'GOOD';
    else if (healthScore >= 35) overallStatus = 'AT_RISK';
    else overallStatus = 'CRITICAL';

    return {
      healthScore,
      revenueScore,
      engagementScore,
      responseScore,
      growthScore,
      overallStatus,
    };
  }

  /**
   * Analyze growth trajectory for a hotel based on project history over time.
   */
  async getGrowthPotential(hotelId: string): Promise<{
    trajectory: 'STRONG_GROWTH' | 'STABLE' | 'DECLINING' | 'NEW';
    projectTrend: { period: string; count: number; revenue: number }[];
    avgProjectValue: number;
    avgProjectValueTrend: 'INCREASING' | 'STABLE' | 'DECREASING';
    potentialUpside: string;
  }> {
    const hotel = await this.prisma.hotel.findUnique({ where: { id: hotelId } });
    if (!hotel) throw new NotFoundException('Hotel not found');

    const projects = await this.prisma.project.findMany({
      where: { hotelId, deletedAt: null },
      select: { createdAt: true, revenue: true, status: true },
      orderBy: { createdAt: 'ASC' },
    });

    if (projects.length === 0) {
      return {
        trajectory: 'NEW',
        projectTrend: [],
        avgProjectValue: 0,
        avgProjectValueTrend: 'STABLE',
        potentialUpside: 'New relationship — high growth potential with proper engagement strategy.',
      };
    }

    // Group projects by quarter
    const quarterMap = new Map<string, { count: number; revenue: number }>();
    for (const p of projects) {
      const y = p.createdAt.getFullYear();
      const q = Math.ceil((p.createdAt.getMonth() + 1) / 3);
      const key = `${y}-Q${q}`;
      if (!quarterMap.has(key)) quarterMap.set(key, { count: 0, revenue: 0 });
      const entry = quarterMap.get(key)!;
      entry.count++;
      entry.revenue += p.revenue || 0;
    }

    const quarters = Array.from(quarterMap.entries()).map(([period, data]) => ({ period, ...data }));

    // Determine trajectory
    let trajectory: 'STRONG_GROWTH' | 'STABLE' | 'DECLINING' | 'NEW';
    if (quarters.length < 2) {
      trajectory = 'NEW';
    } else {
      const recent = quarters.slice(-2);
      const older = quarters.slice(-4, -2);
      const recentCount = recent.reduce((s, q) => s + q.count, 0);
      const olderCount = older.length > 0 ? older.reduce((s, q) => s + q.count, 0) : recentCount;
      if (recentCount > olderCount * 1.3) trajectory = 'STRONG_GROWTH';
      else if (recentCount < olderCount * 0.7) trajectory = 'DECLINING';
      else trajectory = 'STABLE';
    }

    // Average project value trend
    const half = Math.floor(projects.length / 2);
    const firstHalf = projects.slice(0, half);
    const secondHalf = projects.slice(half);
    const avgFirst = firstHalf.length > 0 ? firstHalf.reduce((s, p) => s + (p.revenue || 0), 0) / firstHalf.length : 0;
    const avgSecond = secondHalf.length > 0 ? secondHalf.reduce((s, p) => s + (p.revenue || 0), 0) / secondHalf.length : 0;
    const avgProjectValue = projects.reduce((s, p) => s + (p.revenue || 0), 0) / projects.length;
    const avgProjectValueTrend = avgSecond > avgFirst * 1.15 ? 'INCREASING' : avgSecond < avgFirst * 0.85 ? 'DECREASING' : 'STABLE';

    const potentialUpside =
      trajectory === 'STRONG_GROWTH'
        ? 'Strong upward trajectory — consider expanding scope and proposing maintenance contracts.'
        : trajectory === 'DECLINING'
          ? 'Declining engagement — immediate re-engagement recommended via site visit or complimentary assessment.'
          : 'Stable relationship — focus on deepening engagement through value-add services.';

    return {
      trajectory,
      projectTrend: quarters,
      avgProjectValue: Math.round(avgProjectValue),
      avgProjectValueTrend,
      potentialUpside,
    };
  }

  /**
   * Chronological engagement history for a hotel: projects, opportunities, emergencies, follow-ups.
   */
  async getRelationshipTimeline(hotelId: string): Promise<{
    hotelId: string;
    hotelName: string;
    events: {
      date: string;
      type: 'PROJECT' | 'OPPORTUNITY' | 'EMERGENCY' | 'FOLLOW_UP' | 'SITE_VISIT';
      title: string;
      value?: number;
      status?: string;
    }[];
  }> {
    const hotel = await this.prisma.hotel.findUnique({ where: { id: hotelId } });
    if (!hotel) throw new NotFoundException('Hotel not found');

    const [projects, opportunities, emergencies] = await Promise.all([
      this.prisma.project.findMany({
        where: { hotelId, deletedAt: null },
        select: { createdAt: true, name: true, revenue: true, status: true },
        orderBy: { createdAt: 'ASC' },
        take: 50,
      }),
      this.prisma.opportunity.findMany({
        where: { hotelId, deletedAt: null },
        select: { createdAt: true, title: true, value: true, status: true },
        orderBy: { createdAt: 'ASC' },
        take: 50,
      }),
      this.prisma.emergencyCase.findMany({
        where: { hotelId, deletedAt: null },
        select: { createdAt: true, title: true, status: true },
        orderBy: { createdAt: 'ASC' },
        take: 50,
      }),
    ]);

    const events: any[] = [];
    for (const p of projects) {
      events.push({ date: p.createdAt.toISOString(), type: 'PROJECT', title: p.name, value: p.revenue, status: p.status });
    }
    for (const o of opportunities) {
      events.push({ date: o.createdAt.toISOString(), type: 'OPPORTUNITY', title: o.title, value: o.value, status: o.status });
    }
    for (const e of emergencies) {
      events.push({ date: e.createdAt.toISOString(), type: 'EMERGENCY', title: e.title || 'Emergency Case', status: e.status });
    }

    events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return {
      hotelId,
      hotelName: hotel.name,
      events,
    };
  }

  /**
   * Identify hotels with declining engagement metrics within an organization.
   */
  async getAtRiskHotels(organizationId: string): Promise<{
    hotelId: string;
    hotelName: string;
    relationshipScore: number;
    lastEngagementAt: Date | null;
    daysSinceEngagement: number;
    declineIndicators: string[];
    recommendedAction: string;
  }[]> {
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    const oneYearAgo = new Date();
    oneYearAgo.setDate(oneYearAgo.getDate() - 365);

    const relationships = await this.prisma.hotelRelationship.findMany({
      where: { organizationId },
      include: { hotel: { select: { id: true, name: true } } },
      orderBy: { relationshipScore: 'ASC' },
    });

    const results: any[] = [];
    for (const rel of relationships) {
      const declineIndicators: string[] = [];
      const lastEngagement = rel.lastEngagementAt;
      const daysSinceEngagement = lastEngagement
        ? Math.floor((Date.now() - lastEngagement.getTime()) / (1000 * 60 * 60 * 24))
        : 999;

      if (daysSinceEngagement > 90) declineIndicators.push('No engagement in 90+ days');
      if (rel.relationshipScore < 40) declineIndicators.push('Low relationship score');
      if (rel.winRate < 20 && rel.totalOpportunities > 3) declineIndicators.push('Low win rate');
      if (rel.activeProjects === 0) declineIndicators.push('No active projects');
      if (rel.totalEmergencies > 5) declineIndicators.push('High emergency frequency');

      if (declineIndicators.length > 0) {
        const recommendedAction =
          daysSinceEngagement > 180
            ? 'Immediate re-engagement required — schedule site visit and offer complimentary assessment.'
            : daysSinceEngagement > 90
              ? 'Schedule follow-up meeting and identify new opportunities.'
              : 'Monitor engagement and schedule regular check-ins.';

        results.push({
          hotelId: rel.hotelId,
          hotelName: rel.hotel?.name || 'Unknown',
          relationshipScore: rel.relationshipScore,
          lastEngagementAt: lastEngagement,
          daysSinceEngagement,
          declineIndicators,
          recommendedAction,
        });
      }
    }

    return results;
  }
}
