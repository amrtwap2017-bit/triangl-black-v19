import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { ResourcePlanningService } from './resource-planning.service';
import { CreateEmployeeDto, CreateTeamDto, AssignTeamDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Resource Planning')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('resource-planning')
export class ResourcePlanningController {
  constructor(private readonly resourceService: ResourcePlanningService) {}

  // ── Employees ──

  @Post('employees')
  @ApiOperation({ summary: 'Create an employee' })
  @Roles('admin', 'resource_manager')
  async createEmployee(@Body() dto: CreateEmployeeDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.resourceService.createEmployee(dto);
    return createResponse(result, 'Employee created');
  }

  @Get('employees')
  @ApiOperation({ summary: 'List all employees' })
  async findAllEmployees(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string, @Query('skill') skill?: string) {
    const result = await this.resourceService.findAllEmployees(orgId, pagination, { skill });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('employees/availability')
  @ApiOperation({ summary: 'Get employee availability overview' })
  async getAvailability(@CurrentUser('organizationId') orgId: string) {
    const result = await this.resourceService.getAvailability(orgId);
    return createResponse(result);
  }

  @Get('employees/:id')
  @ApiOperation({ summary: 'Get employee by ID' })
  async findOneEmployee(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.resourceService.findOneEmployee(id);
    return createResponse(result);
  }

  @Put('employees/:id')
  @ApiOperation({ summary: 'Update employee' })
  @Roles('admin', 'resource_manager')
  async updateEmployee(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateEmployeeDto) {
    const result = await this.resourceService.updateEmployee(id, dto);
    return createResponse(result, 'Employee updated');
  }

  @Delete('employees/:id')
  @ApiOperation({ summary: 'Delete employee (soft delete)' })
  @Roles('admin', 'resource_manager')
  async removeEmployee(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.resourceService.removeEmployee(id);
    return createResponse(result);
  }

  @Post('employees/:id/assign')
  @ApiOperation({ summary: 'Assign employee to a project' })
  @Roles('admin', 'resource_manager')
  async assignEmployee(@Param('id', ParseUUIDPipe) id: string, @Body() body: { projectId: string; role: string; allocation?: number }) {
    const result = await this.resourceService.assignEmployee(id, body);
    return createResponse(result, 'Employee assigned to project');
  }

  // ── Teams ──

  @Post('teams')
  @ApiOperation({ summary: 'Create a team' })
  @Roles('admin', 'resource_manager')
  async createTeam(@Body() dto: CreateTeamDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.resourceService.createTeam(dto);
    return createResponse(result, 'Team created');
  }

  @Get('teams')
  @ApiOperation({ summary: 'List all teams' })
  async findAllTeams(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string) {
    const result = await this.resourceService.findAllTeams(orgId, pagination);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('teams/:id')
  @ApiOperation({ summary: 'Get team by ID' })
  async findOneTeam(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.resourceService.findOneTeam(id);
    return createResponse(result);
  }

  @Put('teams/:id')
  @ApiOperation({ summary: 'Update team' })
  @Roles('admin', 'resource_manager')
  async updateTeam(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateTeamDto) {
    const result = await this.resourceService.updateTeam(id, dto);
    return createResponse(result, 'Team updated');
  }

  @Delete('teams/:id')
  @ApiOperation({ summary: 'Delete team (soft delete)' })
  @Roles('admin', 'resource_manager')
  async removeTeam(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.resourceService.removeTeam(id);
    return createResponse(result);
  }

  @Post('teams/:id/members')
  @ApiOperation({ summary: 'Add members to a team' })
  @Roles('admin', 'resource_manager')
  async addTeamMembers(@Param('id', ParseUUIDPipe) id: string, @Body() dto: AssignTeamDto) {
    const result = await this.resourceService.addTeamMembers(id, dto);
    return createResponse(result, 'Team members added');
  }

  // ── AI Recommendation ──

  @Post('recommend')
  @ApiOperation({ summary: 'AI resource recommendation for a project' })
  async recommend(@Body() body: { projectId: string; requiredSkills?: string[]; requiredCount?: number }) {
    const result = await this.resourceService.recommendResources(body);
    return createResponse(result, 'Resource recommendations generated');
  }
}
