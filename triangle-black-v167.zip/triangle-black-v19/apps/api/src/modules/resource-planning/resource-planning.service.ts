import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateEmployeeDto, CreateTeamDto, AssignTeamDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class ResourcePlanningService {
  private readonly logger = new Logger(ResourcePlanningService.name);

  constructor(private readonly prisma: PrismaService) {}

  // ── Employees ──

  async createEmployee(dto: CreateEmployeeDto) {
    return this.prisma.employee.create({
      data: {
        organizationId: dto.organizationId,
        firstName: dto.firstName,
        lastName: dto.lastName,
        email: dto.email,
        phone: dto.phone,
        department: dto.department,
        position: dto.position,
        skills: dto.skills,
        maxAllocation: dto.maxAllocation ?? 100,
        hourlyRate: dto.hourlyRate,
      },
    });
  }

  async findAllEmployees(organizationId: string, pagination: PaginationDto, filters?: { skill?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId, deletedAt: null };
    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (filters?.skill) {
      where.skills = { has: filters.skill };
    }

    const [data, total] = await Promise.all([
      this.prisma.employee.findMany({
        where, skip, take,
        orderBy: { [sortBy]: sortOrder },
        include: { assignments: { where: { active: true }, include: { project: true } } },
      }),
      this.prisma.employee.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async getAvailability(organizationId: string) {
    const employees = await this.prisma.employee.findMany({
      where: { organizationId, deletedAt: null },
      include: { assignments: { where: { active: true } } },
    });

    return employees.map((emp) => {
      const totalAllocation = emp.assignments.reduce((sum, a) => sum + (a.allocation || 100), 0);
      const availableAllocation = Math.max(0, (emp.maxAllocation || 100) - totalAllocation);
      const utilization = emp.maxAllocation ? Math.round((totalAllocation / emp.maxAllocation) * 100) : 0;
      return {
        id: emp.id,
        firstName: emp.firstName,
        lastName: emp.lastName,
        position: emp.position,
        department: emp.department,
        skills: emp.skills,
        currentAllocation: totalAllocation,
        maxAllocation: emp.maxAllocation || 100,
        availableAllocation,
        utilization,
        activeAssignments: emp.assignments.length,
      };
    });
  }

  async findOneEmployee(id: string) {
    const employee = await this.prisma.employee.findFirst({
      where: { id, deletedAt: null },
      include: {
        assignments: { include: { project: true } },
        teams: { include: { team: true } },
      },
    });
    if (!employee) throw new NotFoundException('Employee not found');
    return employee;
  }

  async updateEmployee(id: string, dto: CreateEmployeeDto) {
    const employee = await this.prisma.employee.findFirst({ where: { id, deletedAt: null } });
    if (!employee) throw new NotFoundException('Employee not found');

    return this.prisma.employee.update({
      where: { id },
      data: {
        firstName: dto.firstName,
        lastName: dto.lastName,
        email: dto.email,
        phone: dto.phone,
        department: dto.department,
        position: dto.position,
        skills: dto.skills,
        maxAllocation: dto.maxAllocation,
        hourlyRate: dto.hourlyRate,
      },
    });
  }

  async removeEmployee(id: string) {
    const employee = await this.prisma.employee.findFirst({ where: { id, deletedAt: null } });
    if (!employee) throw new NotFoundException('Employee not found');

    await this.prisma.employee.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    return { success: true, message: 'Employee deleted' };
  }

  async assignEmployee(id: string, body: { projectId: string; role: string; allocation?: number }) {
    const employee = await this.prisma.employee.findFirst({ where: { id, deletedAt: null } });
    if (!employee) throw new NotFoundException('Employee not found');

    return this.prisma.employeeAssignment.create({
      data: {
        employeeId: id,
        projectId: body.projectId,
        role: body.role,
        allocation: body.allocation ?? 100,
        active: true,
        assignedAt: new Date(),
      },
      include: { project: true, employee: true },
    });
  }

  // ── Teams ──

  async createTeam(dto: CreateTeamDto) {
    return this.prisma.team.create({
      data: {
        organizationId: dto.organizationId,
        name: dto.name,
        description: dto.description,
        department: dto.department,
      },
    });
  }

  async findAllTeams(organizationId: string, pagination: PaginationDto) {
    const { page, limit, sortBy, sortOrder } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId, deletedAt: null };

    const [data, total] = await Promise.all([
      this.prisma.team.findMany({
        where, skip, take,
        orderBy: { [sortBy]: sortOrder },
        include: { members: { include: { employee: true } } },
      }),
      this.prisma.team.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOneTeam(id: string) {
    const team = await this.prisma.team.findFirst({
      where: { id, deletedAt: null },
      include: { members: { include: { employee: true } } },
    });
    if (!team) throw new NotFoundException('Team not found');
    return team;
  }

  async updateTeam(id: string, dto: CreateTeamDto) {
    const team = await this.prisma.team.findFirst({ where: { id, deletedAt: null } });
    if (!team) throw new NotFoundException('Team not found');

    return this.prisma.team.update({
      where: { id },
      data: {
        name: dto.name,
        description: dto.description,
        department: dto.department,
      },
    });
  }

  async removeTeam(id: string) {
    const team = await this.prisma.team.findFirst({ where: { id, deletedAt: null } });
    if (!team) throw new NotFoundException('Team not found');

    await this.prisma.team.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    return { success: true, message: 'Team deleted' };
  }

  async addTeamMembers(id: string, dto: AssignTeamDto) {
    const team = await this.prisma.team.findFirst({ where: { id, deletedAt: null } });
    if (!team) throw new NotFoundException('Team not found');

    await this.prisma.teamMember.createMany({
      data: dto.employeeIds.map((employeeId) => ({
        teamId: id,
        employeeId,
        role: dto.role,
      })),
      skipDuplicates: true,
    });

    return this.prisma.team.findFirst({
      where: { id },
      include: { members: { include: { employee: true } } },
    });
  }

  // ── AI Recommendation ──

  async recommendResources(body: { projectId: string; requiredSkills?: string[]; requiredCount?: number }) {
    const project = await this.prisma.project.findUnique({ where: { id: body.projectId } });
    if (!project) throw new NotFoundException('Project not found');

    const existingAssignments = await this.prisma.employeeAssignment.findMany({
      where: { projectId: body.projectId, active: true },
      select: { employeeId: true },
    });
    const assignedIds = new Set(existingAssignments.map((a) => a.employeeId));

    const allEmployees = await this.prisma.employee.findMany({
      where: {
        organizationId: project.organizationId,
        deletedAt: null,
        id: { notIn: [...assignedIds] },
      },
      include: { assignments: { where: { active: true } } },
    });

    let candidates = allEmployees.map((emp) => {
      const totalAllocation = emp.assignments.reduce((sum, a) => sum + (a.allocation || 100), 0);
      const available = Math.max(0, (emp.maxAllocation || 100) - totalAllocation);
      return {
        id: emp.id,
        firstName: emp.firstName,
        lastName: emp.lastName,
        position: emp.position,
        department: emp.department,
        skills: emp.skills,
        availableAllocation: available,
        currentAllocation: totalAllocation,
        matchScore: this.calculateMatchScore(emp.skills, body.requiredSkills || []),
      };
    });

    if (body.requiredSkills && body.requiredSkills.length > 0) {
      candidates = candidates
        .filter((c) => c.matchScore > 0)
        .sort((a, b) => b.matchScore - a.matchScore);
    } else {
      candidates = candidates.sort((a, b) => b.availableAllocation - a.availableAllocation);
    }

    return candidates.slice(0, body.requiredCount || 5);
  }

  private calculateMatchScore(employeeSkills: string[], requiredSkills: string[]): number {
    if (!employeeSkills || requiredSkills.length === 0) return 0;
    const empSkillsLower = employeeSkills.map((s) => s.toLowerCase());
    let matched = 0;
    for (const skill of requiredSkills) {
      if (empSkillsLower.some((s) => s.includes(skill.toLowerCase()))) matched++;
    }
    return Math.round((matched / requiredSkills.length) * 100);
  }
}
