import {
  IsString, IsOptional, IsUUID, IsNumber, IsEnum, IsArray, IsDateString, ValidateNested,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

class RfqItemInput {
  @ApiProperty()
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty()
  @Type(() => Number)
  @IsNumber()
  quantity: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  unit?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  specification?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  estimatedBudget?: number;
}

class RfqResponseLineItemInput {
  @ApiProperty()
  @IsUUID()
  rfqItemId: string;

  @ApiProperty()
  @Type(() => Number)
  @IsNumber()
  unitPrice: number;

  @ApiProperty()
  @Type(() => Number)
  @IsNumber()
  totalPrice: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}

export class CreateRfqDto {
  @ApiProperty()
  @IsUUID()
  organizationId: string;

  @ApiProperty()
  @IsString()
  title: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty()
  @IsDateString()
  deadline: string;

  @ApiPropertyOptional({ default: 'SAR' })
  @IsOptional()
  @IsString()
  currency?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => RfqItemInput)
  items?: RfqItemInput[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @IsUUID('4', { each: true })
  vendorIds?: string[];
}

export class CreateRfqResponseDto {
  @ApiProperty()
  @IsUUID()
  vendorId: string;

  @ApiProperty()
  @IsUUID()
  organizationId: string;

  @ApiProperty()
  @Type(() => Number)
  @IsNumber()
  totalPrice: number;

  @ApiPropertyOptional({ default: 'SAR' })
  @IsOptional()
  @IsString()
  currency?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  validityDays?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  deliveryDays?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => RfqResponseLineItemInput)
  lineItems?: RfqResponseLineItemInput[];
}

export class EvaluateRfqDto {
  @ApiProperty()
  @Type(() => Number)
  @IsNumber()
  score: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;
}
