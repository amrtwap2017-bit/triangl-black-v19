import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { RfqService } from './rfq.service';
import { CreateRfqDto, CreateRfqResponseDto, EvaluateRfqDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('RFQ Management')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('rfqs')
export class RfqController {
  constructor(private readonly rfqService: RfqService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new RFQ' })
  @Roles('admin', 'procurement_manager')
  async create(@Body() dto: CreateRfqDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.rfqService.create(dto);
    return createResponse(result, 'RFQ created');
  }

  @Get()
  @ApiOperation({ summary: 'List all RFQs' })
  async findAll(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string, @Query('status') status?: string) {
    const result = await this.rfqService.findAll(orgId, pagination, { status });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get RFQ by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.rfqService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update RFQ' })
  @Roles('admin', 'procurement_manager')
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateRfqDto) {
    const result = await this.rfqService.update(id, dto);
    return createResponse(result, 'RFQ updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete RFQ (soft delete)' })
  @Roles('admin', 'procurement_manager')
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.rfqService.remove(id);
    return createResponse(result);
  }

  @Post(':id/publish')
  @ApiOperation({ summary: 'Publish an RFQ' })
  @Roles('admin', 'procurement_manager')
  async publish(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.rfqService.publish(id);
    return createResponse(result, 'RFQ published');
  }

  @Post(':id/close')
  @ApiOperation({ summary: 'Close an RFQ' })
  @Roles('admin', 'procurement_manager')
  async close(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.rfqService.close(id);
    return createResponse(result, 'RFQ closed');
  }

  @Post(':id/responses')
  @ApiOperation({ summary: 'Submit a response to an RFQ' })
  async submitResponse(@Param('id', ParseUUIDPipe) id: string, @Body() dto: CreateRfqResponseDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.rfqService.submitResponse(id, dto);
    return createResponse(result, 'RFQ response submitted');
  }

  @Get(':id/responses')
  @ApiOperation({ summary: 'Get all responses for an RFQ' })
  async getResponses(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.rfqService.getResponses(id);
    return createResponse(result);
  }

  @Post(':id/responses/:responseId/evaluate')
  @ApiOperation({ summary: 'Evaluate an RFQ response' })
  @Roles('admin', 'procurement_manager')
  async evaluateResponse(
    @Param('id', ParseUUIDPipe) id: string,
    @Param('responseId', ParseUUIDPipe) responseId: string,
    @Body() dto: EvaluateRfqDto,
  ) {
    const result = await this.rfqService.evaluateResponse(id, responseId, dto);
    return createResponse(result, 'RFQ response evaluated');
  }

  @Post(':id/award')
  @ApiOperation({ summary: 'Award an RFQ to a vendor' })
  @Roles('admin', 'procurement_manager')
  async award(@Param('id', ParseUUIDPipe) id: string, @Body() body: { vendorId: string; responseId: string; notes?: string }) {
    const result = await this.rfqService.award(id, body);
    return createResponse(result, 'RFQ awarded');
  }
}
