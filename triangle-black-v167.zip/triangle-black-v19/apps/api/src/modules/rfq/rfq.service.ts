import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateRfqDto, CreateRfqResponseDto, EvaluateRfqDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../common/utils';

@Injectable()
export class RfqService {
  private readonly logger = new Logger(RfqService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateRfqDto) {
    const rfqNumber = generateSequentialNumber('RFQ');
    return this.prisma.rfq.create({
      data: {
        rfqNumber,
        title: dto.title,
        description: dto.description,
        deadline: new Date(dto.deadline),
        currency: dto.currency,
        organizationId: dto.organizationId,
        status: 'DRAFT',
        items: dto.items
          ? {
              create: dto.items.map((item) => ({
                name: item.name,
                description: item.description,
                quantity: item.quantity,
                unit: item.unit,
                specification: item.specification,
                estimatedBudget: item.estimatedBudget,
              })),
            }
          : undefined,
        invitedVendors: dto.vendorIds
          ? {
              create: dto.vendorIds.map((vendorId) => ({ vendorId })),
            }
          : undefined,
      },
      include: { items: true, invitedVendors: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId, deletedAt: null };
    if (search) where.title = { contains: search, mode: 'insensitive' };
    if (filters?.status) where.status = filters.status;

    const [data, total] = await Promise.all([
      this.prisma.rfq.findMany({
        where,
        skip,
        take,
        orderBy: { [sortBy]: sortOrder },
        include: { items: true, responses: true, invitedVendors: true },
      }),
      this.prisma.rfq.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const rfq = await this.prisma.rfq.findFirst({
      where: { id, deletedAt: null },
      include: { items: true, responses: true, invitedVendors: true },
    });
    if (!rfq) throw new NotFoundException('RFQ not found');
    return rfq;
  }

  async update(id: string, dto: CreateRfqDto) {
    const rfq = await this.prisma.rfq.findFirst({ where: { id, deletedAt: null } });
    if (!rfq) throw new NotFoundException('RFQ not found');
    if (rfq.status !== 'DRAFT') throw new BadRequestException('Only DRAFT RFQs can be updated');

    return this.prisma.rfq.update({
      where: { id },
      data: {
        title: dto.title,
        description: dto.description,
        deadline: new Date(dto.deadline),
        currency: dto.currency,
      },
      include: { items: true, invitedVendors: true },
    });
  }

  async remove(id: string) {
    const rfq = await this.prisma.rfq.findFirst({ where: { id, deletedAt: null } });
    if (!rfq) throw new NotFoundException('RFQ not found');

    await this.prisma.rfq.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    return { success: true, message: 'RFQ deleted' };
  }

  async publish(id: string) {
    const rfq = await this.prisma.rfq.findFirst({ where: { id, deletedAt: null } });
    if (!rfq) throw new NotFoundException('RFQ not found');
    if (rfq.status !== 'DRAFT') throw new BadRequestException('Only DRAFT RFQs can be published');

    return this.prisma.rfq.update({
      where: { id },
      data: { status: 'PUBLISHED', publishedAt: new Date() },
      include: { items: true, invitedVendors: true },
    });
  }

  async close(id: string) {
    const rfq = await this.prisma.rfq.findFirst({ where: { id, deletedAt: null } });
    if (!rfq) throw new NotFoundException('RFQ not found');
    if (rfq.status !== 'PUBLISHED') throw new BadRequestException('Only PUBLISHED RFQs can be closed');

    return this.prisma.rfq.update({
      where: { id },
      data: { status: 'CLOSED', closedAt: new Date() },
      include: { items: true, responses: true },
    });
  }

  async submitResponse(rfqId: string, dto: CreateRfqResponseDto) {
    const rfq = await this.prisma.rfq.findFirst({ where: { id: rfqId, deletedAt: null } });
    if (!rfq) throw new NotFoundException('RFQ not found');
    if (rfq.status !== 'PUBLISHED') throw new BadRequestException('Can only respond to PUBLISHED RFQs');
    if (rfq.deadline < new Date()) throw new BadRequestException('RFQ deadline has passed');

    return this.prisma.rfqResponse.create({
      data: {
        rfqId,
        vendorId: dto.vendorId,
        organizationId: dto.organizationId,
        totalPrice: dto.totalPrice,
        currency: dto.currency,
        validityDays: dto.validityDays,
        deliveryDays: dto.deliveryDays,
        notes: dto.notes,
        lineItems: dto.lineItems
          ? {
              create: dto.lineItems.map((item) => ({
                rfqItemId: item.rfqItemId,
                unitPrice: item.unitPrice,
                totalPrice: item.totalPrice,
                notes: item.notes,
              })),
            }
          : undefined,
      },
      include: { lineItems: true },
    });
  }

  async getResponses(rfqId: string) {
    const rfq = await this.prisma.rfq.findFirst({ where: { id: rfqId, deletedAt: null } });
    if (!rfq) throw new NotFoundException('RFQ not found');

    return this.prisma.rfqResponse.findMany({
      where: { rfqId },
      include: { lineItems: true, vendor: true },
    });
  }

  async evaluateResponse(rfqId: string, responseId: string, dto: EvaluateRfqDto) {
    const rfq = await this.prisma.rfq.findFirst({ where: { id: rfqId, deletedAt: null } });
    if (!rfq) throw new NotFoundException('RFQ not found');

    const response = await this.prisma.rfqResponse.findFirst({
      where: { id: responseId, rfqId },
    });
    if (!response) throw new NotFoundException('RFQ response not found');

    return this.prisma.rfqResponse.update({
      where: { id: responseId },
      data: {
        score: dto.score,
        evaluationNotes: dto.notes,
        evaluatedAt: new Date(),
      },
      include: { lineItems: true, vendor: true },
    });
  }

  async award(rfqId: string, body: { vendorId: string; responseId: string; notes?: string }) {
    const rfq = await this.prisma.rfq.findFirst({ where: { id: rfqId, deletedAt: null } });
    if (!rfq) throw new NotFoundException('RFQ not found');
    if (rfq.status !== 'PUBLISHED' && rfq.status !== 'CLOSED') {
      throw new BadRequestException('RFQ must be PUBLISHED or CLOSED to award');
    }

    return this.prisma.rfq.update({
      where: { id: rfqId },
      data: {
        status: 'AWARDED',
        awardedToId: body.vendorId,
        awardedResponseId: body.responseId,
        awardedAt: new Date(),
        awardNotes: body.notes,
      },
      include: { items: true, responses: true, invitedVendors: true },
    });
  }
}
