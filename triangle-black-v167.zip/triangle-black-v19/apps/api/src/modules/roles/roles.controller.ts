import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { RolesService } from './roles.service';
import { CreateRoleDto, UpdateRoleDto, AssignPermissionsDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Roles')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('roles')
export class RolesController {
  constructor(private readonly rolesService: RolesService) {}

  @Post()
  @ApiOperation({ summary: 'Create a role' })
  async create(@Body() dto: CreateRoleDto) {
    const result = await this.rolesService.create(dto);
    return createResponse(result, 'Role created');
  }

  @Get()
  @ApiOperation({ summary: 'List all roles' })
  async findAll(@Query() pagination: PaginationDto, @Query('organizationId') organizationId?: string) {
    const result = await this.rolesService.findAll(pagination, organizationId);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get role by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.rolesService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update role' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateRoleDto) {
    const result = await this.rolesService.update(id, dto);
    return createResponse(result, 'Role updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete role' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.rolesService.remove(id);
    return createResponse(result);
  }

  @Post(':id/permissions')
  @ApiOperation({ summary: 'Assign permissions to role' })
  async assignPermissions(@Param('id', ParseUUIDPipe) id: string, @Body() dto: AssignPermissionsDto) {
    const result = await this.rolesService.assignPermissions(id, dto.permissionIds);
    return createResponse(result);
  }

  @Get(':id/permissions')
  @ApiOperation({ summary: 'Get role permissions' })
  async getPermissions(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.rolesService.getPermissions(id);
    return createResponse(result);
  }
}
