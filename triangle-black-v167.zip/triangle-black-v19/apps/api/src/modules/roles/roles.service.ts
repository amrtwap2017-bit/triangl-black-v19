import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { CreateRoleDto, UpdateRoleDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class RolesService {
  private readonly logger = new Logger(RolesService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateRoleDto) {
    return this.prisma.role.create({ data: dto });
  }

  async findAll(pagination: PaginationDto, organizationId?: string) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = {};
    if (organizationId) where.organizationId = organizationId;
    if (search) where.name = { contains: search, mode: 'insensitive' };

    const [data, total] = await Promise.all([
      this.prisma.role.findMany({
        where, skip, take,
        orderBy: { [sortBy]: sortOrder },
        include: { rolePermissions: { include: { permission: true } }, _count: { select: { userRoles: true } } },
      }),
      this.prisma.role.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const role = await this.prisma.role.findUnique({
      where: { id },
      include: { rolePermissions: { include: { permission: true } }, _count: { select: { userRoles: true } } },
    });
    if (!role) throw new NotFoundException('Role not found');
    return role;
  }

  async update(id: string, dto: UpdateRoleDto) {
    try {
      return this.prisma.role.update({ where: { id }, data: dto });
    } catch {
      throw new NotFoundException('Role not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.role.delete({ where: { id } });
      return { success: true, message: 'Role deleted' };
    } catch {
      throw new NotFoundException('Role not found');
    }
  }

  async assignPermissions(roleId: string, permissionIds: string[]) {
    const role = await this.prisma.role.findUnique({ where: { id: roleId } });
    if (!role) throw new NotFoundException('Role not found');

    await this.prisma.rolePermission.deleteMany({ where: { roleId } });
    const data = permissionIds.map((permissionId) => ({ roleId, permissionId }));
    await this.prisma.rolePermission.createMany({ data });
    return { success: true, message: 'Permissions assigned' };
  }

  async getPermissions(roleId: string) {
    const rolePermissions = await this.prisma.rolePermission.findMany({
      where: { roleId },
      include: { permission: true },
    });
    return rolePermissions.map((rp) => rp.permission);
  }
}
