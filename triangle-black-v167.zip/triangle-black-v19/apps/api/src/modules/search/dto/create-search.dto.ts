import { IsString, IsOptional, IsEnum, IsInt, Min } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class GlobalSearchDto {
  @ApiProperty()
  @IsString()
  q: string;

  @ApiPropertyOptional({ enum: ['all', 'hotels', 'contacts', 'opportunities', 'projects', 'vendors', 'documents', 'proposals', 'knowledge'], default: 'all' })
  @IsOptional()
  @IsEnum(['all', 'hotels', 'contacts', 'opportunities', 'projects', 'vendors', 'documents', 'proposals', 'knowledge'])
  scope?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  afterId?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number;
}

export interface SearchResultItem {
  type: string;
  id: string;
  title: string;
  subtitle?: string;
  matchedField: string;
}
