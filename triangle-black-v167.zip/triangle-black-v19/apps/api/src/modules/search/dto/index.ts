export { GlobalSearchDto, SearchResultItem } from './create-search.dto';
