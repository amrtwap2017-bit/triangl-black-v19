import { Controller, Get, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { SearchService } from './search.service';
import { GlobalSearchDto } from './dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Search')
@ApiBearerAuth()
@Controller('search')
export class SearchController {
  constructor(private readonly service: SearchService) {}

  @Get()
  @ApiOperation({ summary: 'Global search across all entities' })
  async search(
    @Query() dto: GlobalSearchDto,
    @CurrentUser('organizationId') orgId: string,
  ) {
    const result = await this.service.search(orgId, dto);
    return createResponse(result);
  }
}
