import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { GlobalSearchDto, SearchResultItem } from './dto';

@Injectable()
export class SearchService {
  private readonly logger = new Logger(SearchService.name);

  constructor(private readonly prisma: PrismaService) {}

  async search(organizationId: string, dto: GlobalSearchDto): Promise<{ results: SearchResultItem[]; total: number }> {
    const { q, scope, afterId, limit = 20 } = dto;
    const scopeList = scope === 'all'
      ? ['hotels', 'contacts', 'opportunities', 'projects', 'vendors', 'documents', 'proposals', 'knowledge']
      : [scope!];

    let results: SearchResultItem[] = [];
    let total = 0;

    for (const s of scopeList) {
      const items = await this.searchScope(organizationId, s, q, afterId, limit);
      results.push(...items);
    }

    // Sort by relevance (simple: match position in title)
    results.sort((a, b) => {
      const aIdx = a.title.toLowerCase().indexOf(q.toLowerCase());
      const bIdx = b.title.toLowerCase().indexOf(q.toLowerCase());
      if (aIdx >= 0 && bIdx >= 0) return aIdx - bIdx;
      if (aIdx >= 0) return -1;
      if (bIdx >= 0) return 1;
      return 0;
    });

    total = results.length;
    results = results.slice(0, limit);

    return { results, total };
  }

  private async searchScope(orgId: string, scope: string, q: string, afterId?: string, limit?: number): Promise<SearchResultItem[]> {
    const take = limit ?? 20;
    const commonWhere: any = {
      OR: [],
    };

    switch (scope) {
      case 'hotels':
        return (await this.prisma.hotel.findMany({
          where: {
            organizationId: orgId,
            deletedAt: null,
            OR: [
              { name: { contains: q, mode: 'insensitive' } },
              { city: { contains: q, mode: 'insensitive' } },
            ],
          },
          take,
          orderBy: { name: 'ASC' },
          select: { id: true, name: true, city: true, starRating: true },
        })).map((h) => ({
          type: 'hotels', id: h.id, title: h.name,
          subtitle: `${h.city || ''} ${h.starRating ? `★${h.starRating}` : ''}`.trim(),
          matchedField: 'name',
        }));

      case 'contacts':
        return (await this.prisma.hotelContact.findMany({
          where: {
            hotel: { organizationId: orgId },
            OR: [
              { firstName: { contains: q, mode: 'insensitive' } },
              { lastName: { contains: q, mode: 'insensitive' } },
              { email: { contains: q, mode: 'insensitive' } },
            ],
          },
          take,
          orderBy: { firstName: 'ASC' },
          select: { id: true, firstName: true, lastName: true, position: true, hotelId: true },
        })).map((c) => ({
          type: 'contacts', id: c.id,
          title: `${c.firstName} ${c.lastName}`,
          subtitle: c.position || '',
          matchedField: 'name',
        }));

      case 'opportunities':
        return (await this.prisma.opportunity.findMany({
          where: {
            organizationId: orgId,
            deletedAt: null,
            OR: [
              { title: { contains: q, mode: 'insensitive' } },
              { description: { contains: q, mode: 'insensitive' } },
            ],
          },
          take,
          orderBy: { createdAt: 'DESC' },
          select: { id: true, title: true, status: true, value: true },
        })).map((o) => ({
          type: 'opportunities', id: o.id, title: o.title,
          subtitle: `${o.status} ${o.value ? `| ${o.value} SAR` : ''}`,
          matchedField: 'title',
        }));

      case 'projects':
        return (await this.prisma.project.findMany({
          where: {
            organizationId: orgId,
            deletedAt: null,
            OR: [
              { name: { contains: q, mode: 'insensitive' } },
              { projectNumber: { contains: q, mode: 'insensitive' } },
              { description: { contains: q, mode: 'insensitive' } },
            ],
          },
          take,
          orderBy: { createdAt: 'DESC' },
          select: { id: true, name: true, status: true, type: true },
        })).map((p) => ({
          type: 'projects', id: p.id, title: p.name,
          subtitle: `${p.status} | ${p.type || 'N/A'}`,
          matchedField: 'name',
        }));

      case 'vendors':
        return (await this.prisma.vendor.findMany({
          where: {
            organizationId: orgId,
            deletedAt: null,
            OR: [
              { name: { contains: q, mode: 'insensitive' } },
              { category: { contains: q, mode: 'insensitive' } },
            ],
          },
          take,
          orderBy: { name: 'ASC' },
          select: { id: true, name: true, category: true },
        })).map((v) => ({
          type: 'vendors', id: v.id, title: v.name,
          subtitle: v.category || '',
          matchedField: 'name',
        }));

      case 'documents':
        return (await this.prisma.document.findMany({
          where: {
            organizationId: orgId,
            deletedAt: null,
            OR: [
              { title: { contains: q, mode: 'insensitive' } },
              { category: { contains: q, mode: 'insensitive' } },
            ],
          },
          take,
          orderBy: { createdAt: 'DESC' },
          select: { id: true, title: true, category: true, mimeType: true },
        })).map((d) => ({
          type: 'documents', id: d.id, title: d.title,
          subtitle: d.category || '',
          matchedField: 'title',
        }));

      case 'proposals':
        return (await this.prisma.proposal.findMany({
          where: {
            organizationId: orgId,
            deletedAt: null,
            OR: [
              { title: { contains: q, mode: 'insensitive' } },
              { proposalNumber: { contains: q, mode: 'insensitive' } },
            ],
          },
          take,
          orderBy: { createdAt: 'DESC' },
          select: { id: true, title: true, status: true, totalValue: true },
        })).map((p) => ({
          type: 'proposals', id: p.id, title: p.title,
          subtitle: `${p.status} ${p.totalValue ? `| ${p.totalValue} SAR` : ''}`,
          matchedField: 'title',
        }));

      case 'knowledge':
        return (await this.prisma.knowledgeArticle.findMany({
          where: {
            organizationId: orgId,
            deletedAt: null,
            OR: [
              { title: { contains: q, mode: 'insensitive' } },
              { content: { contains: q, mode: 'insensitive' } },
            ],
          },
          take,
          orderBy: { createdAt: 'DESC' },
          select: { id: true, title: true, category: true },
        })).map((k) => ({
          type: 'knowledge', id: k.id, title: k.title,
          subtitle: k.category,
          matchedField: 'title',
        }));

      default:
        return [];
    }
  }

  /**
   * Global search across all major domains: hotels, contacts, opportunities, projects,
   * vendors, documents, proposals, knowledge articles, drawings, and assets.
   */
  async globalSearch(
    organizationId: string,
    query: string,
    filters?: { scopes?: string[]; limit?: number; offset?: string },
  ): Promise<{ results: SearchResultItem[]; total: number; facets: { scope: string; count: number }[] }> {
    const limit = filters?.limit || 30;
    const scopes = filters?.scopes || [
      'hotels', 'contacts', 'opportunities', 'projects', 'vendors',
      'documents', 'proposals', 'knowledge', 'drawings', 'assets',
    ];

    let results: SearchResultItem[] = [];

    for (const scope of scopes) {
      try {
        const items = await this.searchScope(organizationId, scope, query, undefined, limit);
        results.push(...items);
      } catch {
        // Silently skip unsupported scopes
      }
    }

    // Sort by relevance: title match position, then alphabetically
    const qLower = query.toLowerCase();
    results.sort((a, b) => {
      const aIdx = a.title.toLowerCase().indexOf(qLower);
      const bIdx = b.title.toLowerCase().indexOf(qLower);
      if (aIdx >= 0 && bIdx >= 0) return aIdx - bIdx;
      if (aIdx >= 0) return -1;
      if (bIdx >= 0) return 1;
      return a.title.localeCompare(b.title);
    });

    const total = results.length;

    // Compute facets (count per scope)
    const facetMap = new Map<string, number>();
    for (const r of results) {
      facetMap.set(r.type, (facetMap.get(r.type) || 0) + 1);
    }
    const facets = Array.from(facetMap.entries()).map(([scope, count]) => ({ scope, count })).sort((a, b) => b.count - a.count);

    results = results.slice(0, limit);

    return { results, total, facets };
  }

  /**
   * Autocomplete suggestions based on prefix matching across entities.
   */
  async getSearchSuggestions(query: string, organizationId?: string, limit: number = 10): Promise<{
    suggestions: { type: string; text: string; id: string }[];
  }> {
    if (!query || query.length < 2) return { suggestions: [] };

    const suggestions: { type: string; text: string; id: string }[] = [];

    // Search hotels
    try {
      const hotels = await this.prisma.hotel.findMany({
        where: {
          ...(organizationId ? { organizationId, deletedAt: null } : {}),
          name: { startsWith: query, mode: 'insensitive' },
        },
        take: limit,
        select: { id: true, name: true },
      });
      for (const h of hotels) {
        suggestions.push({ type: 'hotel', text: h.name, id: h.id });
      }
    } catch { /* skip */ }

    // Search projects
    try {
      const projects = await this.prisma.project.findMany({
        where: {
          ...(organizationId ? { organizationId, deletedAt: null } : {}),
          name: { startsWith: query, mode: 'insensitive' },
        },
        take: limit,
        select: { id: true, name: true },
      });
      for (const p of projects) {
        suggestions.push({ type: 'project', text: p.name, id: p.id });
      }
    } catch { /* skip */ }

    // Search vendors
    try {
      const vendors = await this.prisma.vendor.findMany({
        where: {
          ...(organizationId ? { organizationId, deletedAt: null } : {}),
          name: { startsWith: query, mode: 'insensitive' },
        },
        take: limit,
        select: { id: true, name: true },
      });
      for (const v of vendors) {
        suggestions.push({ type: 'vendor', text: v.name, id: v.id });
      }
    } catch { /* skip */ }

    // Search knowledge articles
    try {
      const articles = await this.prisma.knowledgeArticle.findMany({
        where: {
          ...(organizationId ? { organizationId, deletedAt: null } : {}),
          title: { startsWith: query, mode: 'insensitive' },
        },
        take: limit,
        select: { id: true, title: true },
      });
      for (const a of articles) {
        suggestions.push({ type: 'knowledge', text: a.title, id: a.id });
      }
    } catch { /* skip */ }

    return {
      suggestions: suggestions.slice(0, limit),
    };
  }

  /**
   * Get recent searches for a user. Uses a simple in-memory/prisma approach.
   */
  async getRecentSearches(userId: string, organizationId: string, limit: number = 10): Promise<{
    recentSearches: { query: string; timestamp: string; resultCount: number }[];
  }> {
    // Query recent search activity from a searchHistory table if available,
    // otherwise return empty (placeholder for search analytics integration)
    try {
      const recentSearches = await this.prisma.searchHistory.findMany({
        where: { userId, organizationId },
        orderBy: { createdAt: 'DESC' },
        take: limit,
        select: { query: true, createdAt: true, resultCount: true },
      });

      return {
        recentSearches: recentSearches.map((s) => ({
          query: s.query,
          timestamp: s.createdAt.toISOString(),
          resultCount: s.resultCount || 0,
        })),
      };
    } catch {
      // searchHistory table may not exist yet
      return { recentSearches: [] };
    }
  }
}
