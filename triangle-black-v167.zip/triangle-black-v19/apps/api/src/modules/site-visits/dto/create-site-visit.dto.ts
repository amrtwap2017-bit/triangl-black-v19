import { IsString, IsOptional, IsUUID, IsDateString, IsEnum, IsObject, IsArray } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateSiteVisitDto {
  @ApiProperty()
  @IsUUID()
  organizationId: string;

  @ApiProperty()
  @IsUUID()
  hotelId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  partnerRequestId?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  scheduledDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  assignedToId?: string;

  @ApiPropertyOptional({ enum: ['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'] })
  @IsOptional()
  @IsEnum(['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'])
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  findings?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  photos?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  drawings?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  voiceNotes?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  scopeDraft?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  opportunityDraft?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  riskSummary?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: any;
}

export class UpdateSiteVisitDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  scheduledDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  assignedToId?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['SCHEDULED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'])
  status?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  findings?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  photos?: any[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  opportunityDraft?: any;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  riskSummary?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsObject()
  metadata?: any;
}
