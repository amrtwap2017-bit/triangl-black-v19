import { Injectable, NotFoundException, Logger, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { CreateSiteVisitDto, UpdateSiteVisitDto } from '../dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../../common/utils';

@Injectable()
export class SiteVisitsService {
  private readonly logger = new Logger(SiteVisitsService.name);

  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateSiteVisitDto) {
    const visitNumber = generateSequentialNumber('SV');
    return this.prisma.siteVisit.create({
      data: { ...dto, visitNumber },
      include: { hotel: true, assignedTo: true, partnerRequest: true },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { status?: string; hotelId?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId };
    if (search) {
      where.OR = [
        { visitNumber: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (filters?.status) where.status = filters.status;
    if (filters?.hotelId) where.hotelId = filters.hotelId;

    const [data, total] = await Promise.all([
      this.prisma.siteVisit.findMany({ where, skip, take, orderBy: { [sortBy]: sortOrder }, include: { hotel: true, assignedTo: true } }),
      this.prisma.siteVisit.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const visit = await this.prisma.siteVisit.findUnique({
      where: { id },
      include: { hotel: true, assignedTo: true, partnerRequest: true },
    });
    if (!visit) throw new NotFoundException('Site visit not found');
    return visit;
  }

  async update(id: string, dto: UpdateSiteVisitDto) {
    try {
      return this.prisma.siteVisit.update({ where: { id }, data: dto, include: { hotel: true, assignedTo: true } });
    } catch {
      throw new NotFoundException('Site visit not found');
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.siteVisit.delete({ where: { id } });
      return { success: true, message: 'Site visit deleted' };
    } catch {
      throw new NotFoundException('Site visit not found');
    }
  }

  async complete(id: string) {
    const visit = await this.prisma.siteVisit.findUnique({ where: { id } });
    if (!visit) throw new NotFoundException('Site visit not found');
    if (visit.status === 'COMPLETED') throw new BadRequestException('Visit already completed');

    return this.prisma.siteVisit.update({
      where: { id },
      data: { status: 'COMPLETED', completedDate: new Date() },
    });
  }

  async addPhotos(id: string, photos: any[]) {
    const visit = await this.prisma.siteVisit.findUnique({ where: { id } });
    if (!visit) throw new NotFoundException('Site visit not found');

    const currentPhotos = (visit.photos as any[]) || [];
    const updatedPhotos = [...currentPhotos, ...photos];

    return this.prisma.siteVisit.update({
      where: { id },
      data: { photos: updatedPhotos },
    });
  }

  async generateOpportunityDraft(id: string) {
    const visit = await this.prisma.siteVisit.findUnique({ where: { id }, include: { hotel: true, partnerRequest: true } });
    if (!visit) throw new NotFoundException('Site visit not found');

    // AI placeholder - generates a structured opportunity draft
    const draft = {
      title: `Opportunity from Site Visit ${visit.visitNumber} - ${visit.hotel?.name}`,
      description: `Based on site visit findings at ${visit.hotel?.name}. AI-generated draft based on visit observations.`,
      estimatedValue: null,
      suggestedScope: 'Pending detailed scope from AI analysis',
      riskLevel: 'MEDIUM',
      confidence: 0.7,
    };

    await this.prisma.siteVisit.update({
      where: { id },
      data: { opportunityDraft: draft },
    });

    return draft;
  }
}
