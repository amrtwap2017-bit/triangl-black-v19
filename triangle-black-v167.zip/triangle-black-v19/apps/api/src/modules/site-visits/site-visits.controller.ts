import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { SiteVisitsService } from './services/site-visit.service';
import { CreateSiteVisitDto, UpdateSiteVisitDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Site Visits')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('site-visits')
export class SiteVisitsController {
  constructor(private readonly siteVisitsService: SiteVisitsService) {}

  @Post()
  @ApiOperation({ summary: 'Create a site visit' })
  async create(@Body() dto: CreateSiteVisitDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.siteVisitsService.create(dto);
    return createResponse(result, 'Site visit created');
  }

  @Get()
  @ApiOperation({ summary: 'List all site visits' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('status') status?: string,
    @Query('hotelId') hotelId?: string,
  ) {
    const result = await this.siteVisitsService.findAll(orgId, pagination, { status, hotelId });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get site visit by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.siteVisitsService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update site visit' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateSiteVisitDto) {
    const result = await this.siteVisitsService.update(id, dto);
    return createResponse(result, 'Site visit updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete site visit' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.siteVisitsService.remove(id);
    return createResponse(result);
  }

  @Post(':id/complete')
  @ApiOperation({ summary: 'Mark site visit as completed' })
  async complete(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.siteVisitsService.complete(id);
    return createResponse(result, 'Site visit completed');
  }

  @Post(':id/photos')
  @ApiOperation({ summary: 'Add photos to site visit' })
  async addPhotos(@Param('id', ParseUUIDPipe) id: string, @Body('photos') photos: any[]) {
    const result = await this.siteVisitsService.addPhotos(id, photos);
    return createResponse(result, 'Photos added');
  }

  @Post(':id/generate-opportunity-draft')
  @ApiOperation({ summary: 'Generate AI opportunity draft from visit' })
  async generateOpportunityDraft(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.siteVisitsService.generateOpportunityDraft(id);
    return createResponse(result, 'Opportunity draft generated');
  }
}
