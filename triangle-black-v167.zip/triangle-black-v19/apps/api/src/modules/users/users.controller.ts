import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { CreateUserDto, UpdateUserDto, AssignRoleDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../common/dto/api-response.dto';

@ApiTags('Users')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post()
  @ApiOperation({ summary: 'Create a user' })
  async create(@Body() dto: CreateUserDto, @CurrentUser('organizationId') orgId: string) {
    dto.organizationId = orgId;
    const result = await this.usersService.create(dto);
    return createResponse(result, 'User created');
  }

  @Get()
  @ApiOperation({ summary: 'List all users in organization' })
  async findAll(@Query() pagination: PaginationDto, @CurrentUser('organizationId') orgId: string) {
    const result = await this.usersService.findAll(orgId, pagination);
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get user by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.usersService.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update user' })
  async update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateUserDto) {
    const result = await this.usersService.update(id, dto);
    return createResponse(result, 'User updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete user' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.usersService.remove(id);
    return createResponse(result);
  }

  @Post(':id/assign-role')
  @ApiOperation({ summary: 'Assign a role to user' })
  async assignRole(@Param('id', ParseUUIDPipe) id: string, @Body() dto: AssignRoleDto) {
    const result = await this.usersService.assignRole(id, dto.roleId);
    return createResponse(result);
  }

  @Get(':id/roles')
  @ApiOperation({ summary: 'Get user roles' })
  async getUserRoles(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.usersService.getUserRoles(id);
    return createResponse(result);
  }
}
