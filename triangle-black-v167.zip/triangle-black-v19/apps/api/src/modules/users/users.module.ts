import { Module } from '@nestjs/common';
import { UsersController } from './users.controller';
import { UsersService } from './users.service';
import { SecurityService } from '../../infrastructure/security/security.service';

@Module({
  controllers: [UsersController],
  providers: [UsersService, SecurityService],
  exports: [UsersService],
})
export class UsersModule {}
