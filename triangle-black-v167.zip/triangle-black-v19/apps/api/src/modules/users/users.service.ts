import { Injectable, NotFoundException, ConflictException, Logger, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';
import { SecurityService } from '../../infrastructure/security/security.service';
import { CreateUserDto, UpdateUserDto } from './dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { calculatePagination } from '../../common/utils';

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly securityService: SecurityService,
  ) {}

  async create(dto: CreateUserDto) {
    try {
      const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
      if (existing) throw new ConflictException('Email already exists');

      const passwordHash = await this.securityService.hashPassword(dto.password);

      const user = await this.prisma.user.create({
        data: {
          email: dto.email,
          passwordHash,
          name: dto.name,
          nameAr: dto.nameAr,
          phone: dto.phone,
          isActive: dto.isActive ?? true,
          organizationId: dto.organizationId,
        },
      });

      const { passwordHash: _, ...result } = user;
      return result;
    } catch (error) {
      if (error instanceof ConflictException) throw error;
      this.logger.error('Create user error:', error);
      throw error;
    }
  }

  async findAll(organizationId: string, pagination: PaginationDto) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);

    const where: any = { organizationId };
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        skip,
        take,
        orderBy: { [sortBy]: sortOrder },
        select: {
          id: true, email: true, name: true, nameAr: true, phone: true,
          avatarUrl: true, isActive: true, lastLoginAt: true, createdAt: true, updatedAt: true,
          organizationId: true,
        },
      }),
      this.prisma.user.count({ where }),
    ]);

    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      include: {
        organization: true,
        userRoles: { include: { role: true } },
      },
    });
    if (!user) throw new NotFoundException('User not found');
    const { passwordHash: _, ...result } = user;
    return result;
  }

  async update(id: string, dto: UpdateUserDto) {
    try {
      if (dto.email) {
        const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
        if (existing && existing.id !== id) {
          throw new ConflictException('Email already exists');
        }
      }

      const user = await this.prisma.user.update({
        where: { id },
        data: dto,
        include: { userRoles: { include: { role: true } } },
      });
      const { passwordHash: _, ...result } = user;
      return result;
    } catch (error) {
      if (error instanceof ConflictException) throw error;
      this.logger.error('Update user error:', error);
      throw error;
    }
  }

  async remove(id: string) {
    try {
      await this.prisma.user.delete({ where: { id } });
      return { success: true, message: 'User deleted' };
    } catch (error) {
      this.logger.error('Delete user error:', error);
      throw new NotFoundException('User not found');
    }
  }

  async assignRole(userId: string, roleId: string) {
    try {
      const user = await this.prisma.user.findUnique({ where: { id: userId } });
      if (!user) throw new NotFoundException('User not found');

      const role = await this.prisma.role.findUnique({ where: { id: roleId } });
      if (!role) throw new NotFoundException('Role not found');

      const existing = await this.prisma.userRole.findUnique({
        where: { userId_roleId: { userId, roleId } },
      });
      if (existing) throw new BadRequestException('User already has this role');

      await this.prisma.userRole.create({ data: { userId, roleId } });
      return { success: true, message: 'Role assigned' };
    } catch (error) {
      if (error instanceof NotFoundException || error instanceof BadRequestException) throw error;
      this.logger.error('Assign role error:', error);
      throw error;
    }
  }

  async getUserRoles(userId: string) {
    const userRoles = await this.prisma.userRole.findMany({
      where: { userId },
      include: { role: { include: { rolePermissions: { include: { permission: true } } } } },
    });
    return userRoles.map((ur) => ur.role);
  }
}
