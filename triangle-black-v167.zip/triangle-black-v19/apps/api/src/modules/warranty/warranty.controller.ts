import {
  Controller, Get, Post, Put, Delete, Body, Param, Query, ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { WarrantyService } from './warranty.service';
import { CreateWarrantyDto, UpdateWarrantyDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { createResponse, createPaginatedResponse } from '../../../common/dto/api-response.dto';

@ApiTags('Warranty')
@ApiBearerAuth()
@Controller('warranties')
export class WarrantyController {
  constructor(private readonly service: WarrantyService) {}

  @Post()
  @ApiOperation({ summary: 'Create warranty' })
  async create(@Body() dto: CreateWarrantyDto, @CurrentUser('id') userId: string) {
    const result = await this.service.create(dto, userId);
    return createResponse(result, 'Warranty created');
  }

  @Get()
  @ApiOperation({ summary: 'List warranties with filters' })
  async findAll(
    @Query() pagination: PaginationDto,
    @CurrentUser('organizationId') orgId: string,
    @Query('hotelId') hotelId?: string,
    @Query('vendorId') vendorId?: string,
    @Query('projectId') projectId?: string,
  ) {
    const result = await this.service.findAll(orgId, pagination, { hotelId, vendorId, projectId });
    return createPaginatedResponse(result.data, result.meta.total, result.meta.page, result.meta.limit);
  }

  @Get('expiring')
  @ApiOperation({ summary: 'Warranties expiring in next N days (default 30)' })
  async getExpiring(
    @CurrentUser('organizationId') orgId: string,
    @Query('days') days?: string,
  ) {
    const result = await this.service.getExpiring(orgId, parseInt(days || '30', 10));
    return createResponse(result);
  }

  @Get('overdue')
  @ApiOperation({ summary: 'Past warranty end, no follow-up created' })
  async getOverdue(@CurrentUser('organizationId') orgId: string) {
    const result = await this.service.getOverdue(orgId);
    return createResponse(result);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get warranty by ID' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    const result = await this.service.findOne(id);
    return createResponse(result);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update warranty' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateWarrantyDto,
    @CurrentUser('id') userId: string,
  ) {
    const result = await this.service.update(id, dto, userId);
    return createResponse(result, 'Warranty updated');
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Soft delete warranty' })
  async remove(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.service.remove(id, userId);
    return createResponse(result);
  }

  @Post(':id/send-reminder')
  @ApiOperation({ summary: 'Queue warranty reminder email' })
  async sendReminder(@Param('id', ParseUUIDPipe) id: string, @CurrentUser('id') userId: string) {
    const result = await this.service.sendReminder(id, userId);
    return createResponse(result);
  }
}
