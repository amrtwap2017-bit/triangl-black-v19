import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { QueueService } from '../../../infrastructure/queue/queue.service';
import { CreateWarrantyDto, UpdateWarrantyDto } from './dto';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { calculatePagination, generateSequentialNumber } from '../../../common/utils';

@Injectable()
export class WarrantyService {
  private readonly logger = new Logger(WarrantyService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService,
  ) {}

  async create(dto: CreateWarrantyDto, userId: string) {
    const count = await this.prisma.warranty.count({ where: { organizationId: dto.organizationId } });
    const warrantyNumber = generateSequentialNumber('WR', count + 1);
    return this.prisma.warranty.create({
      data: { ...dto, warrantyNumber, createdBy: userId, updatedBy: userId, status: 'ACTIVE' },
    });
  }

  async findAll(organizationId: string, pagination: PaginationDto, filters?: { hotelId?: string; vendorId?: string; projectId?: string }) {
    const { page, limit, sortBy, sortOrder, search } = pagination;
    const { skip, take } = calculatePagination(page, limit);
    const where: any = { organizationId, deletedAt: null };
    if (filters?.hotelId) where.hotelId = filters.hotelId;
    if (filters?.vendorId) where.vendorId = filters.vendorId;
    if (filters?.projectId) where.projectId = filters.projectId;
    if (search) {
      where.OR = [
        { equipment: { contains: search, mode: 'insensitive' } },
        { vendor: { contains: search, mode: 'insensitive' } },
        { warrantyNumber: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [data, total] = await Promise.all([
      this.prisma.warranty.findMany({ where, skip, take, orderBy: { [sortBy || 'createdAt']: sortOrder || 'DESC' } }),
      this.prisma.warranty.count({ where }),
    ]);
    const { totalPages } = calculatePagination(page, limit, total);
    return { data, meta: { total, page, limit, totalPages } };
  }

  async findOne(id: string) {
    const warranty = await this.prisma.warranty.findFirst({ where: { id, deletedAt: null } });
    if (!warranty) throw new NotFoundException('Warranty not found');
    return warranty;
  }

  async update(id: string, dto: UpdateWarrantyDto, userId: string) {
    await this.findOne(id);
    return this.prisma.warranty.update({
      where: { id },
      data: { ...dto, updatedBy: userId, version: { increment: 1 } },
    });
  }

  async remove(id: string, userId: string) {
    await this.findOne(id);
    await this.prisma.warranty.update({
      where: { id },
      data: { deletedAt: new Date(), updatedBy: userId, version: { increment: 1 } },
    });
    return { success: true, message: 'Warranty soft-deleted' };
  }

  async getExpiring(organizationId: string, days: number) {
    const now = new Date();
    const futureDate = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
    return this.prisma.warranty.findMany({
      where: {
        organizationId,
        deletedAt: null,
        warrantyEnd: { gte: now, lte: futureDate },
      },
      orderBy: { warrantyEnd: 'ASC' },
    });
  }

  async getOverdue(organizationId: string) {
    return this.prisma.warranty.findMany({
      where: {
        organizationId,
        deletedAt: null,
        warrantyEnd: { lt: new Date() },
        status: { not: 'CLAIMED' },
      },
      orderBy: { warrantyEnd: 'ASC' },
    });
  }

  async sendReminder(id: string, userId: string) {
    const warranty = await this.findOne(id);
    await this.prisma.warranty.update({
      where: { id },
      data: { reminderSent: true, reminderSentAt: new Date(), updatedBy: userId },
    });
    await this.queue.addJob('warranty-reminder', {
      warrantyId: warranty.id,
      warrantyNumber: warranty.warrantyNumber,
      equipment: warranty.equipment,
      warrantyEnd: warranty.warrantyEnd,
    });
    return { success: true, message: 'Warranty reminder queued' };
  }
}
