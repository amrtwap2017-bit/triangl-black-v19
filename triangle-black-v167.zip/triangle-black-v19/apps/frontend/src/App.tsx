import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './shared/hooks/useAuth';
import { MainLayout } from './shared/components/layout/main-layout';
import { AuthLayout } from './shared/components/layout/auth-layout';
import { LoadingSpinner } from './shared/components/ui/loading-spinner';

const LoginPage = lazy(() => import('./pages/login'));
const RegisterPage = lazy(() => import('./pages/register'));
const DashboardPage = lazy(() => import('./pages/dashboard'));

// Hotels
const HotelsList = lazy(() => import('./domains/hotels/hotels-list'));
const HotelForm = lazy(() => import('./domains/hotels/hotel-form'));
const HotelDetail = lazy(() => import('./domains/hotels/hotel-detail'));

// Requests
const RequestsList = lazy(() => import('./domains/partner-requests/requests-list'));
const RequestForm = lazy(() => import('./domains/partner-requests/request-form'));
const RequestDetail = lazy(() => import('./domains/partner-requests/request-detail'));

// Site Visits
const VisitsList = lazy(() => import('./domains/site-visits/visits-list'));
const VisitForm = lazy(() => import('./domains/site-visits/visit-form'));
const VisitDetail = lazy(() => import('./domains/site-visits/visit-detail'));

// Opportunities
const OpportunitiesList = lazy(() => import('./domains/opportunities/opportunities-list'));
const OpportunityForm = lazy(() => import('./domains/opportunities/opportunity-form'));
const OpportunityDetail = lazy(() => import('./domains/opportunities/opportunity-detail'));
const PipelineView = lazy(() => import('./domains/opportunities/pipeline-view'));

// Proposals
const ProposalsList = lazy(() => import('./domains/proposals/proposals-list'));
const ProposalForm = lazy(() => import('./domains/proposals/proposal-form'));
const ProposalDetail = lazy(() => import('./domains/proposals/proposal-detail'));

// Projects
const ProjectsList = lazy(() => import('./domains/projects/projects-list'));
const ProjectForm = lazy(() => import('./domains/projects/project-form'));
const ProjectDetail = lazy(() => import('./domains/projects/project-detail'));

// Procurement
const ProcurementList = lazy(() => import('./domains/procurement/procurement-list'));
const PurchaseOrdersList = lazy(() => import('./domains/procurement/purchase-orders-list'));

// Vendors
const VendorsList = lazy(() => import('./domains/vendors/vendors-list'));
const VendorForm = lazy(() => import('./domains/vendors/vendor-form'));
const VendorDetail = lazy(() => import('./domains/vendors/vendor-detail'));

// Emergency
const EmergencyList = lazy(() => import('./domains/emergency/emergency-list'));
const EmergencyForm = lazy(() => import('./domains/emergency/emergency-form'));
const EmergencyDetail = lazy(() => import('./domains/emergency/emergency-detail'));

// Documents
const DocumentsList = lazy(() => import('./domains/documents/documents-list'));

// Analytics / Insights
const ExecutiveDashboard = lazy(() => import('./domains/analytics/executive-dashboard'));
const RevenueAnalytics = lazy(() => import('./domains/analytics/revenue-analytics'));
const MarginAnalytics = lazy(() => import('./domains/analytics/margin-analytics'));
const PipelineAnalytics = lazy(() => import('./domains/analytics/pipeline-analytics'));
const HotelRelationships = lazy(() => import('./domains/analytics/hotel-relationships'));
const EmergencyMetrics = lazy(() => import('./domains/analytics/emergency-metrics'));

// Assistant
const AssistantPage = lazy(() => import('./domains/assistant/assistant-page'));

// AI Chat (full-page)
const AIChatWindow = lazy(() => import('./shared/components/ai/chat-window'));

// NEW DOMAINS
// Guest Protection
const GuestProtectionForm = lazy(() => import('./domains/guest-protection/guest-protection-form'));
const GuestProtectionView = lazy(() => import('./domains/guest-protection/guest-protection-view'));

// Knowledge Hub
const KnowledgeHubList = lazy(() => import('./domains/knowledge-hub/knowledge-hub-list'));
const KnowledgeArticleForm = lazy(() => import('./domains/knowledge-hub/knowledge-article-form'));
const KnowledgeArticleView = lazy(() => import('./domains/knowledge-hub/knowledge-article-view'));

// Drawings
const DrawingsList = lazy(() => import('./domains/drawings/drawings-list'));
const DrawingDetail = lazy(() => import('./domains/drawings/drawing-detail'));

// Warranty
const WarrantyList = lazy(() => import('./domains/warranty/warranty-list'));
const WarrantyForm = lazy(() => import('./domains/warranty/warranty-form'));

// Margin Intelligence
const MarginDashboard = lazy(() => import('./domains/margin/margin-dashboard'));

// Relationships
const RelationshipList = lazy(() => import('./domains/relationships/relationship-list'));
const RelationshipDetail = lazy(() => import('./domains/relationships/relationship-detail'));

// Opportunity Radar
const OpportunityRadar = lazy(() => import('./domains/opportunity-radar/opportunity-radar'));

// Hotel Intelligence
const HotelAssets = lazy(() => import('./domains/hotel-intelligence/hotel-assets'));
const AssetForm = lazy(() => import('./domains/hotel-intelligence/asset-form'));

// Proposal Templates
const TemplatesList = lazy(() => import('./domains/proposal-templates/templates-list'));
const TemplateForm = lazy(() => import('./domains/proposal-templates/template-form'));

// Inspections
const InspectionsList = lazy(() => import('./domains/inspections/inspections-list'));

// Handover
const HandoverView = lazy(() => import('./domains/handover/handover-view'));

// RFQ
const RfqList = lazy(() => import('./domains/rfq/rfq-list'));
const RfqForm = lazy(() => import('./domains/rfq/rfq-form'));
const RfqDetail = lazy(() => import('./domains/rfq/rfq-detail'));

// Resource Planning
const ResourceDashboard = lazy(() => import('./domains/resource-planning/resource-dashboard'));
const EmployeeList = lazy(() => import('./domains/resource-planning/employee-list'));
const EmployeeForm = lazy(() => import('./domains/resource-planning/employee-form'));

// CAPEX Intelligence
const CapexDashboard = lazy(() => import('./domains/capex/capex-dashboard'));
const CapexPlanForm = lazy(() => import('./domains/capex/capex-plan-form'));
const CapexRoadmap = lazy(() => import('./domains/capex/capex-roadmap'));

// Forecasting
const ForecastingDashboard = lazy(() => import('./domains/forecasting/forecasting-dashboard'));
const ForecastDetail = lazy(() => import('./domains/forecasting/forecast-detail'));

// Hotel Digital Twin
const TwinOverview = lazy(() => import('./domains/hotel-twin/twin-overview'));
const BuildingForm = lazy(() => import('./domains/hotel-twin/building-form'));
const AssetMap = lazy(() => import('./domains/hotel-twin/asset-map'));

// Vendor Portal
const VendorRfqList = lazy(() => import('./domains/vendor-portal/vendor-rfq-list'));
const VendorRfqDetail = lazy(() => import('./domains/rfq/rfq-detail'));
const VendorRfqResponse = lazy(() => import('./domains/vendor-portal/vendor-rfq-response'));

// PORTAL LAYOUTS
const HotelPortalLayout = lazy(() => import('./portals/hotel-portal-layout'));
const OperationsPortalLayout = lazy(() => import('./portals/operations-portal-layout'));
const ExecutivePortalLayout = lazy(() => import('./portals/executive-portal-layout'));
const VendorPortalLayout = lazy(() => import('./portals/vendor-portal-layout'));

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function PortalRedirect() {
  const { user } = useAuthStore();
  const portal = (user as Record<string, unknown>)?.portal as string || 'operations';
  const redirectMap: Record<string, string> = {
    hotel: '/hotel/dashboard',
    operations: '/operations/dashboard',
    executive: '/executive/dashboard',
    vendor: '/vendor/dashboard',
  };
  return <Navigate to={redirectMap[portal] || '/operations/dashboard'} replace />;
}

/** Shared route definitions used by operations and legacy routes */
function SharedDomainRoutes() {
  return (
    <>
      <Route path="hotels" element={<HotelsList />} />
      <Route path="hotels/new" element={<HotelForm />} />
      <Route path="hotels/:id" element={<HotelDetail />} />
      <Route path="hotels/:id/edit" element={<HotelForm />} />

      <Route path="requests" element={<RequestsList />} />
      <Route path="requests/new" element={<RequestForm />} />
      <Route path="requests/:id" element={<RequestDetail />} />
      <Route path="requests/:id/edit" element={<RequestForm />} />

      <Route path="site-visits" element={<VisitsList />} />
      <Route path="site-visits/new" element={<VisitForm />} />
      <Route path="site-visits/:id" element={<VisitDetail />} />
      <Route path="site-visits/:id/edit" element={<VisitForm />} />

      <Route path="opportunities" element={<OpportunitiesList />} />
      <Route path="opportunities/pipeline" element={<PipelineView />} />
      <Route path="opportunities/new" element={<OpportunityForm />} />
      <Route path="opportunities/:id" element={<OpportunityDetail />} />
      <Route path="opportunities/:id/edit" element={<OpportunityForm />} />

      <Route path="proposals" element={<ProposalsList />} />
      <Route path="proposals/new" element={<ProposalForm />} />
      <Route path="proposals/:id" element={<ProposalDetail />} />
      <Route path="proposals/:id/edit" element={<ProposalForm />} />

      <Route path="projects" element={<ProjectsList />} />
      <Route path="projects/new" element={<ProjectForm />} />
      <Route path="projects/:id" element={<ProjectDetail />} />
      <Route path="projects/:id/edit" element={<ProjectForm />} />
      <Route path="projects/:id/handover" element={<HandoverView />} />
      <Route path="projects/:id/guest-protection" element={<GuestProtectionView />} />
      <Route path="projects/:id/guest-protection/new" element={<GuestProtectionForm />} />
      <Route path="projects/:id/inspections" element={<InspectionsList />} />

      <Route path="procurement" element={<ProcurementList />} />
      <Route path="procurement/purchase-orders" element={<PurchaseOrdersList />} />

      <Route path="vendors" element={<VendorsList />} />
      <Route path="vendors/new" element={<VendorForm />} />
      <Route path="vendors/:id" element={<VendorDetail />} />
      <Route path="vendors/:id/edit" element={<VendorForm />} />

      <Route path="emergency" element={<EmergencyList />} />
      <Route path="emergency/new" element={<EmergencyForm />} />
      <Route path="emergency/:id" element={<EmergencyDetail />} />

      <Route path="documents" element={<DocumentsList />} />

      <Route path="drawings" element={<DrawingsList />} />
      <Route path="drawings/:id" element={<DrawingDetail />} />

      <Route path="knowledge-hub" element={<KnowledgeHubList />} />
      <Route path="knowledge-hub/new" element={<KnowledgeArticleForm />} />
      <Route path="knowledge-hub/:id" element={<KnowledgeArticleView />} />
      <Route path="knowledge-hub/:id/edit" element={<KnowledgeArticleForm />} />

      <Route path="warranties" element={<WarrantyList />} />
      <Route path="warranties/new" element={<WarrantyForm />} />
      <Route path="warranties/:id" element={<WarrantyForm />} />

      <Route path="margin" element={<MarginDashboard />} />

      <Route path="relationships" element={<RelationshipList />} />
      <Route path="relationships/:id" element={<RelationshipDetail />} />

      <Route path="opportunity-radar" element={<OpportunityRadar />} />

      <Route path="hotel-intelligence/assets" element={<HotelAssets />} />
      <Route path="hotel-intelligence/assets/new" element={<AssetForm />} />
      <Route path="hotel-intelligence/assets/:id/edit" element={<AssetForm />} />

      <Route path="proposal-templates" element={<TemplatesList />} />
      <Route path="proposal-templates/new" element={<TemplateForm />} />
      <Route path="proposal-templates/:id/edit" element={<TemplateForm />} />

      <Route path="inspections" element={<InspectionsList />} />

      <Route path="insights" element={<ExecutiveDashboard />} />
      <Route path="insights/revenue" element={<RevenueAnalytics />} />
      <Route path="insights/margins" element={<MarginAnalytics />} />
      <Route path="insights/pipeline" element={<PipelineAnalytics />} />
      <Route path="insights/hotel-relationships" element={<HotelRelationships />} />
      <Route path="insights/emergency-metrics" element={<EmergencyMetrics />} />

      <Route path="assistant" element={<AssistantPage />} />
      <Route path="ai" element={<AIChatWindow />} />

      {/* RFQ */}
      <Route path="rfqs" element={<RfqList />} />
      <Route path="rfqs/new" element={<RfqForm />} />
      <Route path="rfqs/:id" element={<RfqDetail />} />
      <Route path="rfqs/:id/edit" element={<RfqForm />} />

      {/* Resource Planning */}
      <Route path="resources" element={<ResourceDashboard />} />
      <Route path="resources/employees" element={<EmployeeList />} />
      <Route path="resources/employees/new" element={<EmployeeForm />} />
      <Route path="resources/employees/:id/edit" element={<EmployeeForm />} />

      {/* CAPEX Intelligence */}
      <Route path="capex" element={<CapexDashboard />} />
      <Route path="capex/plans/new" element={<CapexPlanForm />} />
      <Route path="capex/plans/:id/edit" element={<CapexPlanForm />} />
      <Route path="capex/roadmap" element={<CapexRoadmap />} />

      {/* Forecasting */}
      <Route path="forecasting" element={<ForecastingDashboard />} />
      <Route path="forecasting/:period" element={<ForecastDetail />} />

      {/* Hotel Digital Twin */}
      <Route path="twin" element={<TwinOverview />} />
      <Route path="twin/buildings/new" element={<BuildingForm />} />
      <Route path="twin/buildings/:id/edit" element={<BuildingForm />} />
      <Route path="twin/asset-map" element={<AssetMap />} />

      <Route path="administration" element={<Navigate to="/administration/users" replace />} />
    </>
  );
}

function AppRoutes() {
  const { isAuthenticated } = useAuthStore();

  return (
    <Suspense fallback={<LoadingSpinner fullScreen />}>
      <Routes>
        {/* Public Routes */}
        <Route
          path="/login"
          element={
            isAuthenticated ? <Navigate to="/" replace /> : (
              <AuthLayout><LoginPage /></AuthLayout>
            )
          }
        />
        <Route
          path="/register"
          element={
            isAuthenticated ? <Navigate to="/" replace /> : (
              <AuthLayout><RegisterPage /></AuthLayout>
            )
          }
        />

        {/* Portal redirect */}
        <Route path="/" element={<ProtectedRoute><PortalRedirect /></ProtectedRoute>} />

        {/* ========== HOTEL PORTAL ========== */}
        <Route path="/hotel" element={<ProtectedRoute><HotelPortalLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="/hotel/dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="requests" element={<RequestsList />} />
          <Route path="requests/new" element={<RequestForm />} />
          <Route path="requests/:id" element={<RequestDetail />} />
          <Route path="projects" element={<ProjectsList />} />
          <Route path="projects/:id" element={<ProjectDetail />} />
          <Route path="emergency" element={<EmergencyList />} />
          <Route path="emergency/new" element={<EmergencyForm />} />
          <Route path="emergency/:id" element={<EmergencyDetail />} />
          <Route path="documents" element={<DocumentsList />} />
          <Route path="knowledge-hub" element={<KnowledgeHubList />} />
          <Route path="knowledge-hub/:id" element={<KnowledgeArticleView />} />
        </Route>

        {/* ========== OPERATIONS PORTAL (Full) ========== */}
        <Route path="/operations" element={<ProtectedRoute><OperationsPortalLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="/operations/dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <SharedDomainRoutes />
        </Route>

        {/* ========== EXECUTIVE PORTAL ========== */}
        <Route path="/executive" element={<ProtectedRoute><ExecutivePortalLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="/executive/dashboard" replace />} />
          <Route path="dashboard" element={<ExecutiveDashboard />} />
          <Route path="hotels" element={<HotelsList />} />
          <Route path="hotels/:id" element={<HotelDetail />} />
          <Route path="opportunities" element={<OpportunitiesList />} />
          <Route path="opportunities/pipeline" element={<PipelineView />} />
          <Route path="opportunities/:id" element={<OpportunityDetail />} />
          <Route path="margin" element={<MarginDashboard />} />
          <Route path="relationships" element={<RelationshipList />} />
          <Route path="relationships/:id" element={<RelationshipDetail />} />
          <Route path="insights" element={<ExecutiveDashboard />} />
          <Route path="insights/revenue" element={<RevenueAnalytics />} />
          <Route path="insights/margins" element={<MarginAnalytics />} />
          <Route path="insights/pipeline" element={<PipelineAnalytics />} />
          <Route path="forecasting" element={<ForecastingDashboard />} />
          <Route path="capex" element={<CapexDashboard />} />
          <Route path="capex/roadmap" element={<CapexRoadmap />} />
          <Route path="opportunity-radar" element={<OpportunityRadar />} />
          <Route path="resources" element={<ResourceDashboard />} />
        </Route>

        {/* ========== VENDOR PORTAL ========== */}
        <Route path="/vendor" element={<ProtectedRoute><VendorPortalLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="/vendor/dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="rfqs" element={<VendorRfqList />} />
          <Route path="rfqs/:id" element={<VendorRfqDetail />} />
          <Route path="rfqs/:id/respond" element={<VendorRfqResponse />} />
          <Route path="performance" element={<VendorsList />} />
          <Route path="performance/:id" element={<VendorDetail />} />
          <Route path="certifications" element={<DocumentsList />} />
          <Route path="purchase-orders" element={<PurchaseOrdersList />} />
        </Route>

        {/* ========== LEGACY ROUTES (preserve backward compatibility) ========== */}
        <Route path="/" element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
          <Route index element={<PortalRedirect />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <SharedDomainRoutes />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  );
}