import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';

interface CostByModel {
  model: string;
  cost: number;
  tokens: number;
  requests: number;
}

interface CostByAgent {
  agent: string;
  cost: number;
  tokens: number;
  conversations: number;
}

interface DailyCost {
  date: string;
  cost: number;
  tokens: number;
}

// Mock data for development
const mockCostByModel: CostByModel[] = [
  { model: 'GPT-4o', cost: 1247.50, tokens: 2840000, requests: 3420 },
  { model: 'GPT-4o-mini', cost: 186.30, tokens: 5200000, requests: 8900 },
  { model: 'Claude 3.5 Sonnet', cost: 423.80, tokens: 1450000, requests: 1560 },
  { model: 'Embeddings (text-embedding-3)', cost: 45.20, tokens: 890000, requests: 4200 },
];

const mockCostByAgent: CostByAgent[] = [
  { agent: 'Assistant', cost: 620.40, tokens: 3200000, conversations: 1240 },
  { agent: 'Procurement', cost: 385.20, tokens: 1800000, conversations: 680 },
  { agent: 'Engineering', cost: 298.50, tokens: 1400000, conversations: 520 },
  { agent: 'Finance', cost: 215.80, tokens: 980000, conversations: 390 },
  { agent: 'Sales', cost: 178.30, tokens: 820000, conversations: 310 },
  { agent: 'Executive', cost: 134.60, tokens: 580000, conversations: 210 },
  { agent: 'Maintenance', cost: 52.40, tokens: 180000, conversations: 95 },
  { agent: 'Contract', cost: 22.60, tokens: 100000, conversations: 42 },
];

const mockDailyCost: DailyCost[] = Array.from({ length: 30 }, (_, i) => {
  const date = new Date();
  date.setDate(date.getDate() - (29 - i));
  return {
    date: date.toISOString().split('T')[0],
    cost: Math.round((80 + Math.random() * 120) * 100) / 100,
    tokens: Math.round(150000 + Math.random() * 200000),
  };
});

const totalCost = mockCostByModel.reduce((sum, m) => sum + m.cost, 0);
const totalTokens = mockCostByModel.reduce((sum, m) => sum + m.tokens, 0);
const totalConversations = mockCostByAgent.reduce((sum, a) => sum + a.conversations, 0);
const avgCostPerDay = totalCost / 30;

export function AiCostDashboard() {
  const { t } = useTranslation();
  const [period, setPeriod] = useState<'daily' | 'monthly'>('daily');

  const statCards = [
    {
      label: t('ai.cost.totalCost'),
      value: `$${totalCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}`,
      change: '+12.3%',
      changeType: 'up' as const,
      icon: '💰',
    },
    {
      label: t('ai.cost.tokensUsed'),
      value: `${(totalTokens / 1000000).toFixed(1)}M`,
      change: '+8.7%',
      changeType: 'up' as const,
      icon: '🔢',
    },
    {
      label: t('ai.cost.thisMonth'),
      value: `${totalConversations.toLocaleString()}`,
      change: '+15.2%',
      changeType: 'up' as const,
      icon: '💬',
    },
    {
      label: t('ai.cost.dailyTrend'),
      value: `$${avgCostPerDay.toFixed(2)}`,
      change: '-3.1%',
      changeType: 'down' as const,
      icon: '📈',
    },
  ];

  const maxModelCost = Math.max(...mockCostByModel.map(m => m.cost));
  const maxAgentCost = Math.max(...mockCostByAgent.map(a => a.cost));
  const maxDailyCost = Math.max(...mockDailyCost.map(d => d.cost));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-slate-100">{t('ai.cost.title')}</h1>
          <p className="text-sm text-slate-400 mt-1">{t('ai.cost.thisMonth')} — TRIANGLE BLACK v18.0</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPeriod('daily')}
            className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
              period === 'daily' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-slate-400 hover:text-slate-200 bg-[#252540]'
            }`}
          >
            Daily
          </button>
          <button
            onClick={() => setPeriod('monthly')}
            className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
              period === 'monthly' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-slate-400 hover:text-slate-200 bg-[#252540]'
            }`}
          >
            Monthly
          </button>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => (
          <div key={i} className="bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl">{card.icon}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                card.changeType === 'up' ? 'bg-green-500/10 text-green-400' : 'bg-blue-500/10 text-blue-400'
              }`}>
                {card.change}
              </span>
            </div>
            <p className="text-2xl font-bold text-slate-100">{card.value}</p>
            <p className="text-xs text-slate-400 mt-1">{card.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost by Model */}
        <div className="bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-5">
          <h2 className="text-sm font-semibold text-slate-200 mb-4">{t('ai.cost.byModel')}</h2>
          <div className="space-y-3">
            {mockCostByModel.map((model, i) => (
              <div key={i}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-slate-300">{model.model}</span>
                  <span className="text-xs text-amber-400 font-medium">${model.cost.toFixed(2)}</span>
                </div>
                <div className="w-full bg-[#252540] rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-amber-500 to-amber-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${(model.cost / maxModelCost) * 100}%` }}
                  />
                </div>
                <div className="flex justify-between mt-0.5">
                  <span className="text-[10px] text-slate-500">{(model.tokens / 1000).toFixed(0)}K tokens</span>
                  <span className="text-[10px] text-slate-500">{model.requests.toLocaleString()} requests</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cost by Agent */}
        <div className="bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-5">
          <h2 className="text-sm font-semibold text-slate-200 mb-4">{t('ai.cost.byAgent')}</h2>
          <div className="space-y-3">
            {mockCostByAgent.map((agent, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-slate-300">{agent.agent}</span>
                    <span className="text-xs text-amber-400 font-medium">${agent.cost.toFixed(2)}</span>
                  </div>
                  <div className="w-full bg-[#252540] rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-blue-400 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${(agent.cost / maxAgentCost) * 100}%` }}
                    />
                  </div>
                </div>
                <span className="text-[10px] text-slate-500 w-16 text-right">{agent.conversations} conv</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Daily Cost Trend */}
      <div className="bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-5">
        <h2 className="text-sm font-semibold text-slate-200 mb-4">{t('ai.cost.dailyTrend')} (Last 30 Days)</h2>
        <div className="flex items-end gap-1 h-48">
          {mockDailyCost.map((day, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div
                className="w-full bg-gradient-to-t from-amber-500/60 to-amber-500/20 rounded-t-sm transition-all duration-300 hover:from-amber-500 hover:to-amber-400/40 cursor-pointer"
                style={{ height: `${(day.cost / maxDailyCost) * 100}%`, minHeight: '4px' }}
                title={`${day.date}: $${day.cost.toFixed(2)} | ${(day.tokens / 1000).toFixed(0)}K tokens`}
              />
              {i % 5 === 0 && (
                <span className="text-[9px] text-slate-500">{day.date.slice(5)}</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Cost Alerts */}
      <div className="bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-5">
        <h2 className="text-sm font-semibold text-slate-200 mb-4">Cost Alerts</h2>
        <div className="space-y-2">
          <div className="flex items-center gap-3 bg-yellow-500/5 border border-yellow-500/20 rounded-lg px-3 py-2">
            <span className="text-yellow-400 text-sm">⚠️</span>
            <div>
              <p className="text-xs text-yellow-300">Budget threshold approaching</p>
              <p className="text-[10px] text-slate-400">AI costs have reached 78% of monthly budget ($1,750 / $2,250)</p>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-blue-500/5 border border-blue-500/20 rounded-lg px-3 py-2">
            <span className="text-blue-400 text-sm">ℹ️</span>
            <div>
              <p className="text-xs text-blue-300">Usage spike detected</p>
              <p className="text-[10px] text-slate-400">GPT-4o usage increased 45% this week compared to the previous week</p>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-green-500/5 border border-green-500/20 rounded-lg px-3 py-2">
            <span className="text-green-400 text-sm">✅</span>
            <div>
              <p className="text-xs text-green-300">Cost optimization opportunity</p>
              <p className="text-[10px] text-slate-400">32% of GPT-4o requests could be routed to GPT-4o-mini, saving ~$180/month</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}