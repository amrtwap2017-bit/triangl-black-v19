import { useTranslation } from 'react-i18next';
import { PageHeader, Card, KpiCards, StatCard, Badge } from '@/shared/components/ui';
import { AlertTriangle, Clock, ShieldCheck, TrendingDown } from 'lucide-react';

const EmergencyMetrics: React.FC = () => {
  const { t } = useTranslation();
  const kpis = [
    { icon: <AlertTriangle className="w-5 h-5" />, label: 'Total Cases (30d)', value: '24', change: -12.0 },
    { icon: <Clock className="w-5 h-5" />, label: 'Avg Response Time', value: '18 min', change: -22.0 },
    { icon: <ShieldCheck className="w-5 h-5" />, label: 'SLA Compliance', value: '94%', change: 3.0 },
    { icon: <TrendingDown className="w-5 h-5" />, label: 'Recurring Issues', value: '3', change: -25.0 },
  ];

  const slaData = [
    { severity: 'Critical', target: 15, average: 12, compliance: 96, total: 4 },
    { severity: 'High', target: 30, average: 22, compliance: 92, total: 8 },
    { severity: 'Medium', target: 60, average: 45, compliance: 95, total: 9 },
    { severity: 'Low', target: 120, average: 68, compliance: 98, total: 3 },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={t('insights.emergencyMetrics')} breadcrumbs={[{label:t('insights.title'),href:'/insights'},{label:t('insights.emergencyMetrics')}]} />
      <KpiCards cards={kpis} />
      <Card header={<h4 className="font-semibold text-slate-200">{t('emergency.slaTracking')}</h4>}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-[#2d2d4a]">
              <th className="text-start py-3 text-slate-400 font-medium">Severity</th>
              <th className="text-end py-3 text-slate-400 font-medium">Target (min)</th>
              <th className="text-end py-3 text-slate-400 font-medium">Avg (min)</th>
              <th className="text-end py-3 text-slate-400 font-medium">Compliance</th>
              <th className="text-end py-3 text-slate-400 font-medium">Cases</th>
            </tr></thead>
            <tbody>
              {slaData.map((row) => (
                <tr key={row.severity} className="border-b border-[#2d2d4a]/50">
                  <td className="py-3"><Badge variant={row.severity === 'Critical' ? 'danger' : row.severity === 'High' ? 'warning' : 'default'}>{row.severity}</Badge></td>
                  <td className="py-3 text-end text-slate-300">{row.target}</td>
                  <td className="py-3 text-end text-slate-200 font-medium">{row.average}</td>
                  <td className="py-3 text-end"><span className={row.compliance >= 95 ? 'text-green-400' : 'text-amber-400'}>{row.compliance}%</span></td>
                  <td className="py-3 text-end text-slate-300">{row.total}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default EmergencyMetrics;