import { useTranslation } from 'react-i18next';
import { DollarSign, HardHat, Target, FileText, AlertTriangle, Trophy, TrendingUp, Users, Building2, ShoppingCart } from 'lucide-react';
import { PageHeader, Card, KpiCards, StatCard, Tabs, RevenueChart, PipelineChart } from '@/shared/components/ui';
import type { RevenueData, PipelineData } from '@/shared/types';

const mockRevenue: RevenueData[] = [
  { month: 'Jan', revenue: 450000, cost: 320000, profit: 130000 },
  { month: 'Feb', revenue: 380000, cost: 270000, profit: 110000 },
  { month: 'Mar', revenue: 520000, cost: 360000, profit: 160000 },
  { month: 'Apr', revenue: 490000, cost: 340000, profit: 150000 },
  { month: 'May', revenue: 610000, cost: 410000, profit: 200000 },
  { month: 'Jun', revenue: 580000, cost: 390000, profit: 190000 },
];

const mockPipeline: PipelineData[] = [
  { stage: 'LEAD', count: 12, value: 2400000 },
  { stage: 'QUALIFIED', count: 8, value: 3200000 },
  { stage: 'PROPOSAL_SENT', count: 5, value: 1800000 },
  { stage: 'NEGOTIATION', count: 3, value: 1500000 },
  { stage: 'VERBAL_AGREEMENT', count: 2, value: 800000 },
  { stage: 'CONTRACT_SIGNED', count: 1, value: 500000 },
];

const ExecutiveDashboard: React.FC = () => {
  const { t } = useTranslation();

  const kpis = [
    { icon: <DollarSign className="w-5 h-5" />, label: t('dashboard.totalRevenue'), value: '$3.03M', change: 12.5 },
    { icon: <HardHat className="w-5 h-5" />, label: t('dashboard.activeProjects'), value: '18', change: 8.0 },
    { icon: <Target className="w-5 h-5" />, label: t('dashboard.openOpportunities'), value: '31', change: -5.0 },
    { icon: <Trophy className="w-5 h-5" />, label: t('dashboard.winRate'), value: '68%', change: 5.0 },
    { icon: <Building2 className="w-5 h-5" />, label: 'Active Hotels', value: '47', change: 6.8 },
    { icon: <ShoppingCart className="w-5 h-5" />, label: 'Procurement Value', value: '$1.8M', change: 10.2 },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={t('insights.executiveSummary')} breadcrumbs={[{label:t('insights.title'),href:'/insights'},{label:t('insights.executiveSummary')}]} />
      <KpiCards cards={kpis} />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card header={<h4 className="font-semibold text-slate-200">{t('insights.revenue')}</h4>}>
          <RevenueChart data={mockRevenue} height={300} />
        </Card>
        <Card header={<h4 className="font-semibold text-slate-200">{t('opportunities.pipeline')}</h4>}>
          <PipelineChart data={mockPipeline} />
        </Card>
      </div>
    </div>
  );
};

export default ExecutiveDashboard;