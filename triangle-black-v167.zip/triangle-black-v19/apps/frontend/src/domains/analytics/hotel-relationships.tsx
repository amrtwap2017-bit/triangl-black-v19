import { useTranslation } from 'react-i18next';
import { PageHeader, Card, KpiCards, StatCard, EmptyState } from '@/shared/components/ui';
import { Building2, DollarSign, Star, HardHat } from 'lucide-react';

const HotelRelationships: React.FC = () => {
  const { t } = useTranslation();
  const kpis = [
    { icon: <Building2 className="w-5 h-5" />, label: 'Total Hotels', value: '47', change: 6.8 },
    { icon: <Star className="w-5 h-5" />, label: 'Avg Relationship Score', value: '72/100', change: 3.2 },
    { icon: <DollarSign className="w-5 h-5" />, label: 'Total Hotel Revenue', value: '$8.5M', change: 14.1 },
    { icon: <HardHat className="w-5 h-5" />, label: 'Hotels with Active Projects', value: '18', change: 2.0 },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={t('insights.hotelRelationships')} breadcrumbs={[{label:t('insights.title'),href:'/insights'},{label:t('insights.hotelRelationships')}]} />
      <KpiCards cards={kpis} />
      <Card>
        <EmptyState message="Hotel relationship analytics coming soon - top hotels by revenue, engagement scoring, and relationship trends" />
      </Card>
    </div>
  );
};

export default HotelRelationships;