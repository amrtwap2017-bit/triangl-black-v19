import { useTranslation } from 'react-i18next';
import { PageHeader, Card, KpiCards, StatCard } from '@/shared/components/ui';
import { MarginChart } from '@/shared/components/charts';
import { TrendingUp, DollarSign, Percent, BarChart3 } from 'lucide-react';
import type { RevenueData } from '@/shared/types';

const mockData: RevenueData[] = [
  { month: 'Jan', revenue: 120000, cost: 82000, profit: 38000 },
  { month: 'Feb', revenue: 135000, cost: 90000, profit: 45000 },
  { month: 'Mar', revenue: 155000, cost: 105000, profit: 50000 },
  { month: 'Apr', revenue: 142000, cost: 98000, profit: 44000 },
  { month: 'May', revenue: 168000, cost: 112000, profit: 56000 },
  { month: 'Jun', revenue: 160000, cost: 108000, profit: 52000 },
];

const MarginAnalytics: React.FC = () => {
  const { t } = useTranslation();
  const kpis = [
    { icon: <Percent className="w-5 h-5" />, label: 'Average Gross Margin', value: '33.5%', change: 2.3 },
    { icon: <TrendingUp className="w-5 h-5" />, label: 'Best Margin Project', value: '42.1%', change: 5.1 },
    { icon: <BarChart3 className="w-5 h-5" />, label: 'Worst Margin Project', value: '18.3%', change: -4.2 },
    { icon: <DollarSign className="w-5 h-5" />, label: 'Total Gross Profit', value: '$285K', change: 8.7 },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={t('insights.margins')} breadcrumbs={[{label:t('insights.title'),href:'/insights'},{label:t('insights.margins')}]} />
      <KpiCards cards={kpis} />
      <Card header={<h4 className="font-semibold text-slate-200">Margin Trend</h4>}>
        <MarginChart data={mockData} height={350} />
      </Card>
    </div>
  );
};

export default MarginAnalytics;