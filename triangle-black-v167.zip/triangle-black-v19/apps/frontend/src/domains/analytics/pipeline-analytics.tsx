import { useTranslation } from 'react-i18next';
import { PageHeader, Card, KpiCards, StatCard } from '@/shared/components/ui';
import { PipelineChart } from '@/shared/components/charts';
import { Target, DollarSign, TrendingUp, BarChart3 } from 'lucide-react';
import type { PipelineData } from '@/shared/types';

const mockPipeline: PipelineData[] = [
  { stage: 'LEAD', count: 12, value: 2400000 },
  { stage: 'QUALIFIED', count: 8, value: 3200000 },
  { stage: 'PROPOSAL_SENT', count: 5, value: 1800000 },
  { stage: 'NEGOTIATION', count: 3, value: 1500000 },
  { stage: 'VERBAL_AGREEMENT', count: 2, value: 800000 },
  { stage: 'CONTRACT_SIGNED', count: 1, value: 500000 },
];

const PipelineAnalytics: React.FC = () => {
  const { t } = useTranslation();
  const kpis = [
    { icon: <Target className="w-5 h-5" />, label: 'Total Pipeline Value', value: '$10.2M', change: 15.3 },
    { icon: <TrendingUp className="w-5 h-5" />, label: 'Win Rate (30d)', value: '68%', change: 5.0 },
    { icon: <DollarSign className="w-5 h-5" />, label: 'Avg Deal Size', value: '$378K', change: -2.1 },
    { icon: <BarChart3 className="w-5 h-5" />, label: 'Avg Sales Cycle', value: '34 days', change: -8.0 },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={t('insights.pipeline')} breadcrumbs={[{label:t('insights.title'),href:'/insights'},{label:t('insights.pipeline')}]} />
      <KpiCards cards={kpis} />
      <Card header={<h4 className="font-semibold text-slate-200">{t('opportunities.pipeline')}</h4>}>
        <PipelineChart data={mockPipeline} />
      </Card>
    </div>
  );
};

export default PipelineAnalytics;