import { useTranslation } from 'react-i18next';
import { PageHeader, Card, Select, KpiCards, StatCard } from '@/shared/components/ui';
import { RevenueChart, MarginChart } from '@/shared/components/charts';
import { DollarSign, TrendingUp, Target, BarChart3 } from 'lucide-react';
import { useState } from 'react';
import type { RevenueData } from '@/shared/types';

const mockRevenue: RevenueData[] = [
  { month: 'Jan', revenue: 450000, cost: 320000, profit: 130000 },
  { month: 'Feb', revenue: 380000, cost: 270000, profit: 110000 },
  { month: 'Mar', revenue: 520000, cost: 360000, profit: 160000 },
  { month: 'Apr', revenue: 490000, cost: 340000, profit: 150000 },
  { month: 'May', revenue: 610000, cost: 410000, profit: 200000 },
  { month: 'Jun', revenue: 580000, cost: 390000, profit: 190000 },
];

const RevenueAnalytics: React.FC = () => {
  const { t } = useTranslation();
  const [period, setPeriod] = useState('6m');
  const [hotelFilter, setHotelFilter] = useState('');

  const kpis = [
    { icon: <DollarSign className="w-5 h-5" />, label: 'Total Revenue', value: '$3.03M', change: 12.5 },
    { icon: <TrendingUp className="w-5 h-5" />, label: 'Avg. Margin', value: '31.2%', change: 2.1 },
    { icon: <Target className="w-5 h-5" />, label: 'Revenue per Project', value: '$168K', change: -3.4 },
    { icon: <BarChart3 className="w-5 h-5" />, label: 'Cost Ratio', value: '68.8%', change: -1.2 },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={t('insights.revenue')} breadcrumbs={[{label:t('insights.title'),href:'/insights'},{label:t('insights.revenue')}]} actions={
        <div className="flex gap-2">
          <Select options={[{value:'6m',label:'Last 6 Months'},{value:'1y',label:t('insights.thisYear')},{value:'all',label:'All Time'}]} value={period} onChange={(e) => setPeriod(e.target.value)} />
        </div>
      }}/>
      <KpiCards cards={kpis} />
      <Card header={<h4 className="font-semibold text-slate-200">{t('insights.revenue')}</h4>}>
        <RevenueChart data={mockRevenue} height={350} />
      </Card>
    </div>
  );
};

export default RevenueAnalytics;