import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Send, FileText, Calculator, ShieldCheck, ClipboardList, MessageSquare } from 'lucide-react';
import { Card } from '../../shared/components/ui/card';
import { Button } from '../../shared/components/ui/button';
import { Input } from '../../shared/components/ui/input';
import { Textarea } from '../../shared/components/ui/textarea';
import { Tabs } from '../../shared/components/ui/tabs';
import { apiClient } from '../../api/client';
import toast from 'react-hot-toast';

type AgentTab = 'chat' | 'proposal' | 'boq' | 'risk' | 'site-visit' | 'summary';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function AssistantPage() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<AgentTab>('chat');
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [context, setContext] = useState('');
  const [loading, setLoading] = useState(false);

  const tabs: { id: AgentTab; label: string; icon: React.ReactNode }[] = [
    { id: 'chat', label: t('assistant.chat'), icon: <MessageSquare size={16} /> },
    { id: 'proposal', label: t('assistant.proposalDraft'), icon: <FileText size={16} /> },
    { id: 'boq', label: t('assistant.generateBoq'), icon: <Calculator size={16} /> },
    { id: 'risk', label: t('assistant.riskReview'), icon: <ShieldCheck size={16} /> },
    { id: 'site-visit', label: t('assistant.siteVisitReport'), icon: <ClipboardList size={16} /> },
    { id: 'summary', label: t('assistant.summary'), icon: <FileText size={16} /> },
  ];

  const getEndpoint = () => {
    switch (activeTab) {
      case 'chat': return '/assistant/chat';
      case 'proposal': return '/assistant/proposal-draft';
      case 'boq': return '/assistant/boq-generate';
      case 'risk': return '/assistant/risk-review';
      case 'site-visit': return '/assistant/site-visit-report';
      case 'summary': return '/assistant/summary';
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !context.trim()) return;
    setLoading(true);

    const userMessage: Message = { role: 'user', content: input || context, timestamp: new Date() };
    setMessages(prev => [...prev, userMessage]);

    try {
      const res = await apiClient.post(getEndpoint(), {
        prompt: input,
        context: context || undefined,
      });
      const assistantMessage: Message = {
        role: 'assistant',
        content: res.data.data?.response || res.data.data || 'No response generated.',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch {
      toast.error('Failed to get AI response');
      setMessages(prev => [...prev, { role: 'assistant', content: 'Error: Could not generate response.', timestamp: new Date() }]);
    } finally {
      setLoading(false);
      setInput('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-slate-100">{t('assistant.title')}</h1>
      </div>

      <div className="flex gap-6">
        {/* Left: Tabs */}
        <div className="w-64 shrink-0">
          <Card className="p-2">
            <nav className="space-y-1">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => { setActiveTab(tab.id); setMessages([]); }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'bg-[#c9a962]/20 text-[#c9a962]'
                      : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </nav>
          </Card>
        </div>

        {/* Right: Chat Area */}
        <Card className="flex-1 flex flex-col h-[calc(100vh-180px)]">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 && (
              <div className="flex items-center justify-center h-full text-slate-500">
                <div className="text-center">
                  <MessageSquare size={48} className="mx-auto mb-4 opacity-30" />
                  <p className="text-lg">{t('assistant.title')}</p>
                  <p className="text-sm mt-1">Select an agent and start typing</p>
                </div>
              </div>
            )}
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-xl px-4 py-3 text-sm ${
                  msg.role === 'user'
                    ? 'bg-[#c9a962] text-[#0f0f1a] font-medium'
                    : 'bg-white/5 text-slate-300 border border-[#2d2d4a]'
                }`}>
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-white/5 border border-[#2d2d4a] rounded-xl px-4 py-3 text-sm text-slate-400 animate-pulse">
                  Generating response...
                </div>
              </div>
            )}
          </div>

          {/* Context Input (for non-chat tabs) */}
          {activeTab !== 'chat' && (
            <div className="px-6 pb-2">
              <Textarea
                value={context}
                onChange={e => setContext(e.target.value)}
                placeholder={`Provide context for ${tabs.find(t => t.id === activeTab)?.label}...`}
                rows={3}
              />
            </div>
          )}

          {/* Input */}
          <div className="p-4 border-t border-[#2d2d4a] flex gap-3">
            <Input
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder={activeTab === 'chat' ? 'Type your message...' : 'Additional instructions...'}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
              className="flex-1"
            />
            <Button onClick={handleSend} disabled={loading || (!input.trim() && !context.trim())}>
              <Send size={16} />
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}