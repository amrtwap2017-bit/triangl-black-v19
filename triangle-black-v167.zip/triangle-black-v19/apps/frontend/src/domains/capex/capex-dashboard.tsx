import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Building2,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
  Plus,
  Calendar,
  ArrowUpRight,
  MapPin,
} from 'lucide-react';
import { Card, PageHeader, StatCard, Button, Select, Badge, Table } from '@/shared/components/ui';
import type { Column } from '@/shared/types';

interface HotelOption {
  id: string;
  name: string;
}

interface YearBudget {
  year: number;
  budget: number;
  spent: number;
  planned: number;
  actual: number;
}

interface PriorityItem {
  id: string;
  asset: string;
  category: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  estimatedCost: number;
  urgency: string;
  status: string;
}

interface RoadmapItem {
  id: string;
  year: number;
  quarter: string;
  project: string;
  budget: number;
  status: 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED' | 'DEFERRED';
}

const hotels: HotelOption[] = [
  { id: 'h1', name: 'Burj Al Arab' },
  { id: 'h2', name: 'Atlantis The Royal' },
  { id: 'h3', name: 'Mandarin Oriental' },
  { id: 'h4', name: 'Four Seasons DIFC' },
  { id: 'h5', name: 'Ritz Carlton' },
  { id: 'h6', name: 'JW Marriott Marquis' },
];

const yearlyBudgets: YearBudget[] = [
  { year: 2024, budget: 12000000, spent: 4200000, planned: 7800000, actual: 4100000 },
  { year: 2025, budget: 15000000, spent: 0, planned: 15000000, actual: 0 },
  { year: 2026, budget: 8000000, spent: 0, planned: 8000000, actual: 0 },
  { year: 2027, budget: 11000000, spent: 0, planned: 11000000, actual: 0 },
  { year: 2028, budget: 9500000, spent: 0, planned: 9500000, actual: 0 },
];

const priorityItems: PriorityItem[] = [
  { id: 'pi1', asset: 'Main Chiller Plant (CH-01)', category: 'HVAC', priority: 'CRITICAL', estimatedCost: 4500000, urgency: 'Immediate — beyond repair', status: 'PLANNED' },
  { id: 'pi2', asset: 'Fire Alarm Control Panel', category: 'Fire Protection', priority: 'CRITICAL', estimatedCost: 850000, urgency: 'Code compliance deadline Q2', status: 'PLANNED' },
  { id: 'pi3', asset: 'Guest Elevator #3 Motor', category: 'Electrical', priority: 'HIGH', estimatedCost: 1200000, urgency: 'Frequent breakdowns reported', status: 'IN_PROGRESS' },
  { id: 'pi4', asset: 'Roof Waterproofing Membrane', category: 'Waterproofing', priority: 'HIGH', estimatedCost: 680000, urgency: 'Leaks detected Level 18-22', status: 'PLANNED' },
  { id: 'pi5', asset: 'Kitchen Ventilation System', category: 'HVAC', priority: 'MEDIUM', estimatedCost: 520000, urgency: 'Efficiency degradation 40%', status: 'PLANNED' },
  { id: 'pi6', asset: 'BMS Server Hardware', category: 'BMS', priority: 'MEDIUM', estimatedCost: 350000, urgency: 'End-of-life hardware', status: 'DEFERRED' },
];

const roadmapItems: RoadmapItem[] = [
  { id: 'rm1', year: 2024, quarter: 'Q1', project: 'Chiller Plant Replacement', budget: 4500000, status: 'IN_PROGRESS' },
  { id: 'rm2', year: 2024, quarter: 'Q2', project: 'Fire Alarm Panel Upgrade', budget: 850000, status: 'PLANNED' },
  { id: 'rm3', year: 2024, quarter: 'Q3', project: 'Elevator Motor Replacement', budget: 1200000, status: 'PLANNED' },
  { id: 'rm4', year: 2024, quarter: 'Q4', project: 'Roof Waterproofing', budget: 680000, status: 'PLANNED' },
  { id: 'rm5', year: 2025, quarter: 'Q1', project: 'Kitchen Ventilation', budget: 520000, status: 'PLANNED' },
  { id: 'rm6', year: 2025, quarter: 'Q2', project: 'BMS Server Upgrade', budget: 350000, status: 'PLANNED' },
  { id: 'rm7', year: 2025, quarter: 'Q3', project: 'AHU Replacement — Tower B', budget: 2100000, status: 'PLANNED' },
  { id: 'rm8', year: 2026, quarter: 'Q1', project: 'Electrical Switchgear', budget: 1800000, status: 'PLANNED' },
];

const getPriorityVariant = (p: string): 'danger' | 'warning' | 'info' => {
  switch (p) {
    case 'CRITICAL': return 'danger';
    case 'HIGH': return 'warning';
    default: return 'info';
  }
};

const getStatusVariant = (s: string) => {
  switch (s) {
    case 'PLANNED': return 'info';
    case 'IN_PROGRESS': return 'warning';
    case 'COMPLETED': return 'success';
    case 'DEFERRED': return 'default';
    default: return 'default';
  }
};

const getStatusDotColor = (s: string) => {
  switch (s) {
    case 'PLANNED': return 'bg-blue-500';
    case 'IN_PROGRESS': return 'bg-amber-500';
    case 'COMPLETED': return 'bg-green-500';
    case 'DEFERRED': return 'bg-slate-500';
    default: return 'bg-slate-500';
  }
};

const CapexDashboard: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [selectedHotel, setSelectedHotel] = useState('h1');

  const currentYearBudget = yearlyBudgets[0];
  const budgetUtilization = currentYearBudget.budget > 0
    ? Math.round((currentYearBudget.spent / currentYearBudget.budget) * 100)
    : 0;
  const maxBudget = Math.max(...yearlyBudgets.map((y) => y.budget));

  const criticalCount = priorityItems.filter((i) => i.priority === 'CRITICAL').length;
  const highCount = priorityItems.filter((i) => i.priority === 'HIGH').length;

  const priorityColumns: Column<PriorityItem>[] = useMemo(() => [
    { key: 'asset', header: t('common.asset', 'Asset'), render: (v) => <span className="font-medium text-slate-100">{v as string}</span> },
    { key: 'category', header: t('common.category', 'Category'), width: 'w-32' },
    { key: 'priority', header: t('common.priority', 'Priority'), width: 'w-24', render: (v) => <Badge variant={getPriorityVariant(v as string)}>{v as string}</Badge> },
    { key: 'estimatedCost', header: t('common.estimatedCost', 'Est. Cost'), align: 'end', width: 'w-32', render: (v) => <span className="text-[#c9a962] font-medium">AED {(v as number).toLocaleString()}</span> },
    { key: 'urgency', header: t('common.urgency', 'Urgency'), width: 'w-48' },
    { key: 'status', header: t('common.status', 'Status'), width: 'w-28', render: (v) => <Badge variant={getStatusVariant(v as string)}>{v as string}</Badge> },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('capex.title', 'CAPEX Intelligence')}
        subtitle={t('capex.subtitle', 'Capital expenditure planning and tracking')}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={() => navigate('/capex/plan/new')}>
              {t('capex.createPlan', 'Create Plan')}
            </Button>
            <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/capex/plan/new')}>
              {t('capex.addPlan', 'New CAPEX Plan')}
            </Button>
          </div>
        }
      />

      {/* Hotel Selector */}
      <Card>
        <div className="flex items-center gap-3">
          <MapPin className="w-5 h-5 text-[#c9a962]" />
          <Select
            options={hotels.map((h) => ({ value: h.id, label: h.name }))}
            value={selectedHotel}
            onChange={(e) => setSelectedHotel(e.target.value)}
            className="w-64"
          />
        </div>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={<DollarSign className="w-5 h-5" />}
          label={t('capex.totalBudget', 'Total 5-Year Budget')}
          value={`AED ${(yearlyBudgets.reduce((s, y) => s + y.budget, 0) / 1000000).toFixed(1)}M`}
          change={12.5}
        />
        <StatCard
          icon={<TrendingUp className="w-5 h-5" />}
          label={`${t('capex.yearBudget', `${new Date().getFullYear()} Budget`)} (AED)`}
          value={`${(currentYearBudget.budget / 1000000).toFixed(1)}M`}
        />
        <StatCard
          icon={<AlertTriangle className="w-5 h-5" />}
          label={t('capex.criticalItems', 'Critical Replacements')}
          value={criticalCount}
          change={1}
        />
        <StatCard
          icon={<CheckCircle2 className="w-5 h-5" />}
          label={t('capex.highPriority', 'High Priority')}
          value={highCount}
        />
      </div>

      {/* 5-Year Budget Plan — Bar Chart */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('capex.fiveYearPlan', '5-Year CAPEX Plan')}</h3>}>
        <div className="space-y-4">
          {yearlyBudgets.map((year) => {
            const spentPercent = year.budget > 0 ? (year.spent / year.budget) * 100 : 0;
            const plannedPercent = year.budget > 0 ? (year.planned / year.budget) * 100 : 0;
            const isCurrentYear = year.year === new Date().getFullYear();

            return (
              <div key={year.year} className="space-y-1.5">
                <div className="flex items-center justify-between text-sm">
                  <span className={`font-medium ${isCurrentYear ? 'text-[#c9a962]' : 'text-slate-300'}`}>
                    {year.year}
                    {isCurrentYear && <span className="text-xs ms-2 text-slate-500">(Current)</span>}
                  </span>
                  <span className="text-slate-400">
                    AED {(year.budget / 1000000).toFixed(1)}M
                    {year.spent > 0 && (
                      <span className="ms-2 text-amber-400">
                        ({((year.spent / year.budget) * 100).toFixed(0)}% spent)
                      </span>
                    )}
                  </span>
                </div>
                <div className="flex gap-0.5 h-8">
                  {year.spent > 0 && (
                    <div
                      className="bg-[#c9a962] rounded-l-sm flex items-center justify-end pe-2 transition-all"
                      style={{ width: `${(year.spent / maxBudget) * 100}%` }}
                    >
                      <span className="text-[10px] font-medium text-[#0f0f1a]">
                        {((year.spent / year.budget) * 100).toFixed(0)}%
                      </span>
                    </div>
                  )}
                  <div
                    className={`rounded-r-sm flex items-center justify-end pe-2 transition-all ${
                      year.spent > 0 ? 'bg-[#2d2d4a]' : 'bg-[#2d2d4a] rounded-sm'
                    }`}
                    style={{ width: `${Math.max(((year.budget - year.spent) / maxBudget) * 100, 0)}%` }}
                  />
                </div>
              </div>
            );
          })}
          <div className="flex items-center gap-4 pt-2 text-xs text-slate-500 border-t border-[#2d2d4a]">
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-[#c9a962] rounded-sm" /> {t('capex.spent', 'Spent')}</div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-[#2d2d4a] rounded-sm" /> {t('capex.remaining', 'Remaining')}</div>
          </div>
        </div>
      </Card>

      {/* Budget Utilization Progress */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('capex.budgetUtilization', 'Budget Utilization')}</h3>}>
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-slate-400">{t('capex.currentYearUtil', `${new Date().getFullYear()} Utilization`)}</span>
            <span className="text-2xl font-bold text-[#c9a962]">{budgetUtilization}%</span>
          </div>
          <div className="w-full h-4 bg-[#2d2d4a] rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                budgetUtilization >= 90 ? 'bg-red-500' : budgetUtilization >= 70 ? 'bg-[#c9a962]' : 'bg-green-500'
              }`}
              style={{ width: `${budgetUtilization}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-slate-500">
            <span>AED {(currentYearBudget.spent / 1000000).toFixed(1)}M {t('capex.spent', 'spent')}</span>
            <span>AED {((currentYearBudget.budget - currentYearBudget.spent) / 1000000).toFixed(1)}M {t('capex.remaining', 'remaining')}</span>
          </div>
        </div>
      </Card>

      {/* Priority Replacements */}
      <Card header={
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-100">{t('capex.priorityReplacements', 'Priority Replacements')}</h3>
          <Button variant="ghost" size="sm" onClick={() => navigate('/capex/roadmap')}>
            {t('capex.viewRoadmap', 'View Roadmap')} <ArrowUpRight className="w-4 h-4" />
          </Button>
        </div>
      }>
        <Table columns={priorityColumns} data={priorityItems} keyExtractor={(r) => r.id} />
      </Card>

      {/* Asset Replacement Roadmap Timeline */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('capex.roadmap', 'Asset Replacement Roadmap')}</h3>}>
        <div className="overflow-x-auto">
          <div className="min-w-[800px]">
            {/* Quarter headers */}
            <div className="flex border-b border-[#2d2d4a] pb-2 mb-4">
              <div className="w-48 shrink-0" />
              {['Q1', 'Q2', 'Q3', 'Q4'].map((q) => (
                <div key={q} className="flex-1 text-center text-xs font-semibold text-slate-400 uppercase">{q}</div>
              ))}
            </div>

            {/* Year rows */}
            {['2024', '2025', '2026'].map((year) => {
              const yearItems = roadmapItems.filter((r) => String(r.year) === year);
              return (
                <div key={year} className="flex items-center mb-4">
                  <div className="w-48 shrink-0">
                    <span className="text-sm font-semibold text-[#c9a962]">{year}</span>
                  </div>
                  <div className="flex-1 flex">
                    {['Q1', 'Q2', 'Q3', 'Q4'].map((q) => {
                      const item = yearItems.find((r) => r.quarter === q);
                      return (
                        <div key={q} className="flex-1 px-1">
                          {item ? (
                            <div
                              className="p-2 bg-[#252540] border border-[#2d2d4a] rounded-lg text-xs"
                            >
                              <div className="flex items-center gap-1.5 mb-1">
                                <div className={`w-2 h-2 rounded-full ${getStatusDotColor(item.status)}`} />
                                <span className="font-medium text-slate-200 truncate">{item.project}</span>
                              </div>
                              <span className="text-slate-500">AED {(item.budget / 1000).toFixed(0)}K</span>
                            </div>
                          ) : (
                            <div className="h-14 border border-dashed border-[#2d2d4a]/30 rounded-lg" />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Card>
    </div>
  );
};

export default CapexDashboard;
