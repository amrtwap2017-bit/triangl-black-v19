import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Trash2, Save, Send, Calculator } from 'lucide-react';
import {
  PageHeader,
  Card,
  Button,
  Input,
  Textarea,
  Select,
  Badge,
} from '@/shared/components/ui';

interface CapexPlanItem {
  id: string;
  asset: string;
  category: string;
  description: string;
  estimatedCost: number;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  justification: string;
  scheduledQuarter: string;
  expectedROI: string;
}

const hotels = [
  { value: '', label: 'Select Hotel' },
  { value: 'Burj Al Arab', label: 'Burj Al Arab' },
  { value: 'Atlantis The Royal', label: 'Atlantis The Royal' },
  { value: 'Mandarin Oriental', label: 'Mandarin Oriental' },
  { value: 'Four Seasons DIFC', label: 'Four Seasons DIFC' },
  { value: 'Ritz Carlton', label: 'Ritz Carlton' },
  { value: 'JW Marriott Marquis', label: 'JW Marriott Marquis' },
];

const years = [
  { value: '', label: 'Select Year' },
  { value: '2024', label: '2024' },
  { value: '2025', label: '2025' },
  { value: '2026', label: '2026' },
  { value: '2027', label: '2027' },
  { value: '2028', label: '2028' },
];

const categories = [
  { value: 'HVAC', label: 'HVAC' },
  { value: 'Electrical', label: 'Electrical' },
  { value: 'Plumbing', label: 'Plumbing' },
  { value: 'Fire Protection', label: 'Fire Protection' },
  { value: 'BMS', label: 'BMS' },
  { value: 'Waterproofing', label: 'Waterproofing' },
  { value: 'Interior', label: 'Interior' },
  { value: 'Structural', label: 'Structural' },
  { value: 'Other', label: 'Other' },
];

const priorities = [
  { value: 'CRITICAL', label: 'Critical' },
  { value: 'HIGH', label: 'High' },
  { value: 'MEDIUM', label: 'Medium' },
  { value: 'LOW', label: 'Low' },
];

const quarters = [
  { value: '', label: 'Select Quarter' },
  { value: 'Q1', label: 'Q1 (Jan–Mar)' },
  { value: 'Q2', label: 'Q2 (Apr–Jun)' },
  { value: 'Q3', label: 'Q3 (Jul–Sep)' },
  { value: 'Q4', label: 'Q4 (Oct–Dec)' },
];

const createEmptyPlanItem = (): CapexPlanItem => ({
  id: crypto.randomUUID(),
  asset: '',
  category: 'HVAC',
  description: '',
  estimatedCost: 0,
  priority: 'MEDIUM',
  justification: '',
  scheduledQuarter: '',
  expectedROI: '',
});

const getPriorityVariant = (p: string): 'danger' | 'warning' | 'info' | 'default' => {
  switch (p) {
    case 'CRITICAL': return 'danger';
    case 'HIGH': return 'warning';
    case 'MEDIUM': return 'info';
    default: return 'default';
  }
};

const CapexPlanForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = Boolean(id);

  const [hotel, setHotel] = useState('');
  const [year, setYear] = useState('');
  const [items, setItems] = useState<CapexPlanItem[]>([createEmptyPlanItem()]);
  const [saving, setSaving] = useState(false);

  const handleAddItem = () => {
    setItems([...items, createEmptyPlanItem()]);
  };

  const handleRemoveItem = (itemId: string) => {
    if (items.length > 1) {
      setItems(items.filter((item) => item.id !== itemId));
    }
  };

  const handleItemChange = (
    itemId: string,
    field: keyof CapexPlanItem,
    value: string | number
  ) => {
    setItems(
      items.map((item) =>
        item.id === itemId ? { ...item, [field]: value } : item
      )
    );
  };

  const totalBudget = items.reduce((sum, item) => sum + item.estimatedCost, 0);
  const criticalTotal = items.filter((i) => i.priority === 'CRITICAL').reduce((s, i) => s + i.estimatedCost, 0);
  const highTotal = items.filter((i) => i.priority === 'HIGH').reduce((s, i) => s + i.estimatedCost, 0);
  const mediumTotal = items.filter((i) => i.priority === 'MEDIUM').reduce((s, i) => s + i.estimatedCost, 0);

  const handleSubmit = async () => {
    setSaving(true);
    try {
      // await apiPost('/capex/plans', { hotel, year, items, totalBudget });
      navigate('/capex');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveDraft = async () => {
    setSaving(true);
    try {
      // await apiPost('/capex/plans/draft', { hotel, year, items, totalBudget });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEditing ? t('capex.editPlan', 'Edit CAPEX Plan') : t('capex.createPlan', 'Create CAPEX Plan')}
        showBack
        backTo="/capex"
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" icon={<Save className="w-4 h-4" />} onClick={handleSaveDraft} loading={saving}>
              {t('common.saveDraft', 'Save Draft')}
            </Button>
            <Button icon={<Send className="w-4 h-4" />} onClick={handleSubmit} loading={saving} disabled={!hotel || !year || items.length === 0}>
              {t('capex.submitForApproval', 'Submit for Approval')}
            </Button>
          </div>
        }
      />

      {/* Plan Header */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('capex.planDetails', 'Plan Details')}</h3>}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select
            label={t('common.hotel', 'Hotel')}
            options={hotels}
            value={hotel}
            onChange={(e) => setHotel(e.target.value)}
          />
          <Select
            label={t('capex.planYear', 'Plan Year')}
            options={years}
            value={year}
            onChange={(e) => setYear(e.target.value)}
          />
        </div>
      </Card>

      {/* CAPEX Items */}
      <Card
        header={
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-100">
              {t('capex.planItems', 'CAPEX Items')} ({items.length})
            </h3>
            <Button size="sm" icon={<Plus className="w-4 h-4" />} onClick={handleAddItem}>
              {t('capex.addItem', 'Add Item')}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {items.map((item, index) => (
            <div key={item.id} className="p-4 bg-[#15152a] border border-[#2d2d4a] rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-[#c9a962]">
                    {t('capex.item', 'Item')} #{index + 1}
                  </span>
                  <Badge variant={getPriorityVariant(item.priority)}>{item.priority}</Badge>
                </div>
                {items.length > 1 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={<Trash2 className="w-3.5 h-3.5 text-red-400" />}
                    onClick={() => handleRemoveItem(item.id)}
                  />
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <Input
                    label={t('common.asset', 'Asset Name')}
                    placeholder="e.g., Main Chiller"
                    value={item.asset}
                    onChange={(e) => handleItemChange(item.id, 'asset', e.target.value)}
                  />
                </div>
                <div>
                  <Select
                    label={t('common.category', 'Category')}
                    options={categories}
                    value={item.category}
                    onChange={(e) => handleItemChange(item.id, 'category', e.target.value)}
                  />
                </div>
                <div>
                  <Input
                    type="number"
                    label={t('common.estimatedCost', 'Estimated Cost (AED)')}
                    placeholder="0"
                    value={String(item.estimatedCost)}
                    onChange={(e) => handleItemChange(item.id, 'estimatedCost', Number(e.target.value))}
                  />
                </div>
                <div>
                  <Select
                    label={t('common.priority', 'Priority')}
                    options={priorities}
                    value={item.priority}
                    onChange={(e) => handleItemChange(item.id, 'priority', e.target.value)}
                  />
                </div>
                <div>
                  <Select
                    label={t('capex.scheduledQuarter', 'Scheduled Quarter')}
                    options={quarters}
                    value={item.scheduledQuarter}
                    onChange={(e) => handleItemChange(item.id, 'scheduledQuarter', e.target.value)}
                  />
                </div>
                <div>
                  <Input
                    label={t('capex.expectedROI', 'Expected ROI')}
                    placeholder="e.g., 15% energy savings"
                    value={item.expectedROI}
                    onChange={(e) => handleItemChange(item.id, 'expectedROI', e.target.value)}
                  />
                </div>
                <div className="md:col-span-2">
                  <Input
                    label={t('common.description', 'Description')}
                    placeholder="Brief description of the replacement/upgrade"
                    value={item.description}
                    onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                  />
                </div>
                <div className="md:col-span-3">
                  <Textarea
                    label={t('capex.justification', 'Justification')}
                    placeholder="Explain the business case for this CAPEX item..."
                    value={item.justification}
                    onChange={(e) => handleItemChange(item.id, 'justification', e.target.value)}
                    rows={2}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Total Budget Summary */}
        <div className="mt-4 pt-4 border-t border-[#2d2d4a]">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="flex flex-wrap gap-4">
              <div className="px-4 py-2 bg-red-900/20 border border-red-800/30 rounded-lg">
                <p className="text-xs text-red-400">{t('common.critical', 'Critical')}</p>
                <p className="text-sm font-bold text-red-300">AED {criticalTotal.toLocaleString()}</p>
              </div>
              <div className="px-4 py-2 bg-amber-900/20 border border-amber-800/30 rounded-lg">
                <p className="text-xs text-amber-400">{t('common.high', 'High')}</p>
                <p className="text-sm font-bold text-amber-300">AED {highTotal.toLocaleString()}</p>
              </div>
              <div className="px-4 py-2 bg-blue-900/20 border border-blue-800/30 rounded-lg">
                <p className="text-xs text-blue-400">{t('common.medium', 'Medium')}</p>
                <p className="text-sm font-bold text-blue-300">AED {mediumTotal.toLocaleString()}</p>
              </div>
            </div>
            <div className="text-end">
              <div className="flex items-center gap-2 mb-1">
                <Calculator className="w-4 h-4 text-[#c9a962]" />
                <span className="text-sm text-slate-400">{t('common.totalBudget', 'Total Budget')}</span>
              </div>
              <p className="text-2xl font-bold text-[#c9a962]">
                AED {totalBudget.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default CapexPlanForm;
