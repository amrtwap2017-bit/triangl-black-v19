import { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Building2, Filter, MapPin, Calendar, ArrowUpRight } from 'lucide-react';
import { Card, PageHeader, Button, Select, Badge, Table } from '@/shared/components/ui';
import type { Column } from '@/shared/types';

interface RoadmapEntry {
  id: string;
  hotel: string;
  asset: string;
  category: string;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  year: number;
  quarter: string;
  estimatedCost: number;
  status: 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED' | 'DEFERRED';
  description: string;
}

const mockRoadmap: RoadmapEntry[] = [
  { id: 'rm1', hotel: 'Burj Al Arab', asset: 'Main Chiller Plant', category: 'HVAC', priority: 'CRITICAL', year: 2024, quarter: 'Q1', estimatedCost: 4500000, status: 'IN_PROGRESS', description: 'Full chiller plant replacement' },
  { id: 'rm2', hotel: 'Burj Al Arab', asset: 'Fire Alarm Panel', category: 'Fire Protection', priority: 'CRITICAL', year: 2024, quarter: 'Q2', estimatedCost: 850000, status: 'PLANNED', description: 'Upgrade to addressable system' },
  { id: 'rm3', hotel: 'Burj Al Arab', asset: 'Elevator #3 Motor', category: 'Electrical', priority: 'HIGH', year: 2024, quarter: 'Q3', estimatedCost: 1200000, status: 'PLANNED', description: 'Motor and drive replacement' },
  { id: 'rm4', hotel: 'Burj Al Arab', asset: 'Roof Waterproofing', category: 'Waterproofing', priority: 'HIGH', year: 2024, quarter: 'Q4', estimatedCost: 680000, status: 'PLANNED', description: 'Membrane replacement for Tower A' },
  { id: 'rm5', hotel: 'Atlantis The Royal', asset: 'AHU Replacement', category: 'HVAC', priority: 'HIGH', year: 2024, quarter: 'Q2', estimatedCost: 2100000, status: 'PLANNED', description: '10 AHU units replacement' },
  { id: 'rm6', hotel: 'Atlantis The Royal', asset: 'BMS Server', category: 'BMS', priority: 'MEDIUM', year: 2024, quarter: 'Q3', estimatedCost: 350000, status: 'DEFERRED', description: 'Hardware upgrade deferred to 2025' },
  { id: 'rm7', hotel: 'Mandarin Oriental', asset: 'Pool Heat Pump', category: 'HVAC', priority: 'MEDIUM', year: 2025, quarter: 'Q1', estimatedCost: 280000, status: 'PLANNED', description: 'New heat pump system for infinity pool' },
  { id: 'rm8', hotel: 'Four Seasons DIFC', asset: 'Emergency Generator', category: 'Electrical', priority: 'CRITICAL', year: 2025, quarter: 'Q2', estimatedCost: 3200000, status: 'PLANNED', description: '500kVA generator replacement' },
  { id: 'rm9', hotel: 'Ritz Carlton', asset: 'Hot Water System', category: 'Plumbing', priority: 'HIGH', year: 2025, quarter: 'Q1', estimatedCost: 750000, status: 'PLANNED', description: 'Calorifier replacement' },
  { id: 'rm10', hotel: 'Burj Al Arab', asset: 'Kitchen Ventilation', category: 'HVAC', priority: 'MEDIUM', year: 2025, quarter: 'Q1', estimatedCost: 520000, status: 'PLANNED', description: 'Kitchen exhaust fan replacement' },
  { id: 'rm11', hotel: 'JW Marriott Marquis', asset: 'Chilled Water Pipes', category: 'HVAC', priority: 'HIGH', year: 2025, quarter: 'Q3', estimatedCost: 1400000, status: 'PLANNED', description: 'Insulated piping replacement Level 15-30' },
  { id: 'rm12', hotel: 'Four Seasons DIFC', asset: 'Lobby Lighting', category: 'Electrical', priority: 'LOW', year: 2025, quarter: 'Q4', estimatedCost: 180000, status: 'PLANNED', description: 'LED upgrade and control system' },
  { id: 'rm13', hotel: 'Burj Al Arab', asset: 'Guest Room Thermostats', category: 'BMS', priority: 'MEDIUM', year: 2026, quarter: 'Q2', estimatedCost: 420000, status: 'PLANNED', description: 'Smart thermostat rollout — 282 rooms' },
  { id: 'rm14', hotel: 'Mandarin Oriental', asset: 'Electrical Switchgear', category: 'Electrical', priority: 'CRITICAL', year: 2026, quarter: 'Q1', estimatedCost: 1800000, status: 'PLANNED', description: 'Main LV switchgear replacement' },
];

const getStatusVariant = (s: string) => {
  switch (s) {
    case 'PLANNED': return 'info';
    case 'IN_PROGRESS': return 'warning';
    case 'COMPLETED': return 'success';
    case 'DEFERRED': return 'default';
    default: return 'default';
  }
};

const getPriorityVariant = (p: string) => {
  switch (p) {
    case 'CRITICAL': return 'danger';
    case 'HIGH': return 'warning';
    case 'MEDIUM': return 'info';
    case 'LOW': return 'default';
    default: return 'default';
  }
};

const getStatusDotColor = (s: string) => {
  switch (s) {
    case 'PLANNED': return 'bg-blue-500';
    case 'IN_PROGRESS': return 'bg-amber-500';
    case 'COMPLETED': return 'bg-green-500';
    case 'DEFERRED': return 'bg-slate-500';
    default: return 'bg-slate-500';
  }
};

const CapexRoadmap: React.FC = () => {
  const { t } = useTranslation();
  const [categoryFilter, setCategoryFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [yearFilter, setYearFilter] = useState('');

  const filteredData = useMemo(() => {
    return mockRoadmap.filter((item) => {
      const matchesCategory = !categoryFilter || item.category === categoryFilter;
      const matchesPriority = !priorityFilter || item.priority === priorityFilter;
      const matchesYear = !yearFilter || item.year === Number(yearFilter);
      return matchesCategory && matchesPriority && matchesYear;
    });
  }, [categoryFilter, priorityFilter, yearFilter]);

  const uniqueHotels = useMemo(() => {
    return [...new Set(filteredData.map((i) => i.hotel))];
  }, [filteredData]);

  const columns: Column<RoadmapEntry>[] = useMemo(() => [
    { key: 'hotel', header: t('common.hotel', 'Hotel'), render: (v) => (
      <div className="flex items-center gap-1.5">
        <Building2 className="w-3.5 h-3.5 text-[#c9a962]" />
        <span className="font-medium text-slate-100">{v as string}</span>
      </div>
    )},
    { key: 'asset', header: t('common.asset', 'Asset'), render: (v) => <span className="font-medium text-slate-200">{v as string}</span> },
    { key: 'category', header: t('common.category', 'Category'), width: 'w-28' },
    { key: 'priority', header: t('common.priority', 'Priority'), width: 'w-24', render: (v) => <Badge variant={getPriorityVariant(v as string)}>{v as string}</Badge> },
    { key: 'year', header: t('common.year', 'Year'), width: 'w-16', align: 'center' },
    { key: 'quarter', header: t('common.quarter', 'Qtr'), width: 'w-16', align: 'center' },
    { key: 'estimatedCost', header: t('common.estimatedCost', 'Est. Cost'), align: 'end', width: 'w-32', render: (v) => <span className="text-[#c9a962] font-medium">AED {(v as number).toLocaleString()}</span> },
    { key: 'status', header: t('common.status', 'Status'), width: 'w-28', render: (v) => <Badge variant={getStatusVariant(v as string)}>{v as string}</Badge> },
  ], [t]);

  // Group by hotel and year for visual roadmap
  const roadmapByHotel = useMemo(() => {
    const grouped: Record<string, Record<number, RoadmapEntry[]>> = {};
    filteredData.forEach((item) => {
      if (!grouped[item.hotel]) grouped[item.hotel] = {};
      if (!grouped[item.hotel][item.year]) grouped[item.hotel][item.year] = [];
      grouped[item.hotel][item.year].push(item);
    });
    return grouped;
  }, [filteredData]);

  const yearsInRange = useMemo(() => {
    const years = new Set(filteredData.map((i) => i.year));
    return Array.from(years).sort();
  }, [filteredData]);

  const totalPlanned = filteredData.reduce((s, i) => s + i.estimatedCost, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('capex.roadmap', 'CAPEX Roadmap')}
        subtitle={t('capex.roadmapSubtitle', 'Visual replacement plan across all hotels')}
        actions={
          <Button variant="secondary" icon={<ArrowUpRight className="w-4 h-4" />}>
            {t('common.export', 'Export')}
          </Button>
        }
      />

      {/* Filters */}
      <Card>
        <div className="flex flex-wrap items-center gap-3">
          <Filter className="w-4 h-4 text-slate-400" />
          <div className="w-44">
            <Select
              options={[
                { value: '', label: t('common.allCategories', 'All Categories') },
                { value: 'HVAC', label: 'HVAC' },
                { value: 'Electrical', label: 'Electrical' },
                { value: 'Plumbing', label: 'Plumbing' },
                { value: 'Fire Protection', label: 'Fire Protection' },
                { value: 'BMS', label: 'BMS' },
                { value: 'Waterproofing', label: 'Waterproofing' },
              ]}
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
            />
          </div>
          <div className="w-40">
            <Select
              options={[
                { value: '', label: t('common.allPriorities', 'All Priorities') },
                { value: 'CRITICAL', label: 'Critical' },
                { value: 'HIGH', label: 'High' },
                { value: 'MEDIUM', label: 'Medium' },
                { value: 'LOW', label: 'Low' },
              ]}
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            />
          </div>
          <div className="w-32">
            <Select
              options={[
                { value: '', label: t('common.allYears', 'All Years') },
                { value: '2024', label: '2024' },
                { value: '2025', label: '2025' },
                { value: '2026', label: '2026' },
                { value: '2027', label: '2027' },
                { value: '2028', label: '2028' },
              ]}
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
            />
          </div>
          <div className="ms-auto">
            <Badge variant="info">{filteredData.length} {t('capex.items', 'items')} • AED {(totalPlanned / 1000000).toFixed(1)}M</Badge>
          </div>
        </div>
      </Card>

      {/* Visual Roadmap by Hotel */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('capex.roadmapByHotel', 'Roadmap by Hotel')}</h3>}>
        <div className="overflow-x-auto">
          <div className="min-w-[900px] space-y-6">
            {uniqueHotels.map((hotelName) => (
              <div key={hotelName}>
                {/* Hotel Header */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full bg-[#c9a962]" />
                  <span className="text-sm font-semibold text-slate-100">{hotelName}</span>
                </div>

                {/* Timeline grid */}
                <div className="flex border-t border-[#2d2d4a]">
                  {/* Year headers */}
                  <div className="w-36 shrink-0 pt-2" />
                  <div className="flex-1 flex">
                    {yearsInRange.map((yr) => (
                      <div key={yr} className="flex-1 text-center text-xs font-semibold text-slate-400 pt-2 pb-3">
                        {yr}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Rows per hotel */}
                {(roadmapByHotel[hotelName] ? Object.entries(roadmapByHotel[hotelName]) : []).map(
                  ([yr, items]) =>
                    items.map((item) => (
                      <div key={item.id} className="flex border-t border-[#2d2d4a]/30">
                        <div className="w-36 shrink-0 py-2 pr-2">
                          <p className="text-xs font-medium text-slate-300 truncate">{item.asset}</p>
                        </div>
                        <div className="flex-1 flex">
                          {yearsInRange.map((yr) => (
                            <div key={yr} className="flex-1 p-1">
                              {Number(yr) === item.year ? (
                                <div className={`p-2 rounded-lg border text-xs h-full ${
                                  item.status === 'IN_PROGRESS'
                                    ? 'bg-amber-900/20 border-amber-800/30'
                                    : item.status === 'COMPLETED'
                                    ? 'bg-green-900/20 border-green-800/30'
                                    : item.status === 'DEFERRED'
                                    ? 'bg-[#15152a] border-[#2d2d4a]'
                                    : 'bg-blue-900/20 border-blue-800/30'
                                }`}>
                                  <div className="flex items-center gap-1 mb-1">
                                    <div className={`w-1.5 h-1.5 rounded-full ${getStatusDotColor(item.status)}`} />
                                    <span className="font-medium text-slate-200">{item.quarter}</span>
                                  </div>
                                  <span className="text-slate-400">AED {(item.estimatedCost / 1000).toFixed(0)}K</span>
                                </div>
                              ) : (
                                <div />
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    ))
                )}
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Table View */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('capex.allItems', 'All Planned Items')}</h3>}>
        <Table columns={columns} data={filteredData} keyExtractor={(r) => r.id} />
      </Card>
    </div>
  );
};

export default CapexRoadmap;
