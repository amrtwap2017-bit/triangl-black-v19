import { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Upload, FileText, Download, Trash2, Filter, Image as ImageIcon } from 'lucide-react';
import { PageHeader, SearchBar, Select, Card, Button, Badge, ConfirmDialog, StatusBadge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { Document, Column } from '@/shared/types';
import { apiDelete } from '@/api/client';
import toast from 'react-hot-toast';
import { useState as useReactState } from 'react';

const DocumentsList: React.FC = () => {
  const { t } = useTranslation();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const { page, limit, setPage, paginationParams } = usePagination(20);

  const { data: documents, isLoading, meta, refetch } = useApi<Document>(
    ['documents'], endpoints.documents.list,
    { ...paginationParams(), search, category: categoryFilter }
  );

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await apiDelete(endpoints.documents.delete(deleteId));
      toast.success(t('common.success'));
      setDeleteId(null);
      refetch();
    } catch { toast.error(t('common.error')); }
  };

  const columns: Column<Document>[] = useMemo(() => [
    { key: 'title', header: t('common.name'), sortable: true, render: (_, row) => (
      <div className="flex items-center gap-3">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${row.category === 'PHOTO' ? 'bg-green-900/30 text-green-400' : 'bg-[#252540] text-slate-400'}`}>
          {row.category === 'PHOTO' ? <ImageIcon className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
        </div>
        <div>
          <p className="font-medium text-slate-100">{row.title}</p>
          <p className="text-xs text-slate-500">{row.fileType} • {(row.fileSize / 1024).toFixed(0)} KB</p>
        </div>
      </div>
    )},
    { key: 'category', header: t('documents.category'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'uploadedBy', header: 'Uploaded By', render: (_, row) => row.uploadedBy?.name || '—' },
    { key: 'version', header: t('proposals.version'), align: 'center', render: (v) => <Badge>v{v}</Badge> },
    { key: 'createdAt', header: t('common.date'), width: 'w-28', render: (v) => new Date(v as string).toLocaleDateString() },
    { key: 'actions', header: t('common.actions'), width: 'w-24', align: 'center', render: (_, row) => (
      <div className="flex items-center justify-center gap-1">
        <button onClick={(e) => { e.stopPropagation(); }} className="p-1 text-slate-400 hover:text-slate-100"><Download className="w-4 h-4" /></button>
        <button onClick={(e) => { e.stopPropagation(); setDeleteId(row.id); }} className="p-1 text-slate-400 hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
      </div>
    )},
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('documents.title')} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[{value:'',label:t('common.all')},{value:'CONTRACT',label:t('documents.contracts')},{value:'DRAWING',label:t('documents.drawings')},{value:'PHOTO',label:t('documents.photos')},{value:'REPORT',label:t('documents.reports')},{value:'WARRANTY',label:t('documents.warranties')},{value:'PROPOSAL',label:t('documents.proposals')},{value:'BOQ',label:t('documents.boq')},{value:'METHOD_STATEMENT',label:t('documents.methodStatements')},{value:'CERTIFICATE',label:t('documents.certificates')},{value:'OTHER',label:t('documents.other')}]} value={categoryFilter} onChange={(e)=>setCategoryFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={documents} keyExtractor={(d)=>d.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} />
      </Card>
      <ConfirmDialog isOpen={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} />
    </div>
  );
};

export default DocumentsList;