import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import toast from 'react-hot-toast';
import { Save } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button, FileUpload } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const UploadForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [files, setFiles] = useState<File[]>([]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = {
      title: (form.elements.namedItem('title') as HTMLInputElement).value,
      description: (form.elements.namedItem('description') as HTMLTextAreaElement).value,
      category: (form.elements.namedItem('category') as HTMLSelectElement).value,
      projectId: (form.elements.namedItem('projectId') as HTMLInputElement).value || undefined,
    };
    if (!data.title || !data.category) { toast.error('Title and category required'); return; }
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('data', JSON.stringify(data));
      files.forEach((f) => formData.append('files', f));
      await apiPost(endpoints.documents.upload, formData);
      toast.success(t('common.success'));
      navigate('/documents');
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title={t('documents.upload')} showBack backTo="/documents" />
      <form onSubmit={handleSubmit}>
        <Card>
          <div className="space-y-6">
            <Input label={t('common.name')} name="title" required />
            <Select label={t('documents.category')} name="category" required options={[{value:'CONTRACT',label:t('documents.contracts')},{value:'DRAWING',label:t('documents.drawings')},{value:'PHOTO',label:t('documents.photos')},{value:'REPORT',label:t('documents.reports')},{value:'WARRANTY',label:t('documents.warranties')},{value:'PROPOSAL',label:t('documents.proposals')},{value:'BOQ',label:t('documents.boq')},{value:'METHOD_STATEMENT',label:t('documents.methodStatements')},{value:'CERTIFICATE',label:t('documents.certificates')},{value:'OTHER',label:t('documents.other')}]} />
            <Input label="Project ID (optional)" name="projectId" />
            <Textarea label={t('common.description')} name="description" rows={3} />
            <FileUpload label={t('common.upload')} onFilesSelected={setFiles} multiple />
            <div className="flex justify-end gap-3 pt-6 border-t border-[#2d2d4a]">
              <Button variant="ghost" onClick={() => navigate('/documents')}>{t('common.cancel')}</Button>
              <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
            </div>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default UploadForm;