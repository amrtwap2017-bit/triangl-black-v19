import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useNavigate } from 'react-router-dom';
import { Brain, Download, FileText, AlertTriangle, Package, Wrench, Target } from 'lucide-react';
import { Card, PageHeader, Badge, Button, LoadingSpinner } from '@/shared/components/ui';
import { apiPost } from '@/api/client';

interface AnalysisResult {
  boqSuggestions: { item: string; quantity: string; unit: string; estimatedCost: number }[];
  materialEstimates: { material: string; quantity: string; unit: string }[];
  scopeRecommendations: { area: string; recommendation: string; priority: string }[];
  risks: { description: string; severity: string; mitigation: string }[];
}

const DrawingDetail: React.FC = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);

  // Mock data
  const drawing = {
    id: id || '1',
    title: 'HVAC Layout — Floor 5',
    type: 'HVAC_LAYOUT',
    hotel: { name: 'Burj Al Arab' },
    status: 'APPROVED',
    version: 3,
    updatedAt: '2025-01-15',
    fileUrl: '#',
  };

  const mockAnalysis: AnalysisResult = {
    boqSuggestions: [
      { item: 'FCU (Concealed)', quantity: '48', unit: 'nos', estimatedCost: 96000 },
      { item: 'AHU (Medium Pressure)', quantity: '2', unit: 'nos', estimatedCost: 48000 },
      { item: 'Ductwork (GI)', quantity: '850', unit: 'm²', estimatedCost: 42500 },
      { item: 'Chilled Water Pipe (Copper)', quantity: '320', unit: 'm', estimatedCost: 38400 },
      { item: 'Insulation (Rubber)', quantity: '1200', unit: 'm²', estimatedCost: 18000 },
    ],
    materialEstimates: [
      { material: 'Galvanized Iron Sheet (0.8mm)', quantity: '142', unit: 'sheets' },
      { material: 'Copper Pipe (28mm)', quantity: '85', unit: 'm' },
      { material: 'Duct Insulation (25mm)', quantity: '1200', unit: 'm²' },
      { material: 'Hangers & Supports', quantity: '340', unit: 'sets' },
    ],
    scopeRecommendations: [
      { area: 'Air Distribution', recommendation: 'Add VAV boxes for energy efficiency in suites', priority: 'MEDIUM' },
      { area: 'Condensate Drainage', recommendation: 'Include condensate pump for low-point FCUs', priority: 'HIGH' },
      { area: 'BMS Integration', recommendation: 'All FCUs and AHUs to be BMS-connected', priority: 'HIGH' },
    ],
    risks: [
      { description: 'Limited ceiling void space in corridor areas', severity: 'HIGH', mitigation: 'Coordinate with interior design for bulkhead allowances' },
      { description: 'Existing structural beam conflicts at grid line C-D', severity: 'MEDIUM', mitigation: 'Route ductwork below beam with fire-rated enclosure' },
    ],
  };

  const handleAnalyze = async () => {
    if (!id) return;
    setAnalyzing(true);
    try {
      const result = await apiPost<AnalysisResult>(`/drawings/${id}/analyze`);
      setAnalysis(result);
    } catch {
      setAnalysis(mockAnalysis);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={drawing.title}
        showBack
        backTo="/drawings"
        actions={
          <div className="flex gap-2">
            <Button variant="secondary" icon={<Download className="w-4 h-4" />}>{t('common.download')}</Button>
            <Button icon={<Brain className="w-4 h-4" />} loading={analyzing} onClick={handleAnalyze}>
              {t('drawings.analyze')}
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Drawing Preview */}
        <div className="lg:col-span-2">
          <Card>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Badge variant="success">{drawing.status}</Badge>
                <span className="text-xs text-slate-400">v{drawing.version}</span>
              </div>
              <div className="text-xs text-slate-400">
                {drawing.hotel.name} • {new Date(drawing.updatedAt).toLocaleDateString()}
              </div>
            </div>
            {/* Drawing preview area */}
            <div className="bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg h-[500px] flex items-center justify-center">
              <div className="text-center">
                <FileText className="w-16 h-16 text-slate-600 mx-auto mb-3" />
                <p className="text-sm text-slate-400">Drawing Preview</p>
                <p className="text-xs text-slate-500 mt-1">PDF/DWG viewer will render here</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Analysis Sidebar */}
        <div className="space-y-6">
          {!analysis ? (
            <Card className="text-center py-12">
              <Brain className="w-12 h-12 text-slate-600 mx-auto mb-3" />
              <p className="text-sm text-slate-400 mb-4">{t('drawings.analysisResults')}</p>
              <Button icon={<Brain className="w-4 h-4" />} loading={analyzing} onClick={handleAnalyze}>
                {t('drawings.analyze')}
              </Button>
            </Card>
          ) : (
            <>
              {/* BOQ Suggestions */}
              <Card header={<h3 className="text-base font-semibold text-slate-100 flex items-center gap-2"><Package className="w-4 h-4 text-[#c9a962]" /> {t('drawings.boqSuggestions')}</h3>}>
                <div className="space-y-2 max-h-60 overflow-y-auto scrollbar-thin">
                  {analysis.boqSuggestions.map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-[#0f0f1a] rounded text-xs">
                      <div>
                        <p className="text-slate-200">{item.item}</p>
                        <p className="text-slate-500">{item.quantity} {item.unit}</p>
                      </div>
                      <span className="text-[#c9a962] font-medium">AED {item.estimatedCost.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Material Estimates */}
              <Card header={<h3 className="text-base font-semibold text-slate-100 flex items-center gap-2"><Wrench className="w-4 h-4 text-[#c9a962]" /> {t('drawings.materialEstimates')}</h3>}>
                <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin">
                  {analysis.materialEstimates.map((m, i) => (
                    <div key={i} className="flex justify-between p-2 bg-[#0f0f1a] rounded text-xs">
                      <span className="text-slate-300">{m.material}</span>
                      <span className="text-slate-400">{m.quantity} {m.unit}</span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Risks */}
              <Card header={<h3 className="text-base font-semibold text-slate-100 flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-red-400" /> {t('drawings.risks')}</h3>}>
                <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin">
                  {analysis.risks.map((r, i) => (
                    <div key={i} className="p-2 bg-[#0f0f1a] rounded border border-[#2d2d4a]">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-slate-200">{r.description}</span>
                        <Badge variant={r.severity === 'HIGH' ? 'danger' : 'warning'}>{r.severity}</Badge>
                      </div>
                      <p className="text-[11px] text-slate-500">{r.mitigation}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default DrawingDetail;