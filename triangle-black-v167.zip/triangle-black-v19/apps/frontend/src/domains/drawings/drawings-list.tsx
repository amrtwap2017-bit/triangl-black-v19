import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Upload, FileText, Eye } from 'lucide-react';
import { PageHeader, SearchBar, Button, Card, Badge, Select, FileUpload } from '@/shared/components/ui';
import { Modal } from '@/shared/components/ui';
import { apiPost } from '@/api/client';

interface Drawing {
  id: string;
  title: string;
  type: string;
  hotel: { name: string };
  status: string;
  thumbnailUrl?: string;
  version: number;
  updatedAt: string;
}

const typeOptions = [
  { value: 'ALL', label: 'All Types' },
  { value: 'HVAC_LAYOUT', label: 'HVAC Layout' },
  { value: 'ELECTRICAL_LAYOUT', label: 'Electrical Layout' },
  { value: 'PLUMBING', label: 'Plumbing' },
  { value: 'FIRE_PROTECTION', label: 'Fire Protection' },
  { value: 'STRUCTURAL', label: 'Structural' },
  { value: 'ARCHITECTURAL', label: 'Architectural' },
];

const statusVariant: Record<string, 'default' | 'success' | 'warning' | 'danger' | 'info'> = {
  DRAFT: 'default',
  REVIEW: 'warning',
  APPROVED: 'success',
  SUPERSEDED: 'danger',
  ANALYZED: 'info',
};

const mockDrawings: Drawing[] = [
  { id: '1', title: 'HVAC Layout — Floor 5', type: 'HVAC_LAYOUT', hotel: { name: 'Burj Al Arab' }, status: 'APPROVED', version: 3, updatedAt: '2025-01-15' },
  { id: '2', title: 'Electrical SLD — Main Distribution', type: 'ELECTRICAL_LAYOUT', hotel: { name: 'Atlantis The Royal' }, status: 'REVIEW', version: 2, updatedAt: '2025-01-14' },
  { id: '3', title: 'Plumbing Isometric — Guest Rooms', type: 'PLUMBING', hotel: { name: 'Burj Al Arab' }, status: 'ANALYZED', version: 1, updatedAt: '2025-01-12' },
  { id: '4', title: 'Fire Protection — Basement Parking', type: 'FIRE_PROTECTION', hotel: { name: 'Mandarin Oriental' }, status: 'DRAFT', version: 1, updatedAt: '2025-01-10' },
  { id: '5', title: 'HVAC Duct Layout — Lobby', type: 'HVAC_LAYOUT', hotel: { name: 'Four Seasons DIFC' }, status: 'APPROVED', version: 2, updatedAt: '2025-01-08' },
  { id: '6', title: 'Electrical Layout — Kitchen Area', type: 'ELECTRICAL_LAYOUT', hotel: { name: 'Ritz Carlton' }, status: 'SUPERSEDED', version: 4, updatedAt: '2025-01-05' },
];

const DrawingsList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [uploadModal, setUploadModal] = useState(false);
  const [uploadFiles, setUploadFiles] = useState<File[]>([]);

  const filtered = useMemo(() => {
    return mockDrawings.filter((d) => {
      const matchSearch = !search || d.title.toLowerCase().includes(search.toLowerCase()) || d.hotel.name.toLowerCase().includes(search.toLowerCase());
      const matchType = typeFilter === 'ALL' || d.type === typeFilter;
      return matchSearch && matchType;
    });
  }, [search, typeFilter]);

  const getTypeLabel = (key: string) => {
    const found = typeOptions.find((o) => o.value === key);
    return found ? found.label : key;
  };

  const handleUpload = async () => {
    if (uploadFiles.length === 0) return;
    try {
      const formData = new FormData();
      uploadFiles.forEach((f) => formData.append('files', f));
      await apiPost('/drawings/upload', formData);
      setUploadModal(false);
      setUploadFiles([]);
    } catch {
      // handle error
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('drawings.title')}
        actions={
          <Button icon={<Upload className="w-4 h-4" />} onClick={() => setUploadModal(true)}>
            {t('drawings.upload')}
          </Button>
        }
      />

      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select
            options={typeOptions}
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
          />
        </div>

        <div className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((drawing) => (
              <div
                key={drawing.id}
                onClick={() => navigate(`/drawings/${drawing.id}`)}
                className="bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg overflow-hidden hover:border-[#c9a962]/40 transition-colors cursor-pointer group"
              >
                {/* Thumbnail */}
                <div className="h-40 bg-[#252540] flex items-center justify-center relative">
                  <FileText className="w-12 h-12 text-slate-600 group-hover:text-[#c9a962]/50 transition-colors" />
                  <div className="absolute top-2 end-2 flex gap-1.5">
                    <Badge variant={statusVariant[drawing.status] || 'default'}>{drawing.status}</Badge>
                  </div>
                </div>
                <div className="p-3">
                  <h3 className="text-sm font-semibold text-slate-100 mb-1.5 line-clamp-1">{drawing.title}</h3>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">{drawing.hotel.name}</span>
                    <Badge>{getTypeLabel(drawing.type)}</Badge>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-[10px] text-slate-500">v{drawing.version}</span>
                    <span className="text-[10px] text-slate-500">{new Date(drawing.updatedAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Upload Modal */}
      <Modal
        isOpen={uploadModal}
        onClose={() => setUploadModal(false)}
        title={t('drawings.upload')}
        size="lg"
        footer={
          <>
            <Button variant="secondary" onClick={() => setUploadModal(false)}>{t('common.cancel')}</Button>
            <Button onClick={handleUpload}>{t('common.upload')}</Button>
          </>
        }
      >
        <FileUpload
          onFilesSelected={setUploadFiles}
          accept=".pdf,.dwg,.dxf,.png,.jpg"
          multiple
          label="Select drawing files"
        />
      </Modal>
    </div>
  );
};

export default DrawingsList;