import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowUpCircle, CheckCircle, Clock, Building2, User, AlertTriangle, ShieldAlert } from 'lucide-react';
import { PageHeader, Card, Button, Badge, LoadingSpinner, EmptyState, StatusBadge, Modal, Textarea, Select } from '@/shared/components/ui';
import { useApiSingle } from '@/shared/hooks';
import { apiPost, apiPatch } from '@/api/client';
import { endpoints } from '@/api/endpoints';
import toast from 'react-hot-toast';
import type { EmergencyCase } from '@/shared/types';

const EmergencyDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [showResolveModal, setShowResolveModal] = useState(false);
  const [resolution, setResolution] = useState('');
  const [rootCause, setRootCause] = useState('');
  const [preventiveMeasures, setPreventiveMeasures] = useState('');
  const [assignUserId, setAssignUserId] = useState('');

  const { data: emergency, isLoading } = useApiSingle<EmergencyCase>(['emergency', id!], `/emergency/${id}`);

  if (isLoading) return <LoadingSpinner />;
  if (!emergency) return <EmptyState message="Emergency case not found" />;

  const handleResolve = async () => {
    try {
      await apiPost(endpoints.emergency.resolve(id!), { resolution, rootCause, preventiveMeasures });
      toast.success(t('common.success'));
      setShowResolveModal(false);
    } catch { toast.error(t('common.error')); }
  };

  const handleEscalate = async () => {
    try {
      await apiPost(endpoints.emergency.escalate(id!));
      toast.success('Escalated');
    } catch { toast.error(t('common.error')); }
  };

  const handleAssign = async () => {
    try {
      await apiPost(endpoints.emergency.assign(id!), { userId: assignUserId });
      toast.success(t('common.success'));
    } catch { toast.error(t('common.error')); }
  };

  const isOpen = ['OPEN', 'IN_PROGRESS', 'ESCALATED'].includes(emergency.status);

  return (
    <div className="space-y-6">
      <PageHeader title={`${t('emergency.caseNumber')}${emergency.caseNumber}`} subtitle={emergency.title} breadcrumbs={[{label:t('emergency.title'),href:'/emergency'},{label:emergency.caseNumber}]} showBack actions={
        <div className="flex gap-2">
          {isOpen && (
            <>
              <Button variant="secondary" icon={<ArrowUpCircle className="w-4 h-4" />} onClick={handleEscalate}>{t('emergency.escalate')}</Button>
              <Button icon={<CheckCircle className="w-4 h-4" />} onClick={() => setShowResolveModal(true)}>{t('emergency.resolve')}</Button>
            </>
          )}
        </div>
      }}/>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card header={<h4 className="font-semibold text-slate-200">Description</h4>}>
            <p className="text-sm text-slate-300 whitespace-pre-wrap">{emergency.description}</p>
          </Card>
          {emergency.resolution && (
            <Card header={<h4 className="font-semibold text-slate-200">{t('emergency.resolution')}</h4>}>
              <p className="text-sm text-slate-300">{emergency.resolution}</p>
              {emergency.rootCause && <div className="mt-4"><p className="text-xs text-slate-400 mb-1">{t('emergency.rootCause')}</p><p className="text-sm text-slate-300">{emergency.rootCause}</p></div>}
              {emergency.preventiveMeasures && <div className="mt-4"><p className="text-xs text-slate-400 mb-1">{t('emergency.preventiveMeasures')}</p><p className="text-sm text-slate-300">{emergency.preventiveMeasures}</p></div>}
            </Card>
          )}
        </div>
        <div className="space-y-6">
          <Card>
            <div className="space-y-4">
              <div><p className="text-xs text-slate-400">{t('common.status')}</p><StatusBadge status={emergency.status} className="mt-1" /></div>
              <div><p className="text-xs text-slate-400">{t('emergency.severity')}</p><StatusBadge status={emergency.severity} className="mt-1" /></div>
              {emergency.responseTime && <div><p className="text-xs text-slate-400">{t('emergency.responseTime')}</p><p className="text-sm font-semibold text-slate-200 mt-1">{Math.round(emergency.responseTime)} minutes</p></div>}
              {emergency.slaTarget && <div><p className="text-xs text-slate-400">SLA Target</p><p className="text-sm text-slate-200 mt-1">{emergency.slaTarget} minutes</p></div>}
              {emergency.hotel && <div><p className="text-xs text-slate-400">{t('hotels.title')}</p><p className="text-sm text-slate-200 mt-1">{emergency.hotel.name}</p></div>}
              {emergency.guestImpact && <div><p className="text-xs text-slate-400">{t('emergency.guestImpact')}</p><p className="text-sm text-slate-200 mt-1">{emergency.guestImpact}</p></div>}
            </div>
          </Card>
          <Card>
            <h4 className="font-semibold text-slate-200 mb-3">Quick Assign</h4>
            <div className="flex gap-2">
              <input value={assignUserId} onChange={(e) => setAssignUserId(e.target.value)} placeholder="User ID" className="flex-1 bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-1.5 text-sm text-slate-100 focus:outline-none focus:ring-1 focus:ring-[#c9a962]/50" />
              <Button size="sm" onClick={handleAssign}>{t('requests.assign')}</Button>
            </div>
          </Card>
        </div>
      </div>

      <Modal isOpen={showResolveModal} onClose={() => setShowResolveModal(false)} title={t('emergency.resolve')} size="lg" footer={
        <><Button variant="ghost" onClick={() => setShowResolveModal(false)}>{t('common.cancel')}</Button><Button onClick={handleResolve}>{t('emergency.resolve')}</Button></>
      }>
        <div className="space-y-4">
          <Textarea label={t('emergency.resolution')} value={resolution} onChange={(e) => setResolution(e.target.value)} rows={4} />
          <Textarea label={t('emergency.rootCause')} value={rootCause} onChange={(e) => setRootCause(e.target.value)} rows={3} />
          <Textarea label={t('emergency.preventiveMeasures')} value={preventiveMeasures} onChange={(e) => setPreventiveMeasures(e.target.value)} rows={3} />
        </div>
      </Modal>
    </div>
  );
};

export default EmergencyDetail;