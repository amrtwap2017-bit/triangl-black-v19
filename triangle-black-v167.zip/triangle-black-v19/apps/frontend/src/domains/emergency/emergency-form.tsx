import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const schema = z.object({
  hotelId: z.string().min(1, 'Hotel required'),
  projectId: z.string().optional(),
  title: z.string().min(2, 'Title required'),
  description: z.string().min(10, 'Description required'),
  severity: z.string().min(1, 'Severity required'),
  guestImpact: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const EmergencyForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { severity: 'HIGH' },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await apiPost(endpoints.emergency.create, data);
      toast.success(t('common.success'));
      navigate('/emergency');
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title={t('emergency.newCase')} showBack backTo="/emergency" />
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Hotel ID" error={errors.hotelId?.message} {...register('hotelId')} />
            <Input label="Project ID (optional)" {...register('projectId')} />
            <Input label={t('common.name')} error={errors.title?.message} {...register('title')} className="md:col-span-2" />
            <Textarea label={t('common.description')} error={errors.description?.message} {...register('description')} className="md:col-span-2" rows={4} />
            <Select label={t('emergency.severity')} options={[{value:'LOW',label:'Low'},{value:'MEDIUM',label:'Medium'},{value:'HIGH',label:'High'},{value:'CRITICAL',label:'Critical'}]} error={errors.severity?.message} {...register('severity')} />
            <Textarea label={t('emergency.guestImpact')} {...register('guestImpact')} rows={3} />
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" onClick={() => navigate('/emergency')}>{t('common.cancel')}</Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default EmergencyForm;