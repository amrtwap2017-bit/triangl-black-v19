import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Clock, AlertTriangle } from 'lucide-react';
import { PageHeader, SearchBar, Button, Select, Card, Table, StatusBadge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { EmergencyCase, Column } from '@/shared/types';

const EmergencyList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: cases, isLoading, meta } = useApi<EmergencyCase>(
    ['emergency'], endpoints.emergency.list,
    { ...paginationParams(), search, severity: severityFilter, status: statusFilter }
  );

  const columns: Column<EmergencyCase>[] = useMemo(() => [
    { key: 'caseNumber', header: t('emergency.caseNumber'), width: 'w-36', sortable: true },
    { key: 'title', header: t('common.name'), sortable: true, render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.title}</p>
        <p className="text-xs text-slate-500">{row.hotel?.name}</p>
      </div>
    )},
    { key: 'severity', header: t('emergency.severity'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'status', header: t('common.status'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'responseTime', header: t('emergency.responseTime'), align: 'center', render: (v) => v ? `${Math.round(v as number)} min` : '—' },
    { key: 'assignedTo', header: t('requests.assign'), render: (_, row) => row.assignedTo?.name || '—' },
    { key: 'createdAt', header: t('common.date'), width: 'w-28', render: (v) => new Date(v as string).toLocaleDateString() },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('emergency.title')} actions={
        <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/emergency/new')}>{t('emergency.newCase')}</Button>
      )} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[{value:'',label:t('common.all')},{value:'LOW',label:'Low'},{value:'MEDIUM',label:'Medium'},{value:'HIGH',label:'High'},{value:'CRITICAL',label:'Critical'}]} value={severityFilter} onChange={(e)=>setSeverityFilter(e.target.value)} />
          <Select options={[{value:'',label:t('common.all')},{value:'OPEN',label:'Open'},{value:'IN_PROGRESS',label:'In Progress'},{value:'ESCALATED',label:'Escalated'},{value:'RESOLVED',label:'Resolved'}]} value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={cases} keyExtractor={(c)=>c.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} onRowClick={(c)=>navigate(`/emergency/${c.id}`)} />
      </Card>
    </div>
  );
};

export default EmergencyList;