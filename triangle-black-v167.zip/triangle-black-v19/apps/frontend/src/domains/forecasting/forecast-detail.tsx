import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  ArrowLeft,
  Calendar,
  Building2,
  TrendingUp,
  TrendingDown,
  Target,
  BarChart3,
} from 'lucide-react';
import { Card, PageHeader, Select, Badge, Table, StatCard, Button } from '@/shared/components/ui';
import type { Column } from '@/shared/types';

interface ForecastBreakdown {
  id: string;
  hotel: string;
  category: string;
  projectType: string;
  projectedValue: number;
  actualValue: number;
  confidence: number;
  status: 'ON_TRACK' | 'AT_RISK' | 'BEHIND';
  notes: string;
}

interface HistoricalComparison {
  period: string;
  projected: number;
  actual: number;
  variance: number;
}

const mockBreakdown: ForecastBreakdown[] = [
  { id: 'fb1', hotel: 'Burj Al Arab', category: 'HVAC', projectType: 'Maintenance', projectedValue: 1200000, actualValue: 1150000, confidence: 92, status: 'ON_TRACK', notes: 'Regular maintenance contracts' },
  { id: 'fb2', hotel: 'Burj Al Arab', category: 'Electrical', projectType: 'Capital', projectedValue: 850000, actualValue: 720000, confidence: 78, status: 'AT_RISK', notes: 'Switchgear project delayed' },
  { id: 'fb3', hotel: 'Atlantis The Royal', category: 'HVAC', projectType: 'Capital', projectedValue: 2100000, actualValue: 1900000, confidence: 85, status: 'ON_TRACK', notes: 'AHU replacement on schedule' },
  { id: 'fb4', hotel: 'Atlantis The Royal', category: 'Fire Protection', projectType: 'Maintenance', projectedValue: 450000, actualValue: 480000, confidence: 88, status: 'ON_TRACK', notes: 'Exceeded target' },
  { id: 'fb5', hotel: 'Mandarin Oriental', category: 'BMS', projectType: 'Capital', projectedValue: 650000, actualValue: 320000, confidence: 65, status: 'BEHIND', notes: 'Software integration delayed' },
  { id: 'fb6', hotel: 'Four Seasons DIFC', category: 'Plumbing', projectType: 'Maintenance', projectedValue: 380000, actualValue: 410000, confidence: 90, status: 'ON_TRACK', notes: 'Emergency repairs higher than expected' },
  { id: 'fb7', hotel: 'Ritz Carlton', category: 'HVAC', projectType: 'Capital', projectedValue: 1500000, actualValue: 800000, confidence: 70, status: 'AT_RISK', notes: 'Pending client approval' },
  { id: 'fb8', hotel: 'JW Marriott Marquis', category: 'Electrical', projectType: 'Maintenance', projectedValue: 520000, actualValue: 530000, confidence: 95, status: 'ON_TRACK', notes: 'On target' },
  { id: 'fb9', hotel: 'Burj Al Arab', category: 'BMS', projectType: 'Capital', projectedValue: 780000, actualValue: 0, confidence: 55, status: 'AT_RISK', notes: 'Waiting for scope finalization' },
  { id: 'fb10', hotel: 'Four Seasons DIFC', category: 'HVAC', projectType: 'Capital', projectedValue: 1800000, actualValue: 0, confidence: 42, status: 'BEHIND', notes: 'Project not yet started' },
];

const historicalData: HistoricalComparison[] = [
  { period: 'Q1 2023', projected: 8500000, actual: 8200000, variance: -3.5 },
  { period: 'Q2 2023', projected: 9200000, actual: 9600000, variance: 4.3 },
  { period: 'Q3 2023', projected: 8800000, actual: 8500000, variance: -3.4 },
  { period: 'Q4 2023', projected: 10500000, actual: 10200000, variance: -2.9 },
  { period: 'Q1 2024', projected: 9800000, actual: 9400000, variance: -4.1 },
  { period: 'Q2 2024', projected: 11200000, actual: 0, variance: 0 },
];

const getStatusVariant = (s: string) => {
  switch (s) {
    case 'ON_TRACK': return 'success';
    case 'AT_RISK': return 'warning';
    case 'BEHIND': return 'danger';
    default: return 'default';
  }
};

const ForecastDetail: React.FC = () => {
  const { t } = useTranslation();
  const { period } = useParams();
  const navigate = useNavigate();
  const [selectedPeriod, setSelectedPeriod] = useState('Q1 2024');
  const [hotelFilter, setHotelFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  const filteredData = useMemo(() => {
    return mockBreakdown.filter((item) => {
      const matchesHotel = !hotelFilter || item.hotel === hotelFilter;
      const matchesCategory = !categoryFilter || item.category === categoryFilter;
      return matchesHotel && matchesCategory;
    });
  }, [hotelFilter, categoryFilter]);

  const totalProjected = filteredData.reduce((s, i) => s + i.projectedValue, 0);
  const totalActual = filteredData.reduce((s, i) => s + i.actualValue, 0);
  const avgConfidence = Math.round(filteredData.reduce((s, i) => s + i.confidence, 0) / filteredData.length);
  const onTrackCount = filteredData.filter((i) => i.status === 'ON_TRACK').length;

  const breakdownColumns: Column<ForecastBreakdown>[] = useMemo(() => [
    { key: 'hotel', header: t('common.hotel', 'Hotel'), render: (v) => (
      <div className="flex items-center gap-1.5">
        <Building2 className="w-3.5 h-3.5 text-[#c9a962]" />
        <span className="font-medium text-slate-100">{v as string}</span>
      </div>
    )},
    { key: 'category', header: t('common.category', 'Category'), width: 'w-28' },
    { key: 'projectType', header: t('forecasting.projectType', 'Type'), width: 'w-24', render: (v) => <Badge variant={v === 'Capital' ? 'warning' : 'info'}>{v as string}</Badge> },
    { key: 'projectedValue', header: t('forecasting.projected', 'Projected'), align: 'end', width: 'w-32', render: (v) => <span className="text-slate-200">AED {(v as number).toLocaleString()}</span> },
    { key: 'actualValue', header: t('forecasting.actual', 'Actual'), align: 'end', width: 'w-28', render: (v) => (
      v > 0 ? <span className="text-slate-200">AED {(v as number).toLocaleString()}</span> : <span className="text-slate-500">—</span>
    )},
    { key: 'confidence', header: t('forecasting.confidence', 'Confidence'), width: 'w-28', render: (_, row) => (
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 bg-[#2d2d4a] rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full ${row.confidence >= 80 ? 'bg-green-500' : row.confidence >= 60 ? 'bg-amber-500' : 'bg-red-500'}`}
            style={{ width: `${row.confidence}%` }}
          />
        </div>
        <span className="text-xs text-slate-400 w-8 text-end">{row.confidence}%</span>
      </div>
    )},
    { key: 'status', header: t('common.status', 'Status'), width: 'w-28', render: (v) => <Badge variant={getStatusVariant(v as string)}>{(v as string).replace('_', ' ')}</Badge> },
    { key: 'notes', header: t('common.notes', 'Notes'), width: 'w-48', render: (v) => <span className="text-xs text-slate-400">{v as string}</span> },
  ], [t]);

  const historicalColumns: Column<HistoricalComparison>[] = useMemo(() => [
    { key: 'period', header: t('common.period', 'Period'), render: (v) => <span className="font-medium text-slate-100">{v as string}</span> },
    { key: 'projected', header: t('forecasting.projected', 'Projected'), align: 'end', render: (v) => <span className="text-slate-200">AED {(v as number).toLocaleString()}</span> },
    { key: 'actual', header: t('forecasting.actual', 'Actual'), align: 'end', render: (v) => (
      v > 0 ? <span className="text-slate-200">AED {(v as number).toLocaleString()}</span> : <span className="text-slate-500">—</span>
    )},
    { key: 'variance', header: t('forecasting.variance', 'Variance'), width: 'w-24', align: 'end', render: (v) => (
      (v as number) !== 0 ? (
        <span className={`flex items-center justify-end gap-1 ${(v as number) > 0 ? 'text-green-400' : 'text-red-400'}`}>
          {(v as number) > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
          {Math.abs(v as number).toFixed(1)}%
        </span>
      ) : <span className="text-slate-500">—</span>
    )},
  ], [t]);

  const uniqueHotels = useMemo(() => {
    return [{ value: '', label: t('common.allHotels', 'All Hotels') }, ...Array.from(new Set(mockBreakdown.map((b) => b.hotel))).map((h) => ({ value: h, label: h }))];
  }, []);

  const uniqueCategories = useMemo(() => {
    return [{ value: '', label: t('common.allCategories', 'All Categories') }, ...Array.from(new Set(mockBreakdown.map((b) => b.category))).map((c) => ({ value: c, label: c }))];
  }, []);

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('forecasting.forecastDetail', 'Forecast Detail')}
        subtitle={selectedPeriod}
        showBack
        backTo="/forecasting"
        actions={
          <div className="flex items-center gap-2">
            <Select
              options={[
                { value: 'Q1 2024', label: 'Q1 2024' },
                { value: 'Q2 2024', label: 'Q2 2024' },
                { value: 'Q3 2024', label: 'Q3 2024' },
                { value: 'Q4 2024', label: 'Q4 2024' },
              ]}
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="w-36"
            />
            <Button variant="secondary">{t('common.export', 'Export')}</Button>
          </div>
        }
      />

      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={<BarChart3 className="w-5 h-5" />}
          label={t('forecasting.totalProjected', 'Total Projected')}
          value={`AED ${(totalProjected / 1000000).toFixed(1)}M`}
        />
        <StatCard
          icon={<TrendingUp className="w-5 h-5" />}
          label={t('forecasting.totalActual', 'Total Actual')}
          value={`AED ${(totalActual / 1000000).toFixed(1)}M`}
        />
        <StatCard
          icon={<Target className="w-5 h-5" />}
          label={t('forecasting.avgConfidence', 'Avg. Confidence')}
          value={`${avgConfidence}%`}
        />
        <StatCard
          icon={<Calendar className="w-5 h-5" />}
          label={t('forecasting.onTrack', 'On Track')}
          value={`${onTrackCount}/${filteredData.length}`}
        />
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-wrap items-center gap-3">
          <div className="w-52">
            <Select
              options={uniqueHotels}
              value={hotelFilter}
              onChange={(e) => setHotelFilter(e.target.value)}
            />
          </div>
          <div className="w-44">
            <Select
              options={uniqueCategories}
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
            />
          </div>
        </div>
      </Card>

      {/* Breakdown Table */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('forecasting.breakdown', 'Forecast Breakdown')}</h3>}>
        <Table columns={breakdownColumns} data={filteredData} keyExtractor={(r) => r.id} />
      </Card>

      {/* Historical Comparison */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('forecasting.historicalComparison', 'Historical Comparison')}</h3>}>
        {/* Chart */}
        <div className="mb-6">
          <div className="flex items-end gap-3 h-32">
            {historicalData.map((item) => {
              const maxVal = Math.max(...historicalData.map((h) => Math.max(h.projected, h.actual)));
              return (
                <div key={item.period} className="flex-1 flex flex-col items-center gap-1">
                  <div className="w-full flex gap-0.5 items-end h-full">
                    {item.actual > 0 && (
                      <div
                        className="flex-1 bg-[#c9a962] rounded-t-sm transition-all"
                        style={{ height: `${(item.actual / maxVal) * 100}%` }}
                      />
                    )}
                    <div
                      className={`flex-1 rounded-sm transition-all ${item.actual > 0 ? 'bg-[#c9a962]/30' : 'bg-[#2d2d4a]'}`}
                      style={{ height: `${(item.projected / maxVal) * 100}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex justify-center gap-6 mt-2 text-[10px] text-slate-500">
            {historicalData.map((item) => (
              <span key={item.period} className="flex-1 text-center">{item.period.replace(' 20', '\n20')}</span>
            ))}
          </div>
        </div>
        <Table columns={historicalColumns} data={historicalData} keyExtractor={(r) => r.period} />
      </Card>
    </div>
  );
};

export default ForecastDetail;
