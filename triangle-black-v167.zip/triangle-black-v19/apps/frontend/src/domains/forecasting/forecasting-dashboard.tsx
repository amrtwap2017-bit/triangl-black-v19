import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  BarChart3,
  Clock,
  Users,
  CreditCard,
  ArrowUpRight,
  Target,
} from 'lucide-react';
import { Card, PageHeader, StatCard, Button, Tabs, Table, Badge } from '@/shared/components/ui';
import type { Column } from '@/shared/types';

interface RevenueForecast {
  month: string;
  projected: number;
  actual: number;
  variance: number;
  confidence: number;
}

interface PipelineForecast {
  stage: string;
  weightedValue: number;
  totalValue: number;
  probability: number;
  expectedCloseDate: string;
  deals: number;
}

interface WorkloadForecast {
  department: string;
  currentUtilization: number;
  forecastUtilization: number;
  capacity: number;
  projectedDemand: number;
  gap: number;
}

interface CashFlowItem {
  category: string;
  projected: number;
  actual: number;
  variance: number;
  direction: string;
}

const revenueData: RevenueForecast[] = [
  { month: 'Jan 2024', projected: 3200000, actual: 3050000, variance: -4.7, confidence: 95 },
  { month: 'Feb 2024', projected: 2800000, actual: 2950000, variance: 5.4, confidence: 90 },
  { month: 'Mar 2024', projected: 4100000, actual: 3800000, variance: -7.3, confidence: 85 },
  { month: 'Apr 2024', projected: 3600000, actual: 0, variance: 0, confidence: 72 },
  { month: 'May 2024', projected: 3900000, actual: 0, variance: 0, confidence: 65 },
  { month: 'Jun 2024', projected: 4200000, actual: 0, variance: 0, confidence: 58 },
  { month: 'Jul 2024', projected: 3800000, actual: 0, variance: 0, confidence: 50 },
  { month: 'Aug 2024', projected: 3500000, actual: 0, variance: 0, confidence: 42 },
  { month: 'Sep 2024', projected: 4100000, actual: 0, variance: 0, confidence: 38 },
  { month: 'Oct 2024', projected: 4500000, actual: 0, variance: 0, confidence: 30 },
  { month: 'Nov 2024', projected: 4800000, actual: 0, variance: 0, confidence: 25 },
  { month: 'Dec 2024', projected: 5200000, actual: 0, variance: 0, confidence: 20 },
];

const pipelineData: PipelineForecast[] = [
  { stage: 'Qualified Lead', weightedValue: 1200000, totalValue: 4000000, probability: 30, expectedCloseDate: 'Q2 2024', deals: 8 },
  { stage: 'Proposal Sent', weightedValue: 2400000, totalValue: 6000000, probability: 40, expectedCloseDate: 'Q2 2024', deals: 5 },
  { stage: 'Negotiation', weightedValue: 3150000, totalValue: 4500000, probability: 70, expectedCloseDate: 'Q1 2024', deals: 4 },
  { stage: 'Verbal Agreement', weightedValue: 2160000, totalValue: 2400000, probability: 90, expectedCloseDate: 'Q1 2024', deals: 3 },
  { stage: 'Contract Signed', weightedValue: 8500000, totalValue: 8500000, probability: 100, expectedCloseDate: 'Won', deals: 6 },
];

const workloadData: WorkloadForecast[] = [
  { department: 'HVAC', currentUtilization: 85, forecastUtilization: 92, capacity: 28, projectedDemand: 32, gap: -4 },
  { department: 'Electrical', currentUtilization: 78, forecastUtilization: 88, capacity: 22, projectedDemand: 26, gap: -4 },
  { department: 'Plumbing', currentUtilization: 72, forecastUtilization: 80, capacity: 15, projectedDemand: 14, gap: 1 },
  { department: 'Fire Protection', currentUtilization: 65, forecastUtilization: 75, capacity: 12, projectedDemand: 11, gap: 1 },
  { department: 'BMS', currentUtilization: 88, forecastUtilization: 95, capacity: 8, projectedDemand: 10, gap: -2 },
];

const cashFlowData: CashFlowItem[] = [
  { category: 'Project Receivables', projected: 6200000, actual: 5800000, variance: -6.5, direction: 'inflow' },
  { category: 'Progress Payments', projected: 8400000, actual: 8100000, variance: -3.6, direction: 'inflow' },
  { category: 'Retention Releases', projected: 1200000, actual: 900000, variance: -25.0, direction: 'inflow' },
  { category: 'Vendor Payments', projected: -4500000, actual: -4800000, variance: 6.7, direction: 'outflow' },
  { category: 'Salary & Benefits', projected: -2100000, actual: -2100000, variance: 0, direction: 'outflow' },
  { category: 'Equipment Rental', projected: -800000, actual: -750000, variance: -6.3, direction: 'outflow' },
  { category: 'Subcontractor', projected: -3200000, actual: -3000000, variance: -6.3, direction: 'outflow' },
];

const ForecastingDashboard: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('revenue');

  const totalProjectedRevenue = revenueData.reduce((s, r) => s + r.projected, 0);
  const totalActualRevenue = revenueData.reduce((s, r) => s + r.actual, 0);
  const weightedPipeline = pipelineData.reduce((s, p) => s + p.weightedValue, 0);
  const netCashFlow = cashFlowData.reduce((s, c) => s + c.actual, 0);

  const revenueColumns: Column<RevenueForecast>[] = useMemo(() => [
    { key: 'month', header: t('common.month', 'Month'), width: 'w-28' },
    { key: 'projected', header: t('forecasting.projected', 'Projected'), align: 'end', render: (v) => <span className="text-slate-200">AED {(v as number).toLocaleString()}</span> },
    { key: 'actual', header: t('forecasting.actual', 'Actual'), align: 'end', render: (_, row) => (
      row.actual > 0 ? <span className="text-slate-200">AED {row.actual.toLocaleString()}</span> : <span className="text-slate-500">—</span>
    )},
    { key: 'variance', header: t('forecasting.variance', 'Variance'), width: 'w-24', align: 'end', render: (_, row) => (
      row.variance !== 0 ? (
        <span className={`flex items-center justify-end gap-1 ${row.variance > 0 ? 'text-green-400' : 'text-red-400'}`}>
          {row.variance > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
          {Math.abs(row.variance).toFixed(1)}%
        </span>
      ) : <span className="text-slate-500">—</span>
    )},
    { key: 'confidence', header: t('forecasting.confidence', 'Confidence'), width: 'w-32', render: (_, row) => (
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 bg-[#2d2d4a] rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full ${row.confidence >= 70 ? 'bg-green-500' : row.confidence >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}
            style={{ width: `${row.confidence}%` }}
          />
        </div>
        <span className="text-xs text-slate-400 w-8 text-end">{row.confidence}%</span>
      </div>
    )},
  ], [t]);

  const pipelineColumns: Column<PipelineForecast>[] = useMemo(() => [
    { key: 'stage', header: t('forecasting.stage', 'Stage'), render: (v) => <span className="font-medium text-slate-100">{v as string}</span> },
    { key: 'weightedValue', header: t('forecasting.weightedValue', 'Weighted Value'), align: 'end', render: (v) => <span className="text-[#c9a962] font-semibold">AED {(v as number).toLocaleString()}</span> },
    { key: 'totalValue', header: t('common.totalValue', 'Total Value'), align: 'end', render: (v) => <span className="text-slate-200">AED {(v as number).toLocaleString()}</span> },
    { key: 'probability', header: t('forecasting.probability', 'Probability'), width: 'w-28', render: (v) => (
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 bg-[#2d2d4a] rounded-full overflow-hidden">
          <div className="h-full rounded-full bg-[#c9a962]" style={{ width: `${v as number}%` }} />
        </div>
        <span className="text-xs text-slate-400 w-8 text-end">{v as number}%</span>
      </div>
    )},
    { key: 'expectedCloseDate', header: t('forecasting.expectedClose', 'Expected Close'), width: 'w-28' },
    { key: 'deals', header: t('forecasting.deals', 'Deals'), width: 'w-16', align: 'center' },
  ], [t]);

  const workloadColumns: Column<WorkloadForecast>[] = useMemo(() => [
    { key: 'department', header: t('common.department', 'Department'), render: (v) => <span className="font-medium text-slate-100">{v as string}</span> },
    { key: 'currentUtilization', header: t('forecasting.currentUtil', 'Current'), width: 'w-32', render: (v) => (
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 bg-[#2d2d4a] rounded-full overflow-hidden">
          <div className={`h-full rounded-full ${v as number >= 85 ? 'bg-red-500' : (v as number) >= 75 ? 'bg-amber-500' : 'bg-green-500'}`} style={{ width: `${v}%` }} />
        </div>
        <span className="text-xs text-slate-400 w-8 text-end">{v}%</span>
      </div>
    )},
    { key: 'forecastUtilization', header: t('forecasting.forecastUtil', 'Forecast'), width: 'w-32', render: (v) => (
      <div className="flex items-center gap-2">
        <div className="flex-1 h-1.5 bg-[#2d2d4a] rounded-full overflow-hidden">
          <div className={`h-full rounded-full ${v as number >= 90 ? 'bg-red-500' : (v as number) >= 80 ? 'bg-amber-500' : 'bg-green-500'}`} style={{ width: `${v}%` }} />
        </div>
        <span className="text-xs text-slate-400 w-8 text-end">{v}%</span>
      </div>
    )},
    { key: 'capacity', header: t('forecasting.capacity', 'Capacity'), width: 'w-20', align: 'center' },
    { key: 'projectedDemand', header: t('forecasting.projectedDemand', 'Demand'), width: 'w-20', align: 'center' },
    { key: 'gap', header: t('forecasting.gap', 'Gap'), width: 'w-20', align: 'center', render: (v) => (
      <span className={`font-semibold ${(v as number) < 0 ? 'text-red-400' : 'text-green-400'}`}>
        {(v as number) < 0 ? `${v}` : `+${v}`}
      </span>
    )},
  ], [t]);

  const cashFlowColumns: Column<CashFlowItem>[] = useMemo(() => [
    { key: 'category', header: t('common.category', 'Category'), render: (v) => (
      <div className="flex items-center gap-2">
        {cashFlowData.find((c) => c.category === (v as string))?.direction === 'inflow'
          ? <TrendingUp className="w-4 h-4 text-green-400" />
          : <TrendingDown className="w-4 h-4 text-red-400" />
        }
        <span className="font-medium text-slate-200">{v as string}</span>
      </div>
    )},
    { key: 'projected', header: t('forecasting.projected', 'Projected'), align: 'end', render: (v) => (
      <span className={`font-medium ${(v as number) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
        AED {Math.abs(v as number).toLocaleString()}
      </span>
    )},
    { key: 'actual', header: t('forecasting.actual', 'Actual'), align: 'end', render: (v) => (
      <span className={`font-medium ${(v as number) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
        AED {Math.abs(v as number).toLocaleString()}
      </span>
    )},
    { key: 'variance', header: t('forecasting.variance', 'Variance'), width: 'w-28', align: 'end', render: (_, row) => (
      <span className={`text-xs ${(row.variance) > 0 ? 'text-red-400' : (row.variance) < 0 ? 'text-green-400' : 'text-slate-400'}`}>
        {row.variance > 0 ? '+' : ''}{row.variance.toFixed(1)}%
      </span>
    )},
  ], [t]);

  const tabs = [
    { key: 'revenue', label: t('forecasting.revenue', 'Revenue'), icon: <DollarSign className="w-4 h-4" /> },
    { key: 'pipeline', label: t('forecasting.pipeline', 'Pipeline'), icon: <Target className="w-4 h-4" /> },
    { key: 'workload', label: t('forecasting.workload', 'Workload'), icon: <Users className="w-4 h-4" /> },
    { key: 'cashflow', label: t('forecasting.cashFlow', 'Cash Flow'), icon: <CreditCard className="w-4 h-4" /> },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('forecasting.title', 'Executive Forecasting')}
        subtitle={t('forecasting.subtitle', 'Revenue, pipeline, workload, and cash flow projections')}
        actions={
          <Button variant="secondary" icon={<ArrowUpRight className="w-4 h-4" />}>
            {t('common.export', 'Export Report')}
          </Button>
        }
      />

      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={<DollarSign className="w-5 h-5" />}
          label={t('forecasting.annualRevenue', 'Annual Revenue Forecast')}
          value={`AED ${(totalProjectedRevenue / 1000000).toFixed(1)}M`}
          change={8.5}
        />
        <StatCard
          icon={<Target className="w-5 h-5" />}
          label={t('forecasting.weightedPipeline', 'Weighted Pipeline')}
          value={`AED ${(weightedPipeline / 1000000).toFixed(1)}M`}
          change={12.3}
        />
        <StatCard
          icon={<Users className="w-5 h-5" />}
          label={t('forecasting.avgUtilization', 'Avg. Forecast Utilization')}
          value={`${Math.round(workloadData.reduce((s, w) => s + w.forecastUtilization, 0) / workloadData.length)}%`}
          change={5.1}
        />
        <StatCard
          icon={<CreditCard className="w-5 h-5" />}
          label={t('forecasting.netCashFlow', 'Net Cash Flow')}
          value={`AED ${(netCashFlow / 1000000).toFixed(1)}M`}
          change={netCashFlow > 0 ? 3.2 : -3.2}
        />
      </div>

      {/* Tab Navigation */}
      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {/* Revenue Tab */}
      {activeTab === 'revenue' && (
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('forecasting.revenueForecast', '12-Month Revenue Forecast')}</h3>}>
          {/* Chart placeholder */}
          <div className="mb-6">
            <div className="flex items-end gap-1.5 h-40">
              {revenueData.map((item) => {
                const maxVal = Math.max(...revenueData.map((r) => r.projected));
                return (
                  <div key={item.month} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full flex flex-col gap-0.5">
                      {item.actual > 0 && (
                        <div
                          className="w-full bg-[#c9a962] rounded-t-sm transition-all"
                          style={{ height: `${(item.actual / maxVal) * 120}px` }}
                          title={`Actual: AED ${(item.actual / 1000000).toFixed(1)}M`}
                        />
                      )}
                      <div
                        className={`w-full rounded-sm transition-all ${item.actual > 0 ? 'bg-[#c9a962]/30 rounded-t-none' : 'bg-[#2d2d4a]'}`}
                        style={{ height: `${(item.projected / maxVal) * 120}px` }}
                        title={`Projected: AED ${(item.projected / 1000000).toFixed(1)}M`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-4 mt-3 text-xs text-slate-500 justify-center">
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-[#c9a962] rounded-sm" /> Actual</div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-[#2d2d4a] rounded-sm" /> Projected</div>
            </div>
          </div>
          <Table columns={revenueColumns} data={revenueData} keyExtractor={(r) => r.month} />
        </Card>
      )}

      {/* Pipeline Tab */}
      {activeTab === 'pipeline' && (
        <Card header={
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-100">{t('forecasting.pipelineByStage', 'Weighted Pipeline by Stage')}</h3>
            <Badge variant="info">{t('forecasting.totalWeighted', 'Total Weighted')}: AED {(weightedPipeline / 1000000).toFixed(1)}M</Badge>
          </div>
        }>
          {/* Pipeline funnel visualization */}
          <div className="mb-6 space-y-2">
            {pipelineData.map((stage) => {
              const maxWeight = Math.max(...pipelineData.map((p) => p.weightedValue));
              return (
                <div key={stage.stage} className="flex items-center gap-3">
                  <div className="w-36 shrink-0 text-xs font-medium text-slate-300 text-end">{stage.stage}</div>
                  <div className="flex-1 h-8 bg-[#15152a] rounded overflow-hidden">
                    <div
                      className="h-full bg-[#c9a962]/60 flex items-center justify-end pe-2 transition-all rounded"
                      style={{ width: `${(stage.weightedValue / maxWeight) * 100}%` }}
                    >
                      <span className="text-[10px] font-semibold text-[#0f0f1a]">
                        AED {(stage.weightedValue / 1000000).toFixed(1)}M
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <Table columns={pipelineColumns} data={pipelineData} keyExtractor={(r) => r.stage} />
        </Card>
      )}

      {/* Workload Tab */}
      {activeTab === 'workload' && (
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('forecasting.resourceUtilization', 'Resource Utilization Forecast')}</h3>}>
          <Table columns={workloadColumns} data={workloadData} keyExtractor={(r) => r.department} />

          <div className="mt-6 pt-4 border-t border-[#2d2d4a]">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-xs">
                <div className="w-3 h-3 bg-green-500 rounded-sm" />
                <span className="text-slate-400">{t('forecasting.healthy', 'Healthy (<75%)')}</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-3 h-3 bg-amber-500 rounded-sm" />
                <span className="text-slate-400">{t('forecasting.stressed', 'Stressed (75-89%)')}</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-3 h-3 bg-red-500 rounded-sm" />
                <span className="text-slate-400">{t('forecasting.overloaded', 'Overloaded (≥90%)')}</span>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Cash Flow Tab */}
      {activeTab === 'cashflow' && (
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('forecasting.cashFlowIndicators', 'Cash Flow Indicators')}</h3>}>
          {/* Net cash flow summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="p-4 bg-[#15152a] border border-[#2d2d4a] rounded-lg">
              <p className="text-sm text-slate-400">{t('forecasting.totalInflow', 'Total Inflow')}</p>
              <p className="text-xl font-bold text-green-400 mt-1">
                AED {(cashFlowData.filter((c) => c.direction === 'inflow').reduce((s, c) => s + c.actual, 0) / 1000000).toFixed(1)}M
              </p>
            </div>
            <div className="p-4 bg-[#15152a] border border-[#2d2d4a] rounded-lg">
              <p className="text-sm text-slate-400">{t('forecasting.totalOutflow', 'Total Outflow')}</p>
              <p className="text-xl font-bold text-red-400 mt-1">
                AED {(Math.abs(cashFlowData.filter((c) => c.direction === 'outflow').reduce((s, c) => s + c.actual, 0)) / 1000000).toFixed(1)}M
              </p>
            </div>
            <div className="p-4 bg-[#15152a] border border-[#2d2d4a] rounded-lg">
              <p className="text-sm text-slate-400">{t('forecasting.netPosition', 'Net Position')}</p>
              <p className={`text-xl font-bold mt-1 ${netCashFlow >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                AED {(netCashFlow / 1000000).toFixed(1)}M
              </p>
            </div>
          </div>
          <Table columns={cashFlowColumns} data={cashFlowData} keyExtractor={(r) => r.category} />
        </Card>
      )}
    </div>
  );
};

export default ForecastingDashboard;
