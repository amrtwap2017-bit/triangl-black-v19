import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import { Save, Plus, Trash2, ArrowLeft } from 'lucide-react';
import { Button, Input, Select, Textarea, Card, PageHeader, Badge } from '@/shared/components/ui';
import { apiPost, apiPut, apiGet } from '@/api/client';

interface MitigationMeasure {
  risk: string;
  measure: string;
  responsible: string;
  status: string;
}

const GuestProtectionForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [loading, setLoading] = useState(false);
  const [guestImpact, setGuestImpact] = useState('NONE');
  const [noiseImpact, setNoiseImpact] = useState('NONE');
  const [dustImpact, setDustImpact] = useState('NONE');
  const [odorImpact, setOdorImpact] = useState('NONE');
  const [shutdownRequired, setShutdownRequired] = useState(false);
  const [shutdownDetails, setShutdownDetails] = useState('');
  const [occupancyLevel, setOccupancyLevel] = useState('');
  const [preferredHours, setPreferredHours] = useState('');
  const [preferredDays, setPreferredDays] = useState('');
  const [blackoutDates, setBlackoutDates] = useState('');
  const [communicationPlan, setCommunicationPlan] = useState('');
  const [mitigations, setMitigations] = useState<MitigationMeasure[]>([
    { risk: '', measure: '', responsible: '', status: 'PENDING' },
  ]);

  const impactOptions = [
    { value: 'NONE', label: 'None' },
    { value: 'LOW', label: 'Low' },
    { value: 'MEDIUM', label: 'Medium' },
    { value: 'HIGH', label: 'High' },
  ];

  const occupancyOptions = [
    { value: 'LOW', label: 'Low (<30%)' },
    { value: 'MEDIUM', label: 'Medium (30-70%)' },
    { value: 'HIGH', label: 'High (>70%)' },
    { value: 'FULL', label: 'Full (90%+)' },
  ];

  const statusOptions = [
    { value: 'PENDING', label: 'Pending' },
    { value: 'IN_PROGRESS', label: 'In Progress' },
    { value: 'IMPLEMENTED', label: 'Implemented' },
  ];

  const addMitigation = () => {
    setMitigations([...mitigations, { risk: '', measure: '', responsible: '', status: 'PENDING' }]);
  };

  const removeMitigation = (index: number) => {
    setMitigations(mitigations.filter((_, i) => i !== index));
  };

  const updateMitigation = (index: number, field: keyof MitigationMeasure, value: string) => {
    const updated = [...mitigations];
    updated[index] = { ...updated[index], [field]: value };
    setMitigations(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        guestImpact,
        noiseImpact,
        dustImpact,
        odorImpact,
        shutdownRequired,
        shutdownDetails: shutdownRequired ? shutdownDetails : undefined,
        occupancyLevel,
        preferredHours,
        preferredDays,
        blackoutDates,
        communicationPlan,
        mitigationMeasures: mitigations,
      };
      if (isEdit) {
        await apiPut(`/guest-protection/${id}`, payload);
      } else {
        await apiPost('/guest-protection', payload);
      }
      navigate(-1);
    } catch {
      // handle error
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('guestProtection.title')}
        subtitle={isEdit ? t('common.edit') : t('common.create')}
        showBack
        backTo={-1}
        actions={
          <Button type="submit" form="guest-protection-form" loading={loading} icon={<Save className="w-4 h-4" />}>
            {t('common.save')}
          </Button>
        }
      />

      <form id="guest-protection-form" onSubmit={handleSubmit} className="space-y-6">
        {/* Risk Assessment */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('guestProtection.riskAssessment')}</h3>}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label={t('emergency.guestImpact')}
              options={impactOptions}
              value={guestImpact}
              onChange={(e) => setGuestImpact(e.target.value)}
            />
            <Select
              label={t('guestProtection.noiseImpact')}
              options={impactOptions}
              value={noiseImpact}
              onChange={(e) => setNoiseImpact(e.target.value)}
            />
            <Select
              label={t('guestProtection.dustImpact')}
              options={impactOptions}
              value={dustImpact}
              onChange={(e) => setDustImpact(e.target.value)}
            />
            <Select
              label={t('guestProtection.odorImpact')}
              options={impactOptions}
              value={odorImpact}
              onChange={(e) => setOdorImpact(e.target.value)}
            />
            <Select
              label={t('guestProtection.occupancyLevel')}
              options={occupancyOptions}
              value={occupancyLevel}
              onChange={(e) => setOccupancyLevel(e.target.value)}
            />
            <div className="flex items-end pb-1">
              <label className="flex items-center gap-3 cursor-pointer">
                <div
                  className={`relative w-11 h-6 rounded-full transition-colors ${
                    shutdownRequired ? 'bg-[#c9a962]' : 'bg-[#2d2d4a]'
                  }`}
                  onClick={() => setShutdownRequired(!shutdownRequired)}
                >
                  <div
                    className={`absolute top-0.5 start-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                      shutdownRequired ? 'translate-x-5' : ''
                    }`}
                  />
                </div>
                <span className="text-sm text-slate-300">{t('guestProtection.shutdownRequired')}</span>
              </label>
            </div>
          </div>

          {shutdownRequired && (
            <div className="mt-4">
              <Textarea
                label={t('guestProtection.shutdownDetails') || 'Shutdown Details'}
                value={shutdownDetails}
                onChange={(e) => setShutdownDetails(e.target.value)}
                placeholder="Describe shutdown scope, duration, areas affected..."
              />
            </div>
          )}
        </Card>

        {/* Mitigation Measures */}
        <Card header={
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-100">{t('guestProtection.mitigationMeasures')}</h3>
            <Button variant="ghost" size="sm" icon={<Plus className="w-4 h-4" />} onClick={addMitigation}>
              {t('common.add')}
            </Button>
          </div>
        }>
          <div className="space-y-4">
            {mitigations.map((m, idx) => (
              <div key={idx} className="grid grid-cols-1 md:grid-cols-5 gap-3 items-start bg-[#0f0f1a] rounded-lg p-3">
                <Input
                  placeholder="Risk"
                  value={m.risk}
                  onChange={(e) => updateMitigation(idx, 'risk', e.target.value)}
                />
                <Input
                  placeholder="Measure"
                  value={m.measure}
                  onChange={(e) => updateMitigation(idx, 'measure', e.target.value)}
                />
                <Input
                  placeholder="Responsible"
                  value={m.responsible}
                  onChange={(e) => updateMitigation(idx, 'responsible', e.target.value)}
                />
                <Select
                  options={statusOptions}
                  value={m.status}
                  onChange={(e) => updateMitigation(idx, 'status', e.target.value)}
                />
                <div className="flex items-center h-[42px]">
                  <Button variant="ghost" size="sm" icon={<Trash2 className="w-4 h-4 text-red-400" />} onClick={() => removeMitigation(idx)} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Recommended Schedule */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('guestProtection.recommendedSchedule')}</h3>}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label={t('guestProtection.preferredHours') || 'Preferred Hours'}
              placeholder="e.g., 10:00 - 16:00"
              value={preferredHours}
              onChange={(e) => setPreferredHours(e.target.value)}
            />
            <Input
              label={t('guestProtection.preferredDays') || 'Preferred Days'}
              placeholder="e.g., Mon-Thu"
              value={preferredDays}
              onChange={(e) => setPreferredDays(e.target.value)}
            />
            <Input
              label={t('guestProtection.blackoutDates') || 'Blackout Dates'}
              placeholder="e.g., Dec 20 - Jan 5"
              value={blackoutDates}
              onChange={(e) => setBlackoutDates(e.target.value)}
            />
          </div>
        </Card>

        {/* Communication Plan */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('guestProtection.communicationPlan')}</h3>}>
          <Textarea
            value={communicationPlan}
            onChange={(e) => setCommunicationPlan(e.target.value)}
            placeholder="Describe the guest communication plan, signage, notifications..."
            className="min-h-[120px]"
          />
        </Card>
      </form>
    </div>
  );
};

export default GuestProtectionForm;