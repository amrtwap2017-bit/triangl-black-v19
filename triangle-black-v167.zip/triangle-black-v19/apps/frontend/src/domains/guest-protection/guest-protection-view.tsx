import React, { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useNavigate } from 'react-router-dom';
import { Edit, Brain, Volume2, Wind, Cloud, Power, CheckCircle } from 'lucide-react';
import { Card, PageHeader, Badge, Button, Table, StatusBadge } from '@/shared/components/ui';
import { apiPost, apiGet } from '@/api/client';
import type { Column } from '@/shared/types';

interface MitigationMeasure {
  id: string;
  risk: string;
  measure: string;
  responsible: string;
  status: string;
}

interface GuestProtectionData {
  id: string;
  projectId: string;
  guestImpact: string;
  noiseImpact: string;
  dustImpact: string;
  odorImpact: string;
  shutdownRequired: boolean;
  shutdownDetails?: string;
  occupancyLevel: string;
  preferredHours?: string;
  preferredDays?: string;
  blackoutDates?: string;
  communicationPlan?: string;
  mitigationMeasures: MitigationMeasure[];
  riskScore?: number;
}

const impactColorMap: Record<string, 'success' | 'warning' | 'danger'> = {
  NONE: 'success',
  LOW: 'success',
  MEDIUM: 'warning',
  HIGH: 'danger',
};

const getRiskColor = (score: number) => {
  if (score <= 30) return 'text-green-400';
  if (score <= 60) return 'text-yellow-400';
  return 'text-red-400';
};

const getRiskBg = (score: number) => {
  if (score <= 30) return 'border-green-500/30 bg-green-900/10';
  if (score <= 60) return 'border-yellow-500/30 bg-yellow-900/10';
  return 'border-red-500/30 bg-red-900/10';
};

const GuestProtectionView: React.FC = () => {
  const { t } = useTranslation();
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [aiResult, setAiResult] = useState<string | null>(null);

  // In production, fetch from API
  const [data] = useState<GuestProtectionData>({
    id: '1',
    projectId: projectId || '',
    guestImpact: 'MEDIUM',
    noiseImpact: 'HIGH',
    dustImpact: 'MEDIUM',
    odorImpact: 'LOW',
    shutdownRequired: false,
    occupancyLevel: 'HIGH',
    preferredHours: '10:00 - 16:00',
    preferredDays: 'Mon-Thu',
    blackoutDates: 'Dec 20 - Jan 5',
    communicationPlan: 'Notify guests 48h in advance via in-room letter. Place signage at all affected areas. Front desk briefing at check-in.',
    mitigationMeasures: [
      { id: '1', risk: 'Noise disturbance', measure: 'Install temporary acoustic barriers around work zone', responsible: 'Site Supervisor', status: 'IMPLEMENTED' },
      { id: '2', risk: 'Dust in corridors', measure: 'Seal work area with negative pressure enclosure', responsible: 'HSE Officer', status: 'IN_PROGRESS' },
      { id: '3', risk: 'Odor from adhesives', measure: 'Use low-VOC materials only, ventilate after hours', responsible: 'Procurement', status: 'PENDING' },
    ],
    riskScore: 45,
  });

  const computedScore = useMemo(() => {
    const impactMap: Record<string, number> = { NONE: 0, LOW: 10, MEDIUM: 25, HIGH: 50 };
    const score = impactMap[data.guestImpact] + impactMap[data.noiseImpact] + impactMap[data.dustImpact] + impactMap[data.odorImpact];
    return Math.min(100, score + (data.shutdownRequired ? 30 : 0));
  }, [data]);

  const riskScore = data.riskScore ?? computedScore;

  const impactCards = [
    { key: 'noiseImpact', icon: Volume2, label: t('guestProtection.noiseImpact'), value: data.noiseImpact },
    { key: 'dustImpact', icon: Wind, label: t('guestProtection.dustImpact'), value: data.dustImpact },
    { key: 'odorImpact', icon: Cloud, label: t('guestProtection.odorImpact'), value: data.odorImpact },
    { key: 'shutdownRequired', icon: Power, label: t('guestProtection.shutdownRequired'), value: data.shutdownRequired ? 'HIGH' : 'NONE' },
  ];

  const mitColumns: Column<MitigationMeasure>[] = [
    { key: 'risk', header: 'Risk', sortable: true },
    { key: 'measure', header: 'Measure' },
    { key: 'responsible', header: 'Responsible', width: 'w-40' },
    { key: 'status', header: t('common.status'), width: 'w-32', render: (v) => <StatusBadge status={String(v)} /> },
  ];

  const handleAiAssess = async () => {
    if (!projectId) return;
    setLoading(true);
    try {
      const result = await apiPost<{ assessment: string }>(`/guest-protection/${projectId}/assess`);
      setAiResult(result.assessment);
    } catch {
      setAiResult('AI assessment is currently unavailable. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('guestProtection.title')}
        showBack
        backTo={-1}
        actions={
          <div className="flex gap-2">
            <Button variant="secondary" icon={<Brain className="w-4 h-4" />} loading={loading} onClick={handleAiAssess}>
              {t('guestProtection.assessRisk')}
            </Button>
            <Button icon={<Edit className="w-4 h-4" />} onClick={() => navigate(`/guest-protection/${data.id}/edit`)}>
              {t('common.edit')}
            </Button>
          </div>
        }
      />

      {/* Risk Score */}
      <Card>
        <div className="flex items-center gap-8">
          <div className={`w-32 h-32 rounded-full border-4 flex flex-col items-center justify-center ${getRiskBg(riskScore)} ${getRiskColor(riskScore)}`}>
            <span className="text-3xl font-bold">{riskScore}</span>
            <span className="text-xs font-medium opacity-70">/ 100</span>
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-slate-100 mb-1">{t('guestProtection.riskScore')}</h3>
            <p className="text-sm text-slate-400">
              {riskScore <= 30
                ? 'Low risk — standard precautions sufficient'
                : riskScore <= 60
                ? 'Medium risk — enhanced mitigation measures required'
                : 'High risk — executive review and detailed guest protection plan mandatory'}
            </p>
            {data.occupancyLevel && (
              <p className="text-sm text-slate-500 mt-1">
                Occupancy Level: <Badge variant={data.occupancyLevel === 'HIGH' || data.occupancyLevel === 'FULL' ? 'danger' : 'default'}>{data.occupancyLevel}</Badge>
              </p>
            )}
          </div>
        </div>
      </Card>

      {/* Impact Assessment Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {impactCards.map((card) => (
          <Card key={card.key} className="hover:border-[#c9a962]/30 transition-colors">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-[#252540]">
                <card.icon className="w-5 h-5 text-slate-300" />
              </div>
              <span className="text-sm text-slate-400">{card.label}</span>
            </div>
            <Badge variant={impactColorMap[card.value] || 'default'}>{card.value}</Badge>
          </Card>
        ))}
      </div>

      {/* Mitigation Measures */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('guestProtection.mitigationMeasures')}</h3>}>
        <Table
          columns={mitColumns}
          data={data.mitigationMeasures}
          keyExtractor={(m) => m.id}
        />
      </Card>

      {/* Recommended Schedule */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('guestProtection.recommendedSchedule')}</h3>}>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {data.preferredHours && (
            <div>
              <p className="text-sm text-slate-400 mb-1">Preferred Hours</p>
              <p className="text-slate-100 font-medium">{data.preferredHours}</p>
            </div>
          )}
          {data.preferredDays && (
            <div>
              <p className="text-sm text-slate-400 mb-1">Preferred Days</p>
              <p className="text-slate-100 font-medium">{data.preferredDays}</p>
            </div>
          )}
          {data.blackoutDates && (
            <div>
              <p className="text-sm text-slate-400 mb-1">Blackout Dates</p>
              <p className="text-slate-100 font-medium">{data.blackoutDates}</p>
            </div>
          )}
        </div>
      </Card>

      {/* Communication Plan */}
      {data.communicationPlan && (
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('guestProtection.communicationPlan')}</h3>}>
          <p className="text-sm text-slate-300 leading-relaxed">{data.communicationPlan}</p>
        </Card>
      )}

      {/* AI Assessment Result */}
      {aiResult && (
        <Card header={<h3 className="text-lg font-semibold text-slate-100 flex items-center gap-2"><Brain className="w-5 h-5 text-[#c9a962]" /> AI Assessment</h3>}>
          <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap">{aiResult}</p>
        </Card>
      )}
    </div>
  );
};

export default GuestProtectionView;