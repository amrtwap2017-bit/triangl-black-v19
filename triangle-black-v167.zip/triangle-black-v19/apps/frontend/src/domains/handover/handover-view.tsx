import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useNavigate } from 'react-router-dom';
import { CheckCircle, Circle, FileText, AlertTriangle, Shield, CheckSquare } from 'lucide-react';
import { Card, PageHeader, Badge, Button, Table, Tabs } from '@/shared/components/ui';
import type { Column } from '@/shared/types';

interface Deliverable {
  id: string;
  name: string;
  status: 'PENDING' | 'SUBMITTED' | 'APPROVED';
  submittedDate?: string;
}

interface PunchItem {
  id: string;
  description: string;
  location: string;
  severity: string;
  status: string;
  assignedTo: string;
}

interface AsBuiltDoc {
  id: string;
  name: string;
  type: string;
  version: string;
  uploadedDate: string;
}

interface WarrantyItem {
  id: string;
  equipment: string;
  warrantyPeriod: string;
  startDate: string;
  endDate: string;
  vendor: string;
}

const HandoverView: React.FC = () => {
  const { t } = useTranslation();
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('deliverables');
  const [signing, setSigning] = useState(false);

  // Mock data
  const project = { name: 'HVAC Replacement — Floor 5', hotel: 'Burj Al Arab' };

  const deliverables: Deliverable[] = [
    { id: '1', name: 'As-Built Drawings (HVAC)', status: 'APPROVED', submittedDate: '2025-01-15' },
    { id: '2', name: 'Operation & Maintenance Manuals', status: 'APPROVED', submittedDate: '2025-01-14' },
    { id: '3', name: 'Test & Commissioning Reports', status: 'SUBMITTED', submittedDate: '2025-01-16' },
    { id: '4', name: 'Warranty Certificates', status: 'PENDING' },
    { id: '5', name: 'Training Records', status: 'SUBMITTED', submittedDate: '2025-01-16' },
    { id: '6', name: 'Defects Liability Period Agreement', status: 'PENDING' },
  ];

  const punchItems: PunchItem[] = [
    { id: '1', description: 'Air balancing not achieved in Room 508', location: 'Floor 5, Room 508', severity: 'HIGH', status: 'OPEN', assignedTo: 'Ahmed M.' },
    { id: '2', description: 'Thermostat cover scratched', location: 'Floor 5, Corridor', severity: 'LOW', status: 'FIXED', assignedTo: 'Sara K.' },
    { id: '3', description: 'Missing diffuser in utility room', location: 'Floor 5, Utility', severity: 'MEDIUM', status: 'IN_PROGRESS', assignedTo: 'Omar H.' },
  ];

  const asBuiltDocs: AsBuiltDoc[] = [
    { id: '1', name: 'HVAC Duct Layout — Floor 5 (As-Built)', type: 'DWG', version: 'v3', uploadedDate: '2025-01-15' },
    { id: '2', name: 'Chilled Water Piping — Floor 5 (As-Built)', type: 'PDF', version: 'v2', uploadedDate: '2025-01-15' },
    { id: '3', name: 'Electrical Wiring — FCU Controls', type: 'PDF', version: 'v1', uploadedDate: '2025-01-14' },
  ];

  const warrantyItems: WarrantyItem[] = [
    { id: '1', equipment: 'Carrier 30XA-350 Chiller', warrantyPeriod: '5 years', startDate: '2025-01-10', endDate: '2030-01-10', vendor: 'Carrier Middle East' },
    { id: '2', equipment: 'Daikin FCU (48 nos)', warrantyPeriod: '2 years', startDate: '2025-01-10', endDate: '2027-01-10', vendor: 'Daikin Gulf' },
    { id: '3', equipment: 'AHU Custom Built (2 nos)', warrantyPeriod: '3 years', startDate: '2025-01-10', endDate: '2028-01-10', vendor: 'Custom Air Mfg' },
  ];

  const deliverableStatusIcon: Record<string, React.ReactNode> = {
    PENDING: <Circle className="w-4 h-4 text-slate-500" />,
    SUBMITTED: <CheckCircle className="w-4 h-4 text-yellow-400" />,
    APPROVED: <CheckCircle className="w-4 h-4 text-green-400" />,
  };

  const punchColumns: Column<PunchItem>[] = [
    { key: 'description', header: 'Description' },
    { key: 'location', header: 'Location', width: 'w-36' },
    { key: 'severity', header: 'Severity', width: 'w-24', render: (v) => <Badge variant={v === 'HIGH' ? 'danger' : v === 'MEDIUM' ? 'warning' : 'default'}>{String(v)}</Badge> },
    { key: 'status', header: t('common.status'), width: 'w-28', render: (v) => <Badge variant={String(v) === 'FIXED' ? 'success' : String(v) === 'IN_PROGRESS' ? 'warning' : 'danger'}>{String(v)}</Badge> },
    { key: 'assignedTo', header: 'Assigned To', width: 'w-32' },
  ];

  const tabList = [
    { key: 'deliverables', label: t('handover.deliverables') },
    { key: 'punchItems', label: t('handover.punchItems') },
    { key: 'asBuilt', label: t('handover.asBuiltDocs') },
    { key: 'warranties', label: t('handover.warrantyItems') },
    { key: 'signOff', label: t('handover.signOff') },
  ];

  const approvedCount = deliverables.filter((d) => d.status === 'APPROVED').length;
  const totalCount = deliverables.length;

  const handleSignOff = async () => {
    setSigning(true);
    try {
      // await apiPost(`/projects/${projectId}/handover/sign-off`);
    } catch {
      // handle
    } finally {
      setSigning(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('handover.title')}
        subtitle={`${project.name} — ${project.hotel}`}
        showBack
        backTo={-1}
      />

      {/* Progress */}
      <Card>
        <div className="flex items-center gap-4">
          <div className="flex-1">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-slate-300">Deliverables Progress</span>
              <span className="text-[#c9a962] font-semibold">{approvedCount}/{totalCount}</span>
            </div>
            <div className="w-full h-2.5 bg-[#2d2d4a] rounded-full overflow-hidden">
              <div className="h-full bg-[#c9a962] rounded-full transition-all" style={{ width: `${(approvedCount / totalCount) * 100}%` }} />
            </div>
          </div>
        </div>
      </Card>

      <Card noPadding>
        <div className="p-4 border-b border-[#2d2d4a]">
          <Tabs tabs={tabList} activeTab={activeTab} onChange={setActiveTab} />
        </div>
        <div className="p-6">
          {activeTab === 'deliverables' && (
            <div className="space-y-2">
              {deliverables.map((d) => (
                <div key={d.id} className="flex items-center justify-between p-3 bg-[#0f0f1a] rounded-lg border border-[#2d2d4a]">
                  <div className="flex items-center gap-3">
                    {deliverableStatusIcon[d.status]}
                    <span className="text-sm text-slate-200">{d.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    {d.submittedDate && <span className="text-xs text-slate-500">{d.submittedDate}</span>}
                    <Badge variant={d.status === 'APPROVED' ? 'success' : d.status === 'SUBMITTED' ? 'warning' : 'default'}>{d.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'punchItems' && (
            <Table columns={punchColumns} data={punchItems} keyExtractor={(p) => p.id} />
          )}

          {activeTab === 'asBuilt' && (
            <div className="space-y-2">
              {asBuiltDocs.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-3 bg-[#0f0f1a] rounded-lg border border-[#2d2d4a]">
                  <div className="flex items-center gap-3">
                    <FileText className="w-4 h-4 text-[#c9a962]" />
                    <div>
                      <p className="text-sm text-slate-200">{doc.name}</p>
                      <p className="text-xs text-slate-500">{doc.type} • {doc.version}</p>
                    </div>
                  </div>
                  <span className="text-xs text-slate-500">{doc.uploadedDate}</span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'warranties' && (
            <div className="space-y-2">
              {warrantyItems.map((w) => (
                <div key={w.id} className="p-3 bg-[#0f0f1a] rounded-lg border border-[#2d2d4a]">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-slate-200">{w.equipment}</p>
                    <Badge variant="success">{w.warrantyPeriod}</Badge>
                  </div>
                  <p className="text-xs text-slate-500">{w.vendor} • {w.startDate} to {w.endDate}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'signOff' && (
            <div className="text-center py-8">
              <Shield className="w-12 h-12 text-[#c9a962] mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-100 mb-2">Project Handover Sign-Off</h3>
              <p className="text-sm text-slate-400 mb-6 max-w-md mx-auto">
                By signing off, you confirm that all deliverables have been reviewed, punch items resolved, and the project is ready for handover to the client.
              </p>
              <div className="bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg p-4 mb-6 text-start max-w-md mx-auto">
                <div className="flex justify-between text-sm mb-1"><span className="text-slate-400">Approved Deliverables</span><span className="text-green-400">{approvedCount}/{totalCount}</span></div>
                <div className="flex justify-between text-sm mb-1"><span className="text-slate-400">Open Punch Items</span><span className={punchItems.filter(p => p.status !== 'FIXED').length > 0 ? 'text-red-400' : 'text-green-400'}>{punchItems.filter(p => p.status !== 'FIXED').length}</span></div>
                <div className="flex justify-between text-sm"><span className="text-slate-400">Warranty Items</span><span className="text-slate-200">{warrantyItems.length}</span></div>
              </div>
              <Button
                size="lg"
                icon={<CheckSquare className="w-5 h-5" />}
                loading={signing}
                onClick={handleSignOff}
                disabled={approvedCount < totalCount}
              >
                {t('handover.complete')}
              </Button>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default HandoverView;