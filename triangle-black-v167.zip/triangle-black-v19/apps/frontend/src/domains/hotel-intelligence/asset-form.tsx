import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import { Save } from 'lucide-react';
import { Button, Input, Select, Textarea, Card, PageHeader } from '@/shared/components/ui';
import { apiPost, apiPut } from '@/api/client';

const AssetForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [type, setType] = useState('');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [location, setlocation] = useState('');
  const [hotelId, setHotelId] = useState('');
  const [installDate, setInstallDate] = useState('');
  const [warrantyEnd, setWarrantyEnd] = useState('');
  const [specs, setSpecs] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = { name, type, brand, model, serialNumber, location, hotelId, installDate, warrantyEnd, specs };
      if (isEdit) {
        await apiPut(`/assets/${id}`, payload);
      } else {
        await apiPost('/assets', payload);
      }
      navigate('/hotel-intelligence/assets');
    } catch {
      // handle error
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEdit ? t('common.edit') + ' Asset' : t('common.create') + ' Asset'}
        showBack
        backTo="/hotel-intelligence/assets"
        actions={
          <Button type="submit" form="asset-form" loading={loading} icon={<Save className="w-4 h-4" />}>
            {t('common.save')}
          </Button>
        }
      />
      <form id="asset-form" onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label={t('common.name')} value={name} onChange={(e) => setName(e.target.value)} placeholder="Asset name" required />
            <Select label={t('hotelIntelligence.assetType')} options={[
              {value:'',label:'Select type'},
              {value:'CHILLER',label:t('hotelIntelligence.chiller')},
              {value:'AHU',label:t('hotelIntelligence.ahu')},
              {value:'PUMP',label:t('hotelIntelligence.pump')},
              {value:'ELECTRICAL_PANEL',label:t('hotelIntelligence.electricalPanel')},
              {value:'BOILER',label:t('hotelIntelligence.boiler')},
              {value:'ELEVATOR',label:t('hotelIntelligence.elevator')},
              {value:'GENERATOR',label:t('hotelIntelligence.generator')},
              {value:'BMS',label:t('hotelIntelligence.bms')},
              {value:'FIRE_ALARM',label:t('hotelIntelligence.fireAlarm')},
            ]} value={type} onChange={(e) => setType(e.target.value)} required />
            <Input label="Brand" value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="Manufacturer" />
            <Input label="Model" value={model} onChange={(e) => setModel(e.target.value)} placeholder="Model number" />
            <Input label="Serial Number" value={serialNumber} onChange={(e) => setSerialNumber(e.target.value)} placeholder="Serial / Asset tag" />
            <Input label="Location" value={location} onChange={(e) => setlocation(e.target.value)} placeholder="Building, floor, room" />
            <Input label="Hotel" value={hotelId} onChange={(e) => setHotelId(e.target.value)} placeholder="Select hotel" />
            <div className="grid grid-cols-2 gap-3">
              <Input label="Install Date" type="date" value={installDate} onChange={(e) => setInstallDate(e.target.value)} />
              <Input label="Warranty End" type="date" value={warrantyEnd} onChange={(e) => setWarrantyEnd(e.target.value)} />
            </div>
          </div>
        </Card>
        <Card>
          <Textarea label="Specifications / Notes" value={specs} onChange={(e) => setSpecs(e.target.value)} placeholder="Capacity, power rating, refrigerant type, etc." className="min-h-[120px]" />
        </Card>
      </form>
    </div>
  );
};

export default AssetForm;