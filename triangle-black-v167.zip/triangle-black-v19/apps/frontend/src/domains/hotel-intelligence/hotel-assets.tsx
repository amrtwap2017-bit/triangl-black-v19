import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Search } from 'lucide-react';
import { PageHeader, SearchBar, Button, Card, Select, Table, Badge, StatusBadge, Modal } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { apiPost, apiPut } from '@/api/client';
import type { Column } from '@/shared/types';

interface Asset {
  id: string;
  name: string;
  type: string;
  brand: string;
  model: string;
  location: string;
  condition: string;
  status: string;
  lastServiceDate: string;
  hotel: { name: string };
}

const conditionVariant: Record<string, 'success' | 'warning' | 'danger'> = {
  EXCELLENT: 'success',
  GOOD: 'success',
  FAIR: 'warning',
  POOR: 'danger',
  CRITICAL: 'danger',
};

const HotelAssets: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [conditionFilter, setConditionFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const { page, limit, setPage, paginationParams } = usePagination(15);

  const { data: assets, isLoading, meta } = useApi<Asset>(
    ['assets'], '/assets',
    { ...paginationParams(), search, type: typeFilter, condition: conditionFilter, status: statusFilter }
  );

  const columns: Column<Asset>[] = useMemo(() => [
    { key: 'name', header: t('common.name'), sortable: true, render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.name}</p>
        <p className="text-xs text-slate-500">{row.brand} {row.model}</p>
      </div>
    )},
    { key: 'type', header: t('hotelIntelligence.assetType'), width: 'w-28', render: (v) => <Badge>{String(v)}</Badge> },
    { key: 'hotel', header: 'Hotel', width: 'w-36', render: (_, row) => row.hotel?.name || '—' },
    { key: 'location', header: 'Location', width: 'w-32' },
    { key: 'condition', header: t('hotelIntelligence.condition'), width: 'w-28', render: (v) => <Badge variant={conditionVariant[String(v)] || 'default'}>{String(v)}</Badge> },
    { key: 'status', header: t('common.status'), width: 'w-28', render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'lastServiceDate', header: 'Last Service', width: 'w-28', render: (v) => v ? new Date(v as string).toLocaleDateString() : '—' },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('hotelIntelligence.title')}
        subtitle={t('hotelIntelligence.assets')}
        actions={
          <Button icon={<Plus className="w-4 h-4" />} onClick={() => setShowCreate(true)}>
            {t('common.create')} {t('hotelIntelligence.assets').slice(0, -1)}
          </Button>
        }
      />

      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a] flex-wrap">
          <div className="flex-1 min-w-[200px]"><SearchBar onSearch={setSearch} /></div>
          <Select options={[
            { value: '', label: t('common.all') },
            { value: 'CHILLER', label: t('hotelIntelligence.chiller') },
            { value: 'AHU', label: t('hotelIntelligence.ahu') },
            { value: 'PUMP', label: t('hotelIntelligence.pump') },
            { value: 'ELECTRICAL_PANEL', label: t('hotelIntelligence.electricalPanel') },
            { value: 'BOILER', label: t('hotelIntelligence.boiler') },
            { value: 'ELEVATOR', label: t('hotelIntelligence.elevator') },
            { value: 'GENERATOR', label: t('hotelIntelligence.generator') },
            { value: 'BMS', label: t('hotelIntelligence.bms') },
            { value: 'FIRE_ALARM', label: t('hotelIntelligence.fireAlarm') },
          ]} value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} />
          <Select options={[
            { value: '', label: t('common.all') + ' Condition' },
            { value: 'EXCELLENT', label: 'Excellent' },
            { value: 'GOOD', label: 'Good' },
            { value: 'FAIR', label: 'Fair' },
            { value: 'POOR', label: 'Poor' },
            { value: 'CRITICAL', label: 'Critical' },
          ]} value={conditionFilter} onChange={(e) => setConditionFilter(e.target.value)} />
          <Select options={[
            { value: '', label: t('common.all') + ' Status' },
            { value: 'OPERATIONAL', label: 'Operational' },
            { value: 'UNDER_MAINTENANCE', label: 'Under Maintenance' },
            { value: 'DECOMMISSIONED', label: 'Decommissioned' },
          ]} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={assets} keyExtractor={(a) => a.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} />
      </Card>

      {/* Create Asset Modal */}
      <AssetFormModal isOpen={showCreate} onClose={() => setShowCreate(false)} />
    </div>
  );
};

const AssetFormModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: '', type: '', brand: '', model: '', location: '', hotelId: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await apiPost('/assets', form);
      onClose();
    } catch {
      // handle error
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={t('common.create') + ' Asset'} size="lg" footer={
      <>
        <Button variant="secondary" onClick={onClose}>{t('common.cancel')}</Button>
        <Button form="asset-form" type="submit" loading={loading}>{t('common.save')}</Button>
      </>
    }>
      <form id="asset-form" onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input placeholder={t('common.name')} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#c9a962]/50" required />
          <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#c9a962]/50" required>
            <option value="">Select Type</option>
            <option value="CHILLER">Chiller</option>
            <option value="AHU">AHU</option>
            <option value="PUMP">Pump</option>
            <option value="ELECTRICAL_PANEL">Electrical Panel</option>
            <option value="BOILER">Boiler</option>
            <option value="ELEVATOR">Elevator</option>
            <option value="GENERATOR">Generator</option>
            <option value="BMS">BMS</option>
            <option value="FIRE_ALARM">Fire Alarm</option>
          </select>
          <input placeholder="Brand" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} className="w-full bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#c9a962]/50" />
          <input placeholder="Model" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} className="w-full bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#c9a962]/50" />
          <input placeholder="Location" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="w-full bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#c9a962]/50" />
          <input placeholder="Hotel" value={form.hotelId} onChange={(e) => setForm({ ...form, hotelId: e.target.value })} className="w-full bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:ring-2 focus:ring-[#c9a962]/50" />
        </div>
      </form>
    </Modal>
  );
};

export default HotelAssets;