import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Building2,
  Layers,
  ChevronRight,
  ChevronDown,
  MapPin,
  Search,
  Filter,
  Box,
  Zap,
  Wrench,
  Shield,
  Droplets,
  Cpu,
} from 'lucide-react';
import { Card, PageHeader, SearchBar, Button, Select, Badge } from '@/shared/components/ui';

interface AssetNode {
  id: string;
  name: string;
  type: string;
  typeIcon: React.ReactNode;
  condition: 'GOOD' | 'FAIR' | 'POOR' | 'CRITICAL';
  children?: AssetNode[];
  assetCount?: number;
  areaCount?: number;
  path?: string;
}

const conditionColors: Record<string, string> = {
  GOOD: 'text-green-400',
  FAIR: 'text-amber-400',
  POOR: 'text-orange-400',
  CRITICAL: 'text-red-400',
};

const conditionDots: Record<string, string> = {
  GOOD: 'bg-green-500',
  FAIR: 'bg-amber-500',
  POOR: 'bg-orange-500',
  CRITICAL: 'bg-red-500',
};

const typeIcons: Record<string, React.ReactNode> = {
  HVAC: <Zap className="w-3.5 h-3.5" />,
  ELECTRICAL: <Zap className="w-3.5 h-3.5" />,
  PLUMBING: <Droplets className="w-3.5 h-3.5" />,
  FIRE_ALARM: <Shield className="w-3.5 h-3.5" />,
  BMS: <Cpu className="w-3.5 h-3.5" />,
  GENERAL: <Box className="w-3.5 h-3.5" />,
};

const mockTree: AssetNode[] = [
  {
    id: 'b1', name: 'Main Tower', type: 'BUILDING', typeIcon: <Building2 className="w-4 h-4 text-[#c9a962]" />,
    areaCount: 168, assetCount: 1240,
    children: [
      {
        id: 'f1', name: 'Basement 2 — Mechanical', type: 'FLOOR', typeIcon: <Layers className="w-4 h-4 text-blue-400" />,
        areaCount: 4, assetCount: 85,
        children: [
          { id: 'a1', name: 'MEP Room B2-01', type: 'AREA', typeIcon: <MapPin className="w-3.5 h-3.5 text-slate-400" />, assetCount: 42,
            children: [
              { id: 'as1', name: 'Chiller Unit #1', type: 'HVAC', condition: 'FAIR', typeIcon: typeIcons.HVAC, path: '/assets/as1' },
              { id: 'as2', name: 'Chiller Unit #2', type: 'HVAC', condition: 'POOR', typeIcon: typeIcons.HVAC, path: '/assets/as2' },
              { id: 'as3', name: 'Main Distribution Panel', type: 'ELECTRICAL', condition: 'GOOD', typeIcon: typeIcons.ELECTRICAL, path: '/assets/as3' },
              { id: 'as4', name: 'Fire Pump #1', type: 'FIRE_ALARM', condition: 'CRITICAL', typeIcon: typeIcons.FIRE_ALARM, path: '/assets/as4' },
            ],
          },
          { id: 'a2', name: 'Electrical Room B2-02', type: 'AREA', typeIcon: <MapPin className="w-3.5 h-3.5 text-slate-400" />, assetCount: 22,
            children: [
              { id: 'as5', name: 'HV Pump Set', type: 'PLUMBING', condition: 'GOOD', typeIcon: typeIcons.PLUMBING, path: '/assets/as5' },
              { id: 'as6', name: 'CT Panel', type: 'ELECTRICAL', condition: 'FAIR', typeIcon: typeIcons.ELECTRICAL, path: '/assets/as6' },
            ],
          },
          { id: 'a3', name: 'Storage B2-03', type: 'AREA', typeIcon: <MapPin className="w-3.5 h-3.5 text-slate-400" />, assetCount: 8,
            children: [
              { id: 'as7', name: 'Emergency Lighting Battery', type: 'ELECTRICAL', condition: 'POOR', typeIcon: typeIcons.ELECTRICAL, path: '/assets/as7' },
            ],
          },
          { id: 'a4', name: 'Parking B2', type: 'AREA', typeIcon: <MapPin className="w-3.5 h-3.5 text-slate-400" />, assetCount: 13, children: [] },
        ],
      },
      {
        id: 'f2', name: 'Ground Floor — Lobby', type: 'FLOOR', typeIcon: <Layers className="w-4 h-4 text-blue-400" />,
        areaCount: 8, assetCount: 64,
        children: [
          { id: 'a5', name: 'Main Lobby', type: 'AREA', typeIcon: <MapPin className="w-3.5 h-3.5 text-slate-400" />, assetCount: 28,
            children: [
              { id: 'as8', name: 'AHU-L01', type: 'HVAC', condition: 'GOOD', typeIcon: typeIcons.HVAC, path: '/assets/as8' },
              { id: 'as9', name: 'BMS Panel Lobby', type: 'BMS', condition: 'FAIR', typeIcon: typeIcons.BMS, path: '/assets/as9' },
            ],
          },
          { id: 'a6', name: 'Reception', type: 'AREA', typeIcon: <MapPin className="w-3.5 h-3.5 text-slate-400" />, assetCount: 18, children: [] },
        ],
      },
      {
        id: 'f3', name: 'Floors 2-5 — Guest Rooms', type: 'FLOOR', typeIcon: <Layers className="w-4 h-4 text-blue-400" />,
        areaCount: 20, assetCount: 160,
        children: [
          { id: 'a7', name: 'AHU Room 2-01', type: 'AREA', typeIcon: <MapPin className="w-3.5 h-3.5 text-slate-400" />, assetCount: 12,
            children: [
              { id: 'as10', name: 'AHU-201', type: 'HVAC', condition: 'GOOD', typeIcon: typeIcons.HVAC, path: '/assets/as10' },
              { id: 'as11', name: 'FCU-201', type: 'HVAC', condition: 'FAIR', typeIcon: typeIcons.HVAC, path: '/assets/as11' },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 'b2', name: 'Podium', type: 'BUILDING', typeIcon: <Building2 className="w-4 h-4 text-[#c9a962]" />,
    areaCount: 32, assetCount: 380,
    children: [
      {
        id: 'f4', name: 'Ground — Restaurants', type: 'FLOOR', typeIcon: <Layers className="w-4 h-4 text-blue-400" />,
        areaCount: 6, assetCount: 48,
        children: [
          { id: 'a8', name: 'Kitchen Ventilation', type: 'AREA', typeIcon: <MapPin className="w-3.5 h-3.5 text-slate-400" />, assetCount: 15, children: [
            { id: 'as12', name: 'Exhaust Fan #1', type: 'HVAC', condition: 'POOR', typeIcon: typeIcons.HVAC, path: '/assets/as12' },
          ] },
        ],
      },
    ],
  },
];

const TreeNode: React.FC<{
  node: AssetNode;
  depth: number;
  expanded: Set<string>;
  onToggle: (id: string) => void;
  onNavigate: (path: string) => void;
  assetTypeFilter: string;
  conditionFilter: string;
}> = ({ node, depth, expanded, onToggle, onNavigate, assetTypeFilter, conditionFilter }) => {
  const hasChildren = node.children && node.children.length > 0;
  const isExpanded = expanded.has(node.id);
  const isAsset = !hasChildren && node.condition;

  // Filter logic
  if (isAsset && assetTypeFilter && node.type !== assetTypeFilter) return null;
  if (isAsset && conditionFilter && node.condition !== conditionFilter) return null;

  return (
    <div>
      <div
        className="flex items-center gap-2 py-1.5 px-2 hover:bg-[#252540] rounded transition-colors group"
        style={{ paddingLeft: `${depth * 20 + 8}px` }}
      >
        {/* Expand/collapse toggle */}
        {hasChildren ? (
          <button
            onClick={() => onToggle(node.id)}
            className="p-0.5 rounded hover:bg-[#2d2d4a] transition-colors"
          >
            {isExpanded ? (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronRight className="w-4 h-4 text-slate-400" />
            )}
          </button>
        ) : (
          <div className="w-5" />
        )}

        {/* Icon */}
        <div className="shrink-0">{node.typeIcon}</div>

        {/* Name */}
        <span className={`text-sm truncate ${isAsset ? 'text-slate-200' : 'font-medium text-slate-100'}`}>
          {node.name}
        </span>

        {/* Type badge */}
        <Badge variant="default" className="ms-auto me-2">
          {node.type}
        </Badge>

        {/* Condition indicator for assets */}
        {node.condition && (
          <div className="flex items-center gap-1.5">
            <div className={`w-2 h-2 rounded-full ${conditionDots[node.condition]}`} />
            <span className={`text-xs ${conditionColors[node.condition]}`}>
              {node.condition}
            </span>
          </div>
        )}

        {/* Asset count for non-leaf nodes */}
        {node.assetCount !== undefined && (
          <span className="text-xs text-slate-500 ms-2">
            {node.assetCount} assets
          </span>
        )}

        {/* Navigate button for assets */}
        {isAsset && node.path && (
          <button
            onClick={() => onNavigate(node.path)}
            className="opacity-0 group-hover:opacity-100 text-xs text-[#c9a962] transition-opacity"
          >
            →
          </button>
        )}
      </div>

      {/* Children */}
      {hasChildren && isExpanded && (
        <div>
          {node.children!.map((child) => (
            <TreeNode
              key={child.id}
              node={child}
              depth={depth + 1}
              expanded={expanded}
              onToggle={onToggle}
              onNavigate={onNavigate}
              assetTypeFilter={assetTypeFilter}
              conditionFilter={conditionFilter}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const AssetMap: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(['b1', 'f1', 'a1']));
  const [assetTypeFilter, setAssetTypeFilter] = useState('');
  const [conditionFilter, setConditionFilter] = useState('');

  const toggleNode = (nodeId: string) => {
    setExpandedNodes((prev) => {
      const next = new Set(prev);
      if (next.has(nodeId)) {
        next.delete(nodeId);
      } else {
        next.add(nodeId);
      }
      return next;
    });
  };

  const expandAll = () => {
    const allIds = new Set<string>();
    const collectIds = (nodes: AssetNode[]) => {
      nodes.forEach((n) => {
        if (n.children && n.children.length > 0) {
          allIds.add(n.id);
          collectIds(n.children);
        }
      });
    };
    collectIds(mockTree);
    setExpandedNodes(allIds);
  };

  const collapseAll = () => {
    setExpandedNodes(new Set());
  };

  // Count assets by condition
  const allAssets: { type: string; condition: string }[] = [];
  const collectAssets = (nodes: AssetNode[]) => {
    nodes.forEach((n) => {
      if (n.condition) allAssets.push({ type: n.type, condition: n.condition });
      if (n.children) collectAssets(n.children);
    });
  };
  collectAssets(mockTree);

  const criticalCount = allAssets.filter((a) => a.condition === 'CRITICAL').length;
  const poorCount = allAssets.filter((a) => a.condition === 'POOR').length;

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('hotelTwin.assetMap', 'Asset Map')}
        subtitle={t('hotelTwin.assetMapSubtitle', 'Navigate hotel structure and locate assets')}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={expandAll}>
              {t('hotelTwin.expandAll', 'Expand All')}
            </Button>
            <Button variant="secondary" size="sm" onClick={collapseAll}>
              {t('hotelTwin.collapseAll', 'Collapse All')}
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <Card>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <div className="flex-1 w-full sm:w-auto">
            <SearchBar
              onSearch={setSearch}
              placeholder={t('hotelTwin.searchAssets', 'Search assets...')}
            />
          </div>
          <div className="w-40">
            <Select
              options={[
                { value: '', label: t('common.allTypes', 'All Types') },
                { value: 'HVAC', label: 'HVAC' },
                { value: 'ELECTRICAL', label: 'Electrical' },
                { value: 'PLUMBING', label: 'Plumbing' },
                { value: 'FIRE_ALARM', label: 'Fire Alarm' },
                { value: 'BMS', label: 'BMS' },
              ]}
              value={assetTypeFilter}
              onChange={(e) => setAssetTypeFilter(e.target.value)}
            />
          </div>
          <div className="w-36">
            <Select
              options={[
                { value: '', label: t('common.allConditions', 'All Conditions') },
                { value: 'GOOD', label: 'Good' },
                { value: 'FAIR', label: 'Fair' },
                { value: 'POOR', label: 'Poor' },
                { value: 'CRITICAL', label: 'Critical' },
              ]}
              value={conditionFilter}
              onChange={(e) => setConditionFilter(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-3">
            {criticalCount > 0 && (
              <Badge variant="danger">{criticalCount} critical</Badge>
            )}
            {poorCount > 0 && (
              <Badge variant="warning">{poorCount} poor</Badge>
            )}
          </div>
        </div>
      </Card>

      {/* Tree View */}
      <Card>
        <div className="flex items-center gap-4 mb-4 pb-3 border-b border-[#2d2d4a]">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-green-500" /> Good</div>
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-amber-500" /> Fair</div>
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-orange-500" /> Poor</div>
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-red-500" /> Critical</div>
          </div>
        </div>

        <div className="space-y-0.5">
          {mockTree.map((node) => (
            <TreeNode
              key={node.id}
              node={node}
              depth={0}
              expanded={expandedNodes}
              onToggle={toggleNode}
              onNavigate={(path) => navigate(path)}
              assetTypeFilter={assetTypeFilter}
              conditionFilter={conditionFilter}
            />
          ))}
        </div>
      </Card>
    </div>
  );
};

export default AssetMap;
