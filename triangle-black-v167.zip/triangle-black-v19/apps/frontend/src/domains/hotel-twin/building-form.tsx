import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Trash2, Save, Layers, Building2, MapPin } from 'lucide-react';
import {
  PageHeader,
  Card,
  Button,
  Input,
  Select,
  Badge,
} from '@/shared/components/ui';

interface FloorEntry {
  id: string;
  number: string;
  name: string;
  type: string;
  area: number;
  areas: AreaEntry[];
}

interface AreaEntry {
  id: string;
  name: string;
  type: string;
  area: number;
  occupancyCapacity: number;
}

const buildingTypes = [
  { value: '', label: 'Select Type' },
  { value: 'Guest Rooms', label: 'Guest Rooms' },
  { value: 'Commercial', label: 'Commercial' },
  { value: 'Leisure', label: 'Leisure' },
  { value: 'Operations', label: 'Operations' },
  { value: 'Restaurant', label: 'Restaurant' },
  { value: 'Parking', label: 'Parking' },
  { value: 'Other', label: 'Other' },
];

const floorTypes = [
  { value: '', label: 'Select Type' },
  { value: 'Basement', label: 'Basement' },
  { value: 'Ground', label: 'Ground' },
  { value: 'Typical Floor', label: 'Typical Floor' },
  { value: 'Mechanical', label: 'Mechanical' },
  { value: 'Roof', label: 'Roof' },
  { value: 'Mezzanine', label: 'Mezzanine' },
];

const areaTypes = [
  { value: '', label: 'Select Type' },
  { value: 'Guest Room', label: 'Guest Room' },
  { value: 'Corridor', label: 'Corridor' },
  { value: 'Lobby', label: 'Lobby' },
  { value: 'Mechanical Room', label: 'Mechanical Room' },
  { value: 'Electrical Room', label: 'Electrical Room' },
  { value: 'Restaurant', label: 'Restaurant' },
  { value: 'Kitchen', label: 'Kitchen' },
  { value: 'Spa', label: 'Spa' },
  { value: 'Pool', label: 'Pool' },
  { value: 'Storage', label: 'Storage' },
  { value: 'Utility', label: 'Utility' },
  { value: 'Office', label: 'Office' },
];

const createEmptyFloor = (): FloorEntry => ({
  id: crypto.randomUUID(),
  number: '',
  name: '',
  type: '',
  area: 0,
  areas: [],
});

const createEmptyArea = (): AreaEntry => ({
  id: crypto.randomUUID(),
  name: '',
  type: '',
  area: 0,
  occupancyCapacity: 0,
});

const BuildingForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = Boolean(id);

  const [name, setName] = useState('');
  const [type, setType] = useState('');
  const [floors, setFloors] = useState<FloorEntry[]>([createEmptyFloor()]);
  const [yearBuilt, setYearBuilt] = useState('');
  const [totalArea, setTotalArea] = useState('');
  const [saving, setSaving] = useState(false);

  const addFloor = () => {
    setFloors([...floors, createEmptyFloor()]);
  };

  const removeFloor = (floorId: string) => {
    if (floors.length > 1) {
      setFloors(floors.filter((f) => f.id !== floorId));
    }
  };

  const updateFloor = (floorId: string, field: keyof FloorEntry, value: string | number) => {
    setFloors(floors.map((f) => (f.id === floorId ? { ...f, [field]: value } : f)));
  };

  const addAreaToFloor = (floorId: string) => {
    setFloors(floors.map((f) => (f.id === floorId ? { ...f, areas: [...f.areas, createEmptyArea()] } : f)));
  };

  const removeAreaFromFloor = (floorId: string, areaId: string) => {
    setFloors(
      floors.map((f) =>
        f.id === floorId ? { ...f, areas: f.areas.filter((a) => a.id !== areaId) } : f
      )
    );
  };

  const updateAreaInFloor = (floorId: string, areaId: string, field: keyof AreaEntry, value: string | number) => {
    setFloors(
      floors.map((f) =>
        f.id === floorId
          ? {
              ...f,
              areas: f.areas.map((a) => (a.id === areaId ? { ...a, [field]: value } : a)),
            }
          : f
      )
    );
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // await apiPost('/hotel-twin/buildings', { name, type, floors, yearBuilt, totalArea });
      navigate('/hotel-twin');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEditing ? t('hotelTwin.editBuilding', 'Edit Building') : t('hotelTwin.addBuilding', 'Add Building')}
        showBack
        backTo="/hotel-twin"
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" icon={<Save className="w-4 h-4" />} onClick={handleSave} loading={saving}>
              {t('common.save', 'Save')}
            </Button>
            <Button icon={<Save className="w-4 h-4" />} onClick={handleSave} loading={saving} disabled={!name || !type}>
              {t('common.saveAndContinue', 'Save & Continue')}
            </Button>
          </div>
        }
      />

      {/* Building Details */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('hotelTwin.buildingDetails', 'Building Details')}</h3>}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <Input
              label={t('common.name', 'Building Name')}
              placeholder="e.g., Main Tower"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div>
            <Select
              label={t('common.type', 'Building Type')}
              options={buildingTypes}
              value={type}
              onChange={(e) => setType(e.target.value)}
            />
          </div>
          <div>
            <Input
              type="number"
              label={t('hotelTwin.yearBuilt', 'Year Built')}
              placeholder="e.g., 1999"
              value={yearBuilt}
              onChange={(e) => setYearBuilt(e.target.value)}
            />
          </div>
          <div>
            <Input
              type="number"
              label={t('common.area', 'Total Area (sqm)')}
              placeholder="e.g., 25000"
              value={totalArea}
              onChange={(e) => setTotalArea(e.target.value)}
            />
          </div>
        </div>
      </Card>

      {/* Floors */}
      <Card
        header={
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-slate-100">{t('hotelTwin.floors', 'Floors')}</h3>
              <p className="text-xs text-slate-500 mt-0.5">{t('hotelTwin.floorsCount', `${floors.length} floors added`)}</p>
            </div>
            <Button size="sm" icon={<Plus className="w-4 h-4" />} onClick={addFloor}>
              {t('hotelTwin.addFloor', 'Add Floor')}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {floors.map((floor, floorIndex) => (
            <div key={floor.id} className="border border-[#2d2d4a] rounded-lg overflow-hidden">
              {/* Floor Header */}
              <div className="p-4 bg-[#15152a]">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded bg-[#252540]">
                      <Layers className="w-4 h-4 text-[#c9a962]" />
                    </div>
                    <span className="text-sm font-medium text-slate-200">
                      {t('hotelTwin.floor', 'Floor')} #{floorIndex + 1}
                    </span>
                    <Badge variant="info">{floor.areas.length} {t('hotelTwin.areas', 'areas')}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="ghost" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => addAreaToFloor(floor.id)}>
                      {t('hotelTwin.addArea', '+ Area')}
                    </Button>
                    {floors.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<Trash2 className="w-3.5 h-3.5 text-red-400" />}
                        onClick={() => removeFloor(floor.id)}
                      />
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <Input
                    label={t('hotelTwin.floorNumber', 'Floor Number')}
                    placeholder="e.g., 1, B1, G"
                    value={floor.number}
                    onChange={(e) => updateFloor(floor.id, 'number', e.target.value)}
                  />
                  <Input
                    label={t('hotelTwin.floorName', 'Floor Name')}
                    placeholder="e.g., Lobby Level"
                    value={floor.name}
                    onChange={(e) => updateFloor(floor.id, 'name', e.target.value)}
                  />
                  <Select
                    label={t('common.type', 'Floor Type')}
                    options={floorTypes}
                    value={floor.type}
                    onChange={(e) => updateFloor(floor.id, 'type', e.target.value)}
                  />
                  <Input
                    type="number"
                    label={t('common.area', 'Area (sqm)')}
                    placeholder="0"
                    value={String(floor.area)}
                    onChange={(e) => updateFloor(floor.id, 'area', Number(e.target.value))}
                  />
                </div>
              </div>

              {/* Areas */}
              {floor.areas.length > 0 && (
                <div className="p-4 space-y-3 border-t border-[#2d2d4a]">
                  <p className="text-xs font-semibold text-slate-400 uppercase">{t('hotelTwin.areas', 'Areas')}</p>
                  {floor.areas.map((area, areaIndex) => (
                    <div key={area.id} className="p-3 bg-[#1a1a2e] border border-[#2d2d4a]/50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-medium text-slate-300">
                          {t('hotelTwin.area', 'Area')} #{areaIndex + 1}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          icon={<Trash2 className="w-3 h-3 text-red-400" />}
                          onClick={() => removeAreaFromFloor(floor.id, area.id)}
                        />
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                        <Input
                          label={t('common.name', 'Name')}
                          placeholder="e.g., Room 101"
                          value={area.name}
                          onChange={(e) => updateAreaInFloor(floor.id, area.id, 'name', e.target.value)}
                        />
                        <Select
                          label={t('common.type', 'Type')}
                          options={areaTypes}
                          value={area.type}
                          onChange={(e) => updateAreaInFloor(floor.id, area.id, 'type', e.target.value)}
                        />
                        <Input
                          type="number"
                          label={t('common.area', 'Area (sqm)')}
                          placeholder="0"
                          value={String(area.area)}
                          onChange={(e) => updateAreaInFloor(floor.id, area.id, 'area', Number(e.target.value))}
                        />
                        <Input
                          type="number"
                          label={t('hotelTwin.occupancy', 'Occupancy Capacity')}
                          placeholder="0"
                          value={String(area.occupancyCapacity)}
                          onChange={(e) => updateAreaInFloor(floor.id, area.id, 'occupancyCapacity', Number(e.target.value))}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default BuildingForm;
