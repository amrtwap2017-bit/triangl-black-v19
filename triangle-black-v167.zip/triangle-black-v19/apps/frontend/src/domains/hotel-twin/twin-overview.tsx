import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Building2,
  Layers,
  AlertTriangle,
  Wrench,
  ChevronRight,
  MapPin,
  Box,
  Shield,
  Zap,
} from 'lucide-react';
import { Card, PageHeader, StatCard, Button, Select, Badge } from '@/shared/components/ui';

interface BuildingInfo {
  id: string;
  name: string;
  type: string;
  floors: number;
  areas: number;
  assets: number;
  criticalConditions: number;
  upcomingMaintenance: number;
}

interface AssetDistribution {
  category: string;
  count: number;
  icon: React.ReactNode;
  color: string;
}

interface FloorInfo {
  id: string;
  number: string;
  name: string;
  areas: number;
}

const hotels = [
  { value: 'h1', label: 'Burj Al Arab' },
  { value: 'h2', label: 'Atlantis The Royal' },
  { value: 'h3', label: 'Mandarin Oriental' },
  { value: 'h4', label: 'Four Seasons DIFC' },
  { value: 'h5', label: 'Ritz Carlton' },
];

const mockBuildings: BuildingInfo[] = [
  { id: 'b1', name: 'Main Tower', type: 'Guest Rooms', floors: 28, areas: 168, assets: 1240, criticalConditions: 3, upcomingMaintenance: 12 },
  { id: 'b2', name: 'Podium', type: 'Commercial', floors: 4, areas: 32, assets: 380, criticalConditions: 1, upcomingMaintenance: 5 },
  { id: 'b3', name: 'Spa Wing', type: 'Leisure', floors: 3, areas: 18, assets: 210, criticalConditions: 0, upcomingMaintenance: 3 },
  { id: 'b4', name: 'Service Building', type: 'Operations', floors: 2, areas: 12, assets: 95, criticalConditions: 2, upcomingMaintenance: 8 },
  { id: 'b5', name: 'Pavilion', type: 'Restaurant', floors: 1, areas: 6, assets: 48, criticalConditions: 0, upcomingMaintenance: 2 },
];

const mockFloors: Record<string, FloorInfo[]> = {
  b1: [
    { id: 'f1', number: 'B2', name: 'Basement 2', areas: 4 },
    { id: 'f2', number: 'B1', name: 'Basement 1', areas: 6 },
    { id: 'f3', number: 'G', name: 'Ground Floor', areas: 8 },
    { id: 'f4', number: '1', name: 'Lobby', areas: 4 },
    { id: 'f5', number: '2-5', name: 'Guest Floors', areas: 20 },
    { id: 'f6', number: '6-10', name: 'Guest Floors', areas: 20 },
    { id: 'f7', number: '11-15', name: 'Guest Floors', areas: 20 },
    { id: 'f8', number: '16-20', name: 'Guest Floors', areas: 20 },
    { id: 'f9', number: '21-25', name: 'Guest Floors', areas: 20 },
    { id: 'f10', number: '26-28', name: 'Royal Suite Floors', areas: 16 },
  ],
};

const assetDistribution: AssetDistribution[] = [
  { category: 'HVAC', count: 520, icon: <Zap className="w-4 h-4" />, color: 'bg-blue-500' },
  { category: 'Electrical', count: 380, icon: <Zap className="w-4 h-4" />, color: 'bg-amber-500' },
  { category: 'Plumbing', count: 260, icon: <Wrench className="w-4 h-4" />, color: 'bg-cyan-500' },
  { category: 'Fire Protection', count: 180, icon: <Shield className="w-4 h-4" />, color: 'bg-red-500' },
  { category: 'BMS', count: 95, icon: <Box className="w-4 h-4" />, color: 'bg-green-500' },
  { category: 'Other', count: 548, icon: <Layers className="w-4 h-4" />, color: 'bg-purple-500' },
];

const TwinOverview: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [selectedHotel, setSelectedHotel] = useState('h1');
  const [expandedBuilding, setExpandedBuilding] = useState<string | null>('b1');

  const totalAssets = mockBuildings.reduce((s, b) => s + b.assets, 0);
  const totalCritical = mockBuildings.reduce((s, b) => s + b.criticalConditions, 0);
  const totalUpcoming = mockBuildings.reduce((s, b) => s + b.upcomingMaintenance, 0);
  const totalFloors = mockBuildings.reduce((s, b) => s + b.floors, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('hotelTwin.title', 'Hotel Digital Twin')}
        subtitle={t('hotelTwin.subtitle', 'Digital representation of hotel assets and structure')}
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={() => navigate('/hotel-twin/building/new')}>
              {t('hotelTwin.addBuilding', 'Add Building')}
            </Button>
            <Button onClick={() => navigate('/hotel-twin/asset-map')}>
              {t('hotelTwin.viewAssetMap', 'Asset Map')}
            </Button>
          </div>
        }
      />

      {/* Hotel Selector */}
      <Card>
        <div className="flex items-center gap-3">
          <MapPin className="w-5 h-5 text-[#c9a962]" />
          <Select
            options={hotels}
            value={selectedHotel}
            onChange={(e) => setSelectedHotel(e.target.value)}
            className="w-64"
          />
        </div>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={<Box className="w-5 h-5" />}
          label={t('hotelTwin.totalAssets', 'Total Assets')}
          value={totalAssets}
          change={3.2}
        />
        <StatCard
          icon={<AlertTriangle className="w-5 h-5" />}
          label={t('hotelTwin.criticalConditions', 'Critical Conditions')}
          value={totalCritical}
          change={1}
        />
        <StatCard
          icon={<Wrench className="w-5 h-5" />}
          label={t('hotelTwin.upcomingMaintenance', 'Upcoming Maintenance')}
          value={totalUpcoming}
        />
        <StatCard
          icon={<Layers className="w-5 h-5" />}
          label={t('hotelTwin.totalFloors', 'Total Floors')}
          value={totalFloors}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Buildings List */}
        <div className="lg:col-span-2">
          <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('hotelTwin.buildings', 'Buildings')}</h3>}>
            <div className="space-y-3">
              {mockBuildings.map((building) => (
                <div
                  key={building.id}
                  className="border border-[#2d2d4a] rounded-lg overflow-hidden hover:border-[#c9a962]/30 transition-colors"
                >
                  {/* Building Header */}
                  <button
                    className="w-full flex items-center justify-between p-4 text-start hover:bg-[#252540] transition-colors"
                    onClick={() =>
                      setExpandedBuilding(expandedBuilding === building.id ? null : building.id)
                    }
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-[#252540]">
                        <Building2 className="w-5 h-5 text-[#c9a962]" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-slate-100">{building.name}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <Badge variant="info">{building.type}</Badge>
                          <span className="text-xs text-slate-500">{building.floors} {t('hotelTwin.floors', 'floors')} • {building.areas} {t('hotelTwin.areas', 'areas')}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-end">
                        <p className="text-xs text-slate-500">{t('common.assets', 'Assets')}</p>
                        <p className="text-sm font-semibold text-slate-200">{building.assets}</p>
                      </div>
                      {building.criticalConditions > 0 && (
                        <Badge variant="danger">{building.criticalConditions} critical</Badge>
                      )}
                      <ChevronRight
                        className={`w-5 h-5 text-slate-400 transition-transform ${
                          expandedBuilding === building.id ? 'rotate-90' : ''
                        }`}
                      />
                    </div>
                  </button>

                  {/* Expanded: Floors */}
                  {expandedBuilding === building.id && (
                    <div className="px-4 pb-4 border-t border-[#2d2d4a]">
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 mt-3">
                        {(mockFloors[building.id] || []).map((floor) => (
                          <button
                            key={floor.id}
                            className="p-2.5 bg-[#15152a] border border-[#2d2d4a] rounded-lg text-start hover:border-[#c9a962]/30 transition-colors"
                            onClick={() => navigate(`/hotel-twin/building/${building.id}/floor/${floor.id}`)}
                          >
                            <div className="flex items-center gap-2 mb-1">
                              <Layers className="w-3.5 h-3.5 text-[#c9a962]" />
                              <span className="text-xs font-semibold text-slate-200">{floor.number}</span>
                            </div>
                            <p className="text-[10px] text-slate-400">{floor.name}</p>
                            <p className="text-[10px] text-slate-500">{floor.areas} areas</p>
                          </button>
                        ))}
                      </div>

                      {/* Building stats */}
                      <div className="flex items-center gap-4 mt-3 pt-3 border-t border-[#2d2d4a]">
                        <div className="flex items-center gap-1.5 text-xs">
                          <span className="text-slate-500">{t('common.assets', 'Assets')}:</span>
                          <span className="font-medium text-slate-200">{building.assets}</span>
                        </div>
                        {building.criticalConditions > 0 && (
                          <div className="flex items-center gap-1.5 text-xs">
                            <span className="text-slate-500">{t('hotelTwin.critical', 'Critical')}:</span>
                            <span className="font-medium text-red-400">{building.criticalConditions}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-1.5 text-xs">
                          <span className="text-slate-500">{t('hotelTwin.maintenance', 'Maintenance')}:</span>
                          <span className="font-medium text-amber-400">{building.upcomingMaintenance}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Asset Distribution */}
        <div>
          <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('hotelTwin.assetDistribution', 'Asset Distribution')}</h3>}>
            <div className="space-y-3">
              {assetDistribution.map((item) => {
                const percentage = (item.count / totalAssets) * 100;
                return (
                  <div key={item.category} className="space-y-1.5">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className={`p-1 rounded ${item.color}/20 text-slate-300`}>
                          {item.icon}
                        </div>
                        <span className="font-medium text-slate-200">{item.category}</span>
                      </div>
                      <span className="text-slate-400">{item.count}</span>
                    </div>
                    <div className="w-full h-2 bg-[#2d2d4a] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${item.color} transition-all`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}

              <div className="pt-3 border-t border-[#2d2d4a] text-center">
                <p className="text-2xl font-bold text-[#c9a962]">{totalAssets}</p>
                <p className="text-xs text-slate-500">{t('hotelTwin.totalAssets', 'Total Assets')}</p>
              </div>
            </div>
          </Card>

          {/* Quick Actions */}
          <Card className="mt-6">
            <h3 className="text-lg font-semibold text-slate-100 mb-3">{t('common.quickActions', 'Quick Actions')}</h3>
            <div className="space-y-2">
              <Button
                variant="secondary"
                className="w-full justify-start"
                icon={<Building2 className="w-4 h-4" />}
                onClick={() => navigate('/hotel-twin/building/new')}
              >
                {t('hotelTwin.addBuilding', 'Add Building')}
              </Button>
              <Button
                variant="secondary"
                className="w-full justify-start"
                icon={<Box className="w-4 h-4" />}
                onClick={() => navigate('/hotel-twin/asset-map')}
              >
                {t('hotelTwin.browseAssets', 'Browse Assets')}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TwinOverview;
