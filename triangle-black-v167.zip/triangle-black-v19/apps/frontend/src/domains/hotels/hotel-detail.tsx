import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Building2, Star, MapPin, Phone, Mail, DollarSign, HardHat,
  FileText, AlertTriangle, FolderOpen, Heart, Users, Edit,
  Target, TrendingUp, Calendar,
} from 'lucide-react';
import { PageHeader } from '@/shared/components/ui/page-header';
import { Card } from '@/shared/components/ui/card';
import { Tabs } from '@/shared/components/ui/tabs';
import { Badge } from '@/shared/components/ui/badge';
import { Button } from '@/shared/components/ui/button';
import { LoadingSpinner } from '@/shared/components/ui/loading-spinner';
import { EmptyState } from '@/shared/components/ui/empty-state';
import { RevenueChart } from '@/shared/components/charts';
import { useApiSingle } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { Hotel, Column, Project, Opportunity, Proposal, EmergencyCase, Document, RevenueData } from '@/shared/types';

const mockRevenue: RevenueData[] = [
  { month: 'Jan', revenue: 120000, cost: 85000, profit: 35000 },
  { month: 'Feb', revenue: 95000, cost: 68000, profit: 27000 },
  { month: 'Mar', revenue: 140000, cost: 95000, profit: 45000 },
  { month: 'Apr', revenue: 110000, cost: 78000, profit: 32000 },
  { month: 'May', revenue: 155000, cost: 105000, profit: 50000 },
  { month: 'Jun', revenue: 130000, cost: 90000, profit: 40000 },
];

const HotelDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  const { data: hotel, isLoading } = useApiSingle<Hotel>(
    ['hotel', id!],
    endpoints.hotels.update(id!)
  );

  if (isLoading) return <LoadingSpinner />;
  if (!hotel) return <EmptyState message="Hotel not found" />;

  const tabs = [
    { key: 'overview', label: t('hotels.overview'), icon: <Building2 className="w-4 h-4" /> },
    { key: 'projects', label: t('hotels.projects'), icon: <HardHat className="w-4 h-4" /> },
    { key: 'opportunities', label: t('hotels.opportunities'), icon: <Target className="w-4 h-4" /> },
    { key: 'proposals', label: t('hotels.proposals'), icon: <FileText className="w-4 h-4" /> },
    { key: 'emergencies', label: t('hotels.emergencies'), icon: <AlertTriangle className="w-4 h-4" /> },
    { key: 'documents', label: t('hotels.documents'), icon: <FolderOpen className="w-4 h-4" /> },
    { key: 'relationship', label: t('hotels.relationship'), icon: <Heart className="w-4 h-4" /> },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title={hotel.name}
        subtitle={`${hotel.city}, ${hotel.country} • ${hotel.chain || ''}`}
        breadcrumbs={[
          { label: t('hotels.title'), href: '/hotels' },
          { label: hotel.name },
        ]}
        showBack
        actions={
          <Button icon={<Edit className="w-4 h-4" />} variant="secondary" onClick={() => navigate(`/hotels/${id}/edit`)}>
            {t('common.edit')}
          </Button>
        }
      />

      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <Card>
              <div className="text-center mb-4">
                <div className="w-16 h-16 rounded-2xl bg-[#252540] flex items-center justify-center text-[#c9a962] mx-auto mb-3">
                  <Building2 className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-slate-100">{hotel.name}</h3>
                <div className="flex justify-center gap-0.5 mt-1">
                  {Array.from({ length: hotel.starRating }, (_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#c9a962] text-[#c9a962]" />
                  ))}
                </div>
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-2 text-slate-400">
                  <MapPin className="w-4 h-4 shrink-0" />
                  <span>{hotel.address}</span>
                </div>
                {hotel.totalRooms && (
                  <div className="flex items-center gap-2 text-slate-400">
                    <Users className="w-4 h-4 shrink-0" />
                    <span>{hotel.totalRooms} rooms</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-slate-400">
                  <DollarSign className="w-4 h-4 shrink-0" />
                  <span className="text-[#c9a962] font-semibold">${hotel.totalRevenue.toLocaleString()}</span>
                </div>
              </div>
            </Card>
            <Card>
              <h4 className="font-semibold text-slate-200 mb-3">{t('hotels.contacts')}</h4>
              <EmptyState message="No contacts yet" />
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <Card header={<h4 className="font-semibold text-slate-200">{t('dashboard.revenueChart')}</h4>}>
              <RevenueChart data={mockRevenue} height={250} />
            </Card>
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <p className="text-sm text-slate-400">{t('hotels.activeProjects')}</p>
                <p className="text-2xl font-bold text-slate-100 mt-1">{hotel.projectCount}</p>
              </Card>
              <Card>
                <p className="text-sm text-slate-400">{t('hotels.relationshipScore')}</p>
                <p className="text-2xl font-bold text-[#c9a962] mt-1">{hotel.relationshipScore}/100</p>
              </Card>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'relationship' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card header={<h4 className="font-semibold text-slate-200">{t('hotels.relationshipScore')}</h4>}>
            <div className="flex items-center justify-center py-8">
              <div className="relative w-40 h-40">
                <svg className="w-40 h-40 -rotate-90" viewBox="0 0 120 120">
                  <circle cx="60" cy="60" r="50" fill="none" stroke="#2d2d4a" strokeWidth="10" />
                  <circle cx="60" cy="60" r="50" fill="none" stroke="#c9a962" strokeWidth="10"
                    strokeDasharray={`${(hotel.relationshipScore / 100) * 314} 314`}
                    strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-bold text-[#c9a962]">{hotel.relationshipScore}</span>
                  <span className="text-xs text-slate-400">/ 100</span>
                </div>
              </div>
            </div>
          </Card>
          <Card header={<h4 className="font-semibold text-slate-200">Engagement Timeline</h4>}>
            <div className="space-y-4">
              {['Project started: Lobby Renovation', 'Proposal submitted: FF&E Supply', 'Emergency resolved: AC Unit Failure', 'New request received: Room Refresh'].map((event, i) => (
                <div key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-2.5 h-2.5 rounded-full bg-[#c9a962]" />
                    {i < 3 && <div className="w-px flex-1 bg-[#2d2d4a]" />}
                  </div>
                  <p className="text-sm text-slate-300 pb-4">{event}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {['projects', 'opportunities', 'proposals', 'emergencies', 'documents'].includes(activeTab) && (
        <Card>
          <EmptyState message={`No ${activeTab} found for this hotel`} />
        </Card>
      )}
    </div>
  );
};

export default HotelDetail;