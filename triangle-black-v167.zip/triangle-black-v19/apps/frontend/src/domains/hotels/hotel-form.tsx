import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save, X } from 'lucide-react';
import { PageHeader } from '@/shared/components/ui/page-header';
import { Card } from '@/shared/components/ui/card';
import { Input } from '@/shared/components/ui/input';
import { Select } from '@/shared/components/ui/select';
import { Textarea } from '@/shared/components/ui/textarea';
import { Button } from '@/shared/components/ui/button';
import { apiPost, apiPut } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const hotelSchema = z.object({
  name: z.string().min(2, 'Name required'),
  nameAr: z.string().optional(),
  chain: z.string().optional(),
  starRating: z.coerce.number().min(1).max(7),
  city: z.string().min(1, 'City required'),
  cityAr: z.string().optional(),
  country: z.string().min(1, 'Country required'),
  countryAr: z.string().optional(),
  address: z.string().min(1, 'Address required'),
  addressAr: z.string().optional(),
  totalRooms: z.coerce.number().optional(),
  notes: z.string().optional(),
});

type HotelForm = z.infer<typeof hotelSchema>;

const HotelFormPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const isEdit = !!id;
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<HotelForm>({
    resolver: zodResolver(hotelSchema),
    defaultValues: {
      starRating: 5,
    },
  });

  const onSubmit = async (data: HotelForm) => {
    setLoading(true);
    try {
      if (isEdit) {
        await apiPut(endpoints.hotels.update(id!), data);
      } else {
        await apiPost(endpoints.hotels.create, data);
      }
      toast.success(t('common.success'));
      navigate('/hotels');
    } catch {
      toast.error(t('common.error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEdit ? t('hotels.editHotel') : t('hotels.addHotel')}
        showBack
        backTo="/hotels"
        breadcrumbs={[
          { label: t('hotels.title'), href: '/hotels' },
          { label: isEdit ? t('common.edit') : t('common.create') },
        ]}
      />

      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label={t('hotels.name')} error={errors.name?.message} {...register('name')} />
            <Input label="الاسم بالعربي" {...register('nameAr')} />
            <Input label={t('hotels.chain')} {...register('chain')} />
            <Select
              label={t('hotels.starRating')}
              options={[1,2,3,4,5,6,7].map(n => ({ value: String(n), label: `${n} Stars` }))}
              error={errors.starRating?.message}
              {...register('starRating')}
            />
            <Input label={t('hotels.city')} error={errors.city?.message} {...register('city')} />
            <Input label="المدينة بالعربي" {...register('cityAr')} />
            <Input label={t('hotels.country')} error={errors.country?.message} {...register('country')} />
            <Input label="الدولة بالعربي" {...register('countryAr')} />
            <Input label={t('hotels.address')} error={errors.address?.message} {...register('address')} className="md:col-span-2" />
            <Input label="العنوان بالعربي" {...register('addressAr')} className="md:col-span-2" />
            <Input label={t('hotels.totalRooms')} type="number" {...register('totalRooms')} />
            <Textarea label={t('common.notes')} {...register('notes')} className="md:col-span-2" />
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" icon={<X className="w-4 h-4" />} onClick={() => navigate('/hotels')}>
              {t('common.cancel')}
            </Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>
              {t('common.save')}
            </Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default HotelFormPage;