import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Star, Building2 } from 'lucide-react';
import { PageHeader } from '@/shared/components/ui/page-header';
import { SearchBar } from '@/shared/components/ui/search-bar';
import { Button } from '@/shared/components/ui/button';
import { Select } from '@/shared/components/ui/select';
import { Table, Card } from '@/shared/components/ui';
import { StatusBadge } from '@/shared/components/ui/status-badge';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { Hotel, Column } from '@/shared/types';

const HotelsList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [starFilter, setStarFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: hotels, isLoading, meta } = useApi<Hotel>(
    ['hotels'],
    endpoints.hotels.list,
    { ...paginationParams(), search, starRating: starFilter }
  );

  const columns: Column<Hotel>[] = useMemo(() => [
    { key: 'name', header: t('hotels.name'), sortable: true, render: (_, row) => (
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-[#252540] flex items-center justify-center text-[#c9a962]">
          <Building2 className="w-4 h-4" />
        </div>
        <div>
          <p className="font-medium text-slate-100">{row.name}</p>
          {row.chain && <p className="text-xs text-slate-500">{row.chain}</p>}
        </div>
      </div>
    )},
    { key: 'starRating', header: t('hotels.starRating'), align: 'center', render: (v) => (
      <div className="flex gap-0.5 justify-center">
        {Array.from({ length: v as number }, (_, i) => (
          <Star key={i} className="w-3.5 h-3.5 fill-[#c9a962] text-[#c9a962]" />
        ))}
      </div>
    )},
    { key: 'city', header: t('hotels.city') },
    { key: 'country', header: t('hotels.country') },
    { key: 'relationshipScore', header: t('hotels.relationshipScore'), align: 'center', render: (v) => (
      <span className="text-sm font-medium text-[#c9a962]">{v as number}/100</span>
    )},
    { key: 'totalRevenue', header: t('hotels.totalRevenue'), align: 'end', render: (v) => `$${(v as number).toLocaleString()}` },
    { key: 'isActive', header: t('common.status'), align: 'center', render: (v) => <StatusBadge status={v ? 'ACTIVE' : 'CLOSED'} /> },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('hotels.title')}
        actions={
          <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/hotels/new')}>
            {t('hotels.addHotel')}
          </Button>
        }
      />

      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1">
            <SearchBar onSearch={setSearch} />
          </div>
          <div className="w-40">
            <Select
              options={[
                { value: '', label: 'All Stars' },
                { value: '5', label: '5 Stars' },
                { value: '4', label: '4 Stars' },
                { value: '3', label: '3 Stars' },
              ]}
              value={starFilter}
              onChange={(e) => setStarFilter(e.target.value)}
            />
          </div>
        </div>
        <Table
          columns={columns}
          data={hotels}
          keyExtractor={(h) => h.id}
          isLoading={isLoading}
          total={meta.total}
          page={meta.page}
          limit={meta.limit}
          totalPages={meta.totalPages}
          onPageChange={setPage}
          onRowClick={(h) => navigate(`/hotels/${h.id}`)}
        />
      </Card>
    </div>
  );
};

export default HotelsList;