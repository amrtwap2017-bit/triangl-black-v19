import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Eye, SearchBar as SearchIcon } from 'lucide-react';
import { PageHeader, SearchBar, Card, Select, Table, Badge, StatusBadge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import type { Column } from '@/shared/types';

interface Inspection {
  id: string;
  inspectionNumber: string;
  project: string;
  hotel: { name: string };
  type: string;
  status: string;
  inspector: string;
  date: string;
  passedCount: number;
  failedCount: number;
  totalItems: number;
}

const statusVariant: Record<string, 'success' | 'warning' | 'danger'> = {
  PASSED: 'success',
  PARTIAL: 'warning',
  FAILED: 'danger',
  SCHEDULED: 'default',
};

const InspectionsList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: inspections, isLoading, meta } = useApi<Inspection>(
    ['inspections'], '/inspections',
    { ...paginationParams(), search, status: statusFilter }
  );

  const columns: Column<Inspection>[] = useMemo(() => [
    { key: 'inspectionNumber', header: 'Inspection #', width: 'w-36', sortable: true },
    { key: 'project', header: 'Project', render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.project}</p>
        <p className="text-xs text-slate-500">{row.hotel?.name}</p>
      </div>
    )},
    { key: 'type', header: t('common.type'), width: 'w-32', render: (v) => <Badge>{String(v)}</Badge> },
    { key: 'status', header: t('common.status'), width: 'w-28', render: (v) => {
      const s = String(v);
      return <Badge variant={statusVariant[s] || 'default'}>{s}</Badge>;
    }},
    { key: 'inspector', header: 'Inspector', width: 'w-36' },
    { key: 'results', header: t('inspections.checklist'), width: 'w-32', render: (_, row) => (
      <div className="flex gap-2 text-xs">
        <span className="text-green-400">{row.passedCount} {t('inspections.passed')}</span>
        <span className="text-red-400">{row.failedCount} {t('inspections.failed')}</span>
      </div>
    )},
    { key: 'date', header: t('common.date'), width: 'w-28', render: (v) => v ? new Date(v as string).toLocaleDateString() : '—' },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('inspections.title')} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[
            {value:'',label:t('common.all')},
            {value:'SCHEDULED',label:'Scheduled'},
            {value:'PASSED',label:t('inspections.passed')},
            {value:'PARTIAL',label:t('inspections.conditional')},
            {value:'FAILED',label:t('inspections.failed')},
          ]} value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={inspections} keyExtractor={(ins)=>ins.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} onRowClick={(ins)=>navigate(`/inspections/${ins.id}`)} />
      </Card>
    </div>
  );
};

export default InspectionsList;