import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import { Save, Brain, Search } from 'lucide-react';
import { Button, Input, Select, Textarea, Card, PageHeader, Badge } from '@/shared/components/ui';
import { apiPost, apiPut } from '@/api/client';

const categoryOptions = [
  { value: 'HOTEL_STANDARDS', label: 'Hotel Standards' },
  { value: 'ENGINEERING_MANUAL', label: 'Engineering Manual' },
  { value: 'SUPPLIER_CATALOG', label: 'Supplier Catalog' },
  { value: 'TECHNICAL_DATA', label: 'Technical Data' },
  { value: 'PROJECT_ARCHIVE', label: 'Project Archive' },
  { value: 'BOQ_TEMPLATE', label: 'BOQ Template' },
  { value: 'EQUIPMENT_MANUAL', label: 'Equipment Manual' },
  { value: 'BEST_PRACTICE', label: 'Best Practice' },
];

const KnowledgeArticleForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [tags, setTags] = useState('');
  const [content, setContent] = useState('');
  const [summary, setSummary] = useState('');
  const [aiSearchQuery, setAiSearchQuery] = useState('');
  const [aiResults, setAiResults] = useState<string[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        title,
        category,
        tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
        content,
        summary,
      };
      if (isEdit) {
        await apiPut(`/knowledge-hub/articles/${id}`, payload);
      } else {
        await apiPost('/knowledge-hub/articles', payload);
      }
      navigate('/knowledge-hub');
    } catch {
      // handle error
    } finally {
      setLoading(false);
    }
  };

  const handleAiSearch = async () => {
    if (!aiSearchQuery.trim()) return;
    try {
      const result = await apiPost<{ suggestions: string[] }>('/knowledge-hub/ai-search', { query: aiSearchQuery });
      setAiResults(result.suggestions);
    } catch {
      setAiResults(['No results found. Try a different query.']);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEdit ? t('common.edit') : t('knowledgeHub.createArticle')}
        showBack
        backTo="/knowledge-hub"
        actions={
          <Button type="submit" form="article-form" loading={loading} icon={<Save className="w-4 h-4" />}>
            {t('common.save')}
          </Button>
        }
      />

      <form id="article-form" onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <div className="space-y-4">
            <Input
              label={t('common.name')}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Article title"
              required
            />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Select
                label={t('knowledgeHub.categories')}
                options={categoryOptions}
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="Select category"
                required
              />
              <Input
                label="Tags"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="Comma-separated tags"
              />
            </div>
            <Textarea
              label={t('common.description')}
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="Brief summary of the article"
              className="min-h-[80px]"
            />
            <Textarea
              label="Content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Full article content (supports markdown)"
              className="min-h-[300px]"
            />
          </div>
        </Card>
      </form>

      {/* AI Knowledge Search */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100 flex items-center gap-2"><Brain className="w-5 h-5 text-[#c9a962]" /> AI Knowledge Search</h3>}>
        <div className="flex gap-2 mb-4">
          <div className="flex-1">
            <Input
              value={aiSearchQuery}
              onChange={(e) => setAiSearchQuery(e.target.value)}
              placeholder="Search knowledge base with AI..."
              onKeyDown={(e) => e.key === 'Enter' && handleAiSearch()}
            />
          </div>
          <Button variant="secondary" icon={<Search className="w-4 h-4" />} onClick={handleAiSearch}>
            Search
          </Button>
        </div>
        {aiResults.length > 0 && (
          <div className="space-y-2">
            {aiResults.map((r, i) => (
              <div key={i} className="p-3 bg-[#0f0f1a] rounded-lg text-sm text-slate-300 border border-[#2d2d4a]">
                {r}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
};

export default KnowledgeArticleForm;