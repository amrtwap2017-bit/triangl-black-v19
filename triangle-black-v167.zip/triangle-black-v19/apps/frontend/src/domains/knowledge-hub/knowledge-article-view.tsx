import { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useNavigate } from 'react-router-dom';
import { Edit, Brain, ArrowLeft, Clock, User, Tag, BookOpen, Search } from 'lucide-react';
import { Card, PageHeader, Badge, Button, Input } from '@/shared/components/ui';
import { apiPost } from '@/api/client';

interface RelatedArticle {
  id: string;
  title: string;
  category: string;
}

const KnowledgeArticleView: React.FC = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const [aiQuery, setAiQuery] = useState('');
  const [aiResults, setAiResults] = useState<string[]>([]);

  // Mock data - in production, fetch from API
  const article = {
    id: id || '1',
    title: 'HVAC Design Standards for 5-Star Hotels',
    category: 'HOTEL_STANDARDS',
    tags: ['hvac', 'design', 'standards', 'luxury'],
    author: { name: 'Ahmed Al-Rashid' },
    createdAt: '2025-01-15',
    updatedAt: '2025-01-18',
    summary: 'Comprehensive HVAC design guidelines for luxury hotel properties including air changes, noise criteria, and temperature tolerances.',
    content: `## Overview\n\nThis document establishes the HVAC design standards for all 5-star hotel projects undertaken by Triangle Black.\n\n## Air Change Requirements\n\n- Guest Rooms: 6-8 ACH\n- Lobbies: 8-12 ACH\n- Restaurants: 10-15 ACH\n- Kitchens: 20-30 ACH\n- Swimming Pool Areas: 4-6 ACH\n- Gym/Spa: 8-10 ACH\n\n## Noise Criteria\n\n- Guest Rooms: NC-25 maximum\n- Corridors: NC-35 maximum\n- Public Areas: NC-35 maximum\n- Mechanical Rooms: NC-50 maximum\n\n## Temperature Tolerances\n\n- Guest Rooms: 22±1°C\n- Lobby: 23±1°C\n- Restaurant: 22±2°C\n- Kitchen: 18±2°C (cooling)`,
    related: [
      { id: '2', title: 'Chiller Maintenance Best Practices', category: 'BEST_PRACTICE' },
      { id: '3', title: 'Fire Alarm System Installation Guide', category: 'ENGINEERING_MANUAL' },
      { id: '5', title: 'BOQ Template — Complete HVAC System', category: 'BOQ_TEMPLATE' },
    ] as RelatedArticle[],
  };

  const handleAiSearch = async () => {
    if (!aiQuery.trim()) return;
    try {
      const result = await apiPost<{ answers: string[] }>('/knowledge-hub/ai-search', { query: aiQuery, articleId: id });
      setAiResults(result.answers);
    } catch {
      setAiResults(['Unable to process query. Please try again.']);
    }
  };

  const categoryLabel: Record<string, string> = {
    HOTEL_STANDARDS: t('knowledgeHub.hotelStandards'),
    ENGINEERING_MANUAL: t('knowledgeHub.engineeringManual'),
    SUPPLIER_CATALOG: t('knowledgeHub.supplierCatalog'),
    TECHNICAL_DATA: t('knowledgeHub.technicalData'),
    PROJECT_ARCHIVE: t('knowledgeHub.projectArchive'),
    BOQ_TEMPLATE: t('knowledgeHub.boqTemplate'),
    EQUIPMENT_MANUAL: t('knowledgeHub.equipmentManual'),
    BEST_PRACTICE: t('knowledgeHub.bestPractice'),
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={article.title}
        showBack
        backTo="/knowledge-hub"
        actions={
          <Button icon={<Edit className="w-4 h-4" />} onClick={() => navigate(`/knowledge-hub/${id}/edit`)}>
            {t('common.edit')}
          </Button>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <div className="flex items-center gap-3 mb-4 flex-wrap">
              <Badge variant="info">{categoryLabel[article.category] || article.category}</Badge>
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <User className="w-3.5 h-3.5" />
                {article.author.name}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Clock className="w-3.5 h-3.5" />
                {new Date(article.createdAt).toLocaleDateString()}
              </div>
            </div>
            <div className="prose prose-invert max-w-none text-sm text-slate-300 leading-relaxed">
              {article.content.split('\n').map((line, i) => {
                if (line.startsWith('## ')) return <h2 key={i} className="text-lg font-bold text-slate-100 mt-6 mb-3">{line.slice(3)}</h2>;
                if (line.startsWith('- ')) return <li key={i} className="ml-4 text-slate-300">{line.slice(2)}</li>;
                if (line.trim() === '') return <br key={i} />;
                return <p key={i} className="mb-2">{line}</p>;
              })}
            </div>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Tags */}
          <Card header={<h3 className="text-base font-semibold text-slate-100 flex items-center gap-2"><Tag className="w-4 h-4" /> Tags</h3>}>
            <div className="flex flex-wrap gap-2">
              {article.tags.map((tag) => (
                <span key={tag} className="px-2 py-1 text-xs rounded-md bg-[#252540] text-slate-300">
                  {tag}
                </span>
              ))}
            </div>
          </Card>

          {/* Related Articles */}
          <Card header={<h3 className="text-base font-semibold text-slate-100 flex items-center gap-2"><BookOpen className="w-4 h-4" /> Related Articles</h3>}>
            <div className="space-y-2">
              {article.related.map((r) => (
                <button
                  key={r.id}
                  onClick={() => navigate(`/knowledge-hub/${r.id}`)}
                  className="w-full text-start p-2 rounded-lg hover:bg-[#252540] transition-colors"
                >
                  <p className="text-sm text-slate-200 line-clamp-2">{r.title}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{categoryLabel[r.category] || r.category}</p>
                </button>
              ))}
            </div>
          </Card>

          {/* AI Search */}
          <Card header={<h3 className="text-base font-semibold text-slate-100 flex items-center gap-2"><Brain className="w-4 h-4 text-[#c9a962]" /> AI Search</h3>}>
            <div className="flex gap-2 mb-3">
              <Input
                value={aiQuery}
                onChange={(e) => setAiQuery(e.target.value)}
                placeholder="Ask about this article..."
                onKeyDown={(e) => e.key === 'Enter' && handleAiSearch()}
              />
              <Button variant="secondary" size="sm" icon={<Search className="w-3.5 h-3.5" />} onClick={handleAiSearch} />
            </div>
            {aiResults.length > 0 && (
              <div className="space-y-2">
                {aiResults.map((r, i) => (
                  <div key={i} className="p-2 bg-[#0f0f1a] rounded text-xs text-slate-300 border border-[#2d2d4a]">
                    {r}
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

export default KnowledgeArticleView;