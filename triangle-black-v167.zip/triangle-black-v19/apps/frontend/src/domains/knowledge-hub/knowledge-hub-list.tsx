import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Search } from 'lucide-react';
import { PageHeader, SearchBar, Button, Card, Badge, Tabs } from '@/shared/components/ui';

interface KnowledgeArticle {
  id: string;
  title: string;
  category: string;
  tags: string[];
  author: { name: string };
  createdAt: string;
  summary: string;
}

const categoryOptions = [
  { key: 'ALL', label: 'All' },
  { key: 'HOTEL_STANDARDS', label: 'Hotel Standards' },
  { key: 'ENGINEERING_MANUAL', label: 'Engineering Manual' },
  { key: 'SUPPLIER_CATALOG', label: 'Supplier Catalog' },
  { key: 'TECHNICAL_DATA', label: 'Technical Data' },
  { key: 'PROJECT_ARCHIVE', label: 'Project Archive' },
  { key: 'BOQ_TEMPLATE', label: 'BOQ Template' },
  { key: 'EQUIPMENT_MANUAL', label: 'Equipment Manual' },
  { key: 'BEST_PRACTICE', label: 'Best Practice' },
];

const categoryBadgeVariant: Record<string, 'default' | 'info' | 'success' | 'warning'> = {
  HOTEL_STANDARDS: 'info',
  ENGINEERING_MANUAL: 'default',
  SUPPLIER_CATALOG: 'warning',
  TECHNICAL_DATA: 'info',
  PROJECT_ARCHIVE: 'default',
  BOQ_TEMPLATE: 'success',
  EQUIPMENT_MANUAL: 'default',
  BEST_PRACTICE: 'success',
};

const mockArticles: KnowledgeArticle[] = [
  { id: '1', title: 'HVAC Design Standards for 5-Star Hotels', category: 'HOTEL_STANDARDS', tags: ['hvac', 'design', 'standards'], author: { name: 'Ahmed Al-Rashid' }, createdAt: '2025-01-15', summary: 'Comprehensive HVAC design guidelines for luxury hotel properties including air changes, noise criteria, and temperature tolerances.' },
  { id: '2', title: 'Chiller Maintenance Best Practices', category: 'BEST_PRACTICE', tags: ['chiller', 'maintenance'], author: { name: 'Sara Khan' }, createdAt: '2025-01-10', summary: 'Monthly, quarterly, and annual maintenance procedures for centrifugal and screw chillers in hotel applications.' },
  { id: '3', title: 'Fire Alarm System Installation Guide', category: 'ENGINEERING_MANUAL', tags: ['fire', 'alarm', 'installation'], author: { name: 'Omar Hassan' }, createdAt: '2025-01-08', summary: 'Step-by-step installation guide for addressable fire alarm systems compliant with NFPA and local civil defense codes.' },
  { id: '4', title: 'Carrier 30XA Chiller Technical Datasheet', category: 'TECHNICAL_DATA', tags: ['carrier', 'chiller', 'datasheet'], author: { name: 'System Import' }, createdAt: '2025-01-05', summary: 'Technical specifications, performance curves, and wiring diagrams for Carrier 30XA series water-cooled chillers.' },
  { id: '5', title: 'BOQ Template — Complete HVAC System', category: 'BOQ_TEMPLATE', tags: ['boq', 'hvac', 'template'], author: { name: 'Lina Mahmoud' }, createdAt: '2024-12-28', summary: 'Pre-built bill of quantities template covering all HVAC components for a typical 200-room hotel project.' },
  { id: '6', title: 'Approved Vendor Catalog 2025', category: 'SUPPLIER_CATALOG', tags: ['vendor', 'catalog'], author: { name: 'Procurement Team' }, createdAt: '2024-12-20', summary: 'Updated catalog of approved vendors and suppliers with contact details, product categories, and performance ratings.' },
];

const KnowledgeHubList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('ALL');

  const filtered = useMemo(() => {
    return mockArticles.filter((a) => {
      const matchSearch = !search || a.title.toLowerCase().includes(search.toLowerCase()) || a.tags.some((tag) => tag.toLowerCase().includes(search.toLowerCase()));
      const matchCategory = activeCategory === 'ALL' || a.category === activeCategory;
      return matchSearch && matchCategory;
    });
  }, [search, activeCategory]);

  const tabs = categoryOptions.map((c) => ({ key: c.key, label: c.label }));

  const getCategoryLabel = (key: string) => {
    const found = categoryOptions.find((c) => c.key === key);
    return found ? found.label : key;
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('knowledgeHub.title')}
        actions={
          <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/knowledge-hub/new')}>
            {t('knowledgeHub.createArticle')}
          </Button>
        }
      />

      <Card noPadding>
        <div className="p-4 border-b border-[#2d2d4a]">
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="flex-1">
              <SearchBar onSearch={setSearch} placeholder={t('knowledgeHub.searchKnowledge')} />
            </div>
          </div>
          <Tabs tabs={tabs} activeTab={activeCategory} onChange={setActiveCategory} />
        </div>

        <div className="p-4">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <Search className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p>{t('common.noData')}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map((article) => (
                <div
                  key={article.id}
                  onClick={() => navigate(`/knowledge-hub/${article.id}`)}
                  className="bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg p-4 hover:border-[#c9a962]/40 transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-2">
                    <Badge variant={categoryBadgeVariant[article.category] || 'default'}>
                      {getCategoryLabel(article.category)}
                    </Badge>
                    <span className="text-xs text-slate-500">{new Date(article.createdAt).toLocaleDateString()}</span>
                  </div>
                  <h3 className="text-sm font-semibold text-slate-100 mb-2 line-clamp-2">{article.title}</h3>
                  <p className="text-xs text-slate-400 mb-3 line-clamp-2">{article.summary}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">{article.author.name}</span>
                    <div className="flex gap-1 flex-wrap justify-end">
                      {article.tags.slice(0, 2).map((tag) => (
                        <span key={tag} className="text-[10px] px-1.5 py-0.5 rounded bg-[#252540] text-slate-400">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default KnowledgeHubList;