import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { DollarSign, TrendingUp, TrendingDown, BarChart3, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Card, PageHeader, StatCard, Table, Badge } from '@/shared/components/ui';
import { useApi } from '@/shared/hooks';
import type { Column } from '@/shared/types';

interface MarginByType {
  type: string;
  revenue: number;
  cost: number;
  margin: number;
  marginPercent: number;
}

interface MarginByHotel {
  hotel: string;
  revenue: number;
  cost: number;
  margin: number;
  marginPercent: number;
  projects: number;
}

interface MonthlyTrend {
  month: string;
  revenue: number;
  cost: number;
  margin: number;
  marginPercent: number;
}

const MarginDashboard: React.FC = () => {
  const { t } = useTranslation();

  const summaryStats = {
    avgMargin: 28.5,
    totalRevenue: 45200000,
    totalCost: 32300000,
    totalProfit: 12900000,
  };

  const marginByType: MarginByType[] = [
    { type: 'HVAC', revenue: 18500000, cost: 12800000, margin: 5700000, marginPercent: 30.8 },
    { type: 'Electrical', revenue: 12200000, cost: 9100000, margin: 3100000, marginPercent: 25.4 },
    { type: 'Plumbing', revenue: 8400000, cost: 6200000, margin: 2200000, marginPercent: 26.2 },
    { type: 'Fire Protection', revenue: 3900000, cost: 2700000, margin: 1200000, marginPercent: 30.8 },
    { type: 'BMS', revenue: 2200000, cost: 1500000, margin: 700000, marginPercent: 31.8 },
  ];

  const marginByHotel: MarginByHotel[] = [
    { hotel: 'Burj Al Arab', revenue: 12500000, cost: 8800000, margin: 3700000, marginPercent: 29.6, projects: 8 },
    { hotel: 'Atlantis The Royal', revenue: 10200000, cost: 7200000, margin: 3000000, marginPercent: 29.4, projects: 5 },
    { hotel: 'Mandarin Oriental', revenue: 8100000, cost: 6000000, margin: 2100000, marginPercent: 25.9, projects: 4 },
    { hotel: 'Four Seasons DIFC', revenue: 6200000, cost: 4500000, margin: 1700000, marginPercent: 27.4, projects: 3 },
    { hotel: 'Ritz Carlton', revenue: 5200000, cost: 3900000, margin: 1300000, marginPercent: 25.0, projects: 6 },
    { hotel: 'Others', revenue: 3000000, cost: 1900000, margin: 1100000, marginPercent: 36.7, projects: 12 },
  ];

  const monthlyTrend: MonthlyTrend[] = [
    { month: 'Jan', revenue: 3800000, cost: 2700000, margin: 1100000, marginPercent: 28.9 },
    { month: 'Feb', revenue: 4200000, cost: 3000000, margin: 1200000, marginPercent: 28.6 },
    { month: 'Mar', revenue: 5100000, cost: 3600000, margin: 1500000, marginPercent: 29.4 },
    { month: 'Apr', revenue: 3900000, cost: 2900000, margin: 1000000, marginPercent: 25.6 },
    { month: 'May', revenue: 4600000, cost: 3200000, margin: 1400000, marginPercent: 30.4 },
    { month: 'Jun', revenue: 4800000, cost: 3400000, margin: 1400000, marginPercent: 29.2 },
  ];

  const maxRevenue = Math.max(...marginByType.map((m) => m.revenue));

  const trendColumns: Column<MonthlyTrend>[] = [
    { key: 'month', header: 'Month', width: 'w-24' },
    { key: 'revenue', header: t('common.revenue'), render: (v) => `AED ${(v as number).toLocaleString()}` },
    { key: 'cost', header: t('common.cost'), render: (v) => `AED ${(v as number).toLocaleString()}` },
    { key: 'margin', header: t('common.profit'), render: (v) => `AED ${(v as number).toLocaleString()}` },
    { key: 'marginPercent', header: t('common.margin'), width: 'w-24', render: (v) => {
      const val = v as number;
      return <span className={val >= 28 ? 'text-green-400' : val >= 25 ? 'text-yellow-400' : 'text-red-400'}>{val}%</span>;
    }},
  ];

  const hotelColumns: Column<MarginByHotel>[] = [
    { key: 'hotel', header: 'Hotel', sortable: true },
    { key: 'revenue', header: t('common.revenue'), render: (v) => `AED ${(v as number).toLocaleString()}` },
    { key: 'cost', header: t('common.cost'), render: (v) => `AED ${(v as number).toLocaleString()}` },
    { key: 'margin', header: t('common.profit'), render: (v) => `AED ${(v as number).toLocaleString()}` },
    { key: 'marginPercent', header: t('common.margin'), width: 'w-28', render: (v) => {
      const val = v as number;
      return <span className={val >= 28 ? 'text-green-400' : val >= 25 ? 'text-yellow-400' : 'text-red-400'}>{val}%</span>;
    }},
    { key: 'projects', header: 'Projects', width: 'w-20', align: 'center' },
  ];

  const formatCurrency = (val: number) => {
    if (val >= 1000000) return `AED ${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `AED ${(val / 1000).toFixed(0)}K`;
    return `AED ${val}`;
  };

  return (
    <div className="space-y-6">
      <PageHeader title={t('margin.title')} />

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={<TrendingUp className="w-5 h-5" />} label={t('common.margin') + ' (%)'} value={summaryStats.avgMargin} suffix="%" change={2.3} />
        <StatCard icon={<DollarSign className="w-5 h-5" />} label={t('margin.revenue')} value={formatCurrency(summaryStats.totalRevenue)} change={8.5} />
        <StatCard icon={<BarChart3 className="w-5 h-5" />} label={t('margin.cost')} value={formatCurrency(summaryStats.totalCost)} change={5.1} />
        <StatCard icon={<TrendingUp className="w-5 h-5" />} label={t('margin.profit')} value={formatCurrency(summaryStats.totalProfit)} change={12.4} />
      </div>

      {/* Margin by Project Type — Bar Chart */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('margin.byType')}</h3>}>
        <div className="space-y-4">
          {marginByType.map((item) => (
            <div key={item.type} className="space-y-1.5">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-200 font-medium w-32">{item.type}</span>
                <span className="text-slate-400">{formatCurrency(item.revenue)}</span>
              </div>
              <div className="flex gap-1 h-7">
                <div
                  className="bg-[#c9a962] rounded-sm flex items-center justify-end pe-2 transition-all"
                  style={{ width: `${(item.revenue / maxRevenue) * 100}%` }}
                >
                  <span className="text-[10px] font-medium text-[#0f0f1a]">{item.marginPercent}%</span>
                </div>
                <div
                  className="bg-slate-600 rounded-sm"
                  style={{ width: `${(item.cost / maxRevenue) * 100}%` }}
                />
              </div>
              <div className="flex justify-end text-xs text-slate-500">
                <span>Cost: {formatCurrency(item.cost)} | Margin: {formatCurrency(item.margin)}</span>
              </div>
            </div>
          ))}
          <div className="flex items-center gap-4 pt-2 text-xs text-slate-500">
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-[#c9a962] rounded-sm" /> Revenue</div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-slate-600 rounded-sm" /> Cost</div>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Margin by Hotel */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('margin.byHotel')}</h3>}>
          <Table columns={hotelColumns} data={marginByHotel} keyExtractor={(r) => r.hotel} />
        </Card>

        {/* Monthly Trend */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('margin.trends')}</h3>}>
          <Table columns={trendColumns} data={monthlyTrend} keyExtractor={(r) => r.month} />
        </Card>
      </div>
    </div>
  );
};

export default MarginDashboard;