import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Target } from 'lucide-react';
import { PageHeader, SearchBar, Button, Select, Card, Table, StatusBadge, Badge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { Opportunity, Column } from '@/shared/types';

const OpportunitiesList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [stageFilter, setStageFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: opportunities, isLoading, meta } = useApi<Opportunity>(
    ['opportunities'], endpoints.opportunities.list,
    { ...paginationParams(), search, stage: stageFilter }
  );

  const columns: Column<Opportunity>[] = useMemo(() => [
    { key: 'opportunityNumber', header: '#', width: 'w-36', sortable: true },
    { key: 'title', header: t('common.name'), sortable: true, render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.title}</p>
        <p className="text-xs text-slate-500">{row.hotel?.name}</p>
      </div>
    )},
    { key: 'stage', header: t('opportunities.stage'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'value', header: t('opportunities.value'), align: 'end', sortable: true, render: (v) => (
      <span className="text-[#c9a962] font-semibold">${(v as number).toLocaleString()}</span>
    )},
    { key: 'probability', header: t('opportunities.probability'), align: 'center', render: (v) => (
      <div className="flex items-center gap-2">
        <div className="w-16 h-2 bg-[#252540] rounded-full overflow-hidden">
          <div className="h-full bg-[#c9a962] rounded-full" style={{ width: `${v as number}%` }} />
        </div>
        <span className="text-sm text-slate-300">{v}%</span>
      </div>
    )},
    { key: 'assignedTo', header: t('requests.assign'), render: (_, row) => row.assignedTo?.name || '—' },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('opportunities.title')} actions={
        <div className="flex gap-2">
          <Button variant="secondary" icon={<Target className="w-4 h-4" />} onClick={() => navigate('/opportunities/pipeline')}>{t('opportunities.pipeline')}</Button>
          <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/opportunities/new')}>{t('common.add')}</Button>
        </div>
      )} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[{value:'',label:t('common.all')},{value:'LEAD',label:'Lead'},{value:'QUALIFIED',label:'Qualified'},{value:'PROPOSAL_SENT',label:'Proposal Sent'},{value:'NEGOTIATION',label:'Negotiation'},{value:'CONTRACT_SIGNED',label:'Contract Signed'}]} value={stageFilter} onChange={(e)=>setStageFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={opportunities} keyExtractor={(o)=>o.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} onRowClick={(o)=>navigate(`/opportunities/${o.id}`)} />
      </Card>
    </div>
  );
};

export default OpportunitiesList;