import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { DollarSign, Calendar, User, Target, Building2, Edit, TrendingUp, TrendingDown, FileText } from 'lucide-react';
import { PageHeader, Card, Button, Badge, LoadingSpinner, EmptyState, StatusBadge, Tabs, Modal, Textarea } from '@/shared/components/ui';
import { useApiSingle } from '@/shared/hooks';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';
import toast from 'react-hot-toast';
import type { Opportunity } from '@/shared/types';

const OpportunityDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [closeType, setCloseType] = useState<'won' | 'lost'>('won');
  const [reason, setReason] = useState('');

  const { data: opportunity, isLoading } = useApiSingle<Opportunity>(
    ['opportunity', id!], `/opportunities/${id}`
  );

  if (isLoading) return <LoadingSpinner />;
  if (!opportunity) return <EmptyState message="Opportunity not found" />;

  const handleClose = async () => {
    try {
      const endpoint = closeType === 'won' ? endpoints.opportunities.closeWon(id!) : endpoints.opportunities.closeLost(id!);
      await apiPost(endpoint, { reason });
      toast.success(t('common.success'));
      setShowCloseModal(false);
    } catch { toast.error(t('common.error')); }
  };

  const handleAdvanceStage = async () => {
    try {
      await apiPost(endpoints.opportunities.advanceStage(id!));
      toast.success('Stage advanced');
    } catch { toast.error(t('common.error')); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title={`Opp ${opportunity.opportunityNumber}`} subtitle={opportunity.title} breadcrumbs={[{label:t('opportunities.title'),href:'/opportunities'},{label:opportunity.opportunityNumber}]} showBack actions={
        <div className="flex gap-2">
          {!['CLOSED_WON','CLOSED_LOST'].includes(opportunity.stage) && (
            <>
              <Button variant="secondary" onClick={handleAdvanceStage}>Advance Stage</Button>
              <Button variant="secondary" icon={<TrendingUp className="w-4 h-4" />} onClick={() => { setCloseType('won'); setShowCloseModal(true); }}>{t('opportunities.closeWon')}</Button>
              <Button variant="danger" icon={<TrendingDown className="w-4 h-4" />} onClick={() => { setCloseType('lost'); setShowCloseModal(true); }}>{t('opportunities.closeLost')}</Button>
            </>
          )}
          <Button variant="secondary" icon={<FileText className="w-4 h-4" />} onClick={() => navigate(`/proposals/new?opportunityId=${id}`)}>Create Proposal</Button>
        </div>
      }}/>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card header={<h4 className="font-semibold text-slate-200">Description</h4>}>
            <p className="text-sm text-slate-300 whitespace-pre-wrap">{opportunity.description}</p>
          </Card>
          {opportunity.internalNotes && (
            <Card header={<h4 className="font-semibold text-slate-200">Internal Notes</h4>} className="mt-6">
              <p className="text-sm text-slate-300">{opportunity.internalNotes}</p>
            </Card>
          )}
        </div>
        <div className="space-y-6">
          <Card>
            <div className="space-y-4">
              <div><p className="text-xs text-slate-400">{t('common.status')}</p><StatusBadge status={opportunity.stage} className="mt-1" /></div>
              <div><p className="text-xs text-slate-400">{t('opportunities.value')}</p><p className="text-lg font-bold text-[#c9a962] mt-1">${opportunity.value.toLocaleString()} {opportunity.currency}</p></div>
              <div><p className="text-xs text-slate-400">{t('opportunities.probability')}</p><div className="flex items-center gap-2 mt-1"><div className="flex-1 h-2 bg-[#252540] rounded-full overflow-hidden"><div className="h-full bg-[#c9a962] rounded-full" style={{width:`${opportunity.probability}%`}} /></div><span className="text-sm text-slate-300">{opportunity.probability}%</span></div></div>
              {opportunity.hotel && <div><p className="text-xs text-slate-400">{t('hotels.title')}</p><p className="text-sm text-slate-200 mt-1">{opportunity.hotel.name}</p></div>}
              {opportunity.assignedTo && <div><p className="text-xs text-slate-400">{t('requests.assign')}</p><p className="text-sm text-slate-200 mt-1">{opportunity.assignedTo.name}</p></div>}
              {opportunity.estimatedStartDate && <div><p className="text-xs text-slate-400">{t('opportunities.estimatedStartDate')}</p><p className="text-sm text-slate-200 mt-1">{new Date(opportunity.estimatedStartDate).toLocaleDateString()}</p></div>}
              {opportunity.estimatedDuration && <div><p className="text-xs text-slate-400">{t('opportunities.estimatedDuration')}</p><p className="text-sm text-slate-200 mt-1">{opportunity.estimatedDuration} days</p></div>}
              {opportunity.competition && <div><p className="text-xs text-slate-400">{t('opportunities.competition')}</p><p className="text-sm text-slate-200 mt-1">{opportunity.competition}</p></div>}
            </div>
          </Card>
        </div>
      </div>

      <Modal isOpen={showCloseModal} onClose={()=>setShowCloseModal(false)} title={closeType === 'won' ? t('opportunities.closeWon') : t('opportunities.closeLost')} footer={
        <><Button variant="ghost" onClick={()=>setShowCloseModal(false)}>{t('common.cancel')}</Button><Button onClick={handleClose}>{t('common.save')}</Button></>
      }>
        <Textarea label="Reason" value={reason} onChange={(e)=>setReason(e.target.value)} />
      </Modal>
    </div>
  );
};

export default OpportunityDetail;