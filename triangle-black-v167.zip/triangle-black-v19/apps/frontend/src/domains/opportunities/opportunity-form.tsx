import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const schema = z.object({
  hotelId: z.string().min(1, 'Hotel required'),
  title: z.string().min(2, 'Title required'),
  description: z.string().min(5, 'Description required'),
  value: z.coerce.number().min(0),
  currency: z.string().min(1),
  probability: z.coerce.number().min(0).max(100),
  estimatedStartDate: z.string().optional(),
  estimatedDuration: z.coerce.number().optional(),
  competition: z.string().optional(),
  internalNotes: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const OpportunityForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { currency: 'USD', probability: 30 },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await apiPost(endpoints.opportunities.create, { ...data, opportunityId: searchParams.get('opportunityId') });
      toast.success(t('common.success'));
      navigate('/opportunities');
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Create Opportunity" showBack backTo="/opportunities" breadcrumbs={[{label:t('opportunities.title'),href:'/opportunities'},{label:t('common.create')}]}/>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Hotel ID" error={errors.hotelId?.message} {...register('hotelId')} />
            <Input label={t('common.name')} error={errors.title?.message} {...register('title')} className="md:col-span-2" />
            <Textarea label={t('common.description')} error={errors.description?.message} {...register('description')} className="md:col-span-2" />
            <Input label={t('opportunities.value')} type="number" error={errors.value?.message} {...register('value')} />
            <Select label={t('common.currency')} options={[{value:'USD',label:'USD'},{value:'AED',label:'AED'},{value:'SAR',label:'SAR'}]} {...register('currency')} />
            <Input label={t('opportunities.probability')} type="number" error={errors.probability?.message} {...register('probability')} />
            <Input label={t('opportunities.estimatedStartDate')} type="date" {...register('estimatedStartDate')} />
            <Input label={t('opportunities.estimatedDuration')} type="number" placeholder="Days" {...register('estimatedDuration')} />
            <Input label={t('opportunities.competition')} {...register('competition')} />
            <Textarea label="Internal Notes" {...register('internalNotes')} className="md:col-span-2" />
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" onClick={() => navigate('/opportunities')}>{t('common.cancel')}</Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default OpportunityForm;