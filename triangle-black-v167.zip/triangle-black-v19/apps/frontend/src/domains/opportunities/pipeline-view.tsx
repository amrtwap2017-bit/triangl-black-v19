import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { PageHeader, Card, Badge, EmptyState, LoadingSpinner, Button, SearchBar } from '@/shared/components/ui';
import { useApi } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { Opportunity, OpportunityStage } from '@/shared/types';
import { clsx } from 'clsx';

const stages: OpportunityStage[] = ['LEAD', 'QUALIFIED', 'PROPOSAL_SENT', 'NEGOTIATION', 'VERBAL_AGREEMENT', 'CONTRACT_SIGNED', 'CLOSED_WON', 'CLOSED_LOST'];
const stageColors: Record<string, string> = {
  LEAD: 'border-t-slate-400', QUALIFIED: 'border-t-blue-400', PROPOSAL_SENT: 'border-t-[#c9a962]',
  NEGOTIATION: 'border-t-amber-400', VERBAL_AGREEMENT: 'border-t-green-400', CONTRACT_SIGNED: 'border-t-emerald-400',
  CLOSED_WON: 'border-t-green-500', CLOSED_LOST: 'border-t-red-400',
};

const PipelineView: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');

  const { data: opportunities, isLoading } = useApi<Opportunity>(
    ['opportunities', 'pipeline'], endpoints.opportunities.list, { search, limit: 200 }
  );

  const grouped = useMemo(() => {
    const map: Record<string, Opportunity[]> = {};
    stages.forEach((s) => (map[s] = []));
    opportunities.forEach((o) => {
      if (map[o.stage]) map[o.stage].push(o);
    });
    return map;
  }, [opportunities]);

  if (isLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-6">
      <PageHeader title={t('opportunities.pipeline')} actions={
        <Button variant="secondary" onClick={() => navigate('/opportunities')}>List View</Button>
      } />
      <div className="mb-4"><SearchBar onSearch={setSearch} /></div>
      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin">
        {stages.map((stage) => (
          <div key={stage} className="min-w-[280px] w-[280px] shrink-0">
            <div className={clsx('bg-[#1a1a2e] border border-[#2d2d4a] rounded-t-xl border-t-4', stageColors[stage])}>
              <div className="px-4 py-3 flex items-center justify-between border-b border-[#2d2d4a]">
                <h3 className="text-sm font-semibold text-slate-200">{stage.replace(/_/g, ' ')}</h3>
                <Badge>{grouped[stage]?.length || 0}</Badge>
              </div>
              <div className="p-3 space-y-2 min-h-[200px] max-h-[60vh] overflow-y-auto">
                {grouped[stage]?.map((opp) => (
                  <div
                    key={opp.id}
                    onClick={() => navigate(`/opportunities/${opp.id}`)}
                    className="p-3 bg-[#252540] rounded-lg cursor-pointer hover:bg-[#2d2d4a] transition-colors"
                  >
                    <p className="text-sm font-medium text-slate-100 truncate">{opp.title}</p>
                    <p className="text-xs text-slate-500 mt-1">{opp.hotel?.name}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-sm font-semibold text-[#c9a962]">${opp.value.toLocaleString()}</span>
                      <span className="text-xs text-slate-400">{opp.probability}%</span>
                    </div>
                  </div>
                ))}
                {(!grouped[stage] || grouped[stage].length === 0) && (
                  <p className="text-xs text-slate-500 text-center py-8">No opportunities</p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PipelineView;