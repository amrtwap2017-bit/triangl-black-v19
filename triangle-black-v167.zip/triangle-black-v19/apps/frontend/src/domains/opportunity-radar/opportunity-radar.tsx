import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { Radar, RefreshCw, Plus, TrendingUp, AlertTriangle, Clock, Award, Zap } from 'lucide-react';
import { Card, PageHeader, Badge, Button } from '@/shared/components/ui';
import { apiPost, apiGet } from '@/api/client';

interface OpportunityRecommendation {
  id: string;
  hotel: string;
  type: string;
  description: string;
  confidence: number;
  estimatedValue: number;
  reason: string;
  icon: React.ReactNode;
}

const OpportunityRadar: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [recommendations, setRecommendations] = useState<OpportunityRecommendation[]>([
    {
      id: '1', hotel: 'Mandarin Oriental', type: 'EXPIRING_WARRANTY',
      description: 'Chiller warranty expires in 45 days. Recommend proactive maintenance contract proposal.',
      confidence: 92, estimatedValue: 850000, reason: t('opportunityRadar.expiringWarranties'),
      icon: <Clock className="w-5 h-5 text-red-400" />,
    },
    {
      id: '2', hotel: 'Ritz Carlton', type: 'REPEATED_EMERGENCY',
      description: '3 emergency calls for AHU failures in 60 days. Recommend replacement proposal.',
      confidence: 88, estimatedValue: 1200000, reason: t('opportunityRadar.repeatedEmergencies'),
      icon: <AlertTriangle className="w-5 h-5 text-orange-400" />,
    },
    {
      id: '3', hotel: 'JW Marriott Marquis', type: 'NO_RECENT_PROJECTS',
      description: 'No active projects in 6 months. Re-engagement opportunity for BMS upgrade.',
      confidence: 72, estimatedValue: 650000, reason: t('opportunityRadar.noRecentProjects'),
      icon: <TrendingUp className="w-5 h-5 text-yellow-400" />,
    },
    {
      id: '4', hotel: 'Four Seasons DIFC', type: 'SEASONAL',
      description: 'Annual chiller maintenance season approaching. Pre-book service contracts.',
      confidence: 85, estimatedValue: 320000, reason: 'Seasonal Opportunity',
      icon: <Zap className="w-5 h-5 text-blue-400" />,
    },
    {
      id: '5', hotel: 'Atlantis The Royal', type: 'UPSELL',
      description: 'Active HVAC project nearing completion. Cross-sell BMS integration.',
      confidence: 78, estimatedValue: 980000, reason: 'Cross-sell Opportunity',
      icon: <Award className="w-5 h-5 text-green-400" />,
    },
  ]);

  const handleRefresh = async () => {
    setLoading(true);
    try {
      const result = await apiGet<OpportunityRecommendation[]>('/opportunity-radar/recommendations');
      setRecommendations(result);
    } catch {
      // keep existing data
    } finally {
      setLoading(false);
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 85) return 'text-green-400 border-green-500/30';
    if (confidence >= 70) return 'text-yellow-400 border-yellow-500/30';
    return 'text-orange-400 border-orange-500/30';
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('opportunityRadar.title')}
        subtitle={t('opportunityRadar.recommendations')}
        actions={
          <Button variant="secondary" icon={<RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />} onClick={handleRefresh} loading={loading}>
            Refresh
          </Button>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {recommendations.map((rec) => (
          <Card key={rec.id} className="hover:border-[#c9a962]/30 transition-colors">
            <div className="flex items-start gap-3 mb-3">
              <div className="p-2 rounded-lg bg-[#252540] shrink-0">
                {rec.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-semibold text-slate-100">{rec.hotel}</h3>
                <Badge variant="info">{rec.type.replace(/_/g, ' ')}</Badge>
              </div>
            </div>

            <p className="text-sm text-slate-300 mb-3 line-clamp-3">{rec.description}</p>

            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-xs text-slate-500">{t('opportunityRadar.confidence')}</p>
                <p className={`text-lg font-bold ${getConfidenceColor(rec.confidence).split(' ')[0]}`}>{rec.confidence}%</p>
              </div>
              <div className="text-end">
                <p className="text-xs text-slate-500">Est. Value</p>
                <p className="text-sm font-semibold text-[#c9a962]">
                  AED {(rec.estimatedValue / 1000).toFixed(0)}K
                </p>
              </div>
            </div>

            {/* Confidence bar */}
            <div className="w-full h-1.5 bg-[#2d2d4a] rounded-full mb-4 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${
                  rec.confidence >= 85 ? 'bg-green-500' : rec.confidence >= 70 ? 'bg-yellow-500' : 'bg-orange-500'
                }`}
                style={{ width: `${rec.confidence}%` }}
              />
            </div>

            <Button
              size="sm"
              className="w-full"
              icon={<Plus className="w-3.5 h-3.5" />}
              onClick={() => navigate('/opportunities/new')}
            >
              {t('opportunityRadar.createOpportunity')}
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default OpportunityRadar;