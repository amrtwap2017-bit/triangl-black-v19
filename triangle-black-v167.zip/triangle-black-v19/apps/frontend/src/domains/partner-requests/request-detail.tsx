import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { MapPin, Calendar, User, DollarSign, ArrowRightLeft, Send, Edit } from 'lucide-react';
import { PageHeader, Card, Button, Tabs, Badge, LoadingSpinner, EmptyState, StatusBadge, Modal, Textarea } from '@/shared/components/ui';
import { useApiSingle } from '@/shared/hooks';
import { apiPost, apiPatch } from '@/api/client';
import { endpoints } from '@/api/endpoints';
import toast from 'react-hot-toast';
import type { PartnerRequest } from '@/shared/types';

const RequestDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [assignUserId, setAssignUserId] = useState('');

  const { data: request, isLoading } = useApiSingle<PartnerRequest>(
    ['partnerRequest', id!],
    `/partner-requests/${id}`
  );

  if (isLoading) return <LoadingSpinner />;
  if (!request) return <EmptyState message="Request not found" />;

  const handleAssign = async () => {
    try {
      await apiPatch(endpoints.partnerRequests.assign(id!), { userId: assignUserId });
      toast.success(t('common.success'));
      setShowAssignModal(false);
    } catch { toast.error(t('common.error')); }
  };

  const handleScheduleVisit = async () => {
    try {
      await apiPost(endpoints.partnerRequests.scheduleVisit(id!));
      toast.success('Visit scheduled');
      navigate(`/site-visits/new?requestId=${id}`);
    } catch { toast.error(t('common.error')); }
  };

  const handleConvert = async () => {
    try {
      await apiPost(endpoints.partnerRequests.convertToOpportunity(id!));
      toast.success('Converted to opportunity');
    } catch { toast.error(t('common.error')); }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={`${t('requests.requestNumber')}${request.requestNumber}`}
        subtitle={request.title}
        breadcrumbs={[
          { label: t('requests.title'), href: '/requests' },
          { label: request.requestNumber },
        ]}
        showBack
        actions={
          <div className="flex gap-2">
            <Button variant="secondary" icon={<User className="w-4 h-4" />} onClick={() => setShowAssignModal(true)}>{t('requests.assign')}</Button>
            <Button variant="secondary" icon={<MapPin className="w-4 h-4" />} onClick={handleScheduleVisit}>{t('requests.scheduleVisit')}</Button>
            <Button icon={<ArrowRightLeft className="w-4 h-4" />} onClick={handleConvert}>{t('requests.convertToOpportunity')}</Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card header={<h4 className="font-semibold text-slate-200">{t('requests.description')}</h4>}>
            <p className="text-sm text-slate-300 whitespace-pre-wrap">{request.description}</p>
          </Card>
          {request.internalNotes && (
            <Card header={<h4 className="font-semibold text-slate-200">Internal Notes</h4>}>
              <p className="text-sm text-slate-300">{request.internalNotes}</p>
            </Card>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-slate-400">{t('common.status')}</p>
                <StatusBadge status={request.status} className="mt-1" />
              </div>
              <div>
                <p className="text-xs text-slate-400">{t('requests.type')}</p>
                <Badge className="mt-1">{request.requestType}</Badge>
              </div>
              <div>
                <p className="text-xs text-slate-400">{t('requests.priority')}</p>
                <StatusBadge status={request.priority} className="mt-1" />
              </div>
              <div>
                <p className="text-xs text-slate-400">{t('requests.estimatedValue')}</p>
                <p className="text-sm font-semibold text-[#c9a962] mt-1">
                  {request.estimatedValue ? `$${request.estimatedValue.toLocaleString()}` : '—'}
                </p>
              </div>
              {request.hotel && (
                <div>
                  <p className="text-xs text-slate-400">{t('hotels.title')}</p>
                  <p className="text-sm text-slate-200 mt-1">{request.hotel.name}</p>
                </div>
              )}
              {request.assignedTo && (
                <div>
                  <p className="text-xs text-slate-400">{t('requests.assign')}</p>
                  <p className="text-sm text-slate-200 mt-1">{request.assignedTo.name}</p>
                </div>
              )}
              {request.deadline && (
                <div>
                  <p className="text-xs text-slate-400">{t('requests.deadline')}</p>
                  <p className="text-sm text-slate-200 mt-1">{new Date(request.deadline).toLocaleDateString()}</p>
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>

      <Modal isOpen={showAssignModal} onClose={() => setShowAssignModal(false)} title={t('requests.assign')} footer={
        <>
          <Button variant="ghost" onClick={() => setShowAssignModal(false)}>{t('common.cancel')}</Button>
          <Button onClick={handleAssign}>{t('common.save')}</Button>
        </>
      }>
        <Textarea label="User ID to assign" value={assignUserId} onChange={(e) => setAssignUserId(e.target.value)} />
      </Modal>
    </div>
  );
};

export default RequestDetail;