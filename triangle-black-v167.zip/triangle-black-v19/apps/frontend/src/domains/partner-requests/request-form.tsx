import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save, X } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const schema = z.object({
  hotelId: z.string().min(1, 'Hotel required'),
  requestType: z.string().min(1, 'Type required'),
  title: z.string().min(2, 'Title required'),
  description: z.string().min(5, 'Description required'),
  priority: z.string().min(1, 'Priority required'),
  source: z.string().optional(),
  estimatedValue: z.coerce.number().optional(),
  deadline: z.string().optional(),
  internalNotes: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const RequestForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { priority: 'MEDIUM', source: 'EMAIL', requestType: 'MAINTENANCE' },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await apiPost(endpoints.partnerRequests.create, data);
      toast.success(t('common.success'));
      navigate('/requests');
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title={t('requests.newRequest')} showBack backTo="/requests" breadcrumbs={[{label:t('requests.title'),href:'/requests'},{label:t('common.create')}]}/>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Hotel ID" error={errors.hotelId?.message} {...register('hotelId')} placeholder="Enter hotel ID" />
            <Select label={t('requests.type')} options={[{value:'MAINTENANCE',label:'Maintenance'},{value:'RENOVATION',label:'Renovation'},{value:'NEW_CONSTRUCTION',label:'New Construction'},{value:'FF&E',label:'FF&E'},{value:'OS&E',label:'OS&E'},{value:'EMERGENCY_REPAIR',label:'Emergency Repair'}]} error={errors.requestType?.message} {...register('requestType')} />
            <Input label={t('common.name')} error={errors.title?.message} {...register('title')} className="md:col-span-2" />
            <Textarea label={t('requests.description')} error={errors.description?.message} {...register('description')} className="md:col-span-2" />
            <Select label={t('requests.priority')} options={[{value:'LOW',label:'Low'},{value:'MEDIUM',label:'Medium'},{value:'HIGH',label:'High'},{value:'CRITICAL',label:'Critical'}]} error={errors.priority?.message} {...register('priority')} />
            <Input label={t('requests.source')} {...register('source')} />
            <Input label={t('requests.estimatedValue')} type="number" {...register('estimatedValue')} />
            <Input label={t('requests.deadline')} type="date" {...register('deadline')} />
            <Textarea label="Internal Notes" {...register('internalNotes')} className="md:col-span-2" />
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" onClick={() => navigate('/requests')}>{t('common.cancel')}</Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default RequestForm;