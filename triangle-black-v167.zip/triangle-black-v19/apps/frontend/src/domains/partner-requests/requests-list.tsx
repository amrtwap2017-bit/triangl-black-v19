import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Calendar, DollarSign } from 'lucide-react';
import { PageHeader, SearchBar, Button, Select, Card, Table, StatusBadge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { PartnerRequest, Column } from '@/shared/types';

const RequestsList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: requests, isLoading, meta } = useApi<PartnerRequest>(
    ['partnerRequests'],
    endpoints.partnerRequests.list,
    { ...paginationParams(), search, status: statusFilter, type: typeFilter }
  );

  const columns: Column<PartnerRequest>[] = useMemo(() => [
    { key: 'requestNumber', header: t('requests.requestNumber'), sortable: true, width: 'w-32' },
    { key: 'title', header: t('common.name'), sortable: true, render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.title}</p>
        <p className="text-xs text-slate-500">{row.hotel?.name}</p>
      </div>
    )},
    { key: 'requestType', header: t('requests.type'), render: (v) => <Badge variant="default">{String(v)}</Badge> },
    { key: 'priority', header: t('requests.priority'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'status', header: t('common.status'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'estimatedValue', header: t('requests.estimatedValue'), align: 'end', render: (v) => v ? `$${(v as number).toLocaleString()}` : '—' },
    { key: 'createdAt', header: t('common.date'), width: 'w-28', render: (v) => new Date(v as string).toLocaleDateString() },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('requests.title')} actions={
        <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/requests/new')}>{t('requests.newRequest')}</Button>
      )} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[{value:'',label:t('common.all')},{value:'NEW',label:'New'},{value:'ASSIGNED',label:'Assigned'},{value:'CONVERTED',label:'Converted'}]} value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} />
          <Select options={[{value:'',label:t('common.all')},{value:'MAINTENANCE',label:'Maintenance'},{value:'RENOVATION',label:'Renovation'},{value:'FF&E',label:'FF&E'}]} value={typeFilter} onChange={(e)=>setTypeFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={requests} keyExtractor={(r)=>r.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} onRowClick={(r)=>navigate(`/requests/${r.id}`)} />
      </Card>
    </div>
  );
};

export default RequestsList;