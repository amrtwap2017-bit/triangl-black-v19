import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save, Plus, X } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const schema = z.object({
  projectId: z.string().min(1, 'Project required'),
  title: z.string().min(2, 'Title required'),
  description: z.string().min(5, 'Description required'),
  urgency: z.string().min(1),
  vendorId: z.string().optional(),
  requiredDate: z.string().optional(),
  items: z.array(z.object({
    description: z.string().min(1),
    specification: z.string().optional(),
    quantity: z.coerce.number().min(1),
    unit: z.string().min(1),
    estimatedUnitPrice: z.coerce.number().min(0),
  })).min(1, 'At least one item required'),
});

type FormData = z.infer<typeof schema>;

const ProcurementForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [lineItems, setLineItems] = useState([{ description: '', specification: '', quantity: 1, unit: 'EA', estimatedUnitPrice: 0, estimatedTotal: 0 }]);

  const { register, handleSubmit, formState: { errors } } = useForm<Omit<FormData, 'items'>>({
    resolver: zodResolver(schema.omit({ items: true })),
    defaultValues: { urgency: 'MEDIUM' },
  });

  const updateLineItem = (index: number, field: string, value: unknown) => {
    const updated = [...lineItems];
    (updated[index] as any)[field] = value;
    if (field === 'quantity' || field === 'estimatedUnitPrice') {
      updated[index].estimatedTotal = updated[index].quantity * updated[index].estimatedUnitPrice;
    }
    setLineItems(updated);
  };

  const addLineItem = () => setLineItems([...lineItems, { description: '', specification: '', quantity: 1, unit: 'EA', estimatedUnitPrice: 0, estimatedTotal: 0 }]);
  const removeLineItem = (index: number) => setLineItems(lineItems.filter((_, i) => i !== index));

  const onSubmit = async (data: Omit<FormData, 'items'>) => {
    setLoading(true);
    try {
      await apiPost(endpoints.procurement.requests.create, { ...data, items: lineItems });
      toast.success(t('common.success'));
      navigate('/procurement');
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  const totalEstimated = lineItems.reduce((sum, item) => sum + item.estimatedTotal, 0);

  return (
    <div className="space-y-6">
      <PageHeader title="New Procurement Request" showBack backTo="/procurement" />
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <Input label="Project ID" error={errors.projectId?.message} {...register('projectId')} />
            <Input label={t('common.name')} error={errors.title?.message} {...register('title')} />
            <Select label={t('procurement.urgency')} options={[{value:'LOW',label:'Low'},{value:'MEDIUM',label:'Medium'},{value:'HIGH',label:'High'},{value:'CRITICAL',label:'Critical'}]} error={errors.urgency?.message} {...register('urgency')} />
            <Input label="Vendor ID" {...register('vendorId')} />
            <Input label={t('procurement.requiredDate')} type="date" {...register('requiredDate')} />
            <Textarea label={t('common.description')} error={errors.description?.message} {...register('description')} />
          </div>

          <div className="border-t border-[#2d2d4a] pt-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-slate-200">Line Items</h4>
              <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={addLineItem}>Add Item</Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-[#2d2d4a]">
                  <th className="text-start py-2 text-slate-400">Description</th>
                  <th className="text-start py-2 text-slate-400 w-24">Unit</th>
                  <th className="text-end py-2 text-slate-400 w-20">Qty</th>
                  <th className="text-end py-2 text-slate-400 w-32">Unit Price</th>
                  <th className="text-end py-2 text-slate-400 w-32">Total</th>
                  <th className="w-10"></th>
                </tr></thead>
                <tbody>
                  {lineItems.map((item, i) => (
                    <tr key={i} className="border-b border-[#2d2d4a]/50">
                      <td className="py-2"><input value={item.description} onChange={(e) => updateLineItem(i, 'description', e.target.value)} className="w-full bg-transparent text-sm text-slate-200 focus:outline-none" placeholder="Item description" /></td>
                      <td className="py-2"><input value={item.unit} onChange={(e) => updateLineItem(i, 'unit', e.target.value)} className="w-full bg-transparent text-sm text-slate-300 text-center focus:outline-none" /></td>
                      <td className="py-2"><input type="number" value={item.quantity} onChange={(e) => updateLineItem(i, 'quantity', Number(e.target.value))} className="w-full bg-transparent text-sm text-slate-300 text-end focus:outline-none" /></td>
                      <td className="py-2"><input type="number" value={item.estimatedUnitPrice} onChange={(e) => updateLineItem(i, 'estimatedUnitPrice', Number(e.target.value))} className="w-full bg-transparent text-sm text-slate-300 text-end focus:outline-none" /></td>
                      <td className="py-2 text-end text-[#c9a962]">${item.estimatedTotal.toLocaleString()}</td>
                      <td className="py-2"><button onClick={() => removeLineItem(i)} className="p-1 text-slate-500 hover:text-red-400"><X className="w-3.5 h-3.5" /></button></td>
                    </tr>
                  ))}
                </tbody>
                <tfoot><tr className="border-t border-[#c9a962]"><td colSpan={4} className="py-2 text-end font-semibold text-slate-200">Total Estimate</td><td className="py-2 text-end font-bold text-[#c9a962]">${totalEstimated.toLocaleString()}</td><td /></tr></tfoot>
              </table>
            </div>
          </div>

          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" onClick={() => navigate('/procurement')}>{t('common.cancel')}</Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default ProcurementForm;