import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus } from 'lucide-react';
import { PageHeader, SearchBar, Button, Select, Card, Table, StatusBadge, Badge, Tabs } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { ProcurementRequest, Column } from '@/shared/types';

const ProcurementList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('requests');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const endpoint = activeTab === 'requests' ? endpoints.procurement.requests.list : endpoints.procurement.purchaseOrders.list;
  const { data: items, isLoading, meta } = useApi<ProcurementRequest>(
    ['procurement', activeTab], endpoint,
    { ...paginationParams(), search, status: statusFilter }
  );

  const columns: Column<ProcurementRequest>[] = useMemo(() => [
    { key: 'requestNumber', header: activeTab === 'requests' ? t('procurement.requestNumber') : t('procurement.poNumber'), width: 'w-36', sortable: true },
    { key: 'title', header: t('common.name'), sortable: true, render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.title}</p>
        <p className="text-xs text-slate-500">{(row as any).project?.title || (row as any).projectId}</p>
      </div>
    )},
    { key: 'status', header: t('common.status'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'estimatedCost', header: t('common.amount'), align: 'end', render: (v) => `$${(v as number).toLocaleString()}` },
    { key: 'requestedBy', header: 'Requested By', render: (_, row) => (row as any).requestedBy?.name || '—' },
    { key: 'createdAt', header: t('common.date'), width: 'w-28', render: (v) => new Date(v as string).toLocaleDateString() },
  ], [t, activeTab]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('procurement.title')} actions={
        <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/procurement/new')}>{t('common.create')}</Button>
      )} />
      <Tabs tabs={[{key:'requests',label:t('procurement.requests')},{key:'purchaseOrders',label:t('procurement.purchaseOrders')}]} activeTab={activeTab} onChange={setActiveTab} className="mb-4" />
      <Card noPadding>
        <div className="p-4 border-b border-[#2d2d4a]"><SearchBar onSearch={setSearch} /></div>
        <Table columns={columns} data={items} keyExtractor={(r)=>r.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} />
      </Card>
    </div>
  );
};

export default ProcurementList;