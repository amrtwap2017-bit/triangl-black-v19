import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { PageHeader, SearchBar, Card, Table, StatusBadge, Badge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { PurchaseOrder, Column } from '@/shared/types';

const PurchaseOrdersList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: orders, isLoading, meta } = useApi<PurchaseOrder>(
    ['purchaseOrders'], endpoints.procurement.purchaseOrders.list,
    { ...paginationParams(), search }
  );

  const columns: Column<PurchaseOrder>[] = useMemo(() => [
    { key: 'poNumber', header: t('procurement.poNumber'), width: 'w-36', sortable: true },
    { key: 'vendor', header: t('procurement.vendor'), render: (_, row) => row.vendor?.name || '—' },
    { key: 'status', header: t('common.status'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'total', header: t('common.amount'), align: 'end', render: (v) => `$${(v as number).toLocaleString()}` },
    { key: 'currency', header: t('common.currency') },
    { key: 'expectedDeliveryDate', header: t('procurement.expectedDelivery'), width: 'w-36', render: (v) => v ? new Date(v as string).toLocaleDateString() : '—' },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('procurement.purchaseOrders')} showBack backTo="/procurement" />
      <Card noPadding>
        <div className="p-4 border-b border-[#2d2d4a]"><SearchBar onSearch={setSearch} /></div>
        <Table columns={columns} data={orders} keyExtractor={(o)=>o.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} />
      </Card>
    </div>
  );
};

export default PurchaseOrdersList;