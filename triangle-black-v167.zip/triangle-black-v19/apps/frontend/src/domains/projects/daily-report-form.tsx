import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save } from 'lucide-react';
import { PageHeader, Card, Input, Textarea, Button, Select, FileUpload } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const schema = z.object({
  reportDate: z.string().min(1, 'Date required'),
  weather: z.string().optional(),
  workCompleted: z.string().min(5, 'Work completed required'),
  workPlannedTomorrow: z.string().optional(),
  issues: z.string().optional(),
  manpowerCount: z.coerce.number().min(0),
  safetyIncidents: z.coerce.number().min(0),
});

type FormData = z.infer<typeof schema>;

const DailyReportForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [photos, setPhotos] = useState<File[]>([]);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { reportDate: new Date().toISOString().split('T')[0], safetyIncidents: 0 },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await apiPost(endpoints.projects.dailyReports(id!), data);
      toast.success(t('common.success'));
      navigate(`/projects/${id}`);
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="New Daily Report" showBack backTo={`/projects/${id}`} breadcrumbs={[{label:t('projects.title'),href:'/projects'},{label:'Daily Report'}]}/>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label={t('common.date')} type="date" error={errors.reportDate?.message} {...register('reportDate')} />
            <Input label="Weather" {...register('weather')} />
            <Textarea label="Work Completed" error={errors.workCompleted?.message} {...register('workCompleted')} className="md:col-span-2" rows={4} />
            <Textarea label="Work Planned Tomorrow" {...register('workPlannedTomorrow')} className="md:col-span-2" rows={3} />
            <Textarea label="Issues" {...register('issues')} className="md:col-span-2" rows={3} />
            <Input label="Manpower Count" type="number" error={errors.manpowerCount?.message} {...register('manpowerCount')} />
            <Input label="Safety Incidents" type="number" error={errors.safetyIncidents?.message} {...register('safetyIncidents')} />
            <FileUpload label="Photos" onFilesSelected={setPhotos} accept="image/*" className="md:col-span-2" />
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" onClick={() => navigate(`/projects/${id}`)}>{t('common.cancel')}</Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default DailyReportForm;