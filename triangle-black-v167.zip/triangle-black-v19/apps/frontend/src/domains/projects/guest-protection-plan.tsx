import { ShieldAlert, Volume2, CloudRain, Wind, Clock, MessageSquare, Eye } from 'lucide-react';
import { Card, Badge, Button } from '@/shared/components/ui';
import { useTranslation } from 'react-i18next';
import { EmptyState } from '@/shared/components/ui/empty-state';
import type { GuestProtectionPlan } from '@/shared/types';

interface GuestProtectionPlanViewProps {
  plan?: GuestProtectionPlan;
  onEdit?: () => void;
}

export const GuestProtectionPlanView: React.FC<GuestProtectionPlanViewProps> = ({ plan, onEdit }) => {
  const { t } = useTranslation();

  if (!plan) return <EmptyState message="No guest protection plan" actionLabel="Create Plan" onAction={onEdit} />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-[#c9a962]" />
          <h3 className="text-lg font-semibold text-slate-100">{t('projects.guestProtection')}</h3>
        </div>
        {onEdit && <Button size="sm" variant="secondary">{t('common.edit')}</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <div className="flex items-center gap-2 mb-3"><Volume2 className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Noise Control</h4></div>
          <p className="text-sm text-slate-300">{plan.noiseControl}</p>
        </Card>
        <Card>
          <div className="flex items-center gap-2 mb-3"><CloudRain className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Dust Control</h4></div>
          <p className="text-sm text-slate-300">{plan.dustControl}</p>
        </Card>
        <Card>
          <div className="flex items-center gap-2 mb-3"><Wind className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Odor Control</h4></div>
          <p className="text-sm text-slate-300">{plan.odorControl}</p>
        </Card>
        <Card>
          <div className="flex items-center gap-2 mb-3"><Clock className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Work Schedule</h4></div>
          <p className="text-sm text-slate-300">{plan.workSchedule}</p>
        </Card>
        <Card>
          <div className="flex items-center gap-2 mb-3"><MessageSquare className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Guest Communication</h4></div>
          <p className="text-sm text-slate-300">{plan.guestCommunication}</p>
        </Card>
        <Card>
          <div className="flex items-center gap-2 mb-3"><Eye className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Monitoring Measures</h4></div>
          <p className="text-sm text-slate-300">{plan.monitoringMeasures}</p>
        </Card>
      </div>

      <Card header={<h4 className="font-semibold text-slate-200">Emergency Procedures</h4>}>
        <p className="text-sm text-slate-300 whitespace-pre-wrap">{plan.emergencyProcedures}</p>
      </Card>
    </div>
  );
};