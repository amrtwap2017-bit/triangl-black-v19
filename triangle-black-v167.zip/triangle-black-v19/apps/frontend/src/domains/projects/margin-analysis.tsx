import { useTranslation } from 'react-i18next';
import { Card, StatCard, LoadingSpinner, EmptyState } from '@/shared/components/ui';
import { MarginChart } from '@/shared/components/charts';
import { useApiSingle } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import { useParams } from 'react-router-dom';
import type { ProjectMargin, RevenueData } from '@/shared/types';

const mockRevenue: RevenueData[] = [
  { month: 'Jan', revenue: 200000, cost: 150000, profit: 50000 },
  { month: 'Feb', revenue: 180000, cost: 135000, profit: 45000 },
  { month: 'Mar', revenue: 220000, cost: 160000, profit: 60000 },
  { month: 'Apr', revenue: 210000, cost: 155000, profit: 55000 },
  { month: 'May', revenue: 240000, cost: 170000, profit: 70000 },
  { month: 'Jun', revenue: 230000, cost: 168000, profit: 62000 },
];

export const MarginAnalysis: React.FC = () => {
  const { t } = useTranslation();
  // In real usage, pass id from parent
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={<span className="text-sm">💰</span>} label="Labor Cost" value="$45,000" />
        <StatCard icon={<span className="text-sm">📦</span>} label="Material Cost" value="$78,000" />
        <StatCard icon={<span className="text-sm">🚛</span>} label="Equipment Cost" value="$12,000" />
        <StatCard icon={<span className="text-sm">👷</span>} label="Subcontractor Cost" value="$33,000" />
      </div>
      <Card header={<h4 className="font-semibold text-slate-200">{t('insights.margins')}</h4>}>
        <MarginChart data={mockRevenue} />
      </Card>
    </div>
  );
};