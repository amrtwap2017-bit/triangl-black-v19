import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  HardHat, DollarSign, Calendar, Users, FileText, ShieldAlert,
  ListChecks, Flag, BarChart3, TrendingUp, Edit, Plus,
} from 'lucide-react';
import { PageHeader, Card, Button, Tabs, Badge, LoadingSpinner, EmptyState, StatusBadge, StatCard } from '@/shared/components/ui';
import { MarginChart } from '@/shared/components/charts';
import { useApiSingle, useApi } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { Project, ProjectTask, ProjectMilestone, DailyReport, RevenueData } from '@/shared/types';

const mockRevenue: RevenueData[] = [
  { month: 'Jan', revenue: 80000, cost: 55000, profit: 25000 },
  { month: 'Feb', revenue: 95000, cost: 68000, profit: 27000 },
  { month: 'Mar', revenue: 110000, cost: 74000, profit: 36000 },
  { month: 'Apr', revenue: 105000, cost: 72000, profit: 33000 },
  { month: 'May', revenue: 125000, cost: 85000, profit: 40000 },
  { month: 'Jun', revenue: 115000, cost: 78000, profit: 37000 },
];

const ProjectDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  const { data: project, isLoading } = useApiSingle<Project>(
    ['project', id!], `/projects/${id}`
  );

  const { data: tasks } = useApi<ProjectTask>(
    ['project-tasks', id!], endpoints.projects.tasks(id!), { limit: 50 }
  );
  const { data: milestones } = useApi<ProjectMilestone>(
    ['project-milestones', id!], endpoints.projects.milestones(id!), { limit: 50 }
  );

  if (isLoading) return <LoadingSpinner />;
  if (!project) return <EmptyState message="Project not found" />;

  const tabs = [
    { key: 'overview', label: t('projects.overview'), icon: <HardHat className="w-4 h-4" /> },
    { key: 'tasks', label: t('projects.tasks'), icon: <ListChecks className="w-4 h-4" /> },
    { key: 'milestones', label: t('projects.milestones'), icon: <Flag className="w-4 h-4" /> },
    { key: 'dailyReports', label: t('projects.dailyReports'), icon: <FileText className="w-4 h-4" /> },
    { key: 'variations', label: t('projects.variations'), icon: <BarChart3 className="w-4 h-4" /> },
    { key: 'guestProtection', label: t('projects.guestProtection'), icon: <ShieldAlert className="w-4 h-4" /> },
    { key: 'documents', label: t('projects.documents'), icon: <FileText className="w-4 h-4" /> },
    { key: 'margin', label: t('projects.marginAnalysis'), icon: <TrendingUp className="w-4 h-4" /> },
  ];

  const budgetVariance = project.budget - project.actualCost;

  return (
    <div className="space-y-6">
      <PageHeader
        title={project.title}
        subtitle={`${project.projectNumber} • ${project.type}`}
        breadcrumbs={[{label:t('projects.title'),href:'/projects'},{label:project.projectNumber}]}
        showBack
        actions={
          <Button variant="secondary" icon={<Edit className="w-4 h-4" />} onClick={() => navigate(`/projects/${id}/edit`)}>{t('common.edit')}</Button>
        }
      />

      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={<DollarSign className="w-5 h-5" />} label={t('projects.budget')} value={`$${project.budget.toLocaleString()}`} />
            <StatCard icon={<TrendingUp className="w-5 h-5" />} label={t('projects.actualCost')} value={`$${project.actualCost.toLocaleString()}`} />
            <StatCard icon={<BarChart3 className="w-5 h-5" />} label={t('projects.revenue')} value={`$${project.revenue.toLocaleString()}`} />
            <StatCard icon={<TrendingUp className="w-5 h-5" />} label={t('projects.profit')} value={`$${(project.revenue - project.actualCost).toLocaleString()}`} />
          </div>

          <div className="flex items-center gap-4 mb-2">
            <span className="text-sm text-slate-400">{t('projects.progress')}</span>
            <div className="flex-1 h-3 bg-[#252540] rounded-full overflow-hidden">
              <div className="h-full bg-[#c9a962] rounded-full transition-all" style={{ width: `${project.progress}%` }} />
            </div>
            <span className="text-sm font-semibold text-[#c9a962]">{project.progress}%</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div><p className="text-slate-400">{t('common.status')}</p><StatusBadge status={project.status} className="mt-1" /></div>
                  <div><p className="text-slate-400">{t('projects.type')}</p><Badge className="mt-1">{project.type}</Badge></div>
                  <div><p className="text-slate-400">{t('projects.startDate')}</p><p className="text-slate-200 mt-1">{new Date(project.startDate).toLocaleDateString()}</p></div>
                  <div><p className="text-slate-400">{t('projects.endDate')}</p><p className="text-slate-200 mt-1">{project.endDate ? new Date(project.endDate).toLocaleDateString() : '—'}</p></div>
                  {project.hotel && <div><p className="text-slate-400">{t('hotels.title')}</p><p className="text-slate-200 mt-1">{project.hotel.name}</p></div>}
                  {project.projectManager && <div><p className="text-slate-400">{t('projects.projectManager')}</p><p className="text-slate-200 mt-1">{project.projectManager.name}</p></div>}
                  <div><p className="text-slate-400">{t('projects.budget')}</p><p className="text-[#c9a962] font-semibold mt-1">${project.budget.toLocaleString()}</p></div>
                  <div><p className="text-slate-400">{t('projects.actualCost')}</p><p className={`font-semibold mt-1 ${budgetVariance < 0 ? 'text-red-400' : 'text-green-400'}`}>${project.actualCost.toLocaleString()}</p></div>
                </div>
              </Card>
            </div>
            <Card>
              <h4 className="font-semibold text-slate-200 mb-3">{t('projects.tasks')}</h4>
              <div className="space-y-2">
                {tasks.slice(0, 5).map((task) => (
                  <div key={task.id} className="flex items-center justify-between py-1.5">
                    <span className="text-sm text-slate-300 truncate">{task.title}</span>
                    <StatusBadge status={task.status} />
                  </div>
                ))}
                {tasks.length === 0 && <p className="text-sm text-slate-500">No tasks yet</p>}
              </div>
            </Card>
          </div>
        </div>
      )}

      {activeTab === 'tasks' && (
        <Card header={<div className="flex items-center justify-between"><h4 className="font-semibold text-slate-200">{t('projects.tasks')}</h4><Button size="sm" icon={<Plus className="w-3.5 h-3.5" />}>Add Task</Button></div>}>
          {tasks.length > 0 ? (
            <div className="divide-y divide-[#2d2d4a]/50">
              {tasks.map((task) => (
                <div key={task.id} className="py-3 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-200">{task.title}</p>
                    {task.description && <p className="text-xs text-slate-500 mt-0.5">{task.description}</p>}
                  </div>
                  <div className="flex items-center gap-3">
                    {task.dueDate && <span className="text-xs text-slate-400">{new Date(task.dueDate).toLocaleDateString()}</span>}
                    <StatusBadge status={task.priority} />
                    <StatusBadge status={task.status} />
                  </div>
                </div>
              ))}
            </div>
          ) : <EmptyState message="No tasks" />}
        </Card>
      )}

      {activeTab === 'milestones' && (
        <Card>
          {milestones.length > 0 ? (
            <div className="space-y-4">
              {milestones.map((ms, i) => (
                <div key={ms.id} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className={`w-3 h-3 rounded-full ${ms.status === 'COMPLETED' ? 'bg-green-400' : ms.status === 'OVERDUE' ? 'bg-red-400' : 'bg-[#c9a962]'}`} />
                    {i < milestones.length - 1 && <div className="w-px flex-1 bg-[#2d2d4a] mt-1" />}
                  </div>
                  <div className="pb-6 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-slate-100">{ms.name}</p>
                      <StatusBadge status={ms.status} />
                    </div>
                    <p className="text-sm text-slate-400 mt-0.5">{ms.description}</p>
                    <p className="text-xs text-slate-500 mt-1">Due: {new Date(ms.dueDate).toLocaleDateString()}</p>
                    <div className="mt-2 w-32 h-1.5 bg-[#252540] rounded-full overflow-hidden">
                      <div className="h-full bg-[#c9a962] rounded-full" style={{ width: `${ms.progress}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : <EmptyState message="No milestones" />}
        </Card>
      )}

      {activeTab === 'margin' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={<DollarSign className="w-5 h-5" />} label="Total Revenue" value={`$${project.revenue.toLocaleString()}`} />
            <StatCard icon={<TrendingUp className="w-5 h-5" />} label="Total Cost" value={`$${project.actualCost.toLocaleString()}`} />
            <StatCard icon={<BarChart3 className="w-5 h-5" />} label="Gross Profit" value={`$${(project.revenue - project.actualCost).toLocaleString()}`} />
            <StatCard icon={<TrendingUp className="w-5 h-5" />} label="Gross Margin" value={`${project.budget > 0 ? (((project.revenue - project.actualCost) / project.revenue) * 100).toFixed(1) : 0}%`} />
          </div>
          <Card header={<h4 className="font-semibold text-slate-200">{t('insights.margins')}</h4>}>
            <MarginChart data={mockRevenue} />
          </Card>
        </div>
      )}

      {['dailyReports', 'variations', 'guestProtection', 'documents'].includes(activeTab) && (
        <Card>
          <EmptyState message={`No ${activeTab} data available`} />
        </Card>
      )}
    </div>
  );
};

export default ProjectDetail;