import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const schema = z.object({
  hotelId: z.string().min(1, 'Hotel required'),
  title: z.string().min(2, 'Title required'),
  description: z.string().optional(),
  type: z.string().min(1, 'Type required'),
  status: z.string().optional(),
  startDate: z.string().min(1, 'Start date required'),
  endDate: z.string().optional(),
  budget: z.coerce.number().min(0),
  proposalId: z.string().optional(),
  projectManagerId: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const ProjectForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { status: 'PLANNING', type: 'MAINTENANCE' },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await apiPost(endpoints.projects.create, data);
      toast.success(t('common.success'));
      navigate('/projects');
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title={t('projects.create')} showBack backTo="/projects" breadcrumbs={[{label:t('projects.title'),href:'/projects'},{label:t('common.create')}]}/>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Hotel ID" error={errors.hotelId?.message} {...register('hotelId')} />
            <Input label={t('common.name')} error={errors.title?.message} {...register('title')} className="md:col-span-2" />
            <Select label={t('projects.type')} options={[{value:'MAINTENANCE',label:'Maintenance'},{value:'RENOVATION',label:'Renovation'},{value:'NEW_CONSTRUCTION',label:'New Construction'},{value:'FF&E_INSTALLATION',label:'FF&E Installation'},{value:'OS&E_SUPPLY',label:'OS&E Supply'},{value:'CONSULTATION',label:'Consultation'},{value:'EMERGENCY_REPAIR',label:'Emergency Repair'}]} error={errors.type?.message} {...register('type')} />
            <Select label={t('common.status')} options={[{value:'PLANNING',label:'Planning'},{value:'IN_PROGRESS',label:'In Progress'},{value:'ON_HOLD',label:'On Hold'}]} {...register('status')} />
            <Input label={t('projects.startDate')} type="date" error={errors.startDate?.message} {...register('startDate')} />
            <Input label={t('projects.endDate')} type="date" {...register('endDate')} />
            <Input label={t('projects.budget')} type="number" error={errors.budget?.message} {...register('budget')} />
            <Input label="Proposal ID" {...register('proposalId')} />
            <Input label="Project Manager ID" {...register('projectManagerId')} />
            <Textarea label={t('common.description')} {...register('description')} className="md:col-span-2" />
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" onClick={() => navigate('/projects')}>{t('common.cancel')}</Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default ProjectForm;