import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, HardHat } from 'lucide-react';
import { PageHeader, SearchBar, Button, Select, Card, Table, StatusBadge, Badge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { Project, Column } from '@/shared/types';

const ProjectsList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: projects, isLoading, meta } = useApi<Project>(
    ['projects'], endpoints.projects.list,
    { ...paginationParams(), search, status: statusFilter, type: typeFilter }
  );

  const columns: Column<Project>[] = useMemo(() => [
    { key: 'projectNumber', header: 'Project #', width: 'w-36', sortable: true },
    { key: 'title', header: t('common.name'), sortable: true, render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.title}</p>
        <p className="text-xs text-slate-500">{row.hotel?.name}</p>
      </div>
    )},
    { key: 'type', header: t('projects.type'), render: (v) => <Badge>{String(v)}</Badge> },
    { key: 'status', header: t('common.status'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'progress', header: t('projects.progress'), align: 'center', render: (v) => (
      <div className="flex items-center gap-2">
        <div className="w-16 h-2 bg-[#252540] rounded-full overflow-hidden">
          <div className="h-full bg-[#c9a962] rounded-full" style={{ width: `${v as number}%` }} />
        </div>
        <span className="text-sm text-slate-300">{v}%</span>
      </div>
    )},
    { key: 'budget', header: t('projects.budget'), align: 'end', render: (v) => `$${(v as number).toLocaleString()}` },
    { key: 'actualCost', header: t('projects.actualCost'), align: 'end', render: (v) => `$${(v as number).toLocaleString()}` },
    { key: 'projectManager', header: t('projects.projectManager'), render: (_, row) => row.projectManager?.name || '—' },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('projects.title')} actions={
        <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/projects/new')}>{t('projects.create')}</Button>
      )} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[{value:'',label:t('common.all')},{value:'PLANNING',label:'Planning'},{value:'IN_PROGRESS',label:'In Progress'},{value:'COMPLETED',label:'Completed'},{value:'ON_HOLD',label:'On Hold'}]} value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} />
          <Select options={[{value:'',label:t('common.all')},{value:'MAINTENANCE',label:'Maintenance'},{value:'RENOVATION',label:'Renovation'},{value:'FF&E_INSTALLATION',label:'FF&E'},{value:'NEW_CONSTRUCTION',label:'New Construction'}]} value={typeFilter} onChange={(e)=>setTypeFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={projects} keyExtractor={(p)=>p.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} onRowClick={(p)=>navigate(`/projects/${p.id}`)} />
      </Card>
    </div>
  );
};

export default ProjectsList;