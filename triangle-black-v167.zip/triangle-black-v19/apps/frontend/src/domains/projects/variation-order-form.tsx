import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button } from '@/shared/components/ui';
import { apiPost } from '@/api/client';

const schema = z.object({
  title: z.string().min(2, 'Title required'),
  description: z.string().min(5, 'Description required'),
  reason: z.string().min(5, 'Reason required'),
  value: z.coerce.number().min(0),
  impactOnSchedule: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const VariationOrderForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await apiPost(`/projects/${id}/variations`, data);
      toast.success(t('common.success'));
      navigate(`/projects/${id}`);
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title="New Variation Order" showBack backTo={`/projects/${id}`} breadcrumbs={[{label:t('projects.title'),href:'/projects'},{label:'Variation Order'}]}/>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label={t('common.name')} error={errors.title?.message} {...register('title')} className="md:col-span-2" />
            <Textarea label={t('common.description')} error={errors.description?.message} {...register('description')} className="md:col-span-2" rows={4} />
            <Textarea label="Reason" error={errors.reason?.message} {...register('reason')} className="md:col-span-2" rows={3} />
            <Input label={t('common.amount')} type="number" error={errors.value?.message} {...register('value')} />
            <Textarea label="Impact on Schedule" {...register('impactOnSchedule')} rows={3} />
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" onClick={() => navigate(`/projects/${id}`)}>{t('common.cancel')}</Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default VariationOrderForm;