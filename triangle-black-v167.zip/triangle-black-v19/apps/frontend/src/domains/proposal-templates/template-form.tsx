import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import { Save } from 'lucide-react';
import { Button, Input, Select, Textarea, Card, PageHeader, Tabs } from '@/shared/components/ui';
import { apiPost, apiPut } from '@/api/client';

const projectTypeOptions = [
  { value: 'HVAC', label: 'HVAC' },
  { value: 'ELECTRICAL', label: 'Electrical' },
  { value: 'PLUMBING', label: 'Plumbing' },
  { value: 'FIRE_PROTECTION', label: 'Fire Protection' },
  { value: 'BMS', label: 'BMS' },
  { value: 'GENERAL', label: 'General' },
];

const TemplateForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [projectType, setProjectType] = useState('');
  const [activeTab, setActiveTab] = useState('executiveSummary');

  const [sections, setSections] = useState({
    executiveSummary: '',
    scope: '',
    methodStatement: '',
    guestProtection: '',
    assumptions: '',
    exclusions: '',
    commercialTerms: '',
  });

  const tabList = [
    { key: 'executiveSummary', label: 'Executive Summary' },
    { key: 'scope', label: 'Scope of Work' },
    { key: 'methodStatement', label: 'Method Statement' },
    { key: 'guestProtection', label: 'Guest Protection' },
    { key: 'assumptions', label: 'Assumptions' },
    { key: 'exclusions', label: 'Exclusions' },
    { key: 'commercialTerms', label: 'Commercial Terms' },
  ];

  const updateSection = (key: string, value: string) => {
    setSections((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = { name, projectType, ...sections };
      if (isEdit) {
        await apiPut(`/proposal-templates/${id}`, payload);
      } else {
        await apiPost('/proposal-templates', payload);
      }
      navigate('/proposal-templates');
    } catch {
      // handle error
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEdit ? t('common.edit') + ' ' + t('proposalTemplates.template') : t('common.create') + ' ' + t('proposalTemplates.template')}
        showBack
        backTo="/proposal-templates"
        actions={
          <Button type="submit" form="template-form" loading={loading} icon={<Save className="w-4 h-4" />}>
            {t('common.save')}
          </Button>
        }
      />

      <form id="template-form" onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label={t('common.name')} value={name} onChange={(e) => setName(e.target.value)} placeholder="Template name" required />
            <Select label={t('proposalTemplates.projectType')} options={projectTypeOptions} value={projectType} onChange={(e) => setProjectType(e.target.value)} placeholder="Select project type" required />
          </div>
        </Card>

        <Card noPadding>
          <div className="p-4 border-b border-[#2d2d4a]">
            <Tabs tabs={tabList} activeTab={activeTab} onChange={setActiveTab} />
          </div>
          <div className="p-6">
            <Textarea
              value={sections[activeTab as keyof typeof sections]}
              onChange={(e) => updateSection(activeTab, e.target.value)}
              placeholder={`Enter content for ${tabList.find((t) => t.key === activeTab)?.label}...`}
              className="min-h-[350px]"
            />
          </div>
        </Card>
      </form>
    </div>
  );
};

export default TemplateForm;