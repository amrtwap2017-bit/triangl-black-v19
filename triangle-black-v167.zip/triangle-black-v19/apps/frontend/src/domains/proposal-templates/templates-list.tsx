import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Copy, FileText } from 'lucide-react';
import { PageHeader, SearchBar, Button, Card, Select, Badge } from '@/shared/components/ui';

interface Template {
  id: string;
  name: string;
  projectType: string;
  lastUpdated: string;
  sections: string[];
  author: string;
}

const mockTemplates: Template[] = [
  { id: '1', name: 'Full HVAC Proposal Template', projectType: 'HVAC', lastUpdated: '2025-01-15', sections: ['executiveSummary', 'scope', 'methodStatement', 'guestProtection', 'boq', 'commercialTerms'], author: 'Ahmed Al-Rashid' },
  { id: '2', name: 'Electrical Upgrade Template', projectType: 'ELECTRICAL', lastUpdated: '2025-01-10', sections: ['executiveSummary', 'scope', 'methodStatement', 'commercialTerms'], author: 'Sara Khan' },
  { id: '3', name: 'Plumbing Repair Proposal', projectType: 'PLUMBING', lastUpdated: '2025-01-08', sections: ['executiveSummary', 'scope', 'commercialTerms'], author: 'Omar Hassan' },
  { id: '4', name: 'Fire Protection System Template', projectType: 'FIRE_PROTECTION', lastUpdated: '2025-01-05', sections: ['executiveSummary', 'scope', 'methodStatement', 'guestProtection', 'assumptions', 'exclusions', 'commercialTerms'], author: 'Lina Mahmoud' },
  { id: '5', name: 'BMS Integration Template', projectType: 'BMS', lastUpdated: '2024-12-28', sections: ['executiveSummary', 'scope', 'methodStatement', 'commercialTerms'], author: 'System Admin' },
  { id: '6', name: 'General MEP Template', projectType: 'GENERAL', lastUpdated: '2024-12-20', sections: ['executiveSummary', 'scope', 'methodStatement', 'guestProtection', 'assumptions', 'exclusions', 'boq', 'commercialTerms'], author: 'Ahmed Al-Rashid' },
];

const TemplatesList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  const filtered = useMemo(() => {
    return mockTemplates.filter((tmpl) => {
      const matchSearch = !search || tmpl.name.toLowerCase().includes(search.toLowerCase());
      const matchType = !typeFilter || tmpl.projectType === typeFilter;
      return matchSearch && matchType;
    });
  }, [search, typeFilter]);

  const sectionLabels: Record<string, string> = {
    executiveSummary: 'Executive Summary',
    scope: 'Scope of Work',
    methodStatement: 'Method Statement',
    guestProtection: 'Guest Protection',
    assumptions: 'Assumptions',
    exclusions: 'Exclusions',
    boq: 'BOQ',
    commercialTerms: 'Commercial Terms',
  };

  const handleDuplicate = async (id: string) => {
    // In production: await apiPost(`/proposal-templates/${id}/duplicate`);
    navigate(`/proposal-templates/${id}/edit`);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('proposalTemplates.title')}
        actions={
          <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/proposal-templates/new')}>
            {t('common.create')} {t('proposalTemplates.template').toLowerCase()}
          </Button>
        }
      />

      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[
            { value: '', label: t('common.all') },
            { value: 'HVAC', label: 'HVAC' },
            { value: 'ELECTRICAL', label: 'Electrical' },
            { value: 'PLUMBING', label: 'Plumbing' },
            { value: 'FIRE_PROTECTION', label: 'Fire Protection' },
            { value: 'BMS', label: 'BMS' },
            { value: 'GENERAL', label: 'General' },
          ]} value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} />
        </div>

        <div className="p-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((tmpl) => (
            <div
              key={tmpl.id}
              onClick={() => navigate(`/proposal-templates/${tmpl.id}/edit`)}
              className="bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg p-4 hover:border-[#c9a962]/40 transition-colors cursor-pointer group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-[#c9a962] shrink-0" />
                  <h3 className="text-sm font-semibold text-slate-100 line-clamp-1">{tmpl.name}</h3>
                </div>
              </div>

              <div className="flex items-center gap-2 mb-3">
                <Badge>{tmpl.projectType}</Badge>
                <span className="text-xs text-slate-500">{tmpl.sections.length} sections</span>
              </div>

              <div className="flex flex-wrap gap-1 mb-3">
                {tmpl.sections.map((s) => (
                  <span key={s} className="text-[10px] px-1.5 py-0.5 rounded bg-[#252540] text-slate-400">
                    {sectionLabels[s] || s}
                  </span>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">{tmpl.author}</span>
                <div className="flex items-center gap-1">
                  <span className="text-xs text-slate-500">{new Date(tmpl.lastUpdated).toLocaleDateString()}</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDuplicate(tmpl.id); }}
                    className="p-1 rounded text-slate-500 hover:text-[#c9a962] opacity-0 group-hover:opacity-100 transition-all"
                    title={t('proposalTemplates.duplicate')}
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default TemplatesList;