import { useState, useCallback } from 'react';
import { Plus, Trash2, GripVertical, Sparkles } from 'lucide-react';
import { Card, Button, Input, Badge, EmptyState } from '@/shared/components/ui';
import { useTranslation } from 'react-i18next';
import type { ProposalBOQItem } from '@/shared/types';

interface BOQEditorProps {
  items: ProposalBOQItem[];
  onChange: (items: ProposalBOQItem[]) => void;
  proposalId?: string;
  onGenerate?: () => void;
}

export const BOQEditor: React.FC<BOQEditorProps> = ({ items, onChange, onGenerate }) => {
  const { t } = useTranslation();

  const addItem = () => {
    const newItem: ProposalBOQItem = {
      section: 'General',
      description: '',
      unit: 'EA',
      quantity: 1,
      unitPrice: 0,
      totalPrice: 0,
      sortOrder: items.length + 1,
    };
    onChange([...items, newItem]);
  };

  const updateItem = (index: number, field: keyof ProposalBOQItem, value: unknown) => {
    const updated = [...items];
    updated[index] = { ...updated[index], [field]: value };
    if (field === 'quantity' || field === 'unitPrice') {
      updated[index].totalPrice = updated[index].quantity * updated[index].unitPrice;
    }
    onChange(updated);
  };

  const removeItem = (index: number) => {
    onChange(items.filter((_, i) => i !== index));
  };

  const totalValue = items.reduce((sum, item) => sum + item.totalPrice, 0);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold text-slate-200">{t('proposals.boq')}</h4>
        <div className="flex gap-2">
          {onGenerate && (
            <Button size="sm" variant="secondary" icon={<Sparkles className="w-3.5 h-3.5" />} onClick={onGenerate}>
              {t('proposals.generateBoq')}
            </Button>
          )}
          <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={addItem}>
            Add Item
          </Button>
        </div>
      </div>

      {items.length === 0 ? (
        <EmptyState message="No BOQ items. Add items or generate with AI." actionLabel="Add Item" onAction={addItem} />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#2d2d4a]">
                <th className="w-8"></th>
                <th className="text-start py-2.5 text-xs font-semibold text-slate-400 uppercase">Section</th>
                <th className="text-start py-2.5 text-xs font-semibold text-slate-400 uppercase">Description</th>
                <th className="text-start py-2.5 text-xs font-semibold text-slate-400 uppercase w-20">Unit</th>
                <th className="text-end py-2.5 text-xs font-semibold text-slate-400 uppercase w-24">Qty</th>
                <th className="text-end py-2.5 text-xs font-semibold text-slate-400 uppercase w-32">Unit Price</th>
                <th className="text-end py-2.5 text-xs font-semibold text-slate-400 uppercase w-32">Total</th>
                <th className="w-10"></th>
              </tr>
            </thead>
            <tbody>
              {items.map((item, index) => (
                <tr key={index} className="border-b border-[#2d2d4a]/50 hover:bg-[#252540] transition-colors">
                  <td className="py-2 text-slate-500"><GripVertical className="w-4 h-4" /></td>
                  <td className="py-2">
                    <input
                      type="text"
                      value={item.section}
                      onChange={(e) => updateItem(index, 'section', e.target.value)}
                      className="w-full bg-transparent border-none text-sm text-slate-300 focus:outline-none focus:text-slate-100"
                    />
                  </td>
                  <td className="py-2">
                    <input
                      type="text"
                      value={item.description}
                      onChange={(e) => updateItem(index, 'description', e.target.value)}
                      className="w-full bg-transparent border-none text-sm text-slate-200 focus:outline-none"
                      placeholder="Item description"
                    />
                  </td>
                  <td className="py-2">
                    <input
                      type="text"
                      value={item.unit}
                      onChange={(e) => updateItem(index, 'unit', e.target.value)}
                      className="w-full bg-transparent border-none text-sm text-slate-300 text-center focus:outline-none"
                    />
                  </td>
                  <td className="py-2">
                    <input
                      type="number"
                      value={item.quantity}
                      onChange={(e) => updateItem(index, 'quantity', Number(e.target.value))}
                      className="w-full bg-transparent border-none text-sm text-slate-300 text-end focus:outline-none"
                    />
                  </td>
                  <td className="py-2">
                    <input
                      type="number"
                      value={item.unitPrice}
                      onChange={(e) => updateItem(index, 'unitPrice', Number(e.target.value))}
                      className="w-full bg-transparent border-none text-sm text-slate-300 text-end focus:outline-none"
                    />
                  </td>
                  <td className="py-2 text-end text-[#c9a962] font-medium">
                    ${item.totalPrice.toLocaleString()}
                  </td>
                  <td className="py-2">
                    <button onClick={() => removeItem(index)} className="p-1 text-slate-500 hover:text-red-400 transition-colors">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-[#c9a962]">
                <td colSpan={6} className="py-3 text-end font-semibold text-slate-200">Total</td>
                <td className="py-3 text-end font-bold text-[#c9a962] text-lg">${totalValue.toLocaleString()}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  );
};