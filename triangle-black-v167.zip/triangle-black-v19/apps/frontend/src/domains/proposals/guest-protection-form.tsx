import { useState } from 'react';
import { Card, Textarea, Input, Badge, Button, Select, StatusBadge } from '@/shared/components/ui';
import { useTranslation } from 'react-i18next';
import { ShieldAlert, Volume2, CloudRain, Wind, X, Plus } from 'lucide-react';
import type { GuestProtectionAssessment } from '@/shared/types';

interface GuestProtectionFormProps {
  assessment?: GuestProtectionAssessment;
  onChange: (assessment: GuestProtectionAssessment) => void;
  onSave?: () => void;
  onGenerate?: () => void;
  loading?: boolean;
}

export const GuestProtectionForm: React.FC<GuestProtectionFormProps> = ({
  assessment: initial,
  onChange,
  onSave,
  onGenerate,
  loading,
}) => {
  const { t } = useTranslation();

  const [assessment, setAssessment] = useState<GuestProtectionAssessment>(
    initial || {
      noiseAssessment: '',
      noiseMitigation: [],
      dustAssessment: '',
      dustMitigation: [],
      odorAssessment: '',
      odorMitigation: [],
      shutdownRequirements: [],
      communicationPlan: '',
      monitoringPlan: '',
      overallRiskLevel: 'MEDIUM',
    }
  );

  const [newNoiseMit, setNewNoiseMit] = useState('');
  const [newDustMit, setNewDustMit] = useState('');
  const [newOdorMit, setNewOdorMit] = useState('');
  const [newShutdown, setNewShutdown] = useState('');

  const update = (field: keyof GuestProtectionAssessment, value: unknown) => {
    const updated = { ...assessment, [field]: value };
    setAssessment(updated);
    onChange(updated);
  };

  const addMitigation = (field: 'noiseMitigation' | 'dustMitigation' | 'odorMitigation' | 'shutdownRequirements', value: string, clear: () => void) => {
    if (!value.trim()) return;
    update(field, [...(assessment[field] as string[]), value]);
    clear();
  };

  const removeMitigation = (field: 'noiseMitigation' | 'dustMitigation' | 'odorMitigation' | 'shutdownRequirements', index: number) => {
    const updated = [...(assessment[field] as string[])];
    updated.splice(index, 1);
    update(field, updated);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-[#c9a962]" />
          <h3 className="text-lg font-semibold text-slate-100">{t('proposals.guestProtection')}</h3>
        </div>
        <div className="flex gap-2">
          {onGenerate && (
            <Button size="sm" variant="secondary" onClick={onGenerate} loading={loading}>
              {t('proposals.generateGuestProtection')}
            </Button>
          )}
          {onSave && <Button size="sm" onClick={onSave}>{t('common.save')}</Button>}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Noise */}
        <Card header={<div className="flex items-center gap-2"><Volume2 className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Noise Assessment</h4></div>}>
          <Textarea value={assessment.noiseAssessment} onChange={(e) => update('noiseAssessment', e.target.value)} placeholder="Describe noise impact on guests" rows={3} />
          <div className="mt-3 flex gap-2">
            <input value={newNoiseMit} onChange={(e) => setNewNoiseMit(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addMitigation('noiseMitigation', newNoiseMit, () => setNewNoiseMit('')))} placeholder="Add mitigation measure" className="flex-1 bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-1.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-[#c9a962]/50" />
            <Button size="sm" variant="secondary" onClick={() => addMitigation('noiseMitigation', newNoiseMit, () => setNewNoiseMit(''))}><Plus className="w-3.5 h-3.5" /></Button>
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {assessment.noiseMitigation.map((m, i) => (
              <Badge key={i} className="gap-1">{m}<button onClick={() => removeMitigation('noiseMitigation', i)}><X className="w-3 h-3" /></button></Badge>
            ))}
          </div>
        </Card>

        {/* Dust */}
        <Card header={<div className="flex items-center gap-2"><CloudRain className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Dust Assessment</h4></div>}>
          <Textarea value={assessment.dustAssessment} onChange={(e) => update('dustAssessment', e.target.value)} placeholder="Describe dust impact" rows={3} />
          <div className="mt-3 flex gap-2">
            <input value={newDustMit} onChange={(e) => setNewDustMit(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addMitigation('dustMitigation', newDustMit, () => setNewDustMit('')))} placeholder="Add mitigation measure" className="flex-1 bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-1.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-[#c9a962]/50" />
            <Button size="sm" variant="secondary" onClick={() => addMitigation('dustMitigation', newDustMit, () => setNewDustMit(''))}><Plus className="w-3.5 h-3.5" /></Button>
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {assessment.dustMitigation.map((m, i) => (
              <Badge key={i} className="gap-1">{m}<button onClick={() => removeMitigation('dustMitigation', i)}><X className="w-3 h-3" /></button></Badge>
            ))}
          </div>
        </Card>

        {/* Odor */}
        <Card header={<div className="flex items-center gap-2"><Wind className="w-4 h-4 text-amber-400" /><h4 className="font-semibold text-slate-200">Odor Assessment</h4></div>}>
          <Textarea value={assessment.odorAssessment} onChange={(e) => update('odorAssessment', e.target.value)} placeholder="Describe odor impact" rows={3} />
          <div className="mt-3 flex gap-2">
            <input value={newOdorMit} onChange={(e) => setNewOdorMit(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addMitigation('odorMitigation', newOdorMit, () => setNewOdorMit('')))} placeholder="Add mitigation measure" className="flex-1 bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-1.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-[#c9a962]/50" />
            <Button size="sm" variant="secondary" onClick={() => addMitigation('odorMitigation', newOdorMit, () => setNewOdorMit(''))}><Plus className="w-3.5 h-3.5" /></Button>
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {assessment.odorMitigation.map((m, i) => (
              <Badge key={i} className="gap-1">{m}<button onClick={() => removeMitigation('odorMitigation', i)}><X className="w-3 h-3" /></button></Badge>
            ))}
          </div>
        </Card>

        {/* Shutdown & Communication */}
        <Card header={<h4 className="font-semibold text-slate-200">Shutdown & Communication</h4>}>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-slate-400 mb-1.5 block">Shutdown Requirements</label>
              <div className="flex gap-2 mb-2">
                <input value={newShutdown} onChange={(e) => setNewShutdown(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addMitigation('shutdownRequirements', newShutdown, () => setNewShutdown('')))} placeholder="Add requirement" className="flex-1 bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg px-3 py-1.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-[#c9a962]/50" />
                <Button size="sm" variant="secondary" onClick={() => addMitigation('shutdownRequirements', newShutdown, () => setNewShutdown(''))}><Plus className="w-3.5 h-3.5" /></Button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {assessment.shutdownRequirements.map((s, i) => (
                  <Badge key={i} className="gap-1">{s}<button onClick={() => removeMitigation('shutdownRequirements', i)}><X className="w-3 h-3" /></button></Badge>
                ))}
              </div>
            </div>
            <Textarea label="Communication Plan" value={assessment.communicationPlan} onChange={(e) => update('communicationPlan', e.target.value)} rows={3} />
            <Textarea label="Monitoring Plan" value={assessment.monitoringPlan} onChange={(e) => update('monitoringPlan', e.target.value)} rows={3} />
          </div>
        </Card>
      </div>

      {/* Overall Risk */}
      <Card>
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-semibold text-slate-200">Overall Risk Level</h4>
            <p className="text-sm text-slate-400 mt-1">Select the overall risk level for guest experience</p>
          </div>
          <Select
            options={[
              { value: 'LOW', label: 'Low Risk' },
              { value: 'MEDIUM', label: 'Medium Risk' },
              { value: 'HIGH', label: 'High Risk' },
              { value: 'CRITICAL', label: 'Critical Risk' },
            ]}
            value={assessment.overallRiskLevel}
            onChange={(e) => update('overallRiskLevel', e.target.value)}
          />
        </div>
      </Card>
    </div>
  );
};