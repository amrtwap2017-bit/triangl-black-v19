import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  FileText, Send, Presentation, CheckCircle, XCircle, Sparkles,
  DollarSign, Calendar, User, ShieldAlert, ListOrdered, Clock,
  FileBarChart, Edit,
} from 'lucide-react';
import { PageHeader, Card, Button, Tabs, Badge, LoadingSpinner, EmptyState, StatusBadge, Modal, Textarea } from '@/shared/components/ui';
import { useApiSingle } from '@/shared/hooks';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';
import toast from 'react-hot-toast';
import type { Proposal } from '@/shared/types';

const ProposalDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(false);

  const { data: proposal, isLoading } = useApiSingle<Proposal>(
    ['proposal', id!], `/proposals/${id}`
  );

  const handleAction = async (endpoint: string, successMsg: string) => {
    setLoading(true);
    try {
      await apiPost(endpoint);
      toast.success(successMsg);
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  if (isLoading) return <LoadingSpinner />;
  if (!proposal) return <EmptyState message="Proposal not found" />;

  const tabs = [
    { key: 'overview', label: t('hotels.overview'), icon: <FileText className="w-4 h-4" /> },
    { key: 'boq', label: t('proposals.boq'), icon: <ListOrdered className="w-4 h-4" /> },
    { key: 'methodStatement', label: t('proposals.methodStatement'), icon: <FileBarChart className="w-4 h-4" /> },
    { key: 'timeline', label: t('proposals.timeline'), icon: <Clock className="w-4 h-4" /> },
    { key: 'guestProtection', label: t('proposals.guestProtection'), icon: <ShieldAlert className="w-4 h-4" /> },
    { key: 'commercial', label: t('proposals.commercialTerms'), icon: <DollarSign className="w-4 h-4" /> },
    { key: 'pdf', label: 'PDF Preview', icon: <FileText className="w-4 h-4" /> },
  ];

  const canSubmit = proposal.status === 'DRAFT' || proposal.status === 'REVISION_REQUESTED';
  const canApprove = proposal.status === 'SUBMITTED' || proposal.status === 'PRESENTED';
  const canReject = canApprove;

  return (
    <div className="space-y-6">
      <PageHeader
        title={`${t('proposals.number')}${proposal.proposalNumber}`}
        subtitle={`${proposal.title} (v${proposal.version})`}
        breadcrumbs={[{label:t('proposals.title'),href:'/proposals'},{label:proposal.proposalNumber}]}
        showBack
        actions={
          <div className="flex gap-2 flex-wrap">
            <Button variant="secondary" icon={<Edit className="w-4 h-4" />} onClick={() => navigate(`/proposals/${id}/edit`)}>{t('common.edit')}</Button>
            {canSubmit && <Button variant="secondary" icon={<Send className="w-4 h-4" />} onClick={() => handleAction(endpoints.proposals.submit(id!), 'Submitted')} loading={loading}>{t('proposals.submit')}</Button>}
            {canSubmit && <Button variant="secondary" icon={<Presentation className="w-4 h-4" />} onClick={() => handleAction(endpoints.proposals.present(id!), 'Marked as presented')} loading={loading}>Present</Button>}
            {canApprove && <Button icon={<CheckCircle className="w-4 h-4" />} onClick={() => handleAction(endpoints.proposals.approve(id!), 'Approved')} loading={loading}>{t('proposals.approve')}</Button>}
            {canReject && <Button variant="danger" icon={<XCircle className="w-4 h-4" />} onClick={() => handleAction(endpoints.proposals.reject(id!), 'Rejected')} loading={loading}>{t('common.reject')}</Button>}
          </div>
        }
      />

      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card header={<h4 className="font-semibold text-slate-200">{t('proposals.executiveSummary')}</h4>}>
              <p className="text-sm text-slate-300 whitespace-pre-wrap">{proposal.executiveSummary || 'No executive summary yet.'}</p>
            </Card>
            <Card header={<h4 className="font-semibold text-slate-200">{t('proposals.scopeOfWork')}</h4>}>
              <p className="text-sm text-slate-300 whitespace-pre-wrap">{proposal.scopeOfWork || 'No scope of work defined.'}</p>
            </Card>
          </div>
          <div className="space-y-6">
            <Card>
              <div className="space-y-4">
                <div><p className="text-xs text-slate-400">{t('common.status')}</p><StatusBadge status={proposal.status} className="mt-1" /></div>
                <div><p className="text-xs text-slate-400">{t('proposals.version')}</p><Badge className="mt-1">v{proposal.version}</Badge></div>
                <div><p className="text-xs text-slate-400">{t('proposals.totalValue')}</p><p className="text-xl font-bold text-[#c9a962] mt-1">${proposal.totalValue.toLocaleString()} {proposal.currency}</p></div>
                {proposal.discount && <div><p className="text-xs text-slate-400">{t('proposals.discount')}</p><p className="text-sm text-slate-200 mt-1">{proposal.discount}%</p></div>}
                {proposal.taxRate && <div><p className="text-xs text-slate-400">{t('proposals.taxRate')}</p><p className="text-sm text-slate-200 mt-1">{proposal.taxRate}%</p></div>}
                {proposal.validUntil && <div><p className="text-xs text-slate-400">{t('proposals.validUntil')}</p><p className="text-sm text-slate-200 mt-1">{new Date(proposal.validUntil).toLocaleDateString()}</p></div>}
                {proposal.hotel && <div><p className="text-xs text-slate-400">{t('hotels.title')}</p><p className="text-sm text-slate-200 mt-1">{proposal.hotel.name}</p></div>}
                {proposal.preparedBy && <div><p className="text-xs text-slate-400">Prepared By</p><p className="text-sm text-slate-200 mt-1">{proposal.preparedBy.name}</p></div>}
                {proposal.approvedBy && <div><p className="text-xs text-slate-400">Approved By</p><p className="text-sm text-slate-200 mt-1">{proposal.approvedBy.name}</p></div>}
              </div>
            </Card>
          </div>
        </div>
      )}

      {activeTab === 'boq' && (
        <Card header={<div className="flex items-center justify-between"><h4 className="font-semibold text-slate-200">{t('proposals.boq')}</h4><Button size="sm" variant="secondary" icon={<Sparkles className="w-3.5 h-3.5" />} onClick={() => handleAction(endpoints.proposals.generateBoq(id!), 'BOQ generated')}>{t('proposals.generateBoq')}</Button></div>}>
          {proposal.boqItems && proposal.boqItems.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-[#2d2d4a]">
                  <th className="text-start py-2 text-slate-400 font-medium">Section</th>
                  <th className="text-start py-2 text-slate-400 font-medium">Description</th>
                  <th className="text-start py-2 text-slate-400 font-medium">Unit</th>
                  <th className="text-end py-2 text-slate-400 font-medium">Qty</th>
                  <th className="text-end py-2 text-slate-400 font-medium">Unit Price</th>
                  <th className="text-end py-2 text-slate-400 font-medium">Total</th>
                </tr></thead>
                <tbody>
                  {proposal.boqItems.map((item, i) => (
                    <tr key={i} className="border-b border-[#2d2d4a]/50">
                      <td className="py-2 text-slate-300">{item.section}</td>
                      <td className="py-2 text-slate-200">{item.description}</td>
                      <td className="py-2 text-slate-400">{item.unit}</td>
                      <td className="py-2 text-end text-slate-300">{item.quantity}</td>
                      <td className="py-2 text-end text-slate-300">${item.unitPrice.toLocaleString()}</td>
                      <td className="py-2 text-end text-[#c9a962] font-medium">${item.totalPrice.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot><tr className="border-t-2 border-[#c9a962]">
                  <td colSpan={5} className="py-3 text-end font-semibold text-slate-200">Total</td>
                  <td className="py-3 text-end font-bold text-[#c9a962]">${proposal.totalValue.toLocaleString()}</td>
                </tr></tfoot>
              </table>
            </div>
          ) : <EmptyState message="No BOQ items" actionLabel={t('proposals.generateBoq')} onAction={() => handleAction(endpoints.proposals.generateBoq(id!), 'BOQ generated')} />}
        </Card>
      )}

      {activeTab === 'methodStatement' && (
        <Card header={<div className="flex items-center justify-between"><h4 className="font-semibold text-slate-200">{t('proposals.methodStatement')}</h4><Button size="sm" variant="secondary" icon={<Sparkles className="w-3.5 h-3.5" />} onClick={() => handleAction(endpoints.proposals.generateMethodStatement(id!), 'Generated')}>{t('proposals.generateMethodStatement')}</Button></div>}>
          <EmptyState message="Method statement not generated yet" />
        </Card>
      )}

      {activeTab === 'timeline' && (
        <Card>
          {proposal.timeline && proposal.timeline.length > 0 ? (
            <div className="space-y-4">
              {proposal.timeline.map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-3 h-3 rounded-full bg-[#c9a962]" />
                    {i < proposal.timeline.length - 1 && <div className="w-px flex-1 bg-[#2d2d4a] mt-1" />}
                  </div>
                  <div className="pb-6">
                    <p className="font-medium text-slate-100">{item.phase}</p>
                    <p className="text-sm text-slate-400 mt-0.5">{item.description}</p>
                    <p className="text-xs text-slate-500 mt-1">{new Date(item.startDate).toLocaleDateString()} — {new Date(item.endDate).toLocaleDateString()} ({item.duration} days)</p>
                    {item.deliverables.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {item.deliverables.map((d, j) => <Badge key={j}>{d}</Badge>)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : <EmptyState message="No timeline defined" />}
        </Card>
      )}

      {activeTab === 'guestProtection' && (
        <Card header={<div className="flex items-center justify-between"><h4 className="font-semibold text-slate-200">{t('proposals.guestProtection')}</h4><Button size="sm" variant="secondary" icon={<Sparkles className="w-3.5 h-3.5" />} onClick={() => handleAction(endpoints.proposals.generateGuestProtection(id!), 'Generated')}>{t('proposals.generateGuestProtection')}</Button></div>}>
          {proposal.guestProtection ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div><h5 className="text-sm font-semibold text-slate-200 mb-2">Noise Assessment</h5><p className="text-sm text-slate-300">{proposal.guestProtection.noiseAssessment}</p></div>
              <div><h5 className="text-sm font-semibold text-slate-200 mb-2">Dust Assessment</h5><p className="text-sm text-slate-300">{proposal.guestProtection.dustAssessment}</p></div>
              <div><h5 className="text-sm font-semibold text-slate-200 mb-2">Odor Assessment</h5><p className="text-sm text-slate-300">{proposal.guestProtection.odorAssessment}</p></div>
              <div><h5 className="text-sm font-semibold text-slate-200 mb-2">Overall Risk Level</h5><StatusBadge status={proposal.guestProtection.overallRiskLevel} /></div>
            </div>
          ) : <EmptyState message="Guest protection plan not generated" actionLabel={t('proposals.generateGuestProtection')} onAction={() => handleAction(endpoints.proposals.generateGuestProtection(id!), 'Generated')} />}
        </Card>
      )}

      {activeTab === 'commercial' && (
        <Card header={<h4 className="font-semibold text-slate-200">{t('proposals.commercialTerms')}</h4>}>
          <div className="space-y-4">
            <div><p className="text-sm font-medium text-slate-300">Commercial Terms</p><p className="text-sm text-slate-200 mt-1">{proposal.commercialTerms || 'Not specified'}</p></div>
            <div><p className="text-sm font-medium text-slate-300">{t('proposals.paymentTerms')}</p><p className="text-sm text-slate-200 mt-1">{proposal.paymentTerms || 'Not specified'}</p></div>
            <div><p className="text-sm font-medium text-slate-300">{t('proposals.warrantyTerms')}</p><p className="text-sm text-slate-200 mt-1">{proposal.warrantyTerms || 'Not specified'}</p></div>
          </div>
        </Card>
      )}

      {activeTab === 'pdf' && (
        <Card>
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <FileText className="w-16 h-16 text-slate-500 mb-4" />
            <p className="text-slate-300">PDF preview will be generated here</p>
            <Button variant="secondary" className="mt-4" icon={<FileText className="w-4 h-4" />}>Generate PDF</Button>
          </div>
        </Card>
      )}
    </div>
  );
};

export default ProposalDetail;