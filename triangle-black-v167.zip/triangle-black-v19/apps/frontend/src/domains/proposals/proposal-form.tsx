import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save, Sparkles } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button, Tabs } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const schema = z.object({
  opportunityId: z.string().min(1, 'Opportunity required'),
  hotelId: z.string().min(1, 'Hotel required'),
  title: z.string().min(2, 'Title required'),
  executiveSummary: z.string().optional(),
  scopeOfWork: z.string().optional(),
  commercialTerms: z.string().optional(),
  paymentTerms: z.string().optional(),
  warrantyTerms: z.string().optional(),
  totalValue: z.coerce.number().min(0),
  currency: z.string().min(1),
  discount: z.coerce.number().optional(),
  taxRate: z.coerce.number().optional(),
  validUntil: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const ProposalForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [section, setSection] = useState('basic');

  const { register, handleSubmit, formState: { errors }, watch, setValue } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      opportunityId: searchParams.get('opportunityId') || '',
      currency: 'USD',
      taxRate: 5,
    },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await apiPost(endpoints.proposals.create, data);
      toast.success(t('common.success'));
      navigate('/proposals');
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  const sections = [
    { key: 'basic', label: 'Basic Info' },
    { key: 'content', label: 'Content' },
    { key: 'commercial', label: 'Commercial' },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={t('proposals.create')} showBack backTo="/proposals" breadcrumbs={[{label:t('proposals.title'),href:'/proposals'},{label:t('common.create')}]}/>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Tabs tabs={sections} activeTab={section} onChange={setSection} className="mb-6" />

        {section === 'basic' && (
          <Card>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input label="Opportunity ID" error={errors.opportunityId?.message} {...register('opportunityId')} />
              <Input label="Hotel ID" error={errors.hotelId?.message} {...register('hotelId')} />
              <Input label={t('common.name')} error={errors.title?.message} {...register('title')} className="md:col-span-2" />
              <Input label={t('proposals.totalValue')} type="number" error={errors.totalValue?.message} {...register('totalValue')} />
              <Select label={t('common.currency')} options={[{value:'USD',label:'USD'},{value:'AED',label:'AED'},{value:'SAR',label:'SAR'}]} {...register('currency')} />
              <Input label={t('proposals.discount')} type="number" {...register('discount')} />
              <Input label={t('proposals.taxRate')} type="number" {...register('taxRate')} />
              <Input label={t('proposals.validUntil')} type="date" {...register('validUntil')} />
            </div>
          </Card>
        )}

        {section === 'content' && (
          <Card>
            <div className="space-y-6">
              <Textarea label={t('proposals.executiveSummary')} {...register('executiveSummary')} rows={5} />
              <Textarea label={t('proposals.scopeOfWork')} {...register('scopeOfWork')} rows={8} />
            </div>
          </Card>
        )}

        {section === 'commercial' && (
          <Card>
            <div className="space-y-6">
              <Textarea label={t('proposals.commercialTerms')} {...register('commercialTerms')} rows={4} />
              <Textarea label={t('proposals.paymentTerms')} {...register('paymentTerms')} rows={3} />
              <Textarea label={t('proposals.warrantyTerms')} {...register('warrantyTerms')} rows={3} />
            </div>
          </Card>
        )}

        <div className="flex justify-end gap-3 mt-6">
          <Button variant="ghost" onClick={() => navigate('/proposals')}>{t('common.cancel')}</Button>
          <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
        </div>
      </form>
    </div>
  );
};

export default ProposalForm;