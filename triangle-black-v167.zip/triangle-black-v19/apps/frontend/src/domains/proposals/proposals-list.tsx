import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, FileText, DollarSign } from 'lucide-react';
import { PageHeader, SearchBar, Button, Select, Card, Table, StatusBadge, Badge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { Proposal, Column } from '@/shared/types';

const ProposalsList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: proposals, isLoading, meta } = useApi<Proposal>(
    ['proposals'], endpoints.proposals.list,
    { ...paginationParams(), search, status: statusFilter }
  );

  const columns: Column<Proposal>[] = useMemo(() => [
    { key: 'proposalNumber', header: t('proposals.number'), width: 'w-36', sortable: true },
    { key: 'title', header: t('common.name'), sortable: true, render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.title}</p>
        <p className="text-xs text-slate-500">{row.hotel?.name}</p>
      </div>
    )},
    { key: 'version', header: t('proposals.version'), align: 'center', render: (v) => <Badge>v{v}</Badge> },
    { key: 'status', header: t('common.status'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'totalValue', header: t('proposals.totalValue'), align: 'end', sortable: true, render: (v) => (
      <span className="text-[#c9a962] font-semibold">${(v as number).toLocaleString()}</span>
    )},
    { key: 'preparedBy', header: 'Prepared By', render: (_, row) => row.preparedBy?.name || '—' },
    { key: 'validUntil', header: t('proposals.validUntil'), width: 'w-28', render: (v) => v ? new Date(v as string).toLocaleDateString() : '—' },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('proposals.title')} actions={
        <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/proposals/new')}>{t('proposals.create')}</Button>
      )} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[{value:'',label:t('common.all')},{value:'DRAFT',label:'Draft'},{value:'SUBMITTED',label:'Submitted'},{value:'APPROVED',label:'Approved'},{value:'REJECTED',label:'Rejected'}]} value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={proposals} keyExtractor={(p)=>p.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} onRowClick={(p)=>navigate(`/proposals/${p.id}`)} />
      </Card>
    </div>
  );
};

export default ProposalsList;