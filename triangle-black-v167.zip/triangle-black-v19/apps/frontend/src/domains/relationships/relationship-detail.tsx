import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useParams, useNavigate } from 'react-router-dom';
import { Building2, TrendingUp, Clock, Trophy, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { Card, PageHeader, Badge, StatCard, Table } from '@/shared/components/ui';
import type { Column } from '@/shared/types';

const RelationshipDetail: React.FC = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();

  const hotel = {
    id: id || '1',
    name: 'Burj Al Arab',
    score: 92,
    totalRevenue: 12500000,
    activeProjects: 3,
    winRate: 78,
    lastEngagement: '2025-01-15',
    avgResponseTime: 45,
  };

  const scoreHistory = [
    { month: 'Jul', score: 78 },
    { month: 'Aug', score: 80 },
    { month: 'Sep', score: 82 },
    { month: 'Oct', score: 85 },
    { month: 'Nov', score: 88 },
    { month: 'Dec', score: 90 },
    { month: 'Jan', score: 92 },
  ];

  const revenueTrend = [
    { year: '2022', revenue: 3200000 },
    { year: '2023', revenue: 5800000 },
    { year: '2024', revenue: 9800000 },
    { year: '2025', revenue: 12500000 },
  ];

  const projects = [
    { id: '1', name: 'HVAC Replacement — Floors 3-8', status: 'IN_PROGRESS', value: 2800000, margin: 28 },
    { id: '2', name: 'Emergency Power Upgrade', status: 'IN_PROGRESS', value: 850000, margin: 32 },
    { id: '3', name: 'BMS Integration Phase 2', status: 'PLANNED', value: 1200000, margin: 35 },
  ];

  const opportunities = [
    { id: '1', name: 'Chiller Plant Replacement', result: 'WON', value: 4500000, date: '2024-11-20' },
    { id: '2', name: 'LED Lighting Retrofit', result: 'WON', value: 380000, date: '2024-10-15' },
    { id: '3', name: 'Pool Heating System', result: 'LOST', value: 620000, date: '2024-09-10' },
    { id: '4', name: 'Kitchen Ventilation Upgrade', result: 'WON', value: 920000, date: '2024-08-22' },
  ];

  const emergencies = [
    { id: '1', case: 'EMR-2025-0042', desc: 'Chiller tripping on high pressure', response: 32, resolved: true },
    { id: '2', case: 'EMR-2024-0398', desc: 'AHU motor bearing failure', response: 28, resolved: true },
    { id: '3', case: 'EMR-2024-0356', desc: 'Electrical panel overheating', response: 55, resolved: true },
  ];

  const engagementTimeline = [
    { date: '2025-01-15', type: 'Meeting', desc: 'Quarterly business review with GM' },
    { date: '2025-01-10', type: 'Proposal', desc: 'Submitted proposal for BMS Phase 2' },
    { date: '2025-01-05', type: 'Site Visit', desc: 'Inspected chiller plant condition' },
    { date: '2024-12-20', type: 'Emergency', desc: 'Resolved emergency EMR-2025-0042' },
    { date: '2024-12-15', type: 'Project', desc: 'HVAC project milestone 3 completed' },
  ];

  const projectColumns: Column<typeof projects[0]>[] = [
    { key: 'name', header: 'Project', render: (v) => <span className="text-slate-100 font-medium">{String(v)}</span> },
    { key: 'status', header: t('common.status'), width: 'w-28', render: (v) => <Badge variant={String(v) === 'IN_PROGRESS' ? 'warning' : 'default'}>{String(v)}</Badge> },
    { key: 'value', header: 'Value', width: 'w-32', render: (v) => `AED ${(v as number).toLocaleString()}` },
    { key: 'margin', header: t('common.margin'), width: 'w-24', render: (v) => <span className={v >= 30 ? 'text-green-400' : 'text-yellow-400'}>{v}%</span> },
  ];

  const maxScore = 100;

  return (
    <div className="space-y-6">
      <PageHeader title={hotel.name} showBack backTo="/relationships" />

      {/* Summary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard icon={<TrendingUp className="w-5 h-5" />} label={t('relationships.score')} value={hotel.score} suffix="/100" />
        <StatCard icon={<Trophy className="w-5 h-5" />} label={t('relationships.winRate')} value={hotel.winRate} suffix="%" />
        <StatCard icon={<TrendingUp className="w-5 h-5" />} label={t('relationships.totalRevenue')} value={`AED ${(hotel.totalRevenue / 1000000).toFixed(1)}M`} />
        <StatCard icon={<Building2 className="w-5 h-5" />} label={t('hotels.activeProjects')} value={hotel.activeProjects} />
        <StatCard icon={<Clock className="w-5 h-5" />} label="Avg Response Time" value={hotel.avgResponseTime} suffix=" min" />
        <StatCard icon={<Clock className="w-5 h-5" />} label={t('relationships.lastEngagement')} value={hotel.lastEngagement} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Score History */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">Score History</h3>}>
          <div className="flex items-end gap-2 h-40">
            {scoreHistory.map((s) => (
              <div key={s.month} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full bg-[#c9a962] rounded-t-sm transition-all" style={{ height: `${(s.score / maxScore) * 140}px` }}>
                  <div className="text-[10px] text-[#0f0f1a] font-bold text-center pt-1">{s.score}</div>
                </div>
                <span className="text-[10px] text-slate-500">{s.month}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Revenue Trend */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">Revenue Trend</h3>}>
          <div className="flex items-end gap-2 h-40">
            {revenueTrend.map((r) => (
              <div key={r.year} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full bg-green-500/70 rounded-t-sm transition-all" style={{ height: `${(r.revenue / 14000000) * 140}px` }}>
                  <div className="text-[10px] text-white font-bold text-center pt-1">{(r.revenue / 1000000).toFixed(1)}M</div>
                </div>
                <span className="text-[10px] text-slate-500">{r.year}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Active Projects */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">Active Projects</h3>}>
        <Table columns={projectColumns} data={projects} keyExtractor={(p) => p.id} />
      </Card>

      {/* Opportunities Win/Loss */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">Opportunities</h3>}>
        <div className="space-y-3">
          {opportunities.map((opp) => (
            <div key={opp.id} className="flex items-center justify-between p-3 bg-[#0f0f1a] rounded-lg border border-[#2d2d4a]">
              <div className="flex items-center gap-3">
                {opp.result === 'WON' ? (
                  <CheckCircle className="w-5 h-5 text-green-400 shrink-0" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-400 shrink-0" />
                )}
                <div>
                  <p className="text-sm text-slate-200">{opp.name}</p>
                  <p className="text-xs text-slate-500">{opp.date}</p>
                </div>
              </div>
              <div className="text-end">
                <p className="text-sm font-medium text-slate-200">AED {opp.value.toLocaleString()}</p>
                <Badge variant={opp.result === 'WON' ? 'success' : 'danger'}>{opp.result}</Badge>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Emergency Response Times */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100 flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-red-400" /> Emergency Response Times</h3>}>
        <div className="space-y-2">
          {emergencies.map((em) => (
            <div key={em.id} className="flex items-center justify-between p-3 bg-[#0f0f1a] rounded-lg border border-[#2d2d4a]">
              <div>
                <p className="text-sm text-slate-200">{em.desc}</p>
                <p className="text-xs text-slate-500">{em.case}</p>
              </div>
              <div className="text-end">
                <p className={`text-sm font-medium ${em.response <= 30 ? 'text-green-400' : em.response <= 60 ? 'text-yellow-400' : 'text-red-400'}`}>
                  {em.response} min
                </p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Engagement Timeline */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('relationships.engagementTimeline')}</h3>}>
        <div className="relative pl-6 space-y-4">
          <div className="absolute start-2 top-2 bottom-2 w-px bg-[#2d2d4a]" />
          {engagementTimeline.map((item, i) => (
            <div key={i} className="relative flex gap-4">
              <div className="absolute -start-[17px] top-1.5 w-3 h-3 rounded-full bg-[#c9a962] border-2 border-[#0f0f1a]" />
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <Badge>{item.type}</Badge>
                  <span className="text-xs text-slate-500">{item.date}</span>
                </div>
                <p className="text-sm text-slate-300">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default RelationshipDetail;