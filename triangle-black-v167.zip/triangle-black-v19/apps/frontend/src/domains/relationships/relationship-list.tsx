import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { AlertTriangle, Clock, TrendingUp, ArrowUpDown } from 'lucide-react';
import { PageHeader, SearchBar, Card, Select, Badge, Button } from '@/shared/components/ui';

interface HotelRelationship {
  id: string;
  name: string;
  score: number;
  totalRevenue: number;
  activeProjects: number;
  winRate: number;
  lastEngagement: string;
  isAtRisk: boolean;
  hasFollowUps: boolean;
}

const mockHotels: HotelRelationship[] = [
  { id: '1', name: 'Burj Al Arab', score: 92, totalRevenue: 12500000, activeProjects: 3, winRate: 78, lastEngagement: '2025-01-15', isAtRisk: false, hasFollowUps: false },
  { id: '2', name: 'Atlantis The Royal', score: 85, totalRevenue: 10200000, activeProjects: 2, winRate: 71, lastEngagement: '2025-01-12', isAtRisk: false, hasFollowUps: true },
  { id: '3', name: 'Mandarin Oriental', score: 72, totalRevenue: 8100000, activeProjects: 1, winRate: 65, lastEngagement: '2024-11-20', isAtRisk: true, hasFollowUps: true },
  { id: '4', name: 'Four Seasons DIFC', score: 68, totalRevenue: 6200000, activeProjects: 2, winRate: 60, lastEngagement: '2025-01-10', isAtRisk: false, hasFollowUps: false },
  { id: '5', name: 'Ritz Carlton', score: 55, totalRevenue: 5200000, activeProjects: 0, winRate: 48, lastEngagement: '2024-09-15', isAtRisk: true, hasFollowUps: false },
  { id: '6', name: 'JW Marriott Marquis', score: 45, totalRevenue: 3400000, activeProjects: 1, winRate: 42, lastEngagement: '2024-10-05', isAtRisk: true, hasFollowUps: true },
];

const getScoreColor = (score: number) => {
  if (score >= 80) return 'text-green-400';
  if (score >= 60) return 'text-yellow-400';
  if (score >= 40) return 'text-orange-400';
  return 'text-red-400';
};

const getScoreRingColor = (score: number) => {
  if (score >= 80) return '#22c55e';
  if (score >= 60) return '#eab308';
  if (score >= 40) return '#f97316';
  return '#ef4444';
};

const ScoreRing: React.FC<{ score: number; size?: number }> = ({ score, size = 64 }) => {
  const radius = (size - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color = getScoreRingColor(score);

  return (
    <svg width={size} height={size} className="transform -rotate-90">
      <circle cx={size / 2} cy={size / 2} r={radius} stroke="#2d2d4a" strokeWidth="4" fill="none" />
      <circle
        cx={size / 2} cy={size / 2} r={radius}
        stroke={color} strokeWidth="4" fill="none"
        strokeDasharray={circumference} strokeDashoffset={offset}
        strokeLinecap="round"
        className="transition-all duration-500"
      />
      <text
        x={size / 2} y={size / 2}
        textAnchor="middle" dominantBaseline="central"
        className="fill-slate-100 text-sm font-bold"
        transform={`rotate(90, ${size / 2}, ${size / 2})`}
      >
        {score}
      </text>
    </svg>
  );
};

const RelationshipList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<'score' | 'revenue' | 'engagement'>('score');
  const [filter, setFilter] = useState<'' | 'atRisk' | 'followUps'>('');

  const filtered = useMemo(() => {
    let result = [...mockHotels];
    if (search) {
      result = result.filter((h) => h.name.toLowerCase().includes(search.toLowerCase()));
    }
    if (filter === 'atRisk') result = result.filter((h) => h.isAtRisk);
    if (filter === 'followUps') result = result.filter((h) => h.hasFollowUps);
    result.sort((a, b) => {
      if (sortKey === 'score') return b.score - a.score;
      if (sortKey === 'revenue') return b.totalRevenue - a.totalRevenue;
      return new Date(b.lastEngagement).getTime() - new Date(a.lastEngagement).getTime();
    });
    return result;
  }, [search, sortKey, filter]);

  const formatCurrency = (val: number) => val >= 1000000 ? `AED ${(val / 1000000).toFixed(1)}M` : `AED ${(val / 1000).toFixed(0)}K`;

  const daysSince = (dateStr: string) => {
    const days = Math.floor((Date.now() - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24));
    return days;
  };

  return (
    <div className="space-y-6">
      <PageHeader title={t('relationships.title')} />

      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[
            { value: '', label: 'All Hotels' },
            { value: 'atRisk', label: t('relationships.atRisk') },
            { value: 'followUps', label: t('relationships.followUps') },
          ]} value={filter} onChange={(e) => setFilter(e.target.value as typeof filter)} />
          <Select options={[
            { value: 'score', label: 'Sort by Score' },
            { value: 'revenue', label: 'Sort by Revenue' },
            { value: 'engagement', label: 'Sort by Last Engagement' },
          ]} value={sortKey} onChange={(e) => setSortKey(e.target.value as typeof sortKey)} />
        </div>

        <div className="p-4 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((hotel) => (
            <div
              key={hotel.id}
              onClick={() => navigate(`/relationships/${hotel.id}`)}
              className="bg-[#0f0f1a] border border-[#2d2d4a] rounded-lg p-4 hover:border-[#c9a962]/40 transition-colors cursor-pointer"
            >
              <div className="flex items-start gap-4">
                <ScoreRing score={hotel.score} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-sm font-semibold text-slate-100 truncate">{hotel.name}</h3>
                    {hotel.isAtRisk && (
                      <Badge variant="danger"><AlertTriangle className="w-3 h-3 me-1" />At Risk</Badge>
                    )}
                  </div>
                  <div className="space-y-1.5 mt-3">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">{t('relationships.totalRevenue')}</span>
                      <span className="text-slate-200 font-medium">{formatCurrency(hotel.totalRevenue)}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">{t('hotels.activeProjects')}</span>
                      <span className="text-slate-200">{hotel.activeProjects}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">{t('relationships.winRate')}</span>
                      <span className={hotel.winRate >= 60 ? 'text-green-400' : 'text-yellow-400'}>{hotel.winRate}%</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">{t('relationships.lastEngagement')}</span>
                      <span className={daysSince(hotel.lastEngagement) > 90 ? 'text-red-400' : 'text-slate-200'}>
                        {daysSince(hotel.lastEngagement)}d ago
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default RelationshipList;