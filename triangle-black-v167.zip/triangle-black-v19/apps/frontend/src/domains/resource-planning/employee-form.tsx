import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Trash2, Save, Send, Award, Calendar } from 'lucide-react';
import {
  PageHeader,
  Card,
  Button,
  Input,
  Select,
  Badge,
} from '@/shared/components/ui';

interface Certification {
  id: string;
  name: string;
  number: string;
  expiryDate: string;
}

const positions = [
  { value: '', label: 'Select Position' },
  { value: 'Senior Engineer', label: 'Senior Engineer' },
  { value: 'Engineer', label: 'Engineer' },
  { value: 'Junior Engineer', label: 'Junior Engineer' },
  { value: 'Project Manager', label: 'Project Manager' },
  { value: 'Supervisor', label: 'Supervisor' },
  { value: 'Technician', label: 'Technician' },
  { value: 'Senior Technician', label: 'Senior Technician' },
  { value: 'Quality Inspector', label: 'Quality Inspector' },
  { value: 'Electrical Engineer', label: 'Electrical Engineer' },
];

const departments = [
  { value: '', label: 'Select Department' },
  { value: 'HVAC', label: 'HVAC' },
  { value: 'Electrical', label: 'Electrical' },
  { value: 'Plumbing', label: 'Plumbing' },
  { value: 'Fire Protection', label: 'Fire Protection' },
  { value: 'BMS', label: 'BMS' },
];

const allSkills = [
  'HVAC', 'ELECTRICAL', 'PLUMBING', 'FIRE_ALARM', 'BMS', 'WATERPROOFING',
];

const availabilityOptions = [
  { value: 'AVAILABLE', label: 'Available' },
  { value: 'ON_PROJECT', label: 'On Project' },
  { value: 'ON_LEAVE', label: 'On Leave' },
  { value: 'NOT_AVAILABLE', label: 'Not Available' },
];

const getAvailabilityVariant = (status: string): 'success' | 'warning' | 'danger' | 'default' => {
  switch (status) {
    case 'AVAILABLE': return 'success';
    case 'ON_PROJECT': return 'warning';
    case 'ON_LEAVE': return 'danger';
    case 'NOT_AVAILABLE': return 'default';
    default: return 'default';
  }
};

const createEmptyCert = (): Certification => ({
  id: crypto.randomUUID(),
  name: '',
  number: '',
  expiryDate: '',
});

const EmployeeForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = Boolean(id);

  const [employeeNumber, setEmployeeNumber] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [nameAr, setNameAr] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [position, setPosition] = useState('');
  const [department, setDepartment] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [certifications, setCertifications] = useState<Certification[]>([]);
  const [hourlyRate, setHourlyRate] = useState('');
  const [availability, setAvailability] = useState('AVAILABLE');
  const [saving, setSaving] = useState(false);

  const toggleSkill = (skill: string) => {
    setSelectedSkills((prev) =>
      prev.includes(skill)
        ? prev.filter((s) => s !== skill)
        : [...prev, skill]
    );
  };

  const addCertification = () => {
    setCertifications([...certifications, createEmptyCert()]);
  };

  const removeCertification = (certId: string) => {
    setCertifications(certifications.filter((c) => c.id !== certId));
  };

  const updateCertification = (certId: string, field: keyof Certification, value: string) => {
    setCertifications(
      certifications.map((c) => (c.id === certId ? { ...c, [field]: value } : c))
    );
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // await apiPost(...)
      navigate('/resource-planning/employees');
    } finally {
      setSaving(false);
    }
  };

  const isExpired = (date: string) => {
    if (!date) return false;
    return new Date(date) < new Date();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEditing ? t('resourcePlanning.editEmployee', 'Edit Employee') : t('resourcePlanning.addEmployee', 'Add Employee')}
        showBack
        backTo="/resource-planning/employees"
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" icon={<Save className="w-4 h-4" />} onClick={handleSave} loading={saving}>
              {t('common.save', 'Save')}
            </Button>
            <Button icon={<Send className="w-4 h-4" />} onClick={handleSave} loading={saving} disabled={!nameEn || !position}>
              {t('common.saveAndContinue', 'Save & Continue')}
            </Button>
          </div>
        }
      />

      {/* Basic Information */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('resourcePlanning.basicInfo', 'Basic Information')}</h3>}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <Input
              label={t('resourcePlanning.employeeNumber', 'Employee Number')}
              placeholder="EMP-XXX"
              value={employeeNumber}
              onChange={(e) => setEmployeeNumber(e.target.value)}
            />
          </div>
          <div>
            <Input
              label={t('resourcePlanning.nameEn', 'Name (English)')}
              placeholder="Full name in English"
              value={nameEn}
              onChange={(e) => setNameEn(e.target.value)}
            />
          </div>
          <div>
            <Input
              label={t('resourcePlanning.nameAr', 'Name (Arabic)')}
              placeholder="الاسم بالعربية"
              value={nameAr}
              dir="rtl"
              onChange={(e) => setNameAr(e.target.value)}
            />
          </div>
          <div>
            <Input
              label={t('common.email', 'Email')}
              type="email"
              placeholder="employee@triangle.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div>
            <Input
              label={t('common.phone', 'Phone')}
              type="tel"
              placeholder="+971XXXXXXXXX"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div>
            <Input
              type="number"
              label={t('resourcePlanning.hourlyRate', 'Hourly Rate (AED)')}
              placeholder="0.00"
              value={hourlyRate}
              onChange={(e) => setHourlyRate(e.target.value)}
            />
          </div>
          <div>
            <Select
              label={t('common.position', 'Position')}
              options={positions}
              value={position}
              onChange={(e) => setPosition(e.target.value)}
            />
          </div>
          <div>
            <Select
              label={t('common.department', 'Department')}
              options={departments}
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
            />
          </div>
          <div>
            <Select
              label={t('common.availability', 'Availability')}
              options={availabilityOptions}
              value={availability}
              onChange={(e) => setAvailability(e.target.value)}
            />
          </div>
        </div>
      </Card>

      {/* Skills Multi-Select */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('common.skills', 'Skills')}</h3>}>
        <div className="flex flex-wrap gap-2">
          {allSkills.map((skill) => {
            const isSelected = selectedSkills.includes(skill);
            const colors: Record<string, string> = {
              HVAC: 'bg-blue-900/40 text-blue-400 border-blue-800/50',
              ELECTRICAL: 'bg-amber-900/40 text-amber-400 border-amber-800/50',
              PLUMBING: 'bg-cyan-900/40 text-cyan-400 border-cyan-800/50',
              FIRE_ALARM: 'bg-red-900/40 text-red-400 border-red-800/50',
              BMS: 'bg-green-900/40 text-green-400 border-green-800/50',
              WATERPROOFING: 'bg-purple-900/40 text-purple-400 border-purple-800/50',
            };
            return (
              <button
                key={skill}
                type="button"
                onClick={() => toggleSkill(skill)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                  isSelected
                    ? `${colors[skill] || 'bg-[#c9a962]/20 text-[#c9a962] border-[#c9a962]/30'} ring-2 ring-[#c9a962]/30`
                    : 'bg-[#15152a] text-slate-400 border-[#2d2d4a] hover:border-[#c9a962]/30'
                }`}
              >
                {isSelected && <Award className="w-3 h-3" />}
                {skill}
              </button>
            );
          })}
        </div>
        {selectedSkills.length > 0 && (
          <p className="text-xs text-slate-500 mt-3">
            {selectedSkills.length} {t('resourcePlanning.skillsSelected', 'skills selected')}
          </p>
        )}
      </Card>

      {/* Certifications */}
      <Card
        header={
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-100">{t('resourcePlanning.certifications', 'Certifications')}</h3>
            <Button size="sm" icon={<Plus className="w-4 h-4" />} onClick={addCertification}>
              {t('resourcePlanning.addCertification', 'Add Certification')}
            </Button>
          </div>
        }
      >
        {certifications.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm">
            <Award className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p>{t('resourcePlanning.noCertifications', 'No certifications added yet')}</p>
          </div>
        ) : (
          <div className="space-y-3">
            {certifications.map((cert, index) => (
              <div
                key={cert.id}
                className={`p-4 bg-[#15152a] border rounded-lg ${
                  isExpired(cert.expiryDate) ? 'border-red-800/50' : 'border-[#2d2d4a]'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-slate-200">
                    {t('resourcePlanning.certification', 'Certification')} #{index + 1}
                  </span>
                  <div className="flex items-center gap-2">
                    {isExpired(cert.expiryDate) && (
                      <Badge variant="danger">{t('resourcePlanning.expired', 'Expired')}</Badge>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      icon={<Trash2 className="w-3.5 h-3.5 text-red-400" />}
                      onClick={() => removeCertification(cert.id)}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <Input
                    label={t('resourcePlanning.certName', 'Certification Name')}
                    placeholder="e.g., HVAC Technician License"
                    value={cert.name}
                    onChange={(e) => updateCertification(cert.id, 'name', e.target.value)}
                  />
                  <Input
                    label={t('resourcePlanning.certNumber', 'Certificate Number')}
                    placeholder="e.g., CERT-12345"
                    value={cert.number}
                    onChange={(e) => updateCertification(cert.id, 'number', e.target.value)}
                  />
                  <Input
                    type="date"
                    label={t('resourcePlanning.expiryDate', 'Expiry Date')}
                    value={cert.expiryDate}
                    onChange={(e) => updateCertification(cert.id, 'expiryDate', e.target.value)}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
};

export default EmployeeForm;
