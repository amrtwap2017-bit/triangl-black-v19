import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Search, Filter, UserCircle } from 'lucide-react';
import {
  PageHeader,
  SearchBar,
  Button,
  Select,
  Card,
  Table,
  Badge,
} from '@/shared/components/ui';
import { usePagination } from '@/shared/hooks';
import type { Column } from '@/shared/types';

interface Employee {
  id: string;
  employeeNumber: string;
  name: string;
  nameAr: string;
  position: string;
  department: string;
  skills: string[];
  availability: 'AVAILABLE' | 'ON_PROJECT' | 'ON_LEAVE' | 'NOT_AVAILABLE';
  currentProject: string;
  email: string;
  phone: string;
  hourlyRate: number;
}

const mockEmployees: Employee[] = [
  { id: 'e1', employeeNumber: 'EMP-001', name: 'Ahmed Al Rashid', nameAr: 'أحمد الراشد', position: 'Senior Engineer', department: 'HVAC', skills: ['HVAC', 'BMS'], availability: 'ON_PROJECT', currentProject: 'Burj Al Arab HVAC', email: 'ahmed@triangle.com', phone: '+971501234567', hourlyRate: 180 },
  { id: 'e2', employeeNumber: 'EMP-002', name: 'Mohammed Hassan', nameAr: 'محمد حسن', position: 'Project Manager', department: 'Electrical', skills: ['ELECTRICAL', 'BMS', 'FIRE_ALARM'], availability: 'ON_PROJECT', currentProject: 'Atlantis The Royal', email: 'mohammed@triangle.com', phone: '+971502345678', hourlyRate: 220 },
  { id: 'e3', employeeNumber: 'EMP-003', name: 'Fatima Al Zahra', nameAr: 'فاطمة الزهراء', position: 'Technician', department: 'HVAC', skills: ['HVAC'], availability: 'AVAILABLE', currentProject: '—', email: 'fatima@triangle.com', phone: '+971503456789', hourlyRate: 95 },
  { id: 'e4', employeeNumber: 'EMP-004', name: 'Khalid Omar', nameAr: 'خالد عمر', position: 'Supervisor', department: 'Plumbing', skills: ['PLUMBING', 'WATERPROOFING'], availability: 'ON_PROJECT', currentProject: 'Ritz Carlton', email: 'khalid@triangle.com', phone: '+971504567890', hourlyRate: 150 },
  { id: 'e5', employeeNumber: 'EMP-005', name: 'Sarah Johnson', nameAr: 'سارة جونسون', position: 'Electrical Engineer', department: 'Electrical', skills: ['ELECTRICAL', 'FIRE_ALARM'], availability: 'AVAILABLE', currentProject: '—', email: 'sarah@triangle.com', phone: '+971505678901', hourlyRate: 160 },
  { id: 'e6', employeeNumber: 'EMP-006', name: 'Rami Nasser', nameAr: 'رامي ناصر', position: 'Technician', department: 'Fire Protection', skills: ['FIRE_ALARM'], availability: 'ON_LEAVE', currentProject: '—', email: 'rami@triangle.com', phone: '+971506789012', hourlyRate: 90 },
  { id: 'e7', employeeNumber: 'EMP-007', name: 'Omar Saeed', nameAr: 'عمر سعيد', position: 'Junior Engineer', department: 'BMS', skills: ['BMS', 'HVAC'], availability: 'ON_PROJECT', currentProject: 'Mandarin Oriental', email: 'omar@triangle.com', phone: '+971507890123', hourlyRate: 120 },
  { id: 'e8', employeeNumber: 'EMP-008', name: 'Layla Mahmoud', nameAr: 'ليلى محمود', position: 'Quality Inspector', department: 'HVAC', skills: ['HVAC', 'PLUMBING', 'WATERPROOFING'], availability: 'AVAILABLE', currentProject: '—', email: 'layla@triangle.com', phone: '+971508901234', hourlyRate: 130 },
  { id: 'e9', employeeNumber: 'EMP-009', name: 'Youssef Ali', nameAr: 'يوسف علي', position: 'Senior Technician', department: 'Plumbing', skills: ['PLUMBING'], availability: 'NOT_AVAILABLE', currentProject: '—', email: 'youssef@triangle.com', phone: '+971509012345', hourlyRate: 110 },
  { id: 'e10', employeeNumber: 'EMP-010', name: 'Nora Khalid', nameAr: 'نورة خالد', position: 'Engineer', department: 'Fire Protection', skills: ['FIRE_ALARM', 'BMS'], availability: 'ON_PROJECT', currentProject: 'Four Seasons DIFC', email: 'nora@triangle.com', phone: '+971501234568', hourlyRate: 155 },
];

const getAvailabilityVariant = (status: string): 'success' | 'warning' | 'danger' | 'default' => {
  switch (status) {
    case 'AVAILABLE': return 'success';
    case 'ON_PROJECT': return 'warning';
    case 'ON_LEAVE': return 'danger';
    case 'NOT_AVAILABLE': return 'default';
    default: return 'default';
  }
};

const getAvailabilityLabel = (status: string) => {
  switch (status) {
    case 'AVAILABLE': return 'Available';
    case 'ON_PROJECT': return 'On Project';
    case 'ON_LEAVE': return 'On Leave';
    case 'NOT_AVAILABLE': return 'Unavailable';
    default: return status;
  }
};

const skillColors: Record<string, string> = {
  HVAC: 'bg-blue-900/40 text-blue-400 border-blue-800/50',
  ELECTRICAL: 'bg-amber-900/40 text-amber-400 border-amber-800/50',
  PLUMBING: 'bg-cyan-900/40 text-cyan-400 border-cyan-800/50',
  FIRE_ALARM: 'bg-red-900/40 text-red-400 border-red-800/50',
  BMS: 'bg-green-900/40 text-green-400 border-green-800/50',
  WATERPROOFING: 'bg-purple-900/40 text-purple-400 border-purple-800/50',
};

const EmployeeList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [positionFilter, setPositionFilter] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [availabilityFilter, setAvailabilityFilter] = useState('');
  const [skillsFilter, setSkillsFilter] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const filteredData = useMemo(() => {
    return mockEmployees.filter((emp) => {
      const matchesSearch =
        !search ||
        emp.name.toLowerCase().includes(search.toLowerCase()) ||
        emp.employeeNumber.toLowerCase().includes(search.toLowerCase()) ||
        emp.nameAr.includes(search);
      const matchesPosition = !positionFilter || emp.position === positionFilter;
      const matchesDepartment = !departmentFilter || emp.department === departmentFilter;
      const matchesAvailability = !availabilityFilter || emp.availability === availabilityFilter;
      const matchesSkills = !skillsFilter || emp.skills.includes(skillsFilter);
      return matchesSearch && matchesPosition && matchesDepartment && matchesAvailability && matchesSkills;
    });
  }, [search, positionFilter, departmentFilter, availabilityFilter, skillsFilter]);

  const positions = useMemo(() => {
    const set = new Set(mockEmployees.map((e) => e.position));
    return [{ value: '', label: t('common.allPositions', 'All Positions') }, ...Array.from(set).map((p) => ({ value: p, label: p }))];
  }, []);

  const departments = useMemo(() => {
    const set = new Set(mockEmployees.map((e) => e.department));
    return [{ value: '', label: t('common.allDepartments', 'All Departments') }, ...Array.from(set).map((d) => ({ value: d, label: d }))];
  }, []);

  const skills = useMemo(() => {
    const set = new Set(mockEmployees.flatMap((e) => e.skills));
    return [{ value: '', label: t('common.allSkills', 'All Skills') }, ...Array.from(set).map((s) => ({ value: s, label: s }))];
  }, []);

  const columns: Column<Employee>[] = useMemo(
    () => [
      {
        key: 'employeeNumber',
        header: t('common.number', 'Number'),
        width: 'w-28',
        sortable: true,
        render: (v) => <span className="font-mono text-[#c9a962] text-xs">{v as string}</span>,
      },
      {
        key: 'name',
        header: t('common.name', 'Name'),
        sortable: true,
        render: (_, row) => (
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#252540] flex items-center justify-center shrink-0">
              <UserCircle className="w-5 h-5 text-slate-400" />
            </div>
            <div>
              <p className="font-medium text-slate-100">{row.name}</p>
              <p className="text-xs text-slate-500">{row.nameAr}</p>
            </div>
          </div>
        ),
      },
      {
        key: 'position',
        header: t('common.position', 'Position'),
        width: 'w-36',
      },
      {
        key: 'skills',
        header: t('common.skills', 'Skills'),
        width: 'w-48',
        render: (_, row) => (
          <div className="flex flex-wrap gap-1">
            {row.skills.slice(0, 2).map((skill) => (
              <span
                key={skill}
                className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium border ${
                  skillColors[skill] || 'bg-[#2d2d4a] text-slate-300 border-[#2d2d4a]'
                }`}
              >
                {skill}
              </span>
            ))}
            {row.skills.length > 2 && (
              <Badge>+{row.skills.length - 2}</Badge>
            )}
          </div>
        ),
      },
      {
        key: 'availability',
        header: t('common.availability', 'Availability'),
        width: 'w-28',
        render: (v) => (
          <Badge variant={getAvailabilityVariant(v as string)}>
            {getAvailabilityLabel(v as string)}
          </Badge>
        ),
      },
      {
        key: 'currentProject',
        header: t('common.currentProject', 'Current Project'),
        width: 'w-40',
        render: (v) => (
          <span className={v === '—' ? 'text-slate-500' : 'text-slate-200'}>
            {v as string}
          </span>
        ),
      },
    ],
    [t]
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('resourcePlanning.employees', 'Employees')}
        subtitle={t('resourcePlanning.employeesSubtitle', 'Manage your workforce')}
        actions={
          <Button
            icon={<Plus className="w-4 h-4" />}
            onClick={() => navigate('/resource-planning/employees/new')}
          >
            {t('resourcePlanning.addEmployee', 'Add Employee')}
          </Button>
        }
      />

      <Card noPadding>
        <div className="p-4 border-b border-[#2d2d4a]">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex-1 w-full sm:w-auto">
              <SearchBar
                onSearch={setSearch}
                placeholder={t('resourcePlanning.searchEmployees', 'Search by name or number...')}
              />
            </div>
            <Button
              variant="ghost"
              size="sm"
              icon={<Filter className="w-4 h-4" />}
              onClick={() => setShowFilters(!showFilters)}
            >
              {t('common.filters', 'Filters')}
            </Button>
          </div>

          {showFilters && (
            <div className="flex flex-wrap gap-3 mt-3 pt-3 border-t border-[#2d2d4a]">
              <div className="w-44">
                <Select
                  options={departments}
                  value={departmentFilter}
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                />
              </div>
              <div className="w-44">
                <Select
                  options={positions}
                  value={positionFilter}
                  onChange={(e) => setPositionFilter(e.target.value)}
                />
              </div>
              <div className="w-40">
                <Select
                  options={[
                    { value: '', label: t('common.allAvailability', 'All') },
                    { value: 'AVAILABLE', label: 'Available' },
                    { value: 'ON_PROJECT', label: 'On Project' },
                    { value: 'ON_LEAVE', label: 'On Leave' },
                    { value: 'NOT_AVAILABLE', label: 'Unavailable' },
                  ]}
                  value={availabilityFilter}
                  onChange={(e) => setAvailabilityFilter(e.target.value)}
                />
              </div>
              <div className="w-40">
                <Select
                  options={skills}
                  value={skillsFilter}
                  onChange={(e) => setSkillsFilter(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        <Table
          columns={columns}
          data={filteredData}
          keyExtractor={(r) => r.id}
          onRowClick={(row) => navigate(`/resource-planning/employees/${row.id}`)}
        />
      </Card>
    </div>
  );
};

export default EmployeeList;
