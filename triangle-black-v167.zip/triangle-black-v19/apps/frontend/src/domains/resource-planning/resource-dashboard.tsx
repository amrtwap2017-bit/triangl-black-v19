import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Users,
  UserCheck,
  UserX,
  Briefcase,
  Plus,
  UserPlus,
  Wrench,
  Zap,
  Droplets,
  Flame,
  Shield,
  Cpu,
} from 'lucide-react';
import { Card, PageHeader, StatCard, Button, Select, Badge, Tabs } from '@/shared/components/ui';

interface DepartmentStat {
  department: string;
  total: number;
  available: number;
  onProject: number;
  onLeave: number;
  utilization: number;
}

interface SkillDistribution {
  skill: string;
  icon: React.ReactNode;
  count: number;
  color: string;
}

const departmentData: DepartmentStat[] = [
  { department: 'HVAC', total: 28, available: 8, onProject: 18, onLeave: 2, utilization: 85 },
  { department: 'Electrical', total: 22, available: 6, onProject: 14, onLeave: 2, utilization: 82 },
  { department: 'Plumbing', total: 15, available: 5, onProject: 9, onLeave: 1, utilization: 80 },
  { department: 'Fire Protection', total: 12, available: 4, onProject: 7, onLeave: 1, utilization: 78 },
  { department: 'BMS', total: 8, available: 2, onProject: 6, onLeave: 0, utilization: 88 },
];

const skillsData: SkillDistribution[] = [
  { skill: 'HVAC', icon: <Wrench className="w-4 h-4" />, count: 28, color: 'bg-blue-500' },
  { skill: 'Electrical', icon: <Zap className="w-4 h-4" />, count: 22, color: 'bg-amber-500' },
  { skill: 'Plumbing', icon: <Droplets className="w-4 h-4" />, count: 15, color: 'bg-cyan-500' },
  { skill: 'Fire Alarm', icon: <Flame className="w-4 h-4" />, count: 12, color: 'bg-red-500' },
  { skill: 'BMS', icon: <Cpu className="w-4 h-4" />, count: 8, color: 'bg-green-500' },
  { skill: 'Waterproofing', icon: <Shield className="w-4 h-4" />, count: 6, color: 'bg-purple-500' },
];

const ResourceDashboard: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [positionFilter, setPositionFilter] = useState('');
  const [availabilityFilter, setAvailabilityFilter] = useState('');

  const totalEmployees = departmentData.reduce((s, d) => s + d.total, 0);
  const totalAvailable = departmentData.reduce((s, d) => s + d.available, 0);
  const totalOnProject = departmentData.reduce((s, d) => s + d.onProject, 0);
  const totalOnLeave = departmentData.reduce((s, d) => s + d.onLeave, 0);
  const avgUtilization = Math.round(
    departmentData.reduce((s, d) => s + d.utilization, 0) / departmentData.length
  );
  const maxDeptTotal = Math.max(...departmentData.map((d) => d.total));

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('resourcePlanning.title', 'Resource Planning')}
        subtitle={t('resourcePlanning.subtitle', 'Workforce management and utilization')}
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              icon={<UserPlus className="w-4 h-4" />}
              onClick={() => navigate('/resource-planning/employees/new')}
            >
              {t('resourcePlanning.addEmployee', 'Add Employee')}
            </Button>
            <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/resource-planning/teams/new')}>
              {t('resourcePlanning.createTeam', 'Create Team')}
            </Button>
          </div>
        }
      />

      {/* Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={<Users className="w-5 h-5" />}
          label={t('resourcePlanning.totalEmployees', 'Total Employees')}
          value={totalEmployees}
          change={5.2}
        />
        <StatCard
          icon={<UserCheck className="w-5 h-5" />}
          label={t('resourcePlanning.available', 'Available')}
          value={totalAvailable}
          suffix={` (${Math.round((totalAvailable / totalEmployees) * 100)}%)`}
          change={-2.1}
        />
        <StatCard
          icon={<Briefcase className="w-5 h-5" />}
          label={t('resourcePlanning.onProject', 'On Project')}
          value={totalOnProject}
          change={8.3}
        />
        <StatCard
          icon={<UserX className="w-5 h-5" />}
          label={t('resourcePlanning.onLeave', 'On Leave')}
          value={totalOnLeave}
          change={-1.5}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Utilization by Department */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('resourcePlanning.utilizationByDept', 'Utilization by Department')}</h3>}>
          <div className="space-y-4">
            {departmentData.map((dept) => (
              <div key={dept.department} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-slate-200">{dept.department}</span>
                    <span className="text-slate-500">({dept.total})</span>
                  </div>
                  <span className={`font-semibold ${
                    dept.utilization >= 85 ? 'text-red-400' :
                    dept.utilization >= 75 ? 'text-amber-400' :
                    'text-green-400'
                  }`}>
                    {dept.utilization}%
                  </span>
                </div>

                {/* Stacked bar: On Project | On Leave | Available */}
                <div className="flex gap-0.5 h-6">
                  <div
                    className="bg-[#c9a962] rounded-l-sm flex items-center justify-end pe-1 transition-all"
                    style={{ width: `${(dept.onProject / dept.total) * 100}%` }}
                  >
                    {dept.onProject > 3 && <span className="text-[9px] font-medium text-[#0f0f1a]">{dept.onProject}</span>}
                  </div>
                  <div
                    className="bg-red-500/60 flex items-center justify-end pe-1 transition-all"
                    style={{ width: `${(dept.onLeave / dept.total) * 100}%` }}
                  >
                    {dept.onLeave > 0 && <span className="text-[9px] font-medium text-white">{dept.onLeave}</span>}
                  </div>
                  <div
                    className="bg-[#2d2d4a] rounded-r-sm flex items-center justify-end pe-1 transition-all"
                    style={{ width: `${(dept.available / dept.total) * 100}%` }}
                  >
                    {dept.available > 2 && <span className="text-[9px] font-medium text-slate-400">{dept.available}</span>}
                  </div>
                </div>

                <div className="flex justify-end text-xs text-slate-500">
                  Avg. Utilization: {dept.utilization}%
                </div>
              </div>
            ))}

            <div className="flex items-center gap-4 pt-2 text-xs text-slate-500 border-t border-[#2d2d4a]">
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-[#c9a962] rounded-sm" /> {t('resourcePlanning.onProject', 'On Project')}</div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-red-500/60 rounded-sm" /> {t('resourcePlanning.onLeave', 'On Leave')}</div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-[#2d2d4a] rounded-sm" /> {t('resourcePlanning.available', 'Available')}</div>
            </div>
          </div>
        </Card>

        {/* Skills Distribution */}
        <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('resourcePlanning.skillsDistribution', 'Skills Distribution')}</h3>}>
          <div className="space-y-3">
            {skillsData.map((skill) => {
              const percentage = (skill.count / totalEmployees) * 100;
              return (
                <div key={skill.skill} className="space-y-1.5">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className={`p-1 rounded ${skill.color}/20 text-slate-300`}>
                        {skill.icon}
                      </div>
                      <span className="font-medium text-slate-200">{skill.skill}</span>
                    </div>
                    <span className="text-slate-400">{skill.count} {t('resourcePlanning.employees', 'employees')}</span>
                  </div>
                  <div className="w-full h-2.5 bg-[#2d2d4a] rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${skill.color} transition-all`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}

            <div className="pt-3 border-t border-[#2d2d4a]">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">{t('resourcePlanning.avgUtilization', 'Average Utilization')}</span>
                <span className={`text-lg font-bold ${
                  avgUtilization >= 85 ? 'text-red-400' :
                  avgUtilization >= 75 ? 'text-amber-400' :
                  'text-green-400'
                }`}>
                  {avgUtilization}%
                </span>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Department Filter Summary */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('resourcePlanning.departmentSummary', 'Department Summary')}</h3>}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2d2d4a]">
                <th className="px-4 py-3 text-start text-xs font-semibold text-slate-400 uppercase">Department</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400 uppercase">Total</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400 uppercase">Available</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400 uppercase">On Project</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-slate-400 uppercase">On Leave</th>
                <th className="px-4 py-3 text-end text-xs font-semibold text-slate-400 uppercase">Utilization</th>
              </tr>
            </thead>
            <tbody>
              {departmentData.map((dept) => (
                <tr key={dept.department} className="border-b border-[#2d2d4a]/50 hover:bg-[#252540] transition-colors cursor-pointer">
                  <td className="px-4 py-3 text-sm font-medium text-slate-200">{dept.department}</td>
                  <td className="px-4 py-3 text-sm text-slate-200 text-center">{dept.total}</td>
                  <td className="px-4 py-3 text-sm text-green-400 text-center">{dept.available}</td>
                  <td className="px-4 py-3 text-sm text-[#c9a962] text-center">{dept.onProject}</td>
                  <td className="px-4 py-3 text-sm text-red-400 text-center">{dept.onLeave}</td>
                  <td className="px-4 py-3 text-end">
                    <Badge variant={dept.utilization >= 85 ? 'danger' : dept.utilization >= 75 ? 'warning' : 'success'}>
                      {dept.utilization}%
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default ResourceDashboard;
