import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  ArrowLeft,
  FileText,
  Clock,
  Users,
  Award,
  Send,
  Download,
  CheckCircle2,
  Circle,
  Package,
  Building2,
} from 'lucide-react';
import {
  PageHeader,
  Card,
  Button,
  Badge,
  Table,
  Modal,
} from '@/shared/components/ui';
import type { Column } from '@/shared/types';

interface RFQDetail {
  id: string;
  number: string;
  title: string;
  status: 'DRAFT' | 'PUBLISHED' | 'CLOSED' | 'AWARDED';
  description: string;
  deadline: string;
  createdAt: string;
  closedAt?: string;
  awardedAt?: string;
  currency: string;
  hotel: string;
  createdBy: string;
}

interface RFQLineItem {
  id: string;
  description: string;
  specification: string;
  quantity: number;
  unit: string;
  estimatedBudget: number;
  category: string;
}

interface VendorResponse {
  id: string;
  vendorId: string;
  vendorName: string;
  submittedAt: string;
  status: 'SUBMITTED' | 'SHORTLISTED' | 'AWARDED' | 'REJECTED';
  totalValue: number;
  items: VendorItemQuote[];
}

interface VendorItemQuote {
  itemId: string;
  unitPrice: number;
  brand: string;
  leadTime: string;
  warranty: string;
  total: number;
}

interface TimelineEntry {
  id: string;
  status: string;
  date: string;
  description: string;
  completed: boolean;
}

const mockRFQ: RFQDetail = {
  id: '1',
  number: 'RFQ-2024-001',
  title: 'HVAC System Upgrade - Burj Al Arab',
  status: 'PUBLISHED',
  description:
    'Complete replacement and upgrade of the HVAC system for the main tower including AHUs, chillers, and BMS integration.',
  deadline: '2024-03-15',
  createdAt: '2024-02-01',
  currency: 'AED',
  hotel: 'Burj Al Arab',
  createdBy: 'Ahmed Al Maktoum',
};

const mockItems: RFQLineItem[] = [
  { id: 'i1', description: 'Chiller Unit 500TR', specification: 'Centrifugal, VFD, 500TR capacity', quantity: 4, unit: 'PCS', estimatedBudget: 400000, category: 'HVAC' },
  { id: 'i2', description: 'Air Handling Unit', specification: 'VAV, 20,000 CFM, with heat recovery', quantity: 12, unit: 'PCS', estimatedBudget: 85000, category: 'HVAC' },
  { id: 'i3', description: 'BMS Controller Integration', specification: 'BACnet protocol, full integration', quantity: 1, unit: 'LOT', estimatedBudget: 250000, category: 'BMS' },
  { id: 'i4', description: 'Ductwork Modification', specification: 'Galvanized steel, insulated', quantity: 500, unit: 'M', estimatedBudget: 350, category: 'HVAC' },
];

const mockResponses: VendorResponse[] = [
  {
    id: 'r1',
    vendorId: 'VND-001',
    vendorName: 'Al Fardan HVAC Solutions',
    submittedAt: '2024-02-20',
    status: 'SUBMITTED',
    totalValue: 2450000,
    items: [
      { itemId: 'i1', unitPrice: 380000, brand: 'Carrier', leadTime: '12 weeks', warranty: '5 years', total: 1520000 },
      { itemId: 'i2', unitPrice: 78000, brand: 'Daikin', leadTime: '6 weeks', warranty: '3 years', total: 936000 },
      { itemId: 'i3', unitPrice: 220000, brand: 'Siemens', leadTime: '8 weeks', warranty: '2 years', total: 220000 },
      { itemId: 'i4', unitPrice: 320, brand: 'Custom', leadTime: '4 weeks', warranty: '1 year', total: 160000 },
    ],
  },
  {
    id: 'r2',
    vendorId: 'VND-003',
    vendorName: 'Dubai Climate Control',
    submittedAt: '2024-02-22',
    status: 'SUBMITTED',
    totalValue: 2680000,
    items: [
      { itemId: 'i1', unitPrice: 420000, brand: 'York', leadTime: '14 weeks', warranty: '7 years', total: 1680000 },
      { itemId: 'i2', unitPrice: 92000, brand: 'Trane', leadTime: '8 weeks', warranty: '5 years', total: 1104000 },
      { itemId: 'i3', unitPrice: 280000, brand: 'Honeywell', leadTime: '10 weeks', warranty: '3 years', total: 280000 },
      { itemId: 'i4', unitPrice: 380, brand: 'Custom', leadTime: '5 weeks', warranty: '2 years', total: 190000 },
    ],
  },
  {
    id: 'r3',
    vendorId: 'VND-006',
    vendorName: 'Emirates MEP Solutions',
    submittedAt: '2024-02-25',
    status: 'SUBMITTED',
    totalValue: 2310000,
    items: [
      { itemId: 'i1', unitPrice: 360000, brand: 'York', leadTime: '10 weeks', warranty: '5 years', total: 1440000 },
      { itemId: 'i2', unitPrice: 71000, brand: 'Daikin', leadTime: '5 weeks', warranty: '3 years', total: 852000 },
      { itemId: 'i3', unitPrice: 195000, brand: 'Siemens', leadTime: '7 weeks', warranty: '2 years', total: 195000 },
      { itemId: 'i4', unitPrice: 290, brand: 'Custom', leadTime: '3 weeks', warranty: '1 year', total: 145000 },
    ],
  },
];

const mockTimeline: TimelineEntry[] = [
  { id: 't1', status: 'DRAFT', date: '2024-02-01', description: 'RFQ created by Ahmed Al Maktoum', completed: true },
  { id: 't2', status: 'PUBLISHED', date: '2024-02-05', description: 'RFQ published to 5 vendors', completed: true },
  { id: 't3', status: 'RESPONSES', date: '2024-02-25', description: '3 vendor responses received', completed: true },
  { id: 't4', status: 'EVALUATION', date: '—', description: 'Technical and commercial evaluation', completed: false },
  { id: 't5', status: 'AWARDED', date: '—', description: 'Award to selected vendor', completed: false },
];

const getStatusVariant = (status: string) => {
  switch (status) {
    case 'DRAFT': return 'default';
    case 'PUBLISHED': return 'info';
    case 'CLOSED': return 'warning';
    case 'AWARDED': return 'success';
    case 'SUBMITTED': return 'info';
    case 'SHORTLISTED': return 'warning';
    case 'REJECTED': return 'danger';
    default: return 'default';
  }
};

const RfqDetail: React.FC = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const [awardModalOpen, setAwardModalOpen] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState<string | null>(null);

  const rfq = mockRFQ;
  const totalEstimated = mockItems.reduce((s, i) => s + i.estimatedBudget * i.quantity, 0);

  const itemsColumns: Column<RFQLineItem>[] = useMemo(
    () => [
      { key: 'description', header: t('common.description', 'Description'), render: (v) => <span className="font-medium text-slate-100">{v as string}</span> },
      { key: 'specification', header: t('rfq.specification', 'Specification') },
      { key: 'quantity', header: t('rfq.quantity', 'Qty'), width: 'w-16', align: 'center' },
      { key: 'unit', header: t('rfq.unit', 'Unit'), width: 'w-16', align: 'center' },
      { key: 'estimatedBudget', header: t('rfq.estimatedBudget', 'Est. Budget'), align: 'end', render: (_, row) => (
        <span className="text-[#c9a962]">{rfq.currency} {(row.estimatedBudget).toLocaleString()}</span>
      )},
      { key: 'total', header: t('common.total', 'Total'), align: 'end', width: 'w-36', render: (_, row) => (
        <span className="font-semibold text-slate-200">{rfq.currency} {(row.estimatedBudget * row.quantity).toLocaleString()}</span>
      )},
    ],
    [t, rfq]
  );

  const comparisonColumns: Column<any>[] = useMemo(() => [
    { key: 'vendorName', header: t('rfq.vendor', 'Vendor'), render: (v) => <span className="font-medium text-slate-100">{v as string}</span> },
    { key: 'submittedAt', header: t('rfq.submittedAt', 'Submitted'), width: 'w-28' },
    { key: 'status', header: t('common.status', 'Status'), width: 'w-28', render: (v) => <Badge variant={getStatusVariant(v as string)}>{v as string}</Badge> },
    { key: 'totalValue', header: t('common.totalValue', 'Total Value'), align: 'end', render: (v) => (
      <span className="font-bold text-[#c9a962]">{rfq.currency} {(v as number).toLocaleString()}</span>
    )},
    { key: 'actions', header: '', width: 'w-32', align: 'center', render: (_, row) => (
      <Button
        size="sm"
        variant="secondary"
        onClick={() => { setSelectedVendor(row.id); setAwardModalOpen(true); }}
      >
        <Award className="w-3.5 h-3.5" />
        {t('rfq.award', 'Award')}
      </Button>
    )},
  ], [t, rfq]);

  const handleAward = () => {
    setAwardModalOpen(false);
    // Award logic
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={rfq.number}
        subtitle={rfq.title}
        showBack
        backTo="/rfq"
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" icon={<Download className="w-4 h-4" />}>
              {t('common.export', 'Export')}
            </Button>
            {rfq.status === 'PUBLISHED' && (
              <Button variant="danger" icon={<Send className="w-4 h-4" />}>
                {t('rfq.closeRfq', 'Close RFQ')}
              </Button>
            )}
          </div>
        }
      />

      {/* Status & Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-lg bg-[#252540]">
              <FileText className="w-5 h-5 text-[#c9a962]" />
            </div>
            <div>
              <p className="text-sm text-slate-400">{t('common.status', 'Status')}</p>
              <Badge variant={getStatusVariant(rfq.status)}>{rfq.status}</Badge>
            </div>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-400">{t('common.hotel', 'Hotel')}</span>
              <span className="text-slate-200 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5" />{rfq.hotel}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">{t('common.createdBy', 'Created By')}</span>
              <span className="text-slate-200">{rfq.createdBy}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">{t('common.createdAt', 'Created')}</span>
              <span className="text-slate-200">{rfq.createdAt}</span>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-lg bg-[#252540]">
              <Clock className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-slate-400">{t('rfq.deadline', 'Deadline')}</p>
              <p className="text-lg font-bold text-slate-100">{rfq.deadline}</p>
            </div>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-400">{t('rfq.items', 'Items')}</span>
              <span className="text-slate-200">{mockItems.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">{t('rfq.estimatedBudget', 'Est. Budget')}</span>
              <span className="text-[#c9a962] font-medium">{rfq.currency} {totalEstimated.toLocaleString()}</span>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-lg bg-[#252540]">
              <Users className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-slate-400">{t('rfq.responses', 'Responses')}</p>
              <p className="text-lg font-bold text-slate-100">{mockResponses.length}</p>
            </div>
          </div>
          <div className="space-y-2 text-sm">
            {mockResponses.map((resp) => (
              <div key={resp.id} className="flex justify-between items-center">
                <span className="text-slate-400 truncate me-2">{resp.vendorName}</span>
                <span className="text-slate-200 font-medium">{rfq.currency} {(resp.totalValue / 1000).toFixed(0)}K</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Description */}
      <Card>
        <h3 className="text-lg font-semibold text-slate-100 mb-2">{t('common.description', 'Description')}</h3>
        <p className="text-sm text-slate-300 leading-relaxed">{rfq.description}</p>
      </Card>

      {/* Items Table */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('rfq.items', 'RFQ Items')}</h3>}>
        <div className="overflow-x-auto">
          <Table columns={itemsColumns} data={mockItems} keyExtractor={(r) => r.id} />
        </div>
      </Card>

      {/* Vendor Responses Comparison */}
      <Card header={
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-100">{t('rfq.vendorResponses', 'Vendor Responses')}</h3>
          <Badge variant="info">{mockResponses.length} {t('rfq.responses', 'Responses')}</Badge>
        </div>
      }>
        <div className="overflow-x-auto">
          <Table columns={comparisonColumns} data={mockResponses} keyExtractor={(r) => r.id} />
        </div>
      </Card>

      {/* Status Timeline */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('rfq.timeline', 'Status Timeline')}</h3>}>
        <div className="space-y-0">
          {mockTimeline.map((entry, index) => (
            <div key={entry.id} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  entry.completed
                    ? 'bg-[#c9a962]/20 border-2 border-[#c9a962]'
                    : 'bg-[#1a1a2e] border-2 border-[#2d2d4a]'
                }`}>
                  {entry.completed ? (
                    <CheckCircle2 className="w-4 h-4 text-[#c9a962]" />
                  ) : (
                    <Circle className="w-4 h-4 text-slate-500" />
                  )}
                </div>
                {index < mockTimeline.length - 1 && (
                  <div className={`w-0.5 h-12 ${entry.completed ? 'bg-[#c9a962]/40' : 'bg-[#2d2d4a]'}`} />
                )}
              </div>
              <div className="pb-8">
                <p className={`text-sm font-medium ${entry.completed ? 'text-slate-100' : 'text-slate-500'}`}>
                  {entry.status}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">{entry.description}</p>
                <p className="text-xs text-slate-500 mt-0.5">{entry.date}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Award Modal */}
      <Modal
        isOpen={awardModalOpen}
        onClose={() => setAwardModalOpen(false)}
        title={t('rfq.awardVendor', 'Award Vendor')}
        footer={
          <div className="flex items-center justify-end gap-2">
            <Button variant="secondary" onClick={() => setAwardModalOpen(false)}>
              {t('common.cancel', 'Cancel')}
            </Button>
            <Button icon={<Award className="w-4 h-4" />} onClick={handleAward}>
              {t('rfq.confirmAward', 'Confirm Award')}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            {t('rfq.awardConfirmMessage', 'Are you sure you want to award this RFQ to the selected vendor? This action cannot be undone.')}
          </p>
          {selectedVendor && (() => {
            const vendor = mockResponses.find((r) => r.id === selectedVendor);
            return vendor ? (
              <div className="p-3 bg-[#252540] rounded-lg">
                <p className="font-medium text-slate-100">{vendor.vendorName}</p>
                <p className="text-sm text-[#c9a962] mt-1">
                  Total: {rfq.currency} {vendor.totalValue.toLocaleString()}
                </p>
              </div>
            ) : null;
          })()}
        </div>
      </Modal>
    </div>
  );
};

export default RfqDetail;
