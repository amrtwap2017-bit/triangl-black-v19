import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Plus, Trash2, Save, Send, Package } from 'lucide-react';
import {
  PageHeader,
  Card,
  Button,
  Input,
  Textarea,
  Select,
  Badge,
} from '@/shared/components/ui';

interface RFQItem {
  id: string;
  description: string;
  specification: string;
  quantity: number;
  unit: string;
  estimatedBudget: number;
  category: string;
}

interface VendorInvite {
  id: string;
  vendorId: string;
  vendorName: string;
  selected: boolean;
}

const categories = [
  { value: 'HVAC', label: 'HVAC' },
  { value: 'ELECTRICAL', label: 'Electrical' },
  { value: 'PLUMBING', label: 'Plumbing' },
  { value: 'FIRE_PROTECTION', label: 'Fire Protection' },
  { value: 'BMS', label: 'BMS' },
  { value: 'GENERAL', label: 'General' },
];

const units = [
  { value: 'PCS', label: 'Pieces' },
  { value: 'SET', label: 'Set' },
  { value: 'M', label: 'Meter' },
  { value: 'SQM', label: 'Square Meter' },
  { value: 'LOT', label: 'Lot' },
  { value: 'KG', label: 'Kilogram' },
  { value: 'L', label: 'Liter' },
];

const currencies = [
  { value: 'AED', label: 'AED' },
  { value: 'USD', label: 'USD' },
  { value: 'EUR', label: 'EUR' },
  { value: 'SAR', label: 'SAR' },
];

const mockVendors: VendorInvite[] = [
  { id: 'v1', vendorId: 'VND-001', vendorName: 'Al Fardan HVAC Solutions', selected: false },
  { id: 'v2', vendorId: 'VND-002', vendorName: 'Gulf Electrical Trading', selected: false },
  { id: 'v3', vendorId: 'VND-003', vendorName: 'Dubai Fire Safety Systems', selected: false },
  { id: 'v4', vendorId: 'VND-004', vendorName: 'Emirates Building Technologies', selected: false },
  { id: 'v5', vendorId: 'VND-005', vendorName: 'National Plumbing Industries', selected: false },
];

const createEmptyItem = (): RFQItem => ({
  id: crypto.randomUUID(),
  description: '',
  specification: '',
  quantity: 1,
  unit: 'PCS',
  estimatedBudget: 0,
  category: 'GENERAL',
});

const RfqForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = Boolean(id);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [currency, setCurrency] = useState('AED');
  const [items, setItems] = useState<RFQItem[]>([createEmptyItem()]);
  const [vendors, setVendors] = useState<VendorInvite[]>(mockVendors);
  const [vendorSearch, setVendorSearch] = useState('');
  const [saving, setSaving] = useState(false);

  const handleAddItem = () => {
    setItems([...items, createEmptyItem()]);
  };

  const handleRemoveItem = (itemId: string) => {
    if (items.length > 1) {
      setItems(items.filter((item) => item.id !== itemId));
    }
  };

  const handleItemChange = (
    itemId: string,
    field: keyof RFQItem,
    value: string | number
  ) => {
    setItems(
      items.map((item) =>
        item.id === itemId ? { ...item, [field]: value } : item
      )
    );
  };

  const toggleVendor = (vendorId: string) => {
    setVendors(
      vendors.map((v) =>
        v.vendorId === vendorId ? { ...v, selected: !v.selected } : v
      )
    );
  };

  const totalEstimated = items.reduce(
    (sum, item) => sum + item.estimatedBudget * item.quantity,
    0
  );
  const selectedVendorsCount = vendors.filter((v) => v.selected).length;

  const filteredVendors = vendors.filter((v) =>
    v.vendorName.toLowerCase().includes(vendorSearch.toLowerCase())
  );

  const handleSaveDraft = async () => {
    setSaving(true);
    try {
      // await apiPost('/rfq/save', { title, description, deadline, currency, items, vendors: vendors.filter(v => v.selected) }, { params: { draft: true } });
    } finally {
      setSaving(false);
    }
  };

  const handleSubmit = async () => {
    setSaving(true);
    try {
      // await apiPost('/rfq/submit', { title, description, deadline, currency, items, vendors: vendors.filter(v => v.selected) });
      navigate('/rfq');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEditing ? t('rfq.editRfq', 'Edit RFQ') : t('rfq.createRfq', 'Create RFQ')}
        showBack
        backTo="/rfq"
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              icon={<Save className="w-4 h-4" />}
              onClick={handleSaveDraft}
              loading={saving}
            >
              {t('common.saveDraft', 'Save Draft')}
            </Button>
            <Button
              icon={<Send className="w-4 h-4" />}
              onClick={handleSubmit}
              loading={saving}
              disabled={!title || items.length === 0 || selectedVendorsCount === 0}
            >
              {t('common.submit', 'Submit')}
            </Button>
          </div>
        }
      />

      {/* RFQ Details */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('rfq.rfqDetails', 'RFQ Details')}</h3>}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <Input
              label={t('common.title', 'Title')}
              placeholder={t('rfq.titlePlaceholder', 'Enter RFQ title')}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          <div className="md:col-span-2">
            <Textarea
              label={t('common.description', 'Description')}
              placeholder={t('rfq.descriptionPlaceholder', 'Describe the scope of work...')}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
            />
          </div>
          <div>
            <Input
              type="date"
              label={t('rfq.deadline', 'Deadline')}
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
            />
          </div>
          <div>
            <Select
              label={t('common.currency', 'Currency')}
              options={currencies}
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
            />
          </div>
        </div>
      </Card>

      {/* Items */}
      <Card
        header={
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-100">
              {t('rfq.items', 'Items')} ({items.length})
            </h3>
            <Button
              size="sm"
              icon={<Plus className="w-4 h-4" />}
              onClick={handleAddItem}
            >
              {t('rfq.addItem', 'Add Item')}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          {items.map((item, index) => (
            <div
              key={item.id}
              className="p-4 bg-[#15152a] border border-[#2d2d4a] rounded-lg"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-[#c9a962]" />
                  <span className="text-sm font-medium text-slate-200">
                    {t('rfq.item', 'Item')} #{index + 1}
                  </span>
                </div>
                {items.length > 1 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={<Trash2 className="w-3.5 h-3.5 text-red-400" />}
                    onClick={() => handleRemoveItem(item.id)}
                  />
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="md:col-span-2">
                  <Input
                    label={t('common.description', 'Description')}
                    placeholder={t('rfq.itemDescription', 'Item description')}
                    value={item.description}
                    onChange={(e) =>
                      handleItemChange(item.id, 'description', e.target.value)
                    }
                  />
                </div>
                <div>
                  <Select
                    label={t('rfq.category', 'Category')}
                    options={categories}
                    value={item.category}
                    onChange={(e) =>
                      handleItemChange(item.id, 'category', e.target.value)
                    }
                  />
                </div>
                <div className="md:col-span-2">
                  <Input
                    label={t('rfq.specification', 'Specification')}
                    placeholder={t('rfq.specPlaceholder', 'Technical specs...')}
                    value={item.specification}
                    onChange={(e) =>
                      handleItemChange(
                        item.id,
                        'specification',
                        e.target.value
                      )
                    }
                  />
                </div>
                <div>
                  <Input
                    type="number"
                    label={t('rfq.quantity', 'Quantity')}
                    value={String(item.quantity)}
                    onChange={(e) =>
                      handleItemChange(
                        item.id,
                        'quantity',
                        Number(e.target.value)
                      )
                    }
                  />
                </div>
                <div>
                  <Select
                    label={t('rfq.unit', 'Unit')}
                    options={units}
                    value={item.unit}
                    onChange={(e) =>
                      handleItemChange(item.id, 'unit', e.target.value)
                    }
                  />
                </div>
                <div>
                  <Input
                    type="number"
                    label={t('rfq.estimatedBudget', 'Estimated Budget')}
                    value={String(item.estimatedBudget)}
                    onChange={(e) =>
                      handleItemChange(
                        item.id,
                        'estimatedBudget',
                        Number(e.target.value)
                      )
                    }
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end mt-4 pt-4 border-t border-[#2d2d4a]">
          <div className="text-end">
            <p className="text-sm text-slate-400">{t('common.totalEstimated', 'Total Estimated')}</p>
            <p className="text-xl font-bold text-[#c9a962]">
              {currency} {totalEstimated.toLocaleString()}
            </p>
          </div>
        </div>
      </Card>

      {/* Vendor Selection */}
      <Card
        header={
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-100">
              {t('rfq.inviteVendors', 'Invite Vendors')}
            </h3>
            <Badge variant="info">{selectedVendorsCount} {t('rfq.selected', 'selected')}</Badge>
          </div>
        }
      >
        <Input
          placeholder={t('rfq.searchVendors', 'Search vendors...')}
          value={vendorSearch}
          onChange={(e) => setVendorSearch(e.target.value)}
          className="mb-3"
        />
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {filteredVendors.map((vendor) => (
            <label
              key={vendor.id}
              className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors ${
                vendor.selected
                  ? 'bg-[#c9a962]/10 border border-[#c9a962]/30'
                  : 'bg-[#15152a] border border-[#2d2d4a] hover:border-[#2d2d4a]'
              }`}
            >
              <input
                type="checkbox"
                checked={vendor.selected}
                onChange={() => toggleVendor(vendor.vendorId)}
                className="w-4 h-4 rounded border-[#2d2d4a] text-[#c9a962] focus:ring-[#c9a962]/50 bg-[#1a1a2e]"
              />
              <div>
                <p className="text-sm font-medium text-slate-200">{vendor.vendorName}</p>
                <p className="text-xs text-slate-500">{vendor.vendorId}</p>
              </div>
            </label>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default RfqForm;
