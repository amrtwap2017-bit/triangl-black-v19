import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, FileText, Clock, Filter } from 'lucide-react';
import {
  PageHeader,
  SearchBar,
  Button,
  Select,
  Card,
  Table,
  Badge,
} from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import type { Column } from '@/shared/types';

interface RFQItem {
  id: string;
  number: string;
  title: string;
  status: 'DRAFT' | 'PUBLISHED' | 'CLOSED' | 'AWARDED';
  deadline: string;
  responsesCount: number;
  totalValue: number;
  currency: string;
  createdAt: string;
  createdBy: string;
}

const getStatusVariant = (status: string) => {
  switch (status) {
    case 'DRAFT': return 'default';
    case 'PUBLISHED': return 'info';
    case 'CLOSED': return 'warning';
    case 'AWARDED': return 'success';
    default: return 'default';
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'DRAFT': return 'text-slate-400';
    case 'PUBLISHED': return 'text-blue-400';
    case 'CLOSED': return 'text-amber-400';
    case 'AWARDED': return 'text-green-400';
    default: return 'text-slate-400';
  }
};

const mockRFQs: RFQItem[] = [
  { id: '1', number: 'RFQ-2024-001', title: 'HVAC System Upgrade - Burj Al Arab', status: 'PUBLISHED', deadline: '2024-03-15', responsesCount: 5, totalValue: 2500000, currency: 'AED', createdAt: '2024-02-01', createdBy: 'Ahmed Al Maktoum' },
  { id: '2', number: 'RFQ-2024-002', title: 'Fire Alarm System - Atlantis The Royal', status: 'PUBLISHED', deadline: '2024-03-20', responsesCount: 3, totalValue: 1800000, currency: 'AED', createdAt: '2024-02-05', createdBy: 'Sarah Johnson' },
  { id: '3', number: 'RFQ-2024-003', title: 'BMS Integration - Mandarin Oriental', status: 'DRAFT', deadline: '2024-04-01', responsesCount: 0, totalValue: 950000, currency: 'AED', createdAt: '2024-02-10', createdBy: 'Ahmed Al Maktoum' },
  { id: '4', number: 'RFQ-2024-004', title: 'Plumbing Renovation - Ritz Carlton', status: 'CLOSED', deadline: '2024-02-10', responsesCount: 4, totalValue: 720000, currency: 'AED', createdAt: '2024-01-15', createdBy: 'Mohammed Hassan' },
  { id: '5', number: 'RFQ-2024-005', title: 'Chiller Replacement - Four Seasons DIFC', status: 'AWARDED', deadline: '2024-01-30', responsesCount: 6, totalValue: 3200000, currency: 'AED', createdAt: '2024-01-05', createdBy: 'Sarah Johnson' },
  { id: '6', number: 'RFQ-2024-006', title: 'Electrical Panel Upgrade - JW Marriott', status: 'PUBLISHED', deadline: '2024-03-25', responsesCount: 2, totalValue: 450000, currency: 'AED', createdAt: '2024-02-12', createdBy: 'Ahmed Al Maktoum' },
  { id: '7', number: 'RFQ-2024-007', title: 'Waterproofing - Address Downtown', status: 'DRAFT', deadline: '2024-04-10', responsesCount: 0, totalValue: 600000, currency: 'AED', createdAt: '2024-02-14', createdBy: 'Mohammed Hassan' },
];

const RfqList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const filteredData = useMemo(() => {
    return mockRFQs.filter((rfq) => {
      const matchesSearch =
        !search ||
        rfq.title.toLowerCase().includes(search.toLowerCase()) ||
        rfq.number.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = !statusFilter || rfq.status === statusFilter;
      const matchesDate = !dateFilter || rfq.deadline.startsWith(dateFilter);
      return matchesSearch && matchesStatus && matchesDate;
    });
  }, [search, statusFilter, dateFilter]);

  const columns: Column<RFQItem>[] = useMemo(
    () => [
      {
        key: 'number',
        header: t('common.number', 'Number'),
        width: 'w-36',
        sortable: true,
        render: (_, row) => (
          <div>
            <p className="font-medium text-[#c9a962]">{row.number}</p>
            <p className="text-xs text-slate-500">{row.createdBy}</p>
          </div>
        ),
      },
      {
        key: 'title',
        header: t('common.title', 'Title'),
        sortable: true,
        render: (v) => (
          <p className="font-medium text-slate-100">{v as string}</p>
        ),
      },
      {
        key: 'status',
        header: t('common.status', 'Status'),
        width: 'w-28',
        render: (v) => (
          <Badge variant={getStatusVariant(v as string)}>{(v as string)}</Badge>
        ),
      },
      {
        key: 'deadline',
        header: t('rfq.deadline', 'Deadline'),
        width: 'w-32',
        render: (v) => (
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>{v as string}</span>
          </div>
        ),
      },
      {
        key: 'responsesCount',
        header: t('rfq.responses', 'Responses'),
        width: 'w-24',
        align: 'center',
        render: (v) => (
          <span className={`font-semibold ${getStatusColor((v as number) > 0 ? 'PUBLISHED' : 'DRAFT')}`}>
            {v as number}
          </span>
        ),
      },
      {
        key: 'totalValue',
        header: t('common.totalValue', 'Total Value'),
        width: 'w-36',
        align: 'end',
        sortable: true,
        render: (_, row) => (
          <span className="font-medium text-slate-200">
            {row.currency} {(row.totalValue).toLocaleString()}
          </span>
        ),
      },
      {
        key: 'actions',
        header: '',
        width: 'w-20',
        align: 'center',
        render: (_, row) => (
          <Button
            size="sm"
            variant="ghost"
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/rfq/${row.id}`);
            }}
          >
            {t('common.view', 'View')}
          </Button>
        ),
      },
    ],
    [t, navigate]
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('rfq.title', 'RFQ Management')}
        subtitle={t('rfq.subtitle', 'Manage requests for quotation')}
        actions={
          <Button
            icon={<Plus className="w-4 h-4" />}
            onClick={() => navigate('/rfq/new')}
          >
            {t('rfq.createRfq', 'New RFQ')}
          </Button>
        }
      />

      <Card noPadding>
        <div className="p-4 border-b border-[#2d2d4a]">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex-1 w-full sm:w-auto">
              <SearchBar
                onSearch={setSearch}
                placeholder={t('rfq.searchPlaceholder', 'Search RFQs by number or title...')}
              />
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                icon={<Filter className="w-4 h-4" />}
                onClick={() => setShowFilters(!showFilters)}
              >
                {t('common.filters', 'Filters')}
              </Button>
            </div>
          </div>

          {showFilters && (
            <div className="flex flex-wrap gap-3 mt-3 pt-3 border-t border-[#2d2d4a]">
              <div className="w-48">
                <Select
                  options={[
                    { value: '', label: t('common.allStatuses', 'All Statuses') },
                    { value: 'DRAFT', label: t('rfq.draft', 'Draft') },
                    { value: 'PUBLISHED', label: t('rfq.published', 'Published') },
                    { value: 'CLOSED', label: t('rfq.closed', 'Closed') },
                    { value: 'AWARDED', label: t('rfq.awarded', 'Awarded') },
                  ]}
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                />
              </div>
              <div className="w-48">
                <Input
                  type="date"
                  placeholder={t('rfq.deadlineFrom', 'Deadline from...')}
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        <Table
          columns={columns}
          data={filteredData}
          keyExtractor={(r) => r.id}
          onRowClick={(row) => navigate(`/rfq/${row.id}`)}
        />
      </Card>
    </div>
  );
};

export default RfqList;
