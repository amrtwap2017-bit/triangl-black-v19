import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Camera, CheckCircle, Sparkles, ArrowRightLeft, MapPin, Calendar, User, Image as ImageIcon } from 'lucide-react';
import { PageHeader, Card, Button, Tabs, Badge, LoadingSpinner, EmptyState, StatusBadge, Modal, Textarea, Input, FileUpload } from '@/shared/components/ui';
import { useApiSingle } from '@/shared/hooks';
import { apiPost, apiPatch } from '@/api/client';
import { endpoints } from '@/api/endpoints';
import toast from 'react-hot-toast';
import type { SiteVisit } from '@/shared/types';

const VisitDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('findings');
  const [showCompleteModal, setShowCompleteModal] = useState(false);
  const [findings, setFindings] = useState('');
  const [recommendations, setRecommendations] = useState('');
  const [scopeAssessment, setScopeAssessment] = useState('');
  const [estimatedBudget, setEstimatedBudget] = useState('');
  const [photos, setPhotos] = useState<File[]>([]);

  const { data: visit, isLoading } = useApiSingle<SiteVisit>(
    ['siteVisit', id!], `/site-visits/${id}`
  );

  if (isLoading) return <LoadingSpinner />;
  if (!visit) return <EmptyState message="Visit not found" />;

  const handleComplete = async () => {
    try {
      await apiPost(endpoints.siteVisits.complete(id!), { findings, recommendations, scopeAssessment, estimatedBudget: Number(estimatedBudget) || undefined });
      toast.success(t('common.success'));
      setShowCompleteModal(false);
    } catch { toast.error(t('common.error')); }
  };

  const handleGenerateDraft = async () => {
    try {
      await apiPost(endpoints.siteVisits.generateDraft(id!));
      toast.success('Draft opportunity generated');
      navigate('/opportunities');
    } catch { toast.error(t('common.error')); }
  };

  const tabs = [
    { key: 'findings', label: t('siteVisits.findings'), icon: <MapPin className="w-4 h-4" /> },
    { key: 'photos', label: t('siteVisits.photos'), icon: <Camera className="w-4 h-4" /> },
    { key: 'recommendations', label: t('siteVisits.recommendations'), icon: <ImageIcon className="w-4 h-4" /> },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title={`Visit ${visit.visitNumber}`} subtitle={visit.hotel?.name} breadcrumbs={[{label:t('siteVisits.title'),href:'/site-visits'},{label:visit.visitNumber}]} showBack actions={
        <div className="flex gap-2">
          {visit.status === 'COMPLETED' && (
            <Button variant="secondary" icon={<Sparkles className="w-4 h-4" />} onClick={handleGenerateDraft}>{t('siteVisits.generateDraft')}</Button>
          )}
          {visit.status !== 'COMPLETED' && (
            <Button icon={<CheckCircle className="w-4 h-4" />} onClick={() => setShowCompleteModal(true)}>{t('siteVisits.completeVisit')}</Button>
          )}
        </div>
      }} />

      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {activeTab === 'findings' && (
        <Card header={<h4 className="font-semibold text-slate-200">{t('siteVisits.findings')}</h4>}>
          {visit.findings ? (
            <p className="text-sm text-slate-300 whitespace-pre-wrap">{visit.findings}</p>
          ) : (
            <EmptyState message="No findings recorded yet" actionLabel={t('siteVisits.completeVisit')} onAction={() => setShowCompleteModal(true)} />
          )}
        </Card>
      )}

      {activeTab === 'photos' && (
        <Card>
          {visit.photos && visit.photos.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {visit.photos.map((photo) => (
                <div key={photo.id} className="aspect-video rounded-lg overflow-hidden bg-[#252540]">
                  <img src={photo.url} alt={photo.caption || ''} className="w-full h-full object-cover" />
                  {photo.caption && <p className="text-xs text-slate-400 mt-1">{photo.caption}</p>}
                </div>
              ))}
            </div>
          ) : <EmptyState message="No photos uploaded" />}
        </Card>
      )}

      {activeTab === 'recommendations' && (
        <Card header={<h4 className="font-semibold text-slate-200">{t('siteVisits.recommendations')}</h4>}>
          {visit.recommendations ? (
            <p className="text-sm text-slate-300 whitespace-pre-wrap">{visit.recommendations}</p>
          ) : <EmptyState message="No recommendations yet" />}
        </Card>
      )}

      <Modal isOpen={showCompleteModal} onClose={() => setShowCompleteModal(false)} title={t('siteVisits.completeVisit')} size="lg" footer={
        <>
          <Button variant="ghost" onClick={() => setShowCompleteModal(false)}>{t('common.cancel')}</Button>
          <Button onClick={handleComplete}>{t('common.save')}</Button>
        </>
      }>
        <div className="space-y-4">
          <Textarea label={t('siteVisits.findings')} value={findings} onChange={(e)=>setFindings(e.target.value)} />
          <Textarea label={t('siteVisits.recommendations')} value={recommendations} onChange={(e)=>setRecommendations(e.target.value)} />
          <Textarea label={t('siteVisits.scopeAssessment')} value={scopeAssessment} onChange={(e)=>setScopeAssessment(e.target.value)} />
          <Input label={t('siteVisits.estimatedBudget')} type="number" value={estimatedBudget} onChange={(e)=>setEstimatedBudget(e.target.value)} />
          <FileUpload label={t('siteVisits.photos')} onFilesSelected={setPhotos} accept="image/*" />
        </div>
      </Modal>
    </div>
  );
};

export default VisitDetail;