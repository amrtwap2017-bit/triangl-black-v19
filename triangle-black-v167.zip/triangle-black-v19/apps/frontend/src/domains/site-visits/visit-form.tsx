import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Save, X } from 'lucide-react';
import { PageHeader, Card, Input, Select, Textarea, Button, FileUpload } from '@/shared/components/ui';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const schema = z.object({
  partnerRequestId: z.string().optional(),
  hotelId: z.string().min(1, 'Hotel required'),
  assignedToId: z.string().min(1, 'Assignee required'),
  scheduledDate: z.string().min(1, 'Date required'),
  purpose: z.string().min(5, 'Purpose required'),
});

type FormData = z.infer<typeof schema>;

const VisitForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [photos, setPhotos] = useState<File[]>([]);

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      partnerRequestId: searchParams.get('requestId') || '',
    },
  });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await apiPost(endpoints.siteVisits.create, data);
      toast.success(t('common.success'));
      navigate('/site-visits');
    } catch { toast.error(t('common.error')); } finally { setLoading(false); }
  };

  return (
    <div className="space-y-6">
      <PageHeader title={t('siteVisits.schedule')} showBack backTo="/site-visits" breadcrumbs={[{label:t('siteVisits.title'),href:'/site-visits'},{label:t('common.create')}]}/>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Hotel ID" error={errors.hotelId?.message} {...register('hotelId')} placeholder="Enter hotel ID" />
            <Input label="Assignee User ID" error={errors.assignedToId?.message} {...register('assignedToId')} placeholder="Enter user ID" />
            <Input label={t('common.date')} type="date" error={errors.scheduledDate?.message} {...register('scheduledDate')} />
            <Textarea label={t('siteVisits.purpose')} error={errors.purpose?.message} {...register('purpose')} className="md:col-span-2" />
            <FileUpload label={t('siteVisits.photos')} onFilesSelected={setPhotos} accept="image/*" className="md:col-span-2" />
          </div>
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-[#2d2d4a]">
            <Button variant="ghost" onClick={() => navigate('/site-visits')}>{t('common.cancel')}</Button>
            <Button type="submit" loading={loading} icon={<Save className="w-4 h-4" />}>{t('common.save')}</Button>
          </div>
        </Card>
      </form>
    </div>
  );
};

export default VisitForm;