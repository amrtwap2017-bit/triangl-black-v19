import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, MapPin } from 'lucide-react';
import { PageHeader, SearchBar, Button, Select, Card, Table, StatusBadge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import { endpoints } from '@/api/endpoints';
import type { SiteVisit, Column } from '@/shared/types';

const VisitsList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: visits, isLoading, meta } = useApi<SiteVisit>(
    ['siteVisits'], endpoints.siteVisits.list,
    { ...paginationParams(), search, status: statusFilter }
  );

  const columns: Column<SiteVisit>[] = useMemo(() => [
    { key: 'visitNumber', header: 'Visit #', width: 'w-32', sortable: true },
    { key: 'hotel', header: t('hotels.title'), render: (_, row) => row.hotel?.name || '—' },
    { key: 'purpose', header: t('siteVisits.purpose'), render: (v) => <span className="text-sm">{String(v)?.substring(0, 80)}</span> },
    { key: 'scheduledDate', header: t('common.date'), width: 'w-36', render: (v) => new Date(v as string).toLocaleDateString() },
    { key: 'status', header: t('common.status'), render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'assignedTo', header: t('requests.assign'), render: (_, row) => row.assignedTo?.name || '—' },
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('siteVisits.title')} actions={
        <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/site-visits/new')}>{t('siteVisits.schedule')}</Button>
      )} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[{value:'',label:t('common.all')},{value:'SCHEDULED',label:'Scheduled'},{value:'IN_PROGRESS',label:'In Progress'},{value:'COMPLETED',label:'Completed'}]} value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={visits} keyExtractor={(v)=>v.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} onRowClick={(v)=>navigate(`/site-visits/${v.id}`)} />
      </Card>
    </div>
  );
};

export default VisitsList;