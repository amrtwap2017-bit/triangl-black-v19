import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { FileText, Clock, Send, Filter, AlertCircle } from 'lucide-react';
import {
  PageHeader,
  SearchBar,
  Button,
  Select,
  Card,
  Table,
  Badge,
} from '@/shared/components/ui';
import { usePagination } from '@/shared/hooks';
import type { Column } from '@/shared/types';

interface VendorRFQ {
  id: string;
  rfqNumber: string;
  title: string;
  hotel: string;
  deadline: string;
  issuedDate: string;
  status: 'NOT_RESPONDED' | 'RESPONSE_SUBMITTED' | 'SHORTLISTED' | 'AWARDED' | 'REJECTED';
  itemsCount: number;
  totalValue: number;
  currency: string;
  daysRemaining: number;
}

const mockVendorRFQs: VendorRFQ[] = [
  { id: '1', rfqNumber: 'RFQ-2024-001', title: 'HVAC System Upgrade - Burj Al Arab', hotel: 'Burj Al Arab', deadline: '2024-03-15', issuedDate: '2024-02-01', status: 'NOT_RESPONDED', itemsCount: 4, totalValue: 2500000, currency: 'AED', daysRemaining: 12 },
  { id: '2', rfqNumber: 'RFQ-2024-002', title: 'Fire Alarm System - Atlantis The Royal', hotel: 'Atlantis The Royal', deadline: '2024-03-20', issuedDate: '2024-02-05', status: 'RESPONSE_SUBMITTED', itemsCount: 6, totalValue: 1800000, currency: 'AED', daysRemaining: 17 },
  { id: '3', rfqNumber: 'RFQ-2024-004', title: 'Plumbing Renovation - Ritz Carlton', hotel: 'Ritz Carlton', deadline: '2024-02-10', issuedDate: '2024-01-15', status: 'SHORTLISTED', itemsCount: 3, totalValue: 720000, currency: 'AED', daysRemaining: -13 },
  { id: '4', rfqNumber: 'RFQ-2024-005', title: 'Chiller Replacement - Four Seasons DIFC', hotel: 'Four Seasons DIFC', deadline: '2024-01-30', issuedDate: '2024-01-05', status: 'AWARDED', itemsCount: 5, totalValue: 3200000, currency: 'AED', daysRemaining: -23 },
  { id: '5', rfqNumber: 'RFQ-2024-006', title: 'Electrical Panel Upgrade - JW Marriott', hotel: 'JW Marriott Marquis', deadline: '2024-03-25', issuedDate: '2024-02-12', status: 'NOT_RESPONDED', itemsCount: 2, totalValue: 450000, currency: 'AED', daysRemaining: 22 },
  { id: '6', rfqNumber: 'RFQ-2024-008', title: 'BMS Integration - Mandarin Oriental', hotel: 'Mandarin Oriental', deadline: '2024-04-01', issuedDate: '2024-02-18', status: 'NOT_RESPONDED', itemsCount: 3, totalValue: 950000, currency: 'AED', daysRemaining: 29 },
];

const getStatusVariant = (status: string) => {
  switch (status) {
    case 'NOT_RESPONDED': return 'warning';
    case 'RESPONSE_SUBMITTED': return 'info';
    case 'SHORTLISTED': return 'success';
    case 'AWARDED': return 'success';
    case 'REJECTED': return 'danger';
    default: return 'default';
  }
};

const getStatusLabel = (status: string) => {
  switch (status) {
    case 'NOT_RESPONDED': return 'Not Responded';
    case 'RESPONSE_SUBMITTED': return 'Response Submitted';
    case 'SHORTLISTED': return 'Shortlisted';
    case 'AWARDED': return 'Awarded';
    case 'REJECTED': return 'Rejected';
    default: return status;
  }
};

const VendorRfqList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const filteredData = useMemo(() => {
    return mockVendorRFQs.filter((rfq) => {
      const matchesSearch =
        !search ||
        rfq.title.toLowerCase().includes(search.toLowerCase()) ||
        rfq.rfqNumber.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = !statusFilter || rfq.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [search, statusFilter]);

  const columns: Column<VendorRFQ>[] = useMemo(
    () => [
      {
        key: 'rfqNumber',
        header: t('common.number', 'Number'),
        width: 'w-36',
        sortable: true,
        render: (v) => <span className="font-mono text-[#c9a962] text-xs">{v as string}</span>,
      },
      {
        key: 'title',
        header: t('common.title', 'Title'),
        sortable: true,
        render: (v, row) => (
          <div>
            <p className="font-medium text-slate-100">{v as string}</p>
            <p className="text-xs text-slate-500">{(row as any).hotel}</p>
          </div>
        ),
      },
      {
        key: 'status',
        header: t('common.status', 'Status'),
        width: 'w-40',
        render: (v) => (
          <Badge variant={getStatusVariant(v as string)}>
            {getStatusLabel(v as string)}
          </Badge>
        ),
      },
      {
        key: 'itemsCount',
        header: t('rfq.items', 'Items'),
        width: 'w-16',
        align: 'center',
      },
      {
        key: 'deadline',
        header: t('rfq.deadline', 'Deadline'),
        width: 'w-32',
        render: (v, row) => (
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>{v as string}</span>
          </div>
        ),
      },
      {
        key: 'daysRemaining',
        header: t('vendorPortal.timeLeft', 'Time Left'),
        width: 'w-28',
        align: 'center',
        render: (_, row) => {
          const days = (row as VendorRFQ).daysRemaining;
          if ((row as VendorRFQ).status === 'AWARDED') {
            return <Badge variant="success">Won</Badge>;
          }
          if (days < 0) {
            return <Badge variant="danger">Expired</Badge>;
          }
          if (days <= 3) {
            return (
              <div className="flex items-center justify-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 text-red-400" />
                <span className="text-sm font-semibold text-red-400">{days}d</span>
              </div>
            );
          }
          if (days <= 7) {
            return <span className="text-sm font-medium text-amber-400">{days} days</span>;
          }
          return <span className="text-sm text-slate-300">{days} days</span>;
        },
      },
      {
        key: 'actions',
        header: '',
        width: 'w-36',
        align: 'center',
        render: (_, row) => {
          const rfq = row as VendorRFQ;
          if (rfq.status === 'NOT_RESPONDED') {
            return (
              <Button
                size="sm"
                icon={<Send className="w-3.5 h-3.5" />}
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/vendor-portal/rfq/${rfq.id}/respond`);
                }}
              >
                {t('vendorPortal.respond', 'Respond')}
              </Button>
            );
          }
          if (rfq.status === 'RESPONSE_SUBMITTED' || rfq.status === 'SHORTLISTED') {
            return (
              <Button
                size="sm"
                variant="ghost"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/vendor-portal/rfq/${rfq.id}/response`);
                }}
              >
                {t('common.view', 'View')}
              </Button>
            );
          }
          return (
            <Button
              size="sm"
              variant="ghost"
              onClick={(e) => {
                e.stopPropagation();
                navigate(`/vendor-portal/rfq/${rfq.id}/response`);
              }}
            >
              {t('common.view', 'View')}
            </Button>
          );
        },
      },
    ],
    [t, navigate]
  );

  const openCount = filteredData.filter((r) => r.status === 'NOT_RESPONDED').length;
  const submittedCount = filteredData.filter((r) => r.status === 'RESPONSE_SUBMITTED').length;

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('vendorPortal.rfqTitle', 'Open RFQs')}
        subtitle={t('vendorPortal.rfqSubtitle', 'View and respond to requests for quotation')}
      />

      {/* Status Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-5 hover:border-[#c9a962]/30 transition-all">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-[#252540] text-amber-400">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm text-slate-400">{t('vendorPortal.pendingResponse', 'Pending Response')}</p>
              <p className="text-2xl font-bold text-slate-100">{openCount}</p>
            </div>
          </div>
        </div>
        <div className="bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-5 hover:border-[#c9a962]/30 transition-all">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-[#252540] text-blue-400">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm text-slate-400">{t('vendorPortal.submitted', 'Submitted')}</p>
              <p className="text-2xl font-bold text-slate-100">{submittedCount}</p>
            </div>
          </div>
        </div>
        <div className="bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-5 hover:border-[#c9a962]/30 transition-all">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-[#252540] text-green-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm text-slate-400">{t('vendorPortal.totalRfqs', 'Total RFQs')}</p>
              <p className="text-2xl font-bold text-slate-100">{filteredData.length}</p>
            </div>
          </div>
        </div>
      </div>

      <Card noPadding>
        <div className="p-4 border-b border-[#2d2d4a]">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex-1 w-full sm:w-auto">
              <SearchBar
                onSearch={setSearch}
                placeholder={t('vendorPortal.searchRfqs', 'Search RFQs...')}
              />
            </div>
            <div className="w-52">
              <Select
                options={[
                  { value: '', label: t('common.allStatuses', 'All Statuses') },
                  { value: 'NOT_RESPONDED', label: 'Not Responded' },
                  { value: 'RESPONSE_SUBMITTED', label: 'Response Submitted' },
                  { value: 'SHORTLISTED', label: 'Shortlisted' },
                  { value: 'AWARDED', label: 'Awarded' },
                  { value: 'REJECTED', label: 'Rejected' },
                ]}
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              />
            </div>
          </div>
        </div>

        <Table
          columns={columns}
          data={filteredData}
          keyExtractor={(r) => r.id}
          onRowClick={(row) => navigate(`/vendor-portal/rfq/${row.id}/response`)}
        />
      </Card>
    </div>
  );
};

export default VendorRfqList;
