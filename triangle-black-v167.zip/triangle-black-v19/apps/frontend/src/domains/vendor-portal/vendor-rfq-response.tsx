import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  ArrowLeft,
  Send,
  Calculator,
  FileText,
  Clock,
  Building2,
  Save,
} from 'lucide-react';
import {
  PageHeader,
  Card,
  Button,
  Input,
  Textarea,
  Badge,
  Modal,
} from '@/shared/components/ui';

interface RFQLineItem {
  id: string;
  description: string;
  specification: string;
  quantity: number;
  unit: string;
}

interface VendorItemResponse {
  itemId: string;
  unitPrice: number;
  brand: string;
  leadTime: string;
  warranty: string;
  total: number;
  notes: string;
}

const mockRFQDetail = {
  id: '1',
  number: 'RFQ-2024-001',
  title: 'HVAC System Upgrade - Burj Al Arab',
  hotel: 'Burj Al Arab',
  description: 'Complete replacement and upgrade of the HVAC system for the main tower including AHUs, chillers, and BMS integration.',
  deadline: '2024-03-15',
  issuedDate: '2024-02-01',
  currency: 'AED',
  issuedBy: 'TRIANGLE BLACK Engineering',
};

const mockItems: RFQLineItem[] = [
  { id: 'i1', description: 'Chiller Unit 500TR', specification: 'Centrifugal, VFD, 500TR capacity', quantity: 4, unit: 'PCS' },
  { id: 'i2', description: 'Air Handling Unit', specification: 'VAV, 20,000 CFM, with heat recovery', quantity: 12, unit: 'PCS' },
  { id: 'i3', description: 'BMS Controller Integration', specification: 'BACnet protocol, full integration', quantity: 1, unit: 'LOT' },
  { id: 'i4', description: 'Ductwork Modification', specification: 'Galvanized steel, insulated', quantity: 500, unit: 'M' },
];

const VendorRfqResponse: React.FC = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const [responses, setResponses] = useState<VendorItemResponse[]>(
    mockItems.map((item) => ({
      itemId: item.id,
      unitPrice: 0,
      brand: '',
      leadTime: '',
      warranty: '',
      total: 0,
      notes: '',
    }))
  );
  const [generalNotes, setGeneralNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);

  const updateResponse = (
    itemId: string,
    field: keyof VendorItemResponse,
    value: string | number
  ) => {
    setResponses((prev) =>
      prev.map((r) => {
        if (r.itemId !== itemId) return r;
        const updated = { ...r, [field]: value };
        // Auto-calculate total
        const item = mockItems.find((i) => i.id === itemId);
        if (item && field === 'unitPrice') {
          updated.total = (value as number) * item.quantity;
        }
        return updated;
      })
    );
  };

  const totalQuotation = responses.reduce((sum, r) => sum + r.total, 0);
  const allPriced = responses.every((r) => r.unitPrice > 0);

  const handleSubmit = async () => {
    setConfirmModalOpen(false);
    setSubmitting(true);
    try {
      // await apiPost(`/vendor-portal/rfq/${id}/respond`, { responses, generalNotes });
      navigate('/vendor-portal/rfq');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={`${t('vendorPortal.respondTo', 'Respond to')} ${mockRFQDetail.number}`}
        subtitle={mockRFQDetail.title}
        showBack
        backTo="/vendor-portal/rfq"
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              icon={<Save className="w-4 h-4" />}
              onClick={() => {}}
            >
              {t('common.saveDraft', 'Save Draft')}
            </Button>
            <Button
              icon={<Send className="w-4 h-4" />}
              onClick={() => setConfirmModalOpen(true)}
              disabled={!allPriced}
              loading={submitting}
            >
              {t('vendorPortal.submitResponse', 'Submit Response')}
            </Button>
          </div>
        }
      />

      {/* RFQ Information */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('vendorPortal.rfqDetails', 'RFQ Details')}</h3>}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <p className="text-xs text-slate-500 mb-1">{t('common.hotel', 'Hotel')}</p>
            <div className="flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-[#c9a962]" />
              <span className="text-sm font-medium text-slate-200">{mockRFQDetail.hotel}</span>
            </div>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">{t('rfq.deadline', 'Deadline')}</p>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-400" />
              <span className="text-sm font-medium text-slate-200">{mockRFQDetail.deadline}</span>
            </div>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">{t('common.issuedBy', 'Issued By')}</p>
            <span className="text-sm font-medium text-slate-200">{mockRFQDetail.issuedBy}</span>
          </div>
          <div>
            <p className="text-xs text-slate-500 mb-1">{t('common.currency', 'Currency')}</p>
            <span className="text-sm font-medium text-slate-200">{mockRFQDetail.currency}</span>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-[#2d2d4a]">
          <p className="text-sm text-slate-300 leading-relaxed">{mockRFQDetail.description}</p>
        </div>
      </Card>

      {/* Per-Item Response Form */}
      <Card
        header={
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-100">{t('vendorPortal.itemPricing', 'Per-Item Pricing')}</h3>
            <Badge variant="info">{mockItems.length} {t('rfq.items', 'items')}</Badge>
          </div>
        }
      >
        <div className="space-y-6">
          {mockItems.map((item, index) => {
            const response = responses.find((r) => r.itemId === item.id)!;
            return (
              <div key={item.id} className="border border-[#2d2d4a] rounded-lg overflow-hidden">
                {/* Item Header */}
                <div className="p-4 bg-[#15152a]">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <span className="text-sm font-bold text-[#c9a962]">#{index + 1}</span>
                      <div>
                        <p className="text-sm font-semibold text-slate-100">{item.description}</p>
                        <p className="text-xs text-slate-400 mt-0.5">{item.specification}</p>
                      </div>
                    </div>
                    <div className="text-end shrink-0">
                      <p className="text-xs text-slate-500">{t('rfq.quantity', 'Quantity')}</p>
                      <p className="text-sm font-semibold text-slate-200">
                        {item.quantity} {item.unit}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Response Fields */}
                <div className="p-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3">
                    <div>
                      <Input
                        type="number"
                        label={t('vendorPortal.unitPrice', 'Unit Price')}
                        placeholder="0.00"
                        value={response.unitPrice || ''}
                        onChange={(e) =>
                          updateResponse(item.id, 'unitPrice', Number(e.target.value))
                        }
                      />
                    </div>
                    <div>
                      <Input
                        label={t('vendorPortal.brand', 'Brand')}
                        placeholder="e.g., Carrier"
                        value={response.brand}
                        onChange={(e) =>
                          updateResponse(item.id, 'brand', e.target.value)
                        }
                      />
                    </div>
                    <div>
                      <Input
                        label={t('vendorPortal.leadTime', 'Lead Time')}
                        placeholder="e.g., 8 weeks"
                        value={response.leadTime}
                        onChange={(e) =>
                          updateResponse(item.id, 'leadTime', e.target.value)
                        }
                      />
                    </div>
                    <div>
                      <Input
                        label={t('vendorPortal.warranty', 'Warranty')}
                        placeholder="e.g., 5 years"
                        value={response.warranty}
                        onChange={(e) =>
                          updateResponse(item.id, 'warranty', e.target.value)
                        }
                      />
                    </div>
                    <div>
                      <Input
                        label={t('vendorPortal.itemNotes', 'Notes')}
                        placeholder="Optional"
                        value={response.notes}
                        onChange={(e) =>
                          updateResponse(item.id, 'notes', e.target.value)
                        }
                      />
                    </div>
                    <div>
                      <div className="block text-sm font-medium text-slate-300 mb-1.5">
                        {t('common.total', 'Total')}
                      </div>
                      <div className="w-full bg-[#1a1a2e] border border-[#2d2d4a] rounded-lg px-3 py-2 text-sm">
                        <span className={`font-bold ${response.total > 0 ? 'text-[#c9a962]' : 'text-slate-500'}`}>
                          {response.total > 0 ? `${mockRFQDetail.currency} ${response.total.toLocaleString()}` : '—'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Total */}
        <div className="mt-6 pt-4 border-t border-[#2d2d4a]">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="flex items-center gap-4">
              <Badge variant={allPriced ? 'success' : 'danger'}>
                {allPriced ? t('vendorPortal.allItemsPriced', 'All items priced') : t('vendorPortal.pendingItems', 'Pending pricing')}
              </Badge>
              <span className="text-sm text-slate-500">
                {responses.filter((r) => r.unitPrice > 0).length}/{responses.length} {t('vendorPortal.itemsCompleted', 'items completed')}
              </span>
            </div>
            <div className="text-end">
              <div className="flex items-center gap-2 mb-1">
                <Calculator className="w-4 h-4 text-[#c9a962]" />
                <span className="text-sm text-slate-400">{t('vendorPortal.totalQuotation', 'Total Quotation')}</span>
              </div>
              <p className="text-3xl font-bold text-[#c9a962]">
                {mockRFQDetail.currency} {totalQuotation.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* General Notes */}
      <Card header={<h3 className="text-lg font-semibold text-slate-100">{t('vendorPortal.generalNotes', 'General Notes')}</h3>}>
        <Textarea
          placeholder={t('vendorPortal.notesPlaceholder', 'Add any general notes, terms, or conditions for your quotation...')}
          value={generalNotes}
          onChange={(e) => setGeneralNotes(e.target.value)}
          rows={4}
        />
      </Card>

      {/* Submit Confirmation Modal */}
      <Modal
        isOpen={confirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        title={t('vendorPortal.confirmSubmit', 'Confirm Submission')}
        footer={
          <div className="flex items-center justify-end gap-2">
            <Button variant="secondary" onClick={() => setConfirmModalOpen(false)}>
              {t('common.cancel', 'Cancel')}
            </Button>
            <Button icon={<Send className="w-4 h-4" />} onClick={handleSubmit}>
              {t('vendorPortal.confirmSubmitBtn', 'Confirm & Submit')}
            </Button>
          </div>
        }
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-300">
            {t('vendorPortal.submitWarning', 'You are about to submit your quotation. Once submitted, you cannot modify your response. Please review all item pricing before confirming.')}
          </p>
          <div className="p-3 bg-[#252540] rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">{t('vendorPortal.totalQuotation', 'Total Quotation')}</span>
              <span className="text-lg font-bold text-[#c9a962]">
                {mockRFQDetail.currency} {totalQuotation.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm text-slate-400">{t('rfq.items', 'Items')}</span>
              <span className="text-sm text-slate-200">{responses.length}</span>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default VendorRfqResponse;
