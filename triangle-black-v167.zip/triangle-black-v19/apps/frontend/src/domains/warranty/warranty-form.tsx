import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate, useParams } from 'react-router-dom';
import { Save } from 'lucide-react';
import { Button, Input, Select, Textarea, Card, PageHeader } from '@/shared/components/ui';
import { apiPost, apiPut } from '@/api/client';

const WarrantyForm: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;

  const [loading, setLoading] = useState(false);
  const [itemId, setItemId] = useState('');
  const [itemName, setItemName] = useState('');
  const [category, setCategory] = useState('');
  const [hotelId, setHotelId] = useState('');
  const [vendor, setVendor] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [terms, setTerms] = useState('');
  const [coverage, setCoverage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = { itemId, itemName, category, hotelId, vendor, startDate, endDate, terms, coverage };
      if (isEdit) {
        await apiPut(`/warranties/${id}`, payload);
      } else {
        await apiPost('/warranties', payload);
      }
      navigate('/warranties');
    } catch {
      // handle error
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title={isEdit ? t('common.edit') : t('common.create') + ' ' + t('warranty.title').toLowerCase()}
        showBack
        backTo="/warranties"
        actions={
          <Button type="submit" form="warranty-form" loading={loading} icon={<Save className="w-4 h-4" />}>
            {t('common.save')}
          </Button>
        }
      />
      <form id="warranty-form" onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label={t('common.name')} value={itemName} onChange={(e) => setItemName(e.target.value)} placeholder="Warranty item name" required />
            <Input label="Item Reference" value={itemId} onChange={(e) => setItemId(e.target.value)} placeholder="Serial / PO reference" />
            <Select label={t('common.type')} options={[
              {value:'',label:'Select category'},
              {value:'HVAC',label:'HVAC'},
              {value:'ELECTRICAL',label:'Electrical'},
              {value:'PLUMBING',label:'Plumbing'},
              {value:'FIRE_PROTECTION',label:'Fire Protection'},
              {value:'ELEVATOR',label:'Elevator'},
              {value:'GENSET',label:'Generator'},
            ]} value={category} onChange={(e) => setCategory(e.target.value)} required />
            <Input label="Vendor" value={vendor} onChange={(e) => setVendor(e.target.value)} placeholder="Vendor / Supplier name" />
            <Input label="Hotel" value={hotelId} onChange={(e) => setHotelId(e.target.value)} placeholder="Select hotel" />
            <div className="grid grid-cols-2 gap-3">
              <Input label="Start Date" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
              <Input label="End Date" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} required />
            </div>
          </div>
        </Card>
        <Card>
          <Textarea label="Warranty Terms" value={terms} onChange={(e) => setTerms(e.target.value)} placeholder="Detailed warranty terms and conditions" className="min-h-[120px]" />
          <div className="mt-4">
            <Textarea label="Coverage Details" value={coverage} onChange={(e) => setCoverage(e.target.value)} placeholder="What is covered, exclusions, claim process" className="min-h-[100px]" />
          </div>
        </Card>
      </form>
    </div>
  );
};

export default WarrantyForm;