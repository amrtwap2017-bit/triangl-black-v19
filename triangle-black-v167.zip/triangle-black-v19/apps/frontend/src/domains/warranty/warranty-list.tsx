import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Plus, Bell, BellOff } from 'lucide-react';
import { PageHeader, SearchBar, Button, Card, Select, Table, Badge, StatusBadge } from '@/shared/components/ui';
import { useApi, usePagination } from '@/shared/hooks';
import type { Column } from '@/shared/types';

interface Warranty {
  id: string;
  item: string;
  category: string;
  hotel: { name: string };
  vendor: string;
  startDate: string;
  endDate: string;
  status: string;
}

const statusVariant: Record<string, 'success' | 'warning' | 'danger' | 'info'> = {
  ACTIVE: 'success',
  EXPIRING: 'warning',
  EXPIRED: 'danger',
  CLAIMED: 'info',
};

const WarrantyList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const { page, limit, setPage, paginationParams } = usePagination(10);

  const { data: warranties, isLoading, meta } = useApi<Warranty>(
    ['warranties'], '/warranties',
    { ...paginationParams(), search, status: statusFilter, category: categoryFilter }
  );

  const isExpiringSoon = (endDate: string) => {
    const daysLeft = (new Date(endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
    return daysLeft > 0 && daysLeft <= 30;
  };

  const columns: Column<Warranty>[] = useMemo(() => [
    { key: 'item', header: t('common.name'), sortable: true, render: (_, row) => (
      <div>
        <p className="font-medium text-slate-100">{row.item}</p>
        <p className="text-xs text-slate-500">{row.vendor}</p>
      </div>
    )},
    { key: 'category', header: t('common.type'), width: 'w-32', render: (v) => <Badge>{String(v)}</Badge> },
    { key: 'hotel', header: 'Hotel', render: (_, row) => row.hotel?.name || '—' },
    { key: 'startDate', header: 'Start', width: 'w-28', render: (v) => new Date(v as string).toLocaleDateString() },
    { key: 'endDate', header: 'End', width: 'w-28', render: (v) => {
      const d = new Date(v as string);
      const expiring = isExpiringSoon(v as string);
      return (
        <span className={expiring ? 'text-red-400 font-medium' : ''}>
          {d.toLocaleDateString()}
          {expiring && <Badge variant="danger" className="ms-2">{t('warranty.expiringSoon')}</Badge>}
        </span>
      );
    }},
    { key: 'status', header: t('common.status'), width: 'w-28', render: (v) => <StatusBadge status={String(v)} /> },
    { key: 'actions', header: t('common.actions'), width: 'w-24', render: (_, row) => (
      <Button variant="ghost" size="sm" icon={<Bell className="w-3.5 h-3.5" />} onClick={(e) => { e.stopPropagation(); }}>
        {t('warranty.sendReminder')}
      </Button>
    )},
  ], [t]);

  return (
    <div className="space-y-6">
      <PageHeader title={t('warranty.title')} actions={
        <Button icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/warranties/new')}>{t('common.create')}</Button>
      )} />
      <Card noPadding>
        <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-[#2d2d4a]">
          <div className="flex-1"><SearchBar onSearch={setSearch} /></div>
          <Select options={[
            {value:'',label:t('common.all')},
            {value:'ACTIVE',label:t('warranty.active')},
            {value:'EXPIRING',label:t('warranty.expiring')},
            {value:'EXPIRED',label:t('warranty.expired')},
            {value:'CLAIMED',label:t('warranty.claimed')},
          ]} value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)} />
          <Select options={[
            {value:'',label:t('common.all')},
            {value:'HVAC',label:'HVAC'},
            {value:'ELECTRICAL',label:'Electrical'},
            {value:'PLUMBING',label:'Plumbing'},
            {value:'FIRE_PROTECTION',label:'Fire Protection'},
          ]} value={categoryFilter} onChange={(e)=>setCategoryFilter(e.target.value)} />
        </div>
        <Table columns={columns} data={warranties} keyExtractor={(w)=>w.id} isLoading={isLoading} total={meta.total} page={meta.page} limit={meta.limit} totalPages={meta.totalPages} onPageChange={setPage} onRowClick={(w)=>navigate(`/warranties/${w.id}`)} />
      </Card>
    </div>
  );
};

export default WarrantyList;