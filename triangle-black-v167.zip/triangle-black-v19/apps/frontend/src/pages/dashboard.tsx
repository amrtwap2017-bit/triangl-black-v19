import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import {
  DollarSign,
  HardHat,
  Target,
  FileText,
  AlertTriangle,
  Trophy,
  Plus,
  ClipboardList,
  MapPin,
  Building2,
} from 'lucide-react';
import { Card } from '@/shared/components/ui/card';
import { Button } from '@/shared/components/ui/button';
import { KpiCards } from '@/shared/components/charts/kpi-cards';
import { RevenueChart } from '@/shared/components/charts/revenue-chart';
import { PipelineChart } from '@/shared/components/charts/pipeline-chart';
import { PageHeader } from '@/shared/components/ui/page-header';
import type { RevenueData, PipelineData } from '@/shared/types';

const mockRevenue: RevenueData[] = [
  { month: 'Jan', revenue: 450000, cost: 320000, profit: 130000 },
  { month: 'Feb', revenue: 380000, cost: 270000, profit: 110000 },
  { month: 'Mar', revenue: 520000, cost: 360000, profit: 160000 },
  { month: 'Apr', revenue: 490000, cost: 340000, profit: 150000 },
  { month: 'May', revenue: 610000, cost: 410000, profit: 200000 },
  { month: 'Jun', revenue: 580000, cost: 390000, profit: 190000 },
];

const mockPipeline: PipelineData[] = [
  { stage: 'LEAD', count: 12, value: 2400000 },
  { stage: 'QUALIFIED', count: 8, value: 3200000 },
  { stage: 'PROPOSAL_SENT', count: 5, value: 1800000 },
  { stage: 'NEGOTIATION', count: 3, value: 1500000 },
  { stage: 'VERBAL_AGREEMENT', count: 2, value: 800000 },
  { stage: 'CONTRACT_SIGNED', count: 1, value: 500000 },
];

const recentActivity = [
  { id: '1', text: 'Proposal PRO-2024-042 submitted to Burj Al Arab', time: '2h ago', type: 'proposal' },
  { id: '2', text: 'Emergency case EMC-2024-018 resolved at Ritz Carlton', time: '4h ago', type: 'emergency' },
  { id: '3', text: 'New site visit scheduled for Atlantis The Royal', time: '5h ago', type: 'visit' },
  { id: '4', text: 'Project PRJ-2024-033 milestone "Phase 2 Completion" achieved', time: '1d ago', type: 'project' },
  { id: '5', text: 'Vendor evaluation completed for Al Fardan Trading', time: '1d ago', type: 'vendor' },
];

const DashboardPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const kpiCards = [
    { icon: <DollarSign className="w-5 h-5" />, label: t('dashboard.totalRevenue'), value: '$3.03M', change: 12.5, prefix: '$', suffix: '' },
    { icon: <HardHat className="w-5 h-5" />, label: t('dashboard.activeProjects'), value: 18, change: 8 },
    { icon: <Target className="w-5 h-5" />, label: t('dashboard.openOpportunities'), value: 31, change: -5 },
    { icon: <FileText className="w-5 h-5" />, label: t('dashboard.pendingProposals'), value: 7, change: 15 },
    { icon: <AlertTriangle className="w-5 h-5" />, label: t('dashboard.activeEmergencies'), value: 3, change: -33 },
    { icon: <Trophy className="w-5 h-5" />, label: t('dashboard.winRate'), value: '68%', change: 5, suffix: '%' },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('dashboard.title')}
        actions={
          <div className="flex gap-2">
            <Button size="sm" icon={<Plus className="w-4 h-4" />} onClick={() => navigate('/requests/new')}>
              {t('requests.newRequest')}
            </Button>
          </div>
        }
      />

      <KpiCards cards={kpiCards} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card header={<h3 className="font-semibold text-slate-100">{t('dashboard.revenueChart')}</h3>}>
            <RevenueChart data={mockRevenue} />
          </Card>
        </div>
        <div>
          <Card header={<h3 className="font-semibold text-slate-100">{t('dashboard.pipelineSummary')}</h3>}>
            <PipelineChart data={mockPipeline} />
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card header={<h3 className="font-semibold text-slate-100">{t('dashboard.recentActivity')}</h3>}>
          <div className="divide-y divide-[#2d2d4a]/50">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="py-3 flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-[#c9a962] mt-2 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-200">{activity.text}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card header={<h3 className="font-semibold text-slate-100">{t('dashboard.quickActions')}</h3>}>
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => navigate('/requests/new')} className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#252540] hover:bg-[#2d2d4a] transition-colors">
              <ClipboardList className="w-6 h-6 text-[#c9a962]" />
              <span className="text-sm text-slate-300">{t('requests.newRequest')}</span>
            </button>
            <button onClick={() => navigate('/site-visits/new')} className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#252540] hover:bg-[#2d2d4a] transition-colors">
              <MapPin className="w-6 h-6 text-[#c9a962]" />
              <span className="text-sm text-slate-300">{t('siteVisits.schedule')}</span>
            </button>
            <button onClick={() => navigate('/proposals/new')} className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#252540] hover:bg-[#2d2d4a] transition-colors">
              <FileText className="w-6 h-6 text-[#c9a962]" />
              <span className="text-sm text-slate-300">{t('proposals.create')}</span>
            </button>
            <button onClick={() => navigate('/hotels/new')} className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#252540] hover:bg-[#2d2d4a] transition-colors">
              <Building2 className="w-6 h-6 text-[#c9a962]" />
              <span className="text-sm text-slate-300">{t('hotels.addHotel')}</span>
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default DashboardPage;