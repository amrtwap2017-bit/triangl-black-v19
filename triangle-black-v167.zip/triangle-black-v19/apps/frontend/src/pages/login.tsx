import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import { Mail, Lock, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { Input } from '@/shared/components/ui/input';
import { Button } from '@/shared/components/ui/button';
import { Card } from '@/shared/components/ui/card';
import { useAuthStore } from '@/shared/hooks/useAuth';

const loginSchema = z.object({
  email: z.email('Invalid email'),
  password: z.string().min(1, 'Password is required'),
});

type LoginForm = z.infer<typeof loginSchema>;

const LoginPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const login = useAuthStore((s) => s.login);
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginForm) => {
    setLoading(true);
    try {
      await login(data.email, data.password);
      toast.success(t('common.success'));
      navigate('/dashboard');
    } catch {
      toast.error(t('common.error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-[#2d2d4a]">
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-xl font-bold text-slate-100">{t('auth.welcomeBack')}</h2>
          <p className="text-sm text-slate-400 mt-1">{t('auth.login')}</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input
            label={t('auth.email')}
            type="email"
            placeholder="admin@triangleblack.com"
            icon={<Mail className="w-4 h-4" />}
            error={errors.email?.message}
            {...register('email')}
          />

          <Input
            label={t('auth.password')}
            type="password"
            placeholder="••••••••"
            icon={<Lock className="w-4 h-4" />}
            error={errors.password?.message}
            {...register('password')}
          />

          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm text-slate-400 cursor-pointer">
              <input type="checkbox" className="rounded border-[#2d2d4a] bg-[#1a1a2e] text-[#c9a962] focus:ring-[#c9a962]/50" />
              {t('auth.rememberMe')}
            </label>
            <button type="button" className="text-sm text-[#c9a962] hover:underline">
              {t('auth.forgotPassword')}
            </button>
          </div>

          <Button type="submit" className="w-full" size="lg" loading={loading}>
            {t('auth.login')}
          </Button>
        </form>

        <p className="text-center text-sm text-slate-400">
          {t('auth.register')}{' '}
          <button
            onClick={() => navigate('/register')}
            className="text-[#c9a962] hover:underline font-medium"
          >
            {t('auth.register')}
          </button>
        </p>
      </div>
    </Card>
  );
};

export default LoginPage;