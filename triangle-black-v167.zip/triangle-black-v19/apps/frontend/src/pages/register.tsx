import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useForm } from 'react-hook-form';
import { z } from 'zod/v4';
import { zodResolver } from '@hookform/resolvers/zod';
import { Mail, Lock, User, Phone, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { Input } from '@/shared/components/ui/input';
import { Button } from '@/shared/components/ui/button';
import { Card } from '@/shared/components/ui/card';
import { apiPost } from '@/api/client';
import { endpoints } from '@/api/endpoints';

const registerSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.email('Invalid email'),
  phone: z.string().optional(),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  confirmPassword: z.string().min(1, 'Please confirm password'),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
});

type RegisterForm = z.infer<typeof registerSchema>;

const RegisterPage: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
  });

  const onSubmit = async (data: RegisterForm) => {
    setLoading(true);
    try {
      await apiPost(endpoints.auth.register, {
        name: data.name,
        email: data.email,
        phone: data.phone,
        password: data.password,
      });
      toast.success(t('common.success'));
      navigate('/login');
    } catch {
      toast.error(t('common.error'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-[#2d2d4a]">
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-xl font-bold text-slate-100">{t('auth.register')}</h2>
          <p className="text-sm text-slate-400 mt-1">Create your TRIANGLE BLACK account</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input
            label={t('common.name')}
            placeholder="John Doe"
            icon={<User className="w-4 h-4" />}
            error={errors.name?.message}
            {...register('name')}
          />

          <Input
            label={t('auth.email')}
            type="email"
            placeholder="admin@triangleblack.com"
            icon={<Mail className="w-4 h-4" />}
            error={errors.email?.message}
            {...register('email')}
          />

          <Input
            label={t('administration.phone')}
            placeholder="+971 50 000 0000"
            icon={<Phone className="w-4 h-4" />}
            error={errors.phone?.message}
            {...register('phone')}
          />

          <Input
            label={t('auth.password')}
            type="password"
            placeholder="••••••••"
            icon={<Lock className="w-4 h-4" />}
            error={errors.password?.message}
            {...register('password')}
          />

          <Input
            label="Confirm Password"
            type="password"
            placeholder="••••••••"
            icon={<Lock className="w-4 h-4" />}
            error={errors.confirmPassword?.message}
            {...register('confirmPassword')}
          />

          <Button type="submit" className="w-full" size="lg" loading={loading}>
            {t('auth.register')}
          </Button>
        </form>

        <p className="text-center text-sm text-slate-400">
          Already have an account?{' '}
          <button
            onClick={() => navigate('/login')}
            className="text-[#c9a962] hover:underline font-medium"
          >
            {t('auth.login')}
          </button>
        </p>
      </div>
    </Card>
  );
};

export default RegisterPage;