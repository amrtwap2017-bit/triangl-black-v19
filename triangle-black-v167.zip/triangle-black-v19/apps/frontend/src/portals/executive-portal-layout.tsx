import React from 'react';
import { Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Building2,
  Target,
  BarChart3,
  TrendingUp,
  Radar,
} from 'lucide-react';
import { PortalLayout } from './portal-layout';

const navItems = [
  { path: '/dashboard', key: 'dashboard', icon: LayoutDashboard },
  { path: '/hotels', key: 'hotels', icon: Building2 },
  { path: '/opportunities', key: 'opportunities', icon: Target },
  { path: '/margin', key: 'marginAnalytics', icon: BarChart3 },
  { path: '/relationships', key: 'relationships', icon: TrendingUp },
  { path: '/opportunity-radar', key: 'opportunityRadar', icon: Radar },
  { path: '/insights', key: 'insights', icon: LayoutDashboard },
];

const ExecutivePortalLayout: React.FC = () => {
  return (
    <PortalLayout
      portalName="EXECUTIVE"
      portalPrefix="/executive"
      navItems={navItems}
      accentColor="#a855f7"
    />
  );
};

export default ExecutivePortalLayout;