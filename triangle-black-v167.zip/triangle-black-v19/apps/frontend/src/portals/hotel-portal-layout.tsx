import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import {
  LayoutDashboard,
  ClipboardList,
  HardHat,
  AlertTriangle,
  FolderOpen,
  BookOpen,
} from 'lucide-react';
import { PortalLayout } from './portal-layout';

const navItems = [
  { path: '/dashboard', key: 'dashboard', icon: LayoutDashboard },
  { path: '/requests', key: 'requests', icon: ClipboardList },
  { path: '/projects', key: 'projects', icon: HardHat },
  { path: '/emergency', key: 'emergency', icon: AlertTriangle },
  { path: '/documents', key: 'documents', icon: FolderOpen },
  { path: '/knowledge-hub', key: 'knowledgeHub', icon: BookOpen },
];

const HotelPortalLayout: React.FC = () => {
  return (
    <PortalLayout
      portalName="HOTEL PORTAL"
      portalPrefix="/hotel"
      navItems={navItems}
      accentColor="#3b82f6"
    >
      <Outlet />
    </PortalLayout>
  );
};

export default HotelPortalLayout;