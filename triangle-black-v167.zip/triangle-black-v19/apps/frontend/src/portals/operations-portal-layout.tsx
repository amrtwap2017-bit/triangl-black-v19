import React from 'react';
import { Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Building2,
  ClipboardList,
  MapPin,
  Target,
  FileText,
  HardHat,
  ShoppingCart,
  Store,
  AlertTriangle,
  FolderOpen,
  PenTool,
  BookOpen,
  Shield,
  BarChart3,
  Bot,
  Sparkles,
} from 'lucide-react';
import { PortalLayout } from './portal-layout';

const navItems = [
  { path: '/dashboard', key: 'dashboard', icon: LayoutDashboard },
  { path: '/hotels', key: 'hotels', icon: Building2 },
  { path: '/requests', key: 'requests', icon: ClipboardList },
  { path: '/site-visits', key: 'siteVisits', icon: MapPin },
  { path: '/opportunities', key: 'opportunities', icon: Target },
  { path: '/proposals', key: 'proposals', icon: FileText },
  { path: '/projects', key: 'projects', icon: HardHat },
  { path: '/procurement', key: 'procurement', icon: ShoppingCart },
  { path: '/vendors', key: 'vendors', icon: Store },
  { path: '/emergency', key: 'emergency', icon: AlertTriangle },
  { path: '/documents', key: 'documents', icon: FolderOpen },
  { path: '/drawings', key: 'drawings', icon: PenTool },
  { path: '/knowledge-hub', key: 'knowledgeHub', icon: BookOpen },
  { path: '/warranties', key: 'warranties', icon: Shield },
  { path: '/insights', key: 'insights', icon: BarChart3 },
  { path: '/ai', key: 'aiChat', icon: Sparkles },
  { path: '/assistant', key: 'assistant', icon: Bot },
];

const OperationsPortalLayout: React.FC = () => {
  return (
    <PortalLayout
      portalName="OPERATIONS"
      portalPrefix="/operations"
      navItems={navItems}
    />
  );
};

export default OperationsPortalLayout;