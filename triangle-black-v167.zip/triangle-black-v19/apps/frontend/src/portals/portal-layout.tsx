import { Outlet } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { clsx } from 'clsx';
import { NavLink, useLocation } from 'react-router-dom';
import { ChevronLeft, Triangle } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Header } from '@/shared/components/layout/header';
import { useAppStore } from '@/store';
import { useEffect } from 'react';

interface NavItem {
  path: string;
  key: string;
  icon: LucideIcon;
}

interface PortalLayoutProps {
  portalName: string;
  portalPrefix: string;
  navItems: NavItem[];
  accentColor?: string;
}

export const PortalLayout: React.FC<PortalLayoutProps> = ({
  portalName,
  portalPrefix,
  navItems,
  accentColor = '#c9a962',
}) => {
  const { t, i18n } = useTranslation();
  const { sidebarCollapsed, toggleSidebar } = useAppStore();
  const isRtl = i18n.language === 'ar';
  const location = useLocation();

  useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
  }, [isRtl]);

  const marginInline = sidebarCollapsed ? '68px' : '256px';

  return (
    <div className={clsx('min-h-screen bg-[#0f0f1a]')} dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Portal Sidebar */}
      <aside
        className={clsx(
          'fixed top-0 h-full bg-[#1a1a2e] border-e border-[#2d2d4a] z-40 flex flex-col transition-all duration-300',
          sidebarCollapsed ? 'w-[68px]' : 'w-64',
          isRtl ? 'right-0 border-e-0 border-s' : 'left-0'
        )}
      >
        {/* Logo & Portal Name */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-[#2d2d4a]">
          <div className="flex items-center gap-2.5 min-w-0">
            <Triangle className="w-8 h-8 shrink-0" style={{ color: accentColor }} />
            {!sidebarCollapsed && (
              <div className="min-w-0">
                <h1 className="text-sm font-bold tracking-wider truncate" style={{ color: accentColor }}>
                  {portalName}
                </h1>
                <p className="text-[10px] text-slate-500 truncate">{t('app.tagline')}</p>
              </div>
            )}
          </div>
          <button
            onClick={toggleSidebar}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#252540] transition-colors shrink-0"
          >
            <ChevronLeft className={clsx('w-4 h-4 transition-transform', sidebarCollapsed && 'rotate-180')} />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-4 px-2 scrollbar-thin">
          <ul className="space-y-1">
            {navItems.map((item) => {
              const fullPath = `${portalPrefix}${item.path}`;
              const isActive =
                location.pathname === fullPath ||
                location.pathname.startsWith(fullPath + '/');
              return (
                <li key={item.path}>
                  <NavLink
                    to={fullPath}
                    className={clsx(
                      'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200',
                      isActive
                        ? 'font-medium'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-[#252540]'
                    )}
                    style={isActive ? { backgroundColor: `${accentColor}15`, color: accentColor } : undefined}
                    title={sidebarCollapsed ? t(`nav.${item.key}`) : undefined}
                  >
                    <item.icon className="w-5 h-5 shrink-0" />
                    {!sidebarCollapsed && (
                      <span className="truncate">{t(`nav.${item.key}`)}</span>
                    )}
                  </NavLink>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* User */}
        <div className="p-3 border-t border-[#2d2d4a]">
          {!sidebarCollapsed && (
            <div className="flex items-center gap-3 px-3 py-2">
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold" style={{ backgroundColor: `${accentColor}33`, color: accentColor }}>
                U
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-slate-200 truncate">User</p>
                <p className="text-xs text-slate-500 truncate">{portalName}</p>
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <div
        className="transition-all duration-300 hidden lg:block"
        style={{ [isRtl ? 'marginRight' : 'marginLeft']: marginInline }}
      >
        <Header />
        <main className="p-6 animate-fade-in">
          <Outlet />
        </main>
      </div>
      <div className="lg:hidden">
        <Header />
        <main className="p-4 animate-fade-in">
          <Outlet />
        </main>
      </div>
    </div>
  );
};