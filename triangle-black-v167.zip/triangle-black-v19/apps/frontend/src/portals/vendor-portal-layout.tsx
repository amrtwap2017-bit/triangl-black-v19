import React from 'react';
import { Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  Award,
  ShieldCheck,
  ShoppingCart,
} from 'lucide-react';
import { PortalLayout } from './portal-layout';

const navItems = [
  { path: '/dashboard', key: 'dashboard', icon: LayoutDashboard },
  { path: '/rfqs', key: 'requests', icon: FileText },
  { path: '/performance', key: 'vendors', icon: Award },
  { path: '/certifications', key: 'documents', icon: ShieldCheck },
  { path: '/purchase-orders', key: 'procurement', icon: ShoppingCart },
];

const VendorPortalLayout: React.FC = () => {
  return (
    <PortalLayout
      portalName="VENDOR PORTAL"
      portalPrefix="/vendor"
      navItems={navItems}
      accentColor="#22c55e"
    />
  );
};

export default VendorPortalLayout;