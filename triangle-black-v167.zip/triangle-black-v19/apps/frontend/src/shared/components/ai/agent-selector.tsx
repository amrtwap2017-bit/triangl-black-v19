import React, { useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Sparkles, Package, Wrench, DollarSign, BarChart3, TrendingUp,
  ClipboardList, Building2, ChevronDown,
} from 'lucide-react';
import { clsx } from 'clsx';

// ─── Types ─────────────────────────────────────────────────────────────

export interface AgentOption {
  id: string;
  labelKey: string;
  labelEn: string;
  labelAr: string;
  descriptionEn: string;
  descriptionAr: string;
  icon: React.ReactNode;
  color: string;
}

interface AgentSelectorProps {
  value: string;
  onChange: (agentId: string) => void;
  className?: string;
}

// ─── Agent Definitions ──────────────────────────────────────────────────

export const AGENT_OPTIONS: AgentOption[] = [
  {
    id: 'assistant',
    labelKey: 'ai.assistant',
    labelEn: 'General Assistant',
    labelAr: 'مساعد عام',
    descriptionEn: 'General-purpose AI assistant',
    descriptionAr: 'مساعد ذكاء اصطناعي عام',
    icon: <Sparkles className="w-4 h-4" />,
    color: 'text-amber-400',
  },
  {
    id: 'procurement',
    labelKey: 'ai.procurement',
    labelEn: 'Procurement',
    labelAr: 'المشتريات',
    descriptionEn: 'Procurement & purchasing assistant',
    descriptionAr: 'مساعد المشتريات والشراء',
    icon: <Package className="w-4 h-4" />,
    color: 'text-blue-400',
  },
  {
    id: 'contract',
    labelKey: 'ai.contract',
    labelEn: 'Contract',
    labelAr: 'العقود',
    descriptionEn: 'Contract management assistant',
    descriptionAr: 'مساعد إدارة العقود',
    icon: <ClipboardList className="w-4 h-4" />,
    color: 'text-purple-400',
  },
  {
    id: 'finance',
    labelKey: 'ai.finance',
    labelEn: 'Finance',
    labelAr: 'المالية',
    descriptionEn: 'Financial analysis assistant',
    descriptionAr: 'مساعد التحليل المالي',
    icon: <DollarSign className="w-4 h-4" />,
    color: 'text-green-400',
  },
  {
    id: 'engineering',
    labelKey: 'ai.engineering',
    labelEn: 'Engineering',
    labelAr: 'الهندسة',
    descriptionEn: 'Engineering & technical assistant',
    descriptionAr: 'مساعد الهندسة والفني',
    icon: <Wrench className="w-4 h-4" />,
    color: 'text-orange-400',
  },
  {
    id: 'maintenance',
    labelKey: 'ai.maintenance',
    labelEn: 'Maintenance',
    labelAr: 'الصيانة',
    descriptionEn: 'Maintenance & operations assistant',
    descriptionAr: 'مساعد الصيانة والعمليات',
    icon: <Building2 className="w-4 h-4" />,
    color: 'text-red-400',
  },
  {
    id: 'sales',
    labelKey: 'ai.sales',
    labelEn: 'Sales',
    labelAr: 'المبيعات',
    descriptionEn: 'Sales & opportunity assistant',
    descriptionAr: 'مساعد المبيعات والفرص',
    icon: <BarChart3 className="w-4 h-4" />,
    color: 'text-cyan-400',
  },
  {
    id: 'executive',
    labelKey: 'ai.executive',
    labelEn: 'Executive',
    labelAr: 'التنفيذي',
    descriptionEn: 'Executive dashboard & insights',
    descriptionAr: 'لوحة التحكم التنفيذية',
    icon: <TrendingUp className="w-4 h-4" />,
    color: 'text-yellow-400',
  },
];

// ─── Component ─────────────────────────────────────────────────────────

export function AgentSelector({ value, onChange, className }: AgentSelectorProps) {
  const { t, i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const isAr = i18n.language === 'ar';

  const selectedAgent = AGENT_OPTIONS.find(a => a.id === value) ?? AGENT_OPTIONS[0];

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (agentId: string) => {
    onChange(agentId);
    setIsOpen(false);
  };

  return (
    <div className={clsx('relative', className)} ref={dropdownRef}>
      {/* Trigger */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 bg-[#1a1a2e] border border-[#2d2d4a] rounded-lg hover:bg-[#252540] transition-colors w-full text-left"
      >
        <span className={selectedAgent.color}>{selectedAgent.icon}</span>
        <span className="text-sm text-slate-200 flex-1 truncate">
          {isAr ? selectedAgent.labelAr : selectedAgent.labelEn}
        </span>
        <ChevronDown
          className={clsx(
            'w-4 h-4 text-slate-400 transition-transform duration-200',
            isOpen && 'rotate-180',
          )}
        />
      </button>

      {/* Dropdown */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl shadow-xl shadow-black/40 z-50 overflow-hidden py-1 max-h-[300px] overflow-y-auto scrollbar-thin">
          {AGENT_OPTIONS.map(agent => {
            const isSelected = agent.id === value;
            return (
              <button
                key={agent.id}
                onClick={() => handleSelect(agent.id)}
                className={clsx(
                  'w-full flex items-center gap-3 px-3 py-2.5 transition-colors text-left',
                  isSelected
                    ? 'bg-amber-500/10 text-amber-400'
                    : 'text-slate-300 hover:bg-[#252540] hover:text-slate-100',
                )}
              >
                <span className={clsx('w-8 h-8 rounded-lg flex items-center justify-center shrink-0',
                  isSelected ? 'bg-amber-500/20' : 'bg-[#252540]'
                )}>
                  <span className={agent.color}>{agent.icon}</span>
                </span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">
                    {isAr ? agent.labelAr : agent.labelEn}
                  </div>
                  <div className="text-[10px] text-slate-500 truncate">
                    {isAr ? agent.descriptionAr : agent.descriptionEn}
                  </div>
                </div>
                {isSelected && (
                  <div className="w-2 h-2 bg-amber-400 rounded-full shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

import { useState } from 'react';

export default AgentSelector;