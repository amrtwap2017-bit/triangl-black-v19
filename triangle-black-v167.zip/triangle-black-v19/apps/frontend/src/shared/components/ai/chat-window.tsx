import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Sparkles, Minus, X, Send, Paperclip, MessageSquare,
  Package, Wrench, DollarSign, BarChart3, TrendingUp,
  ClipboardList, Building2,
} from 'lucide-react';
import { clsx } from 'clsx';

// ─── Types ─────────────────────────────────────────────────────────────

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: Date | string;
  agentType?: string;
  toolCalls?: ToolCallResult[];
  isStreaming?: boolean;
}

export interface ToolCallResult {
  id: string;
  toolName: string;
  params: Record<string, unknown>;
  result: unknown;
  status: 'success' | 'error';
}

export interface Conversation {
  id: string;
  title: string;
  agentType: string;
  messageCount: number;
  updatedAt: Date | string;
}

export interface AgentOption {
  id: string;
  labelKey: string;
  labelAr: string;
  labelEn: string;
  icon: React.ReactNode;
  color: string;
}

// ─── Agent Definitions ──────────────────────────────────────────────────

const AGENTS: AgentOption[] = [
  { id: 'assistant', labelKey: 'ai.assistant', labelEn: 'Assistant', labelAr: 'مساعد', icon: <Sparkles className="w-3.5 h-3.5" />, color: 'text-amber-400' },
  { id: 'procurement', labelKey: 'ai.procurement', labelEn: 'Procurement', labelAr: 'المشتريات', icon: <Package className="w-3.5 h-3.5" />, color: 'text-blue-400' },
  { id: 'contract', labelKey: 'ai.contract', labelEn: 'Contract', labelAr: 'العقود', icon: <ClipboardList className="w-3.5 h-3.5" />, color: 'text-purple-400' },
  { id: 'finance', labelKey: 'ai.finance', labelEn: 'Finance', labelAr: 'المالية', icon: <DollarSign className="w-3.5 h-3.5" />, color: 'text-green-400' },
  { id: 'engineering', labelKey: 'ai.engineering', labelEn: 'Engineering', labelAr: 'الهندسة', icon: <Wrench className="w-3.5 h-3.5" />, color: 'text-orange-400' },
  { id: 'maintenance', labelKey: 'ai.maintenance', labelEn: 'Maintenance', labelAr: 'الصيانة', icon: <Building2 className="w-3.5 h-3.5" />, color: 'text-red-400' },
  { id: 'sales', labelKey: 'ai.sales', labelEn: 'Sales', labelAr: 'المبيعات', icon: <BarChart3 className="w-3.5 h-3.5" />, color: 'text-cyan-400' },
  { id: 'executive', labelKey: 'ai.executive', labelEn: 'Executive', labelAr: 'التنفيذي', icon: <TrendingUp className="w-3.5 h-3.5" />, color: 'text-yellow-400' },
];

// ─── Component ─────────────────────────────────────────────────────────

interface ChatWindowProps {
  embedded?: boolean;
  onClose?: () => void;
  onSendMessage?: (message: string, agent: string) => void;
}

export function ChatWindow({ embedded = false, onClose, onSendMessage }: ChatWindowProps) {
  const { t, i18n } = useTranslation();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState('assistant');
  const [isMinimized, setIsMinimized] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const streamBufferRef = useRef('');

  const lang = i18n.language;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }
  }, [input]);

  const sendMessage = useCallback(async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input.trim(),
      createdAt: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setIsTyping(true);

    try {
      if (onSendMessage) {
        onSendMessage(input.trim(), selectedAgent);
      }

      // Simulate streaming response
      streamBufferRef.current = '';
      const agentObj = AGENTS.find(a => a.id === selectedAgent);
      const agentName = agentObj
        ? (lang === 'ar' ? agentObj.labelAr : agentObj.labelEn)
        : selectedAgent;

      const fullResponse = `Based on your query about "${input.trim()}", here is what I found:\n\nThe system has analyzed the request using the **${agentName}** agent. This would connect to the actual AI backend in production.\n\nKey findings:\n- Relevant documents have been searched\n- Data is scoped to your organization\n- Results are ready for review`;

      // Simulate token-by-token streaming
      const tokens = fullResponse.split(' ');
      for (let i = 0; i < tokens.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 20 + Math.random() * 30));
        streamBufferRef.current += (i > 0 ? ' ' : '') + tokens[i];

        setMessages(prev => {
          const updated = [...prev];
          const lastMsg = updated[updated.length - 1];
          if (lastMsg?.isStreaming) {
            updated[updated.length - 1] = {
              ...lastMsg,
              content: streamBufferRef.current,
            };
          }
          return updated;
        });
      }

      // Finalize message
      setMessages(prev => {
        const updated = [...prev];
        const streamingIdx = updated.findIndex(m => m.isStreaming);
        if (streamingIdx >= 0) {
          updated[streamingIdx] = {
            ...updated[streamingIdx],
            isStreaming: false,
            content: streamBufferRef.current,
          };
        }
        return updated;
      });
    } catch {
      setMessages(prev => [...prev, {
        id: crypto.randomUUID(),
        role: 'system',
        content: t('ai.error', 'Error connecting to AI. Please try again.'),
        createdAt: new Date(),
      }]);
    } finally {
      setIsLoading(false);
      setIsTyping(false);
      streamBufferRef.current = '';
    }
  }, [input, isLoading, selectedAgent, onSendMessage, t, lang]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const currentAgent = AGENTS.find(a => a.id === selectedAgent);

  // ─── Render ─────────────────────────────────────────────────────────

  if (isMinimized && !embedded) {
    return (
      <div className="fixed bottom-6 right-6 z-50 bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl shadow-lg px-4 py-3 flex items-center gap-3 cursor-pointer hover:bg-[#252540] transition-colors"
        onClick={() => setIsMinimized(false)}>
        {currentAgent?.icon}
        <span className="text-slate-200 text-sm font-medium">{t('ai.title', 'AI Assistant')}</span>
        {isTyping && (
          <span className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
        )}
      </div>
    );
  }

  return (
    <div className={clsx('flex bg-[#0f0f23] text-slate-200', embedded ? 'h-full' : 'h-[620px] w-[440px] rounded-2xl border border-[#2d2d4a] overflow-hidden')}>
      {/* ─── Header ───────────────────────────────────────────────── */}
      <div className={clsx('flex flex-col', embedded ? 'w-full' : 'w-full')}>
        {/* Top bar */}
        <div className="bg-[#15152a] px-4 py-3 border-b border-[#2d2d4a] flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-slate-100 font-semibold text-sm leading-tight">{t('ai.title', 'AI Assistant')}</h3>
            <p className="text-[10px] text-slate-500">v19.0 • {currentAgent ? (lang === 'ar' ? currentAgent.labelAr : currentAgent.labelEn) : ''}</p>
          </div>
          <div className="flex items-center gap-1">
            {!embedded && (
              <button onClick={() => setIsMinimized(true)} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#252540] transition-colors">
                <Minus className="w-3.5 h-3.5" />
              </button>
            )}
            {onClose && (
              <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#252540] transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Agent selector dropdown */}
        <div className="bg-[#12122a] px-3 py-2 border-b border-[#2d2d4a]/50 flex items-center gap-2 overflow-x-auto scrollbar-thin">
          {AGENTS.map(agent => (
            <button
              key={agent.id}
              onClick={() => setSelectedAgent(agent.id)}
              className={clsx(
                'flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-[11px] whitespace-nowrap transition-all duration-200 border',
                selectedAgent === agent.id
                  ? `bg-amber-500/15 text-amber-400 border-amber-500/30 shadow-sm`
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#252540] border-transparent',
              )}
            >
              <span className={selectedAgent === agent.id ? agent.color : 'text-slate-500'}>{agent.icon}</span>
              <span>{lang === 'ar' ? agent.labelAr : agent.labelEn}</span>
            </button>
          ))}
        </div>

        {/* ─── Messages ─────────────────────────────────────────── */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-8">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/5 flex items-center justify-center mb-4">
                <MessageSquare className="w-7 h-7 text-amber-400/70" />
              </div>
              <h4 className="text-slate-100 font-semibold mb-1">{t('ai.welcomeTitle', 'AI Assistant')}</h4>
              <p className="text-slate-400 text-xs max-w-xs mb-5 leading-relaxed">
                {t('ai.copilotWelcome', 'Ask me anything about your projects, documents, vendors, and more...')}
              </p>
              <div className="grid grid-cols-2 gap-2 w-full max-w-sm">
                {[
                  t('ai.suggestion1', 'Show all overdue RFQs'),
                  t('ai.suggestion2', 'Generate vendor comparison'),
                  t('ai.suggestion3', 'Analyze hotel maintenance'),
                  t('ai.suggestion4', 'Show pipeline forecast'),
                ].map((s, i) => (
                  <button
                    key={i}
                    onClick={() => { setInput(s); textareaRef.current?.focus(); }}
                    className="text-left text-[11px] text-slate-300 bg-[#1a1a2e] hover:bg-[#252540] p-2.5 rounded-lg transition-colors border border-[#2d2d4a] leading-snug"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map(msg => (
              <MessageBubble key={msg.id} message={msg} isStreaming={msg.isStreaming} />
            ))
          )}

          {isTyping && !messages.some(m => m.isStreaming) && (
            <div className="flex justify-start">
              <div className="bg-[#1a1a2e] border border-[#2d2d4a] text-slate-400 rounded-xl rounded-bl-sm px-4 py-3 text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* ─── Input Area ───────────────────────────────────────── */}
        <div className="p-3 border-t border-[#2d2d4a] bg-[#15152a]">
          <div className="flex items-end gap-2">
            <button
              className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-[#252540] transition-colors shrink-0"
              title={t('ai.attachFile', 'Attach file')}
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={t('ai.typeMessage', 'Type a message...')}
                rows={1}
                className="w-full bg-[#1a1a2e] text-slate-200 placeholder-slate-500 rounded-xl px-3.5 py-2.5 text-sm border border-[#2d2d4a] focus:border-amber-500/50 focus:outline-none focus:ring-1 focus:ring-amber-500/20 resize-none max-h-[120px] scrollbar-thin transition-colors"
              />
            </div>

            <button
              onClick={sendMessage}
              disabled={!input.trim() || isLoading}
              className={clsx(
                'p-2.5 rounded-xl transition-all duration-200 shrink-0',
                input.trim() && !isLoading
                  ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-lg shadow-amber-500/20'
                  : 'bg-[#252540] text-slate-500 cursor-not-allowed',
              )}
              aria-label={t('ai.send', 'Send')}
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
          <p className="text-[9px] text-slate-600 text-center mt-1.5">
            {t('ai.disclaimer', 'AI responses may contain errors. Verify critical information.')}
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Inline MessageBubble (simplified — full version is separate) ──────

function MessageBubble({ message, isStreaming }: { message: ChatMessage; isStreaming?: boolean }) {
  const isUser = message.role === 'user';
  const isSystem = message.role === 'system';

  return (
    <div className={clsx('flex', isUser ? 'justify-end' : 'justify-start')}>
      <div
        className={clsx(
          'max-w-[80%] rounded-xl px-4 py-2.5 text-sm leading-relaxed',
          isUser
            ? 'bg-amber-500/15 text-amber-50 rounded-br-sm border border-amber-500/20'
            : isSystem
              ? 'bg-red-500/10 text-red-300 rounded-bl-sm border border-red-500/20'
              : 'bg-[#1a1a2e] text-slate-200 border border-[#2d2d4a] rounded-bl-sm',
          isStreaming && 'animate-pulse-subtle',
        )}
      >
        {message.agentType && (
          <span className="text-[10px] text-amber-500 block mb-1 font-medium uppercase tracking-wider">
            {message.agentType}
          </span>
        )}

        {/* Content with basic markdown rendering */}
        <div className="prose prose-invert prose-sm max-w-none">
          {message.content.split('\n').map((line, i) => {
            // Bold
            const rendered = line.replace(/\*\*(.*?)\*\*/g, '<strong class="text-slate-100 font-semibold">$1</strong>');
            // Code
            const withCode = rendered.replace(/`([^`]+)`/g, '<code class="bg-[#252540] px-1.5 py-0.5 rounded text-amber-300 text-xs font-mono">$1</code>');
            // List items
            if (line.startsWith('- ')) {
              return <p key={i} className="ml-2" dangerouslySetInnerHTML={{ __html: '• ' + withCode.slice(2) }} />;
            }
            return <p key={i} className="whitespace-pre-wrap" dangerouslySetInnerHTML={{ __html: withCode || '&nbsp;' }} />;
          })}
        </div>

        {/* Tool calls */}
        {message.toolCalls && message.toolCalls.length > 0 && (
          <ToolCallSection toolCalls={message.toolCalls} />
        )}

        {/* Timestamp */}
        <div className="text-[9px] text-slate-500 mt-1.5">
          {typeof message.createdAt === 'string'
            ? new Date(message.createdAt).toLocaleTimeString()
            : message.createdAt.toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
}

// ─── Tool Call Section ─────────────────────────────────────────────────

function ToolCallSection({ toolCalls }: { toolCalls: ToolCallResult[] }) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  return (
    <div className="mt-2 space-y-1.5">
      {toolCalls.map(tc => (
        <div key={tc.id} className="bg-[#252540]/50 rounded-lg border border-[#3d3d5a] overflow-hidden">
          <button
            onClick={() => setExpanded(prev => ({ ...prev, [tc.id]: !prev[tc.id] }))}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-[#2d2d4a] transition-colors"
          >
            <span className={clsx('w-1.5 h-1.5 rounded-full', tc.status === 'success' ? 'bg-green-400' : 'bg-red-400')} />
            <span className="font-mono text-amber-400">{tc.toolName}</span>
            <span className="text-slate-500 flex-1 text-right">▼</span>
          </button>
          {expanded[tc.id] && (
            <div className="px-3 pb-2 space-y-1">
              <div className="text-[10px] text-slate-500">Params:</div>
              <pre className="text-[10px] text-slate-400 bg-[#0f0f23] p-2 rounded overflow-x-auto">
                {JSON.stringify(tc.params, null, 2)}
              </pre>
              <div className="text-[10px] text-slate-500">Result:</div>
              <pre className="text-[10px] text-slate-400 bg-[#0f0f23] p-2 rounded overflow-x-auto max-h-32">
                {JSON.stringify(tc.result, null, 2)}
              </pre>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

export default ChatWindow;