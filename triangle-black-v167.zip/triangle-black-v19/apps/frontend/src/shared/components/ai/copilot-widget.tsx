import React, { useEffect, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Sparkles, X, MessageSquare, Minus } from 'lucide-react';

// ─── Types ─────────────────────────────────────────────────────────────

interface CopilotState {
  isOpen: boolean;
  unreadCount: number;
}

interface UseCopilotStore {
  isOpen: boolean;
  unreadCount: number;
  toggle: () => void;
  open: () => void;
  close: () => void;
  markRead: () => void;
}

// Lightweight Zustand-like store using a module-level singleton
let store: CopilotState = {
  isOpen: typeof window !== 'undefined'
    ? localStorage.getItem('tb-copilot-open') === 'true'
    : false,
  unreadCount: 0,
};

const listeners = new Set<() => void>();

function notify() {
  listeners.forEach(l => l());
}

export function useCopilotStore(): UseCopilotStore {
  const [state, setState] = React.useState(store);

  useEffect(() => {
    const listener = () => setState({ ...store });
    listeners.add(listener);
    return () => { listeners.delete(listener); };
  }, []);

  return {
    isOpen: state.isOpen,
    unreadCount: state.unreadCount,
    toggle: useCallback(() => {
      store.isOpen = !store.isOpen;
      if (store.isOpen) store.unreadCount = 0;
      localStorage.setItem('tb-copilot-open', String(store.isOpen));
      notify();
    }, []),
    open: useCallback(() => {
      store.isOpen = true;
      store.unreadCount = 0;
      localStorage.setItem('tb-copilot-open', 'true');
      notify();
    }, []),
    close: useCallback(() => {
      store.isOpen = false;
      localStorage.setItem('tb-copilot-open', 'false');
      notify();
    }, []),
    markRead: useCallback(() => {
      store.unreadCount = 0;
      notify();
    }, []),
  };
}

// ─── Component ─────────────────────────────────────────────────────────

export function CopilotWidget() {
  const { t } = useTranslation();
  const { isOpen, unreadCount, toggle, close } = useCopilotStore();

  return (
    <>
      {/* Floating FAB Button */}
      {!isOpen && (
        <button
          onClick={toggle}
          className="fixed bottom-6 right-6 z-50 group relative"
          aria-label={t('ai.toggleCopilot', 'Toggle AI Copilot')}
        >
          {/* Animated pulse ring */}
          <span className="absolute inset-0 rounded-full bg-amber-500/40 animate-ping" />
          <span className="absolute inset-0 rounded-full bg-amber-500/20 scale-110" />
          <span className="relative flex items-center justify-center w-14 h-14 bg-gradient-to-br from-amber-500 to-amber-600 text-white rounded-full shadow-lg shadow-amber-500/25 hover:shadow-amber-500/40 transition-all duration-300 hover:scale-110 active:scale-95">
            <Sparkles className="w-6 h-6" />
          </span>

          {/* Unread badge */}
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center shadow-lg">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>
      )}

      {/* Chat Window Container */}
      {isOpen && (
        <div
          className="fixed bottom-6 right-6 z-50 w-[440px] max-h-[620px] bg-[#1a1a2e] border border-[#2d2d4a] rounded-2xl shadow-2xl shadow-black/40 flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 fade-in duration-300"
        >
          {/* Pass close handler to ChatWindow via data attribute — ChatWindow reads the store */}
          <button
            onClick={close}
            className="absolute top-3 right-3 z-10 p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#252540] transition-colors"
            aria-label="Close copilot"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Render children — the actual chat content is in ChatWindow */}
          <div className="h-full">
            <ChatPlaceholder />
          </div>
        </div>
      )}
    </>
  );
}

// ─── Inline placeholder — the real ChatWindow is rendered via route ───

function ChatPlaceholder() {
  const { t } = useTranslation();
  const { close } = useCopilotStore();

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="bg-[#15152a] p-4 border-b border-[#2d2d4a] flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center">
          <Sparkles className="w-4 h-4 text-amber-400" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-slate-100 font-semibold text-sm">{t('ai.title', 'AI Assistant')}</h3>
          <p className="text-[10px] text-amber-400">v19.0</p>
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 p-6 flex flex-col items-center justify-center text-center">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 flex items-center justify-center mb-4">
          <MessageSquare className="w-8 h-8 text-amber-400" />
        </div>
        <h4 className="text-slate-100 font-semibold mb-2">{t('ai.welcomeTitle', 'AI Assistant')}</h4>
        <p className="text-slate-400 text-sm max-w-xs mb-6">
          {t('ai.copilotWelcome', 'Ask me anything about your projects, documents, vendors, and more...')}
        </p>
        <div className="grid grid-cols-1 gap-2 w-full max-w-sm">
          {[
            t('ai.suggestion1', 'Show all overdue RFQs'),
            t('ai.suggestion2', 'Generate vendor comparison'),
            t('ai.suggestion3', 'Analyze hotel maintenance issues'),
            t('ai.suggestion4', 'Show pipeline forecast'),
          ].map((s, i) => (
            <button
              key={i}
              onClick={close}
              className="text-left text-xs text-slate-300 bg-[#252540] hover:bg-[#2d2d4a] p-3 rounded-lg transition-colors border border-[#3d3d5a]"
            >
              {s}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default CopilotWidget;