import React, { useState } from 'react';
import { Copy, Check, User, Bot, AlertTriangle } from 'lucide-react';
import { clsx } from 'clsx';
import type { ChatMessage, ToolCallResult } from './chat-window';

// ─── Props ─────────────────────────────────────────────────────────────

interface MessageBubbleProps {
  message: ChatMessage;
  isStreaming?: boolean;
}

// ─── Component ─────────────────────────────────────────────────────────

export function MessageBubble({ message, isStreaming }: MessageBubbleProps) {
  const [copiedBlock, setCopiedBlock] = useState<string | null>(null);
  const [expandedTools, setExpandedTools] = useState<Record<string, boolean>>({});

  const isUser = message.role === 'user';
  const isSystem = message.role === 'system';

  const handleCopyCode = (code: string, blockId: string) => {
    navigator.clipboard.writeText(code);
    setCopiedBlock(blockId);
    setTimeout(() => setCopiedBlock(null), 2000);
  };

  return (
    <div className={clsx('flex gap-2.5', isUser ? 'justify-end' : 'justify-start')}>
      {/* Avatar */}
      {!isUser && (
        <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5">
          {isSystem ? (
            <AlertTriangle className="w-4 h-4 text-red-400" />
          ) : (
            <Bot className="w-4 h-4 text-amber-400" />
          )}
        </div>
      )}

      <div className="max-w-[80%] space-y-1">
        {/* Agent type badge */}
        {message.agentType && !isUser && (
          <span className="text-[10px] text-amber-500 font-medium uppercase tracking-wider">
            {message.agentType}
          </span>
        )}

        {/* Message bubble */}
        <div
          className={clsx(
            'rounded-xl px-4 py-3 text-sm leading-relaxed',
            isUser
              ? 'bg-gradient-to-br from-amber-500/20 to-amber-600/10 text-amber-50 rounded-br-sm border border-amber-500/20'
              : isSystem
                ? 'bg-red-500/10 text-red-300 rounded-bl-sm border border-red-500/20'
                : 'bg-[#1a1a2e] text-slate-200 border border-[#2d2d4a] rounded-bl-sm',
            isStreaming && 'opacity-90',
          )}
        >
          {/* Render content with markdown */}
          <MessageContent
            content={message.content}
            isStreaming={isStreaming}
            onCopyCode={handleCopyCode}
            copiedBlock={copiedBlock}
          />
        </div>

        {/* Tool calls */}
        {message.toolCalls && message.toolCalls.length > 0 && (
          <ToolCallResults
            toolCalls={message.toolCalls}
            expanded={expandedTools}
            onToggle={(id) => setExpandedTools(prev => ({ ...prev, [id]: !prev[id] }))}
          />
        )}

        {/* Timestamp */}
        <div className="text-[9px] text-slate-500 px-1">
          {formatTime(message.createdAt)}
        </div>
      </div>

      {/* User avatar */}
      {isUser && (
        <div className="w-7 h-7 rounded-lg bg-amber-500/20 flex items-center justify-center shrink-0 mt-0.5">
          <User className="w-4 h-4 text-amber-400" />
        </div>
      )}
    </div>
  );
}

// ─── Message Content with Markdown ─────────────────────────────────────

function MessageContent({
  content,
  isStreaming,
  onCopyCode,
  copiedBlock,
}: {
  content: string;
  isStreaming?: boolean;
  onCopyCode: (code: string, id: string) => void;
  copiedBlock: string | null;
}) {
  const blocks = parseMarkdownBlocks(content);

  return (
    <div className="space-y-2">
      {blocks.map((block, i) => {
        if (block.type === 'code') {
          const blockId = `code-${i}-${block.lang}`;
          const isCopied = copiedBlock === blockId;
          return (
            <div key={i} className="relative group">
              <div className="flex items-center justify-between bg-[#0d0d1a] rounded-lg border border-[#2d2d4a] px-3 py-2 mb-1">
                <span className="text-[10px] text-slate-500 font-mono">{block.lang || 'code'}</span>
                <button
                  onClick={() => onCopyCode(block.content, blockId)}
                  className="flex items-center gap-1 text-[10px] text-slate-400 hover:text-slate-200 transition-colors"
                >
                  {isCopied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                  {isCopied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="bg-[#0d0d1a] rounded-b-lg border border-t-0 border-[#2d2d4a] p-3 overflow-x-auto">
                <code className="text-[12px] text-slate-300 font-mono whitespace-pre">
                  {block.content}
                </code>
              </pre>
            </div>
          );
        }

        // Regular text with inline formatting
        return (
          <p key={i} className="whitespace-pre-wrap">
            <InlineMarkdown text={block.content} />
            {isStreaming && i === blocks.length - 1 && (
              <span className="inline-block w-1.5 h-4 bg-amber-400 animate-pulse ml-0.5 align-middle" />
            )}
          </p>
        );
      })}
    </div>
  );
}

// ─── Inline Markdown Renderer ───────────────────────────────────────────

function InlineMarkdown({ text }: { text: string }) {
  // Split by code spans, bold, and italic
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);

  return (
    <>
      {parts.map((part, i) => {
        if (part.startsWith('`') && part.endsWith('`')) {
          return (
            <code key={i} className="bg-[#252540] px-1.5 py-0.5 rounded text-amber-300 text-xs font-mono">
              {part.slice(1, -1)}
            </code>
          );
        }
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={i} className="text-slate-100 font-semibold">{part.slice(2, -2)}</strong>;
        }
        if (part.startsWith('*') && part.endsWith('*')) {
          return <em key={i}>{part.slice(1, -1)}</em>;
        }
        return <span key={i}>{part}</span>;
      })}
    </>
  );
}

// ─── Tool Call Results ──────────────────────────────────────────────────

function ToolCallResults({
  toolCalls,
  expanded,
  onToggle,
}: {
  toolCalls: ToolCallResult[];
  expanded: Record<string, boolean>;
  onToggle: (id: string) => void;
}) {
  return (
    <div className="space-y-1.5 mt-2">
      {toolCalls.map(tc => (
        <div
          key={tc.id}
          className="bg-[#252540]/50 rounded-lg border border-[#3d3d5a] overflow-hidden"
        >
          <button
            onClick={() => onToggle(tc.id)}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:bg-[#2d2d4a] transition-colors"
          >
            <span className={clsx(
              'w-2 h-2 rounded-full shrink-0',
              tc.status === 'success' ? 'bg-green-400' : 'bg-red-400',
            )} />
            <span className="font-mono text-amber-400 text-[11px]">{tc.toolName}()</span>
            <span className="text-slate-500 text-[10px] flex-1 text-right">
              {expanded[tc.id] ? '▲' : '▼'}
            </span>
          </button>

          {expanded[tc.id] && (
            <div className="px-3 pb-3 pt-1 space-y-2 border-t border-[#3d3d5a]/50">
              <div>
                <span className="text-[10px] text-slate-500 block mb-1">Parameters</span>
                <pre className="text-[10px] text-slate-400 bg-[#0f0f23] p-2 rounded overflow-x-auto font-mono">
                  {JSON.stringify(tc.params, null, 2)}
                </pre>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block mb-1">Result</span>
                <pre className="text-[10px] text-slate-400 bg-[#0f0f23] p-2 rounded overflow-x-auto max-h-40 font-mono">
                  {JSON.stringify(tc.result, null, 2)}
                </pre>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Markdown Block Parser ─────────────────────────────────────────────

interface MarkdownBlock {
  type: 'text' | 'code';
  content: string;
  lang?: string;
}

function parseMarkdownBlocks(content: string): MarkdownBlock[] {
  const blocks: MarkdownBlock[] = [];
  const codeRegex = /```(\w*)\n?([\s\S]*?)```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = codeRegex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      blocks.push({ type: 'text', content: content.slice(lastIndex, match.index) });
    }
    blocks.push({ type: 'code', content: match[2], lang: match[1] || undefined });
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < content.length) {
    blocks.push({ type: 'text', content: content.slice(lastIndex) });
  }

  // If no code blocks found, treat entire content as text
  if (blocks.length === 0) {
    blocks.push({ type: 'text', content });
  }

  return blocks;
}

// ─── Time Formatter ────────────────────────────────────────────────────

function formatTime(date: Date | string): string {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export default MessageBubble;