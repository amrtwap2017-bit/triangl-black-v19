import { StatCard } from '../ui/stat-card';

interface KpiCardData {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  change?: number;
  prefix?: string;
  suffix?: string;
}

interface KpiCardsProps {
  cards: KpiCardData[];
}

export const KpiCards: React.FC<KpiCardsProps> = ({ cards }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {cards.map((card, idx) => (
        <StatCard key={idx} {...card} />
      ))}
    </div>
  );
};