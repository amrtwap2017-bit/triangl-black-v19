import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import type { RevenueData } from '@/shared/types';

interface MarginChartProps {
  data: RevenueData[];
  height?: number;
}

export const MarginChart: React.FC<MarginChartProps> = ({ data, height = 300 }) => {
  const marginData = data.map((d) => ({
    ...d,
    margin: d.revenue > 0 ? ((d.revenue - d.cost) / d.revenue) * 100 : 0,
  }));

  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={marginData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#2d2d4a" />
        <XAxis dataKey="month" tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={{ stroke: '#2d2d4a' }} />
        <YAxis tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={{ stroke: '#2d2d4a' }} tickFormatter={(v) => `${v}%`} domain={[0, 'auto']} />
        <Tooltip
          contentStyle={{
            backgroundColor: '#1a1a2e',
            border: '1px solid #2d2d4a',
            borderRadius: '8px',
            color: '#f1f5f9',
          }}
          formatter={(value: number) => [`${value.toFixed(1)}%`, 'Gross Margin']}
        />
        <Line
          type="monotone"
          dataKey="margin"
          stroke="#c9a962"
          strokeWidth={3}
          dot={{ fill: '#c9a962', r: 4 }}
          activeDot={{ r: 6, fill: '#d4b872' }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};