import type { PipelineData } from '@/shared/types';
import { useTranslation } from 'react-i18next';

interface PipelineChartProps {
  data: PipelineData[];
}

const stageOrder = ['LEAD', 'QUALIFIED', 'PROPOSAL_SENT', 'NEGOTIATION', 'VERBAL_AGREEMENT', 'CONTRACT_SIGNED'];
const stageColors: Record<string, string> = {
  LEAD: '#94a3b8',
  QUALIFIED: '#60a5fa',
  PROPOSAL_SENT: '#c9a962',
  NEGOTIATION: '#f59e0b',
  VERBAL_AGREEMENT: '#22c55e',
  CONTRACT_SIGNED: '#10b981',
};

export const PipelineChart: React.FC<PipelineChartProps> = ({ data }) => {
  const { t } = useTranslation();
  const sorted = [...data].sort((a, b) => stageOrder.indexOf(a.stage) - stageOrder.indexOf(b.stage));
  const maxValue = Math.max(...sorted.map((d) => d.value), 1);

  return (
    <div className="space-y-3">
      {sorted.map((item) => {
        const pct = (item.value / maxValue) * 100;
        const color = stageColors[item.stage] || '#94a3b8';
        return (
          <div key={item.stage} className="flex items-center gap-3">
            <div className="w-32 text-sm text-slate-300 truncate shrink-0">
              {item.stage.replace(/_/g, ' ')}
            </div>
            <div className="flex-1 h-8 bg-[#252540] rounded-lg overflow-hidden relative">
              <div
                className="h-full rounded-lg transition-all duration-500"
                style={{ width: `${Math.max(pct, 8)}%`, backgroundColor: color }}
              />
              <span className="absolute inset-0 flex items-center px-3 text-xs font-medium text-slate-100 mix-blend-difference">
                ${item.value.toLocaleString()} ({item.count})
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
};