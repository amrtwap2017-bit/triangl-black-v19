import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import type { RevenueData } from '@/shared/types';

interface RevenueChartProps {
  data: RevenueData[];
  height?: number;
}

export const RevenueChart: React.FC<RevenueChartProps> = ({ data, height = 300 }) => {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#2d2d4a" />
        <XAxis dataKey="month" tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={{ stroke: '#2d2d4a' }} />
        <YAxis tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={{ stroke: '#2d2d4a' }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
        <Tooltip
          contentStyle={{
            backgroundColor: '#1a1a2e',
            border: '1px solid #2d2d4a',
            borderRadius: '8px',
            color: '#f1f5f9',
          }}
          formatter={(value: number) => [`$${value.toLocaleString()}`, undefined]}
        />
        <Legend />
        <Bar dataKey="revenue" name="Revenue" fill="#c9a962" radius={[4, 4, 0, 0]} />
        <Bar dataKey="cost" name="Cost" fill="#ef4444" radius={[4, 4, 0, 0]} opacity={0.7} />
        <Bar dataKey="profit" name="Profit" fill="#22c55e" radius={[4, 4, 0, 0]} opacity={0.7} />
      </BarChart>
    </ResponsiveContainer>
  );
};