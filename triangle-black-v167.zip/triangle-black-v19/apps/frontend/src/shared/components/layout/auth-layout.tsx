import { Outlet } from 'react-router-dom';
import { Triangle } from 'lucide-react';

export const AuthLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#0f0f1a] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-2.5 mb-8">
          <Triangle className="w-10 h-10 text-[#c9a962]" />
          <div>
            <h1 className="text-2xl font-bold text-[#c9a962] tracking-wider">
              TRIANGLE BLACK
            </h1>
            <p className="text-xs text-slate-500 text-center">
              Hospitality Supply & Contracting Partner
            </p>
          </div>
        </div>
        <Outlet />
      </div>
    </div>
  );
};