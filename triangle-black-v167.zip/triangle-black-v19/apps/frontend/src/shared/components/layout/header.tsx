import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Bell, Globe, LogOut, User, Settings, Menu } from 'lucide-react';
import { clsx } from 'clsx';
import { useAppStore } from '@/store';
import { useAuthStore } from '@/shared/hooks/useAuth';
import { apiGet } from '@/api/client';
import { endpoints } from '@/api/endpoints';

export const Header: React.FC = () => {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const { language, setLanguage, toggleSidebar } = useAppStore();
  const { user, logout } = useAuthStore();
  const isRtl = i18n.language === 'ar';
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    apiGet<{ count: number }>(endpoints.notifications.unreadCount)
      .then((res) => setUnreadCount(res.count))
      .catch(() => {});
  }, []);

  const toggleLanguage = () => {
    const newLang = language === 'en' ? 'ar' : 'en';
    setLanguage(newLang);
    i18n.changeLanguage(newLang);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="h-16 bg-[#1a1a2e]/80 backdrop-blur-md border-b border-[#2d2d4a] flex items-center justify-between px-4 sm:px-6 sticky top-0 z-30">
      {/* Left: Menu toggle (mobile) */}
      <div className="flex items-center gap-3">
        <button
          onClick={toggleSidebar}
          className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#252540] transition-colors lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        {/* Language toggle */}
        <button
          onClick={toggleLanguage}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-slate-300 hover:text-slate-100 hover:bg-[#252540] transition-colors"
        >
          <Globe className="w-4 h-4" />
          <span>{language === 'en' ? 'عربي' : 'EN'}</span>
        </button>

        {/* Notifications */}
        <button
          onClick={() => navigate('/notifications')}
          className="relative p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#252540] transition-colors"
        >
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 end-1 w-4 h-4 bg-[#ef4444] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        {/* User menu */}
        <div className="relative">
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 p-1.5 pe-3 rounded-lg hover:bg-[#252540] transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-[#c9a962]/20 flex items-center justify-center text-[#c9a962] font-semibold text-sm">
              {user?.name?.charAt(0)?.toUpperCase() || 'U'}
            </div>
            <span className="hidden sm:block text-sm text-slate-200">
              {user?.name || 'User'}
            </span>
          </button>

          {showUserMenu && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowUserMenu(false)}
              />
              <div
                className={clsx(
                  'absolute top-full mt-2 z-50 w-56 bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl shadow-xl py-1 animate-slide-in',
                  isRtl ? 'left-0' : 'right-0'
                )}
              >
                <div className="px-4 py-3 border-b border-[#2d2d4a]">
                  <p className="text-sm font-medium text-slate-100">{user?.name}</p>
                  <p className="text-xs text-slate-400">{user?.email}</p>
                </div>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    navigate('/profile');
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-300 hover:bg-[#252540] hover:text-slate-100 transition-colors"
                >
                  <User className="w-4 h-4" />
                  {t('auth.profile')}
                </button>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    navigate('/settings');
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-300 hover:bg-[#252540] hover:text-slate-100 transition-colors"
                >
                  <Settings className="w-4 h-4" />
                  {t('auth.settings')}
                </button>
                <div className="border-t border-[#2d2d4a] my-1" />
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-red-400 hover:bg-red-900/20 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  {t('auth.signOut')}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};