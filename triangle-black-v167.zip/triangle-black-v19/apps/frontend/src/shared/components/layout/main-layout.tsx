import { Outlet } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { clsx } from 'clsx';
import { Sidebar } from './sidebar';
import { Header } from './header';
import { CopilotWidget } from '../ai/copilot-widget';
import { useAppStore } from '@/store';
import { useEffect } from 'react';

export const MainLayout: React.FC = () => {
  const { i18n } = useTranslation();
  const { sidebarCollapsed, language } = useAppStore();
  const isRtl = i18n.language === 'ar';

  useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [isRtl, language]);

  const marginInline = sidebarCollapsed ? '68px' : '256px';

  return (
    <div className={clsx('min-h-screen bg-[#0f0f1a]')} dir={isRtl ? 'rtl' : 'ltr'}>
      <Sidebar />
      <div
        className="transition-all duration-300 hidden lg:block"
        style={{ [isRtl ? 'marginRight' : 'marginLeft']: marginInline }}
      >
        <Header />
        <main className="p-6 animate-fade-in">
          <Outlet />
        </main>
      </div>
      <div className="lg:hidden">
        <Header />
        <main className="p-4 animate-fade-in">
          <Outlet />
        </main>
      </div>
      <CopilotWidget />
    </div>
  );
};