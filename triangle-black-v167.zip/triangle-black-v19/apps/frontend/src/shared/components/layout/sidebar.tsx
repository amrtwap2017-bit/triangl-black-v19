import { NavLink, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  LayoutDashboard,
  Building2,
  ClipboardList,
  MapPin,
  Target,
  FileText,
  HardHat,
  ShoppingCart,
  Store,
  AlertTriangle,
  FolderOpen,
  BarChart3,
  Bot,
  Settings,
  ChevronLeft,
  Triangle,
  BookOpen,
  Shield,
  Radar,
  PenTool,
  Users,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import { clsx } from 'clsx';
import { useAppStore } from '@/store';

const navItems = [
  { path: '/dashboard', key: 'dashboard', icon: LayoutDashboard },
  { path: '/hotels', key: 'hotels', icon: Building2 },
  { path: '/requests', key: 'requests', icon: ClipboardList },
  { path: '/site-visits', key: 'siteVisits', icon: MapPin },
  { path: '/opportunities', key: 'opportunities', icon: Target },
  { path: '/proposals', key: 'proposals', icon: FileText },
  { path: '/projects', key: 'projects', icon: HardHat },
  { path: '/procurement', key: 'procurement', icon: ShoppingCart },
  { path: '/operations/rfqs', key: 'rfq', icon: FileText },
  { path: '/vendors', key: 'vendors', icon: Store },
  { path: '/emergency', key: 'emergency', icon: AlertTriangle },
  { path: '/documents', key: 'documents', icon: FolderOpen },
  { path: '/drawings', key: 'drawings', icon: PenTool },
  { path: '/knowledge-hub', key: 'knowledgeHub', icon: BookOpen },
  { path: '/warranties', key: 'warranties', icon: Shield },
  { path: '/insights', key: 'insights', icon: BarChart3 },
  { path: '/opportunity-radar', key: 'opportunityRadar', icon: Radar },
  { path: '/operations/resources', key: 'resources', icon: Users },
  { path: '/operations/capex', key: 'capex', icon: TrendingUp },
  { path: '/operations/forecasting', key: 'forecasting', icon: BarChart3 },
  { path: '/operations/twin', key: 'digitalTwin', icon: Building2 },
  { path: '/ai', key: 'aiChat', icon: Sparkles },
  { path: '/assistant', key: 'assistant', icon: Bot },
  { path: '/administration', key: 'administration', icon: Settings },
];

export const Sidebar: React.FC = () => {
  const { t, i18n } = useTranslation();
  const { sidebarCollapsed, toggleSidebar } = useAppStore();
  const isRtl = i18n.language === 'ar';
  const location = useLocation();

  return (
    <aside
      className={clsx(
        'fixed top-0 h-full bg-[#1a1a2e] border-e border-[#2d2d4a] z-40 flex flex-col transition-all duration-300',
        sidebarCollapsed ? 'w-[68px]' : 'w-64',
        isRtl ? 'right-0 border-e-0 border-s' : 'left-0'
      )}
    >
      {/* Logo */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-[#2d2d4a]">
        <div className="flex items-center gap-2.5 min-w-0">
          <Triangle className="w-8 h-8 text-[#c9a962] shrink-0" />
          {!sidebarCollapsed && (
            <div className="min-w-0">
              <h1 className="text-sm font-bold text-[#c9a962] tracking-wider truncate">
                TRIANGLE BLACK
              </h1>
              {!sidebarCollapsed && (
                <p className="text-[10px] text-slate-500 truncate">
                  {t('app.tagline')}
                </p>
              )}
            </div>
          )}
        </div>
        <button
          onClick={toggleSidebar}
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#252540] transition-colors shrink-0"
        >
          <ChevronLeft className={clsx('w-4 h-4 transition-transform', sidebarCollapsed && 'rotate-180')} />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-2 scrollbar-thin">
        <ul className="space-y-1">
          {navItems.map((item) => {
            const isActive =
              location.pathname === item.path ||
              location.pathname.startsWith(item.path + '/');
            return (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={clsx(
                    'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200',
                    isActive
                      ? 'bg-[#c9a962]/10 text-[#c9a962] font-medium'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-[#252540]'
                  )}
                  title={sidebarCollapsed ? t(`nav.${item.key}`) : undefined}
                >
                  <item.icon className="w-5 h-5 shrink-0" />
                  {!sidebarCollapsed && (
                    <span className="truncate">{t(`nav.${item.key}`)}</span>
                  )}
                </NavLink>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User */}
      <div className="p-3 border-t border-[#2d2d4a]">
        {!sidebarCollapsed && (
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="w-8 h-8 rounded-full bg-[#c9a962]/20 flex items-center justify-center text-[#c9a962] font-semibold text-sm">
              TB
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-slate-200 truncate">Admin User</p>
              <p className="text-xs text-slate-500 truncate">admin@triangleblack.com</p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};