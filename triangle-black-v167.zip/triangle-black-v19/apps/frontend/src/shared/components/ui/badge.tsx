import { clsx } from 'clsx';

type BadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'info';

interface BadgeProps {
  variant?: BadgeVariant;
  children: React.ReactNode;
  className?: string;
}

const variantStyles: Record<BadgeVariant, string> = {
  default: 'bg-[#2d2d4a] text-slate-300',
  success: 'bg-green-900/40 text-green-400 border border-green-800/50',
  warning: 'bg-amber-900/40 text-amber-400 border border-amber-800/50',
  danger: 'bg-red-900/40 text-red-400 border border-red-800/50',
  info: 'bg-blue-900/40 text-blue-400 border border-blue-800/50',
};

export const Badge: React.FC<BadgeProps> = ({
  variant = 'default',
  children,
  className,
}) => {
  return (
    <span
      className={clsx(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
        variantStyles[variant],
        className
      )}
    >
      {children}
    </span>
  );
};