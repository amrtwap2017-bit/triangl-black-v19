import { clsx } from 'clsx';

interface CardProps {
  header?: React.ReactNode;
  footer?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  noPadding?: boolean;
}

export const Card: React.FC<CardProps> = ({
  header,
  footer,
  children,
  className,
  noPadding,
}) => {
  return (
    <div
      className={clsx(
        'bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl overflow-hidden',
        className
      )}
    >
      {header && (
        <div className="px-6 py-4 border-b border-[#2d2d4a]">
          {header}
        </div>
      )}
      <div className={clsx(!noPadding && 'p-6')}>
        {children}
      </div>
      {footer && (
        <div className="px-6 py-4 border-t border-[#2d2d4a] bg-[#15152a]">
          {footer}
        </div>
      )}
    </div>
  );
};