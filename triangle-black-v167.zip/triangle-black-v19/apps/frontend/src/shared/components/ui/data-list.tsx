import { clsx } from 'clsx';

interface DataListItem {
  id: string;
  primary: string;
  secondary?: string;
  tertiary?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
}

interface DataListProps {
  items: DataListItem[];
  onItemSelect?: (item: DataListItem) => void;
}

export const DataList: React.FC<DataListProps> = ({ items, onItemSelect }) => {
  if (items.length === 0) return null;

  return (
    <div className="divide-y divide-[#2d2d4a]/50">
      {items.map((item) => (
        <div
          key={item.id}
          className={clsx(
            'px-4 py-3 flex items-center justify-between gap-4 hover:bg-[#252540] transition-colors',
            onItemSelect && 'cursor-pointer'
          )}
          onClick={() => onItemSelect?.(item)}
        >
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="text-sm font-medium text-slate-100 truncate">
                {item.primary}
              </p>
              {item.badge}
            </div>
            {item.secondary && (
              <p className="text-xs text-slate-400 mt-0.5 truncate">{item.secondary}</p>
            )}
            {item.tertiary && (
              <p className="text-xs text-slate-500 mt-0.5 truncate">{item.tertiary}</p>
            )}
          </div>
          {item.actions && (
            <div className="flex items-center gap-2 shrink-0">
              {item.actions}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};