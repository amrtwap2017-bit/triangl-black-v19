import { FolderOpen } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Button } from './button';

interface EmptyStateProps {
  message?: string;
  icon?: React.ReactNode;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  message,
  icon,
  actionLabel,
  onAction,
}) => {
  const { t } = useTranslation();

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="p-4 rounded-full bg-[#252540] mb-4 text-slate-500">
        {icon || <FolderOpen className="w-10 h-10" />}
      </div>
      <p className="text-slate-400 text-sm mb-4">{message || t('common.noData')}</p>
      {actionLabel && onAction && (
        <Button onClick={onAction} size="sm">
          {actionLabel}
        </Button>
      )}
    </div>
  );
};