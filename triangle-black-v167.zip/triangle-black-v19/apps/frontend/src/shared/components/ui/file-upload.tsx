import { useState, useCallback, useRef } from 'react';
import { Upload, X, FileText, Image as ImageIcon } from 'lucide-react';
import { clsx } from 'clsx';
import { useTranslation } from 'react-i18next';

interface FileUploadProps {
  onFilesSelected: (files: File[]) => void;
  accept?: string;
  maxSize?: number;
  maxFiles?: number;
  multiple?: boolean;
  label?: string;
}

interface FilePreview {
  file: File;
  preview?: string;
  progress: number;
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onFilesSelected,
  accept = '*',
  maxSize = 10 * 1024 * 1024,
  maxFiles = 10,
  multiple = true,
  label,
}) => {
  const { t } = useTranslation();
  const [files, setFiles] = useState<FilePreview[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback(
    (fileList: FileList | null) => {
      if (!fileList) return;
      const newFiles: FilePreview[] = Array.from(fileList)
        .slice(0, maxFiles - files.length)
        .filter((f) => f.size <= maxSize)
        .map((f) => ({
          file: f,
          preview: f.type.startsWith('image/') ? URL.createObjectURL(f) : undefined,
          progress: 0,
        }));
      const updated = [...files, ...newFiles];
      setFiles(updated);
      onFilesSelected(updated.map((f) => f.file));
    },
    [files, maxFiles, maxSize, onFilesSelected]
  );

  const removeFile = (index: number) => {
    const updated = files.filter((_, i) => i !== index);
    if (files[index].preview) URL.revokeObjectURL(files[index].preview!);
    setFiles(updated);
    onFilesSelected(updated.map((f) => f.file));
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div>
      {label && (
        <label className="block text-sm font-medium text-slate-300 mb-1.5">
          {label}
        </label>
      )}
      <div
        className={clsx(
          'border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer',
          isDragging
            ? 'border-[#c9a962] bg-[#c9a962]/5'
            : 'border-[#2d2d4a] hover:border-[#c9a962]/50 hover:bg-[#252540]/50'
        )}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          handleFiles(e.dataTransfer.files);
        }}
        onClick={() => inputRef.current?.click()}
      >
        <Upload className="w-8 h-8 text-slate-500 mx-auto mb-2" />
        <p className="text-sm text-slate-300">
          {t('documents.upload')}
        </p>
        <p className="text-xs text-slate-500 mt-1">
          Max {formatSize(maxSize)} per file
        </p>
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />
      </div>
      {files.length > 0 && (
        <div className="mt-3 space-y-2">
          {files.map((f, i) => (
            <div
              key={i}
              className="flex items-center justify-between bg-[#252540] rounded-lg px-3 py-2"
            >
              <div className="flex items-center gap-2 min-w-0">
                {f.file.type.startsWith('image/') ? (
                  <ImageIcon className="w-4 h-4 text-[#c9a962] shrink-0" />
                ) : (
                  <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                )}
                <span className="text-sm text-slate-200 truncate">{f.file.name}</span>
                <span className="text-xs text-slate-500">{formatSize(f.file.size)}</span>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeFile(i);
                }}
                className="p-1 text-slate-400 hover:text-red-400 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};