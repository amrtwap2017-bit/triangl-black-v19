import { Loader2 } from 'lucide-react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  message?: string;
}

const sizeMap = { sm: 'w-5 h-5', md: 'w-8 h-8', lg: 'w-12 h-12' };

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ size = 'md', message }) => {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <Loader2 className={`${sizeMap[size]} text-[#c9a962] animate-spin`} />
      {message && (
        <p className="text-sm text-slate-400 mt-3">{message}</p>
      )}
    </div>
  );
};