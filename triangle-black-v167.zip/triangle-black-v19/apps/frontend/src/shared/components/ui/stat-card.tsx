import { clsx } from 'clsx';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  change?: number;
  prefix?: string;
  suffix?: string;
  className?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  icon,
  label,
  value,
  change,
  prefix = '',
  suffix = '',
  className,
}) => {
  const isPositive = change !== undefined && change > 0;
  const isNegative = change !== undefined && change < 0;
  const isNeutral = change === undefined || change === 0;

  return (
    <div
      className={clsx(
        'bg-[#1a1a2e] border border-[#2d2d4a] rounded-xl p-5 transition-all hover:border-[#c9a962]/30',
        className
      )}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm text-slate-400 mb-1">{label}</p>
          <p className="text-2xl font-bold text-slate-100">
            {prefix}{typeof value === 'number' ? value.toLocaleString() : value}{suffix}
          </p>
        </div>
        <div className="p-3 rounded-lg bg-[#252540] text-[#c9a962]">
          {icon}
        </div>
      </div>
      {change !== undefined && (
        <div className="flex items-center gap-1 mt-3">
          {isPositive && <TrendingUp className="w-3.5 h-3.5 text-green-400" />}
          {isNegative && <TrendingDown className="w-3.5 h-3.5 text-red-400" />}
          {isNeutral && <Minus className="w-3.5 h-3.5 text-slate-400" />}
          <span
            className={clsx(
              'text-xs font-medium',
              isPositive && 'text-green-400',
              isNegative && 'text-red-400',
              isNeutral && 'text-slate-400'
            )}
          >
            {isPositive ? '+' : ''}{change}%
          </span>
          <span className="text-xs text-slate-500 ms-1">vs last month</span>
        </div>
      )}
    </div>
  );
};