import { Badge } from './badge';

type StatusType =
  | 'NEW' | 'ACKNOWLEDGED' | 'ASSIGNED' | 'SITE_VISIT_SCHEDULED' | 'CONVERTED' | 'CLOSED_LOST' | 'CLOSED_WON'
  | 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
  | 'LEAD' | 'QUALIFIED' | 'PROPOSAL_SENT' | 'NEGOTIATION' | 'VERBAL_AGREEMENT' | 'CONTRACT_SIGNED'
  | 'DRAFT' | 'INTERNAL_REVIEW' | 'SUBMITTED' | 'PRESENTED' | 'APPROVED' | 'REJECTED' | 'REVISION_REQUESTED' | 'EXPIRED'
  | 'PLANNING' | 'ON_HOLD' | 'CLOSED'
  | 'TODO' | 'REVIEW' | 'DONE'
  | 'OPEN' | 'ESCALATED' | 'RESOLVED'
  | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  | 'ACTIVE'
  | 'ISSUED' | 'CONFIRMED' | 'SHIPPED' | 'DELIVERED' | 'PARTIALLY_DELIVERED' | 'RECEIVED'
  | 'PENDING' | 'PO_CREATED' | 'IMPLEMENTED';

const statusMap: Record<StatusType, { variant: 'default' | 'success' | 'warning' | 'danger' | 'info'; label: string; labelAr: string }> = {
  NEW: { variant: 'info', label: 'New', labelAr: 'جديد' },
  ACKNOWLEDGED: { variant: 'info', label: 'Acknowledged', labelAr: 'تم الاعتراف' },
  ASSIGNED: { variant: 'info', label: 'Assigned', labelAr: 'تم التعيين' },
  SITE_VISIT_SCHEDULED: { variant: 'info', label: 'Visit Scheduled', labelAr: 'تمت جدولة الزيارة' },
  CONVERTED: { variant: 'success', label: 'Converted', labelAr: 'تم التحويل' },
  CLOSED_LOST: { variant: 'danger', label: 'Lost', labelAr: 'خاسر' },
  CLOSED_WON: { variant: 'success', label: 'Won', labelAr: 'رابح' },
  SCHEDULED: { variant: 'info', label: 'Scheduled', labelAr: 'مجدول' },
  IN_PROGRESS: { variant: 'warning', label: 'In Progress', labelAr: 'قيد التنفيذ' },
  COMPLETED: { variant: 'success', label: 'Completed', labelAr: 'مكتمل' },
  CANCELLED: { variant: 'danger', label: 'Cancelled', labelAr: 'ملغي' },
  LEAD: { variant: 'info', label: 'Lead', labelAr: 'مهتم' },
  QUALIFIED: { variant: 'info', label: 'Qualified', labelAr: 'مؤهل' },
  PROPOSAL_SENT: { variant: 'warning', label: 'Proposal Sent', labelAr: 'تم إرسال العرض' },
  NEGOTIATION: { variant: 'warning', label: 'Negotiation', labelAr: 'تفاوض' },
  VERBAL_AGREEMENT: { variant: 'success', label: 'Verbal Agreement', labelAr: 'اتفاق شفهي' },
  CONTRACT_SIGNED: { variant: 'success', label: 'Contract Signed', labelAr: 'تم توقيع العقد' },
  DRAFT: { variant: 'default', label: 'Draft', labelAr: 'مسودة' },
  INTERNAL_REVIEW: { variant: 'warning', label: 'Internal Review', labelAr: 'مراجعة داخلية' },
  SUBMITTED: { variant: 'info', label: 'Submitted', labelAr: 'تم الإرسال' },
  PRESENTED: { variant: 'info', label: 'Presented', labelAr: 'تم العرض' },
  APPROVED: { variant: 'success', label: 'Approved', labelAr: 'تمت الموافقة' },
  REJECTED: { variant: 'danger', label: 'Rejected', labelAr: 'مرفوض' },
  REVISION_REQUESTED: { variant: 'warning', label: 'Revision Requested', labelAr: 'طلب مراجعة' },
  EXPIRED: { variant: 'danger', label: 'Expired', labelAr: 'منتهي الصلاحية' },
  PLANNING: { variant: 'info', label: 'Planning', labelAr: 'تخطيط' },
  ON_HOLD: { variant: 'warning', label: 'On Hold', labelAr: 'معلق' },
  CLOSED: { variant: 'default', label: 'Closed', labelAr: 'مغلق' },
  TODO: { variant: 'default', label: 'To Do', labelAr: 'للتنفيذ' },
  REVIEW: { variant: 'warning', label: 'Review', labelAr: 'مراجعة' },
  DONE: { variant: 'success', label: 'Done', labelAr: 'منتهي' },
  OPEN: { variant: 'danger', label: 'Open', labelAr: 'مفتوح' },
  ESCALATED: { variant: 'danger', label: 'Escalated', labelAr: 'تم التصعيد' },
  RESOLVED: { variant: 'success', label: 'Resolved', labelAr: 'تم الحل' },
  LOW: { variant: 'default', label: 'Low', labelAr: 'منخفض' },
  MEDIUM: { variant: 'warning', label: 'Medium', labelAr: 'متوسط' },
  HIGH: { variant: 'danger', label: 'High', labelAr: 'مرتفع' },
  CRITICAL: { variant: 'danger', label: 'Critical', labelAr: 'حرج' },
  ACTIVE: { variant: 'success', label: 'Active', labelAr: 'نشط' },
  ISSUED: { variant: 'info', label: 'Issued', labelAr: 'مصدر' },
  CONFIRMED: { variant: 'success', label: 'Confirmed', labelAr: 'مؤكد' },
  SHIPPED: { variant: 'warning', label: 'Shipped', labelAr: 'تم الشحن' },
  DELIVERED: { variant: 'success', label: 'Delivered', labelAr: 'تم التسليم' },
  PARTIALLY_DELIVERED: { variant: 'warning', label: 'Partial', labelAr: 'تسليم جزئي' },
  RECEIVED: { variant: 'success', label: 'Received', labelAr: 'تم الاستلام' },
  PENDING: { variant: 'warning', label: 'Pending', labelAr: 'قيد الانتظار' },
  PO_CREATED: { variant: 'info', label: 'PO Created', labelAr: 'تم إنشاء أمر الشراء' },
  IMPLEMENTED: { variant: 'success', label: 'Implemented', labelAr: 'تم التنفيذ' },
};

interface StatusBadgeProps {
  status: string;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className }) => {
  const mapping = statusMap[status as StatusType];
  if (!mapping) {
    return (
      <Badge variant="default" className={className}>
        {status}
      </Badge>
    );
  }

  return (
    <Badge variant={mapping.variant} className={className}>
      {mapping.label}
    </Badge>
  );
};