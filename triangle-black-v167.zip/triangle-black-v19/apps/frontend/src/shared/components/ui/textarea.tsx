import React, { forwardRef } from 'react';
import { clsx } from 'clsx';

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ label, error, className, id, ...props }, ref) => {
    const textareaId = id || label?.toLowerCase().replace(/\s+/g, '-');
    return (
      <div className="w-full">
        {label && (
          <label
            htmlFor={textareaId}
            className="block text-sm font-medium text-slate-300 mb-1.5"
          >
            {label}
          </label>
        )}
        <textarea
          ref={ref}
          id={textareaId}
          className={clsx(
            'w-full bg-[#1a1a2e] border border-[#2d2d4a] rounded-lg px-3 py-2 text-sm text-slate-100',
            'placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-[#c9a962]/50 focus:border-[#c9a962]',
            'transition-colors duration-200 min-h-[100px] resize-y',
            error && 'border-[#ef4444] focus:ring-[#ef4444]/50',
            className
          )}
          {...props}
        />
        {error && (
          <p className="mt-1 text-xs text-[#ef4444]">{error}</p>
        )}
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';