import { useState, useCallback, useEffect, useRef } from 'react';
import { aiService, type ChatResponse, type Conversation, type ConversationMessage, type UsageSummary } from '@/shared/services/ai.service';

// ─── Types ─────────────────────────────────────────────────────────────

interface UseAiCopilotReturn {
  // State
  isOpen: boolean;
  messages: ConversationMessage[];
  isStreaming: boolean;
  selectedAgent: string;
  conversations: Conversation[];
  activeConversationId: string | null;
  error: string | null;

  // Actions
  toggle: () => void;
  open: () => void;
  close: () => void;
  sendMessage: (message: string) => Promise<void>;
  selectAgent: (agentId: string) => void;
  loadConversations: () => Promise<void>;
  loadConversation: (conversationId: string) => Promise<void>;
  clearChat: () => void;
  deleteConversation: (conversationId: string) => Promise<void>;
  setActiveConversation: (id: string | null) => void;
}

// ─── Hook ──────────────────────────────────────────────────────────────

const STORAGE_KEY_OPEN = 'tb-ai-copilot-open';
const STORAGE_KEY_AGENT = 'tb-ai-copilot-agent';

export function useAiCopilot(organizationId?: string): UseAiCopilotReturn {
  // Persisted state
  const [isOpen, setIsOpen] = useState<boolean>(() =>
    localStorage.getItem(STORAGE_KEY_OPEN) === 'true',
  );
  const [selectedAgent, setSelectedAgent] = useState<string>(() =>
    localStorage.getItem(STORAGE_KEY_AGENT) || 'assistant',
  );

  // Ephemeral state
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const eventSourceRef = useRef<EventSource | null>(null);

  // Persist open/closed state
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_OPEN, String(isOpen));
  }, [isOpen]);

  // Persist selected agent
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_AGENT, selectedAgent);
  }, [selectedAgent]);

  // Cleanup SSE on unmount
  useEffect(() => {
    return () => {
      eventSourceRef.current?.close();
    };
  }, []);

  // ─── Toggle / Open / Close ─────────────────────────────────────────

  const toggle = useCallback(() => {
    setIsOpen(prev => !prev);
  }, []);

  const open = useCallback(() => {
    setIsOpen(true);
  }, []);

  const close = useCallback(() => {
    setIsOpen(false);
  }, []);

  // ─── Send Message (SSE Streaming) ─────────────────────────────────

  const sendMessage = useCallback(async (message: string) => {
    if (!message.trim() || isStreaming || !organizationId) return;

    // Add user message to local state
    const userMessage: ConversationMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: message.trim(),
      createdAt: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setIsStreaming(true);
    setError(null);

    try {
      // Create a placeholder assistant message for streaming
      const assistantMessageId = crypto.randomUUID();
      setMessages(prev => [
        ...prev,
        {
          id: assistantMessageId,
          role: 'assistant',
          content: '',
          createdAt: new Date().toISOString(),
          agentType: selectedAgent,
        },
      ]);

      // Try SSE streaming first
      const eventSource = aiService.streamMessage(
        organizationId,
        message,
        selectedAgent,
        activeConversationId ?? undefined,
      );

      eventSourceRef.current = eventSource;

      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);

          if (data.type === 'token') {
            setMessages(prev =>
              prev.map(msg =>
                msg.id === assistantMessageId
                  ? { ...msg, content: msg.content + data.content }
                  : msg,
              ),
            );
          } else if (data.type === 'done') {
            setMessages(prev =>
              prev.map(msg =>
                msg.id === assistantMessageId
                  ? { ...msg, content: data.fullContent ?? msg.content }
                  : msg,
              ),
            );
            eventSource.close();
            setIsStreaming(false);
          } else if (data.type === 'tool_call') {
            setMessages(prev =>
              prev.map(msg =>
                msg.id === assistantMessageId
                  ? {
                      ...msg,
                      toolCalls: [
                        ...(msg.toolCalls ?? []),
                        {
                          id: data.toolCallId,
                          toolName: data.toolName,
                          params: data.params ?? {},
                          result: data.result,
                          status: data.status ?? 'success',
                        },
                      ],
                    }
                  : msg,
              ),
            );
          } else if (data.type === 'error') {
            setError(data.message ?? 'AI error');
            eventSource.close();
            setIsStreaming(false);
          }
        } catch {
          // Non-JSON event, ignore
        }
      };

      eventSource.onerror = () => {
        eventSource.close();
        // Fallback to non-streaming API
        aiService
          .sendMessage(organizationId, message, selectedAgent, activeConversationId ?? undefined)
          .then((response: ChatResponse) => {
            setMessages(prev =>
              prev.map(msg =>
                msg.id === assistantMessageId
                  ? { ...msg, content: response.response, agentType: selectedAgent }
                  : msg,
              ),
            );
          })
          .catch((err: Error) => {
            setError(err.message ?? 'Failed to send message');
          })
          .finally(() => {
            setIsStreaming(false);
          });
      };
    } catch (err) {
      setError((err as Error).message ?? 'Failed to send message');
      setIsStreaming(false);
    }
  }, [isStreaming, organizationId, selectedAgent, activeConversationId]);

  // ─── Agent Selection ──────────────────────────────────────────────

  const selectAgent = useCallback((agentId: string) => {
    setSelectedAgent(agentId);
  }, []);

  // ─── Load Conversations ───────────────────────────────────────────

  const loadConversations = useCallback(async () => {
    if (!organizationId) return;
    try {
      const result = await aiService.getConversations(organizationId, { page: 1, limit: 50 });
      setConversations(result.data);
    } catch {
      // Silently fail — conversations are optional
    }
  }, [organizationId]);

  // ─── Load Specific Conversation ───────────────────────────────────

  const loadConversation = useCallback(async (conversationId: string) => {
    try {
      const msgs = await aiService.getConversationMessages(conversationId);
      setMessages(msgs);
      setActiveConversationId(conversationId);
    } catch {
      setError('Failed to load conversation');
    }
  }, []);

  // ─── Clear Chat ───────────────────────────────────────────────────

  const clearChat = useCallback(() => {
    setMessages([]);
    setActiveConversationId(null);
    eventSourceRef.current?.close();
    setIsStreaming(false);
    setError(null);
  }, []);

  // ─── Delete Conversation ───────────────────────────────────────────

  const deleteConversation = useCallback(async (conversationId: string) => {
    try {
      await aiService.deleteConversation(conversationId);
      setConversations(prev => prev.filter(c => c.id !== conversationId));
      if (activeConversationId === conversationId) {
        clearChat();
      }
    } catch {
      setError('Failed to delete conversation');
    }
  }, [activeConversationId, clearChat]);

  // ─── Set Active Conversation ──────────────────────────────────────

  const setActiveConversation = useCallback((id: string | null) => {
    setActiveConversationId(id);
  }, []);

  return {
    // State
    isOpen,
    messages,
    isStreaming,
    selectedAgent,
    conversations,
    activeConversationId,
    error,

    // Actions
    toggle,
    open,
    close,
    sendMessage,
    selectAgent,
    loadConversations,
    loadConversation,
    clearChat,
    deleteConversation,
    setActiveConversation,
  };
}

export default useAiCopilot;