import { useQuery } from '@tanstack/react-query';
import { apiGet } from '@/api/client';
import type { PaginatedResponse } from '@/shared/types';

export function useApi<T>(
  queryKey: string[],
  endpoint: string,
  params?: Record<string, unknown>,
  options?: { enabled?: boolean }
) {
  const { data, isLoading, error, refetch, isFetching } = useQuery<PaginatedResponse<T>>({
    queryKey: [...queryKey, params],
    queryFn: () => apiGet<PaginatedResponse<T>>(endpoint, params),
    enabled: options?.enabled !== false,
    staleTime: 30000,
  });

  return {
    data: data?.data ?? [],
    meta: data?.meta ?? { total: 0, page: 1, limit: 10, totalPages: 0 },
    isLoading,
    error,
    refetch,
    isFetching,
  };
}

export function useApiSingle<T>(
  queryKey: string[],
  endpoint: string,
  options?: { enabled?: boolean }
) {
  const { data, isLoading, error, refetch, isFetching } = useQuery<T>({
    queryKey,
    queryFn: () => apiGet<T>(endpoint),
    enabled: options?.enabled !== false,
    staleTime: 30000,
  });

  return {
    data,
    isLoading,
    error,
    refetch,
    isFetching,
  };
}