import { create } from 'zustand';
import { apiPost, apiGet } from '@/api/client';
import { endpoints } from '@/api/endpoints';
import type { UserWithRoles } from '@/shared/types';

interface AuthState {
  user: UserWithRoles | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  setUser: (user: UserWithRoles) => void;
  initialize: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: localStorage.getItem('tb_token'),
  isAuthenticated: !!localStorage.getItem('tb_token'),
  isLoading: true,

  initialize: async () => {
    const token = localStorage.getItem('tb_token');
    if (!token) {
      set({ isLoading: false, isAuthenticated: false });
      return;
    }
    try {
      const user = await apiGet<UserWithRoles>(endpoints.auth.me);
      set({ user, isAuthenticated: true, isLoading: false });
    } catch {
      localStorage.removeItem('tb_token');
      localStorage.removeItem('tb_user');
      set({ user: null, token: null, isAuthenticated: false, isLoading: false });
    }
  },

  login: async (email: string, password: string) => {
    const response = await apiPost<{ token: string; user: UserWithRoles }>(
      endpoints.auth.login,
      { email, password }
    );
    localStorage.setItem('tb_token', response.token);
    set({
      token: response.token,
      user: response.user,
      isAuthenticated: true,
    });
  },

  logout: () => {
    localStorage.removeItem('tb_token');
    localStorage.removeItem('tb_user');
    set({
      user: null,
      token: null,
      isAuthenticated: false,
    });
  },

  setUser: (user: UserWithRoles) => set({ user }),
}));