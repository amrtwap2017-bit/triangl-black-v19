import { useState, useCallback } from 'react';

export function usePagination(defaultLimit = 10) {
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(defaultLimit);

  const paginationParams = useCallback(
    () => ({ page, limit }),
    [page, limit]
  );

  const handlePageChange = useCallback((newPage: number) => {
    setPage(newPage);
  }, []);

  const handleLimitChange = useCallback((newLimit: number) => {
    setLimit(newLimit);
    setPage(1);
  }, []);

  return {
    page,
    limit,
    setPage: handlePageChange,
    setLimit: handleLimitChange,
    paginationParams,
  };
}