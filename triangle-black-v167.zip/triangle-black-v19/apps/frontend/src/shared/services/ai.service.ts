import { apiClient } from '@/api/client';
import { endpoints } from '@/api/endpoints';

// ─── Types ─────────────────────────────────────────────────────────────

export interface ChatResponse {
  response: string;
  metadata: {
    context?: string;
    agentType?: string;
    tokensUsed?: number;
  };
}

export interface Conversation {
  id: string;
  title: string;
  agentType: string;
  messageCount: number;
  updatedAt: string;
}

export interface ConversationMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: string;
  agentType?: string;
  toolCalls?: ToolCallResult[];
}

export interface ToolCallResult {
  id: string;
  toolName: string;
  params: Record<string, unknown>;
  result: unknown;
  status: 'success' | 'error';
}

export interface ConversationList {
  data: Conversation[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

export interface UsageSummary {
  totalInteractions: number;
  totalPromptTokens: number;
  totalCompletionTokens: number;
  byAgent: Array<{
    agentType: string;
    count: number;
    promptTokens: number;
    completionTokens: number;
  }>;
  period: string;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
}

// ─── AI Service ────────────────────────────────────────────────────────

class AiService {
  /**
   * Send a message and receive a complete response.
   */
  async sendMessage(
    organizationId: string,
    message: string,
    agentType?: string,
    conversationId?: string,
  ): Promise<ChatResponse> {
    const response = await apiClient.post<ChatResponse>(endpoints.assistant.chat, {
      message,
      agentType,
      conversationId,
      organizationId,
    });
    return response.data;
  }

  /**
   * Stream a message using Server-Sent Events.
   * Returns an EventSource for consuming the stream.
   */
  streamMessage(
    organizationId: string,
    message: string,
    agentType?: string,
    conversationId?: string,
  ): EventSource {
    const token = localStorage.getItem('tb_token');
    const baseUrl = apiClient.defaults.baseURL || '/api/v1';
    const params = new URLSearchParams({
      message,
      organizationId,
      ...(agentType ? { agentType } : {}),
      ...(conversationId ? { conversationId } : {}),
    });

    const url = `${baseUrl}${endpoints.assistant.chat}/stream?${params.toString()}`;

    return new EventSource(url, {
      withCredentials: false,
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    } as EventSourceInit);
  }

  /**
   * Get list of conversations for an organization.
   */
  async getConversations(
    organizationId: string,
    pagination?: PaginationParams,
  ): Promise<ConversationList> {
    const response = await apiClient.get<ConversationList>('/assistant/conversations', {
      params: { organizationId, ...pagination },
    });
    return response.data;
  }

  /**
   * Get messages for a specific conversation.
   */
  async getConversationMessages(conversationId: string): Promise<ConversationMessage[]> {
    const response = await apiClient.get<ConversationMessage[]>(
      `/assistant/conversations/${conversationId}/messages`,
    );
    return response.data;
  }

  /**
   * Delete a conversation.
   */
  async deleteConversation(conversationId: string): Promise<void> {
    await apiClient.delete(`/assistant/conversations/${conversationId}`);
  }

  /**
   * Get AI usage summary for an organization.
   */
  async getUsageSummary(
    organizationId: string,
    period?: string,
  ): Promise<UsageSummary> {
    const response = await apiClient.get<UsageSummary>('/assistant/usage', {
      params: { organizationId, period },
    });
    return response.data;
  }

  /**
   * Generate a proposal draft using AI.
   */
  async generateProposalDraft(
    organizationId: string,
    userId: string,
    data: { description: string; hotelName?: string; scope?: string },
  ): Promise<unknown> {
    const response = await apiClient.post(endpoints.assistant.proposalDraft, {
      organizationId,
      userId,
      ...data,
    });
    return response.data;
  }

  /**
   * Generate a BOQ using AI.
   */
  async generateBoq(
    organizationId: string,
    userId: string,
    data: { description: string; scope?: string; projectType?: string },
  ): Promise<unknown> {
    const response = await apiClient.post(endpoints.assistant.boqGenerate, {
      organizationId,
      userId,
      ...data,
    });
    return response.data;
  }

  /**
   * Review project risks using AI.
   */
  async reviewRisk(
    organizationId: string,
    userId: string,
    projectId: string,
  ): Promise<unknown> {
    const response = await apiClient.post(endpoints.assistant.riskReview, {
      organizationId,
      userId,
      projectId,
    });
    return response.data;
  }

  /**
   * Generate an executive summary using AI.
   */
  async generateSummary(
    organizationId: string,
    userId: string,
    period?: string,
  ): Promise<unknown> {
    const response = await apiClient.post(endpoints.assistant.summary, {
      organizationId,
      userId,
      period,
    });
    return response.data;
  }

  /**
   * Generate a site visit report using AI.
   */
  async generateSiteVisitReport(
    organizationId: string,
    userId: string,
    siteVisitId: string,
  ): Promise<unknown> {
    const response = await apiClient.post(endpoints.assistant.siteVisitReport, {
      organizationId,
      userId,
      siteVisitId,
    });
    return response.data;
  }
}

export const aiService = new AiService();
export default aiService;