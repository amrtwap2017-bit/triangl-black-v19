// ==================== Prisma-matching Model Interfaces ====================

export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  avatarUrl?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface UserWithRoles extends User {
  roles: UserRole[];
}

export interface UserRole {
  id: string;
  userId: string;
  role: Role;
  grantedAt: string;
}

export type Role =
  | 'SUPER_ADMIN'
  | 'ADMIN'
  | 'SALES_MANAGER'
  | 'SALES_REP'
  | 'PROJECT_MANAGER'
  | 'SITE_ENGINEER'
  | 'PROCUREMENT_OFFICER'
  | 'EMERGENCY_RESPONSE'
  | 'FINANCE'
  | 'VIEWER';

export interface Organization {
  id: string;
  name: string;
  nameAr?: string;
  logoUrl?: string;
  isActive: boolean;
  createdAt: string;
}

export interface Hotel {
  id: string;
  name: string;
  nameAr?: string;
  chain?: string;
  starRating: number;
  city: string;
  cityAr?: string;
  country: string;
  countryAr?: string;
  address: string;
  addressAr?: string;
  latitude?: number;
  longitude?: number;
  totalRooms?: number;
  openingDate?: string;
  contactCount: number;
  projectCount: number;
  relationshipScore: number;
  totalRevenue: number;
  isActive: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface HotelContact {
  id: string;
  hotelId: string;
  name: string;
  nameAr?: string;
  title: string;
  titleAr?: string;
  email?: string;
  phone?: string;
  mobile?: string;
  isPrimary: boolean;
  department?: string;
  notes?: string;
  createdAt: string;
}

export interface PartnerRequest {
  id: string;
  requestNumber: string;
  hotelId: string;
  hotel?: Hotel;
  hotelContactId?: string;
  contact?: HotelContact;
  requestType: RequestType;
  title: string;
  titleAr?: string;
  description: string;
  priority: Priority;
  status: PartnerRequestStatus;
  assignedToId?: string;
  assignedTo?: User;
  estimatedValue?: number;
  deadline?: string;
  source: string;
  internalNotes?: string;
  convertedToOpportunityId?: string;
  createdAt: string;
  updatedAt: string;
}

export type RequestType =
  | 'MAINTENANCE'
  | 'RENOVATION'
  | 'NEW_CONSTRUCTION'
  | 'FF&E'
  | 'OS&E'
  | 'CONSULTATION'
  | 'EMERGENCY_REPAIR'
  | 'OTHER';

export type Priority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type PartnerRequestStatus =
  | 'NEW'
  | 'ACKNOWLEDGED'
  | 'ASSIGNED'
  | 'SITE_VISIT_SCHEDULED'
  | 'CONVERTED'
  | 'CLOSED_LOST'
  | 'CLOSED_WON';

export interface SiteVisit {
  id: string;
  visitNumber: string;
  partnerRequestId: string;
  partnerRequest?: PartnerRequest;
  hotelId: string;
  hotel?: Hotel;
  assignedToId: string;
  assignedTo?: User;
  scheduledDate: string;
  completedDate?: string;
  status: SiteVisitStatus;
  purpose: string;
  findings?: string;
  recommendations?: string;
  scopeAssessment?: string;
  estimatedBudget?: number;
  draftOpportunityId?: string;
  photos: SiteVisitPhoto[];
  attendees: string[];
  createdAt: string;
  updatedAt: string;
}

export type SiteVisitStatus = 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';

export interface SiteVisitPhoto {
  id: string;
  siteVisitId: string;
  url: string;
  thumbnailUrl?: string;
  caption?: string;
  takenAt: string;
  uploadedBy: string;
}

export interface Opportunity {
  id: string;
  opportunityNumber: string;
  hotelId: string;
  hotel?: Hotel;
  partnerRequestId?: string;
  siteVisitId?: string;
  title: string;
  description: string;
  value: number;
  currency: string;
  stage: OpportunityStage;
  probability: number;
  assignedToId?: string;
  assignedTo?: User;
  estimatedStartDate?: string;
  estimatedDuration?: number;
  estimatedEndDate?: string;
  competition?: string;
  winReason?: string;
  lossReason?: string;
  closedAt?: string;
  internalNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export type OpportunityStage =
  | 'LEAD'
  | 'QUALIFIED'
  | 'PROPOSAL_SENT'
  | 'NEGOTIATION'
  | 'VERBAL_AGREEMENT'
  | 'CONTRACT_SIGNED'
  | 'CLOSED_WON'
  | 'CLOSED_LOST';

export interface Proposal {
  id: string;
  proposalNumber: string;
  opportunityId: string;
  opportunity?: Opportunity;
  hotelId: string;
  hotel?: Hotel;
  title: string;
  description?: string;
  status: ProposalStatus;
  version: number;
  validUntil?: string;
  executiveSummary?: string;
  scopeOfWork?: string;
  commercialTerms?: string;
  paymentTerms?: string;
  warrantyTerms?: string;
  totalValue: number;
  currency: string;
  discount?: number;
  taxRate?: number;
  preparedById: string;
  preparedBy?: User;
  approvedById?: string;
  approvedBy?: User;
  approvedAt?: string;
  presentedAt?: string;
  submittedAt?: string;
  boqItems: ProposalBOQItem[];
  timeline: ProposalTimeline[];
  guestProtection?: GuestProtectionAssessment;
  createdAt: string;
  updatedAt: string;
}

export type ProposalStatus =
  | 'DRAFT'
  | 'INTERNAL_REVIEW'
  | 'SUBMITTED'
  | 'PRESENTED'
  | 'APPROVED'
  | 'REJECTED'
  | 'REVISION_REQUESTED'
  | 'EXPIRED';

export interface ProposalBOQItem {
  id?: string;
  proposalId?: string;
  section: string;
  description: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  notes?: string;
  sortOrder: number;
}

export interface ProposalTimeline {
  id?: string;
  proposalId?: string;
  phase: string;
  description: string;
  startDate: string;
  endDate: string;
  duration: number;
  deliverables: string[];
  sortOrder: number;
}

export interface GuestProtectionAssessment {
  id?: string;
  proposalId?: string;
  noiseAssessment: string;
  noiseMitigation: string[];
  dustAssessment: string;
  dustMitigation: string[];
  odorAssessment: string;
  odorMitigation: string[];
  shutdownRequirements: string[];
  communicationPlan: string;
  monitoringPlan: string;
  overallRiskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export interface Project {
  id: string;
  projectNumber: string;
  proposalId?: string;
  hotelId: string;
  hotel?: Hotel;
  opportunityId?: string;
  title: string;
  description?: string;
  status: ProjectStatus;
  type: ProjectType;
  startDate: string;
  endDate?: string;
  actualEndDate?: string;
  budget: number;
  actualCost: number;
  revenue: number;
  progress: number;
  location?: string;
  projectManagerId?: string;
  projectManager?: User;
  clientContactId?: string;
  clientContact?: HotelContact;
  contractNumber?: string;
  contractValue?: number;
  warrantyExpiry?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type ProjectStatus =
  | 'PLANNING'
  | 'IN_PROGRESS'
  | 'ON_HOLD'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'CLOSED';

export type ProjectType =
  | 'MAINTENANCE'
  | 'RENOVATION'
  | 'NEW_CONSTRUCTION'
  | 'FF&E_INSTALLATION'
  | 'OS&E_SUPPLY'
  | 'CONSULTATION'
  | 'EMERGENCY_REPAIR';

export interface ProjectMember {
  id: string;
  projectId: string;
  userId: string;
  user?: User;
  role: string;
  joinDate: string;
  leaveDate?: string;
  allocation: number;
}

export interface ProjectMilestone {
  id: string;
  projectId: string;
  name: string;
  description?: string;
  dueDate: string;
  completedDate?: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'OVERDUE';
  progress: number;
  sortOrder: number;
}

export interface ProjectTask {
  id: string;
  projectId: string;
  milestoneId?: string;
  assigneeId?: string;
  assignee?: User;
  title: string;
  description?: string;
  status: TaskStatus;
  priority: Priority;
  dueDate?: string;
  completedAt?: string;
  estimatedHours?: number;
  actualHours?: number;
  sortOrder: number;
  createdAt: string;
}

export type TaskStatus = 'TODO' | 'IN_PROGRESS' | 'REVIEW' | 'DONE' | 'CANCELLED';

export interface DailyReport {
  id: string;
  projectId: string;
  project?: Project;
  reportDate: string;
  weather?: string;
  temperature?: number;
  workCompleted: string;
  workPlannedTomorrow: string;
  issues?: string;
  manpowerCount: number;
  safetyIncidents: number;
  photos: string[];
  preparedById: string;
  preparedBy?: User;
  reviewedById?: string;
  reviewedBy?: User;
  reviewedAt?: string;
  createdAt: string;
}

export interface VariationOrder {
  id: string;
  projectId: string;
  project?: Project;
  voNumber: string;
  title: string;
  description: string;
  reason: string;
  status: VariationStatus;
  value: number;
  impactOnSchedule?: string;
  approvedById?: string;
  approvedBy?: User;
  approvedAt?: string;
  createdAt: string;
}

export type VariationStatus = 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'IMPLEMENTED';

export interface GuestProtectionPlan {
  id: string;
  projectId: string;
  project?: Project;
  noiseControl: string;
  dustControl: string;
  odorControl: string;
  workSchedule: string;
  shutdownPlan: string;
  guestCommunication: string;
  monitoringMeasures: string;
  emergencyProcedures: string;
  lastUpdated: string;
  updatedById: string;
}

export interface ProjectMargin {
  projectId: string;
  project?: Project;
  totalRevenue: number;
  totalCost: number;
  grossProfit: number;
  grossMargin: number;
  laborCost: number;
  materialCost: number;
  equipmentCost: number;
  subcontractorCost: number;
  overheadCost: number;
  contingencyAmount: number;
  contingencyUsed: number;
  variationOrdersValue: number;
  actualMargin: number;
  budgetVariance: number;
}

// Procurement
export interface ProcurementRequest {
  id: string;
  requestNumber: string;
  projectId: string;
  project?: Project;
  requestedById: string;
  requestedBy?: User;
  title: string;
  description: string;
  urgency: Priority;
  status: ProcurementStatus;
  requiredDate?: string;
  vendorId?: string;
  vendor?: Vendor;
  estimatedCost: number;
  approvedById?: string;
  approvedBy?: User;
  approvedAt?: string;
  items: ProcurementRequestItem[];
  createdAt: string;
}

export type ProcurementStatus = 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'PO_CREATED' | 'RECEIVED' | 'REJECTED' | 'CANCELLED';

export interface ProcurementRequestItem {
  id?: string;
  description: string;
  specification?: string;
  quantity: number;
  unit: string;
  estimatedUnitPrice: number;
  estimatedTotal: number;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  procurementRequestId: string;
  vendorId: string;
  vendor?: Vendor;
  projectId: string;
  project?: Project;
  status: POStatus;
  subtotal: number;
  tax: number;
  shipping: number;
  total: number;
  currency: string;
  expectedDeliveryDate?: string;
  actualDeliveryDate?: string;
  paymentTerms?: string;
  notes?: string;
  items: PurchaseOrderItem[];
  createdAt: string;
}

export type POStatus = 'DRAFT' | 'ISSUED' | 'CONFIRMED' | 'SHIPPED' | 'DELIVERED' | 'PARTIALLY_DELIVERED' | 'RECEIVED' | 'CANCELLED';

export interface PurchaseOrderItem {
  id?: string;
  description: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  totalPrice: number;
}

// Vendors
export interface Vendor {
  id: string;
  name: string;
  nameAr?: string;
  contactPerson: string;
  email: string;
  phone: string;
  address?: string;
  city?: string;
  country?: string;
  categories: string[];
  rating: number;
  isActive: boolean;
  bankName?: string;
  bankAccount?: string;
  iban?: string;
  taxId?: string;
  paymentTerms?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface VendorEvaluation {
  id: string;
  vendorId: string;
  vendor?: Vendor;
  projectId?: string;
  project?: Project;
  qualityScore: number;
  deliveryScore: number;
  costScore: number;
  reliabilityScore: number;
  responsivenessScore: number;
  overallScore: number;
  evaluatedById: string;
  evaluatedBy?: User;
  comments?: string;
  evaluationDate: string;
}

// Emergency
export interface EmergencyCase {
  id: string;
  caseNumber: string;
  hotelId: string;
  hotel?: Hotel;
  projectId?: string;
  project?: Project;
  title: string;
  description: string;
  severity: Severity;
  status: EmergencyStatus;
  reportedById: string;
  reportedBy?: User;
  assignedToId?: string;
  assignedTo?: User;
  responseTime?: number;
  resolvedAt?: string;
  resolution?: string;
  rootCause?: string;
  preventiveMeasures?: string;
  guestImpact?: string;
  slaTarget?: number;
  createdAt: string;
  updatedAt: string;
}

export type Severity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type EmergencyStatus = 'OPEN' | 'IN_PROGRESS' | 'ESCALATED' | 'RESOLVED' | 'CLOSED';

// Contracts
export interface Contract {
  id: string;
  contractNumber: string;
  projectId?: string;
  project?: Project;
  hotelId: string;
  hotel?: Hotel;
  title: string;
  type: string;
  status: 'DRAFT' | 'ACTIVE' | 'EXPIRED' | 'TERMINATED';
  value?: number;
  startDate: string;
  endDate?: string;
  signedDate?: string;
  version: number;
  terms?: string;
  filePath?: string;
  createdAt: string;
  updatedAt: string;
}

// Documents
export interface Document {
  id: string;
  title: string;
  description?: string;
  category: DocumentCategory;
  fileType: string;
  fileSize: number;
  filePath: string;
  projectId?: string;
  project?: Project;
  hotelId?: string;
  hotel?: Hotel;
  proposalId?: string;
  uploadedById: string;
  uploadedBy?: User;
  tags?: string[];
  version: number;
  isLatest: boolean;
  createdAt: string;
}

export type DocumentCategory = 'CONTRACT' | 'DRAWING' | 'PHOTO' | 'REPORT' | 'PROPOSAL' | 'BOQ' | 'METHOD_STATEMENT' | 'WARRANTY' | 'CERTIFICATE' | 'OTHER';

// Notifications
export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR';
  isRead: boolean;
  link?: string;
  createdAt: string;
}

// Audit
export interface AuditLog {
  id: string;
  userId: string;
  user?: User;
  action: string;
  entity: string;
  entityId?: string;
  details?: string;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

// Analytics
export interface RevenueData {
  month: string;
  revenue: number;
  cost: number;
  profit: number;
}

export interface PipelineData {
  stage: string;
  count: number;
  value: number;
}

export interface SlaTrackingData {
  severity: string;
  targetMinutes: number;
  averageMinutes: number;
  complianceRate: number;
  totalCases: number;
}

// Assistant
export interface AssistantMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

// ==================== Generic Types ====================

export interface PaginatedResponse<T> {
  data: T[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}

export interface SelectOption {
  value: string;
  label: string;
  labelAr?: string;
}

export interface Column<T> {
  key: keyof T | string;
  header: string;
  headerAr?: string;
  render?: (value: unknown, row: T) => React.ReactNode;
  sortable?: boolean;
  width?: string;
  align?: 'start' | 'center' | 'end';
}

export interface BreadcrumbItem {
  label: string;
  labelAr?: string;
  href?: string;
}