import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { BullModule } from '@nestjs/bullmq';
import { PrismaModule } from './infrastructure/prisma/prisma.module';
import { PdfWorkerModule } from './workers/pdf/pdf.module';
import { EmailWorkerModule } from './workers/email/email.module';
import { AiWorkerModule } from './workers/ai/ai.module';
import { ReportsWorkerModule } from './workers/reports/reports.module';
import { NotificationWorkerModule } from './workers/notifications/notifications.module';
import { RfqWorkerModule } from './workers/rfq/rfq.module';
import { CapexWorkerModule } from './workers/capex/capex.module';
import { DocumentWorkerModule } from './workers/documents/documents.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env', `.env.${process.env.NODE_ENV || 'development'}`],
    }),
    BullModule.forRoot({
      connection: {
        host: process.env.REDIS_HOST ?? 'localhost',
        port: parseInt(process.env.REDIS_PORT ?? '6379', 10),
      },
      defaultJobOptions: {
        removeOnComplete: { count: 100 },
        removeOnFail: { count: 50 },
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 2000,
        },
      },
    }),
    PrismaModule,
    PdfWorkerModule,
    EmailWorkerModule,
    AiWorkerModule,
    ReportsWorkerModule,
    NotificationWorkerModule,
    RfqWorkerModule,
    CapexWorkerModule,
    DocumentWorkerModule,
  ],
})
export class AppModule {}