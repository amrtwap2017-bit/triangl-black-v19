import { Logger } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const logger = new Logger('WorkersBootstrap');

  const app = await NestFactory.createApplicationContext(AppModule, {
    logger: ['log', 'warn', 'error', 'fatal'],
  });

  logger.log('🚀 TRIANGLE BLACK V16 Workers started');
  logger.log(`📧 Email queue worker active`);
  logger.log(`📄 PDF queue worker active`);
  logger.log(`🤖 AI queue worker active`);
  logger.log(`📊 Reports queue worker active`);
  logger.log(`🔔 Notifications queue worker active`);
  logger.log(`📄 Document processing queue worker active`);

  // Graceful shutdown
  const shutdown = async (signal: string) => {
    logger.log(`Received ${signal}, shutting down gracefully...`);
    await app.close();
    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

bootstrap();