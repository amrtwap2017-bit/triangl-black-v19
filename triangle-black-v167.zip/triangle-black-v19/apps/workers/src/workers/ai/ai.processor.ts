import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';

interface AiJobData {
  type: 'proposal-draft' | 'boq-generate' | 'site-visit-report' | 'drawing-analysis' | 'risk-assessment';
  data: any;
}

@Processor('ai')
export class AiProcessor extends WorkerHost {
  private readonly logger = new Logger(AiProcessor.name);

  constructor(private readonly prisma: PrismaService) {
    super();
  }

  async process(job: Job<AiJobData>): Promise<any> {
    const { type, data } = job.data;

    this.logger.log(`Processing AI job [${type}]`);

    try {
      switch (type) {
        case 'proposal-draft':
          return await this.processProposalDraft(data);
        case 'boq-generate':
          return await this.processBoQGeneration(data);
        case 'site-visit-report':
          return await this.processSiteVisitReport(data);
        case 'drawing-analysis':
          return await this.processDrawingAnalysis(data);
        case 'risk-assessment':
          return await this.processRiskAssessment(data);
        default:
          throw new Error(`Unknown AI job type: ${type}`);
      }
    } catch (error) {
      this.logger.error(
        `AI job [${type}] failed: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw error;
    }
  }

  private async logAiInteraction(type: string, input: any, output: any): Promise<void> {
    await this.prisma.aIInteraction.create({
      data: {
        type,
        input: typeof input === 'string' ? input : JSON.stringify(input),
        output: typeof output === 'string' ? output : JSON.stringify(output),
        model: 'placeholder-model',
        tokensUsed: 0,
        userId: input?.userId ?? null,
        organizationId: input?.organizationId ?? null,
      },
    });
  }

  private async processProposalDraft(data: any): Promise<any> {
    this.logger.log(`Generating proposal draft for opportunity ${data.opportunityId}`);

    // Simulate AI processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const result = {
      draft: `Proposal draft generated for opportunity ${data.opportunityId}`,
      sections: ['executive-summary', 'scope-of-work', 'pricing', 'timeline'],
      confidence: 0.85,
    };

    await this.logAiInteraction('proposal-draft', data, result);
    this.logger.log(`Proposal draft generated for opportunity ${data.opportunityId}`);

    return result;
  }

  private async processBoQGeneration(data: any): Promise<any> {
    this.logger.log(`Generating BoQ for proposal ${data.proposalId}`);

    await new Promise((resolve) => setTimeout(resolve, 2000));

    const result = {
      items: [
        { description: 'Item 1', quantity: 10, unit: 'pcs', unitPrice: 100 },
        { description: 'Item 2', quantity: 5, unit: 'sets', unitPrice: 500 },
      ],
      totalAmount: 3500,
    };

    await this.logAiInteraction('boq-generate', data, result);
    this.logger.log(`BoQ generated for proposal ${data.proposalId}`);

    return result;
  }

  private async processSiteVisitReport(data: any): Promise<any> {
    this.logger.log(`Generating site visit report for visit ${data.siteVisitId}`);

    await new Promise((resolve) => setTimeout(resolve, 2000));

    const result = {
      summary: `Site visit report for ${data.siteVisitId}`,
      findings: ['Finding 1', 'Finding 2'],
      recommendations: ['Recommendation 1'],
    };

    await this.logAiInteraction('site-visit-report', data, result);
    this.logger.log(`Site visit report generated for visit ${data.siteVisitId}`);

    return result;
  }

  private async processDrawingAnalysis(data: any): Promise<any> {
    this.logger.log(`Analyzing drawing ${data.drawingId ?? 'unknown'}`);

    await new Promise((resolve) => setTimeout(resolve, 2000));

    const result = {
      analysis: 'Drawing analysis complete',
      detectedElements: ['walls', 'doors', 'windows', 'fixtures'],
      estimatedArea: 150,
    };

    await this.logAiInteraction('drawing-analysis', data, result);
    this.logger.log(`Drawing analysis complete for ${data.drawingId ?? 'unknown'}`);

    return result;
  }

  private async processRiskAssessment(data: any): Promise<any> {
    this.logger.log(`Running risk assessment for project ${data.projectId ?? 'unknown'}`);

    await new Promise((resolve) => setTimeout(resolve, 2000));

    const result = {
      risks: [
        { category: 'schedule', level: 'medium', description: 'Potential delay in material delivery' },
        { category: 'budget', level: 'low', description: 'Minor cost variance expected' },
      ],
      overallScore: 72,
    };

    await this.logAiInteraction('risk-assessment', data, result);
    this.logger.log(`Risk assessment complete for project ${data.projectId ?? 'unknown'}`);

    return result;
  }
}