import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { CapexProcessor } from './capex.processor';

@Module({
  imports: [
    BullModule.registerQueue({
      name: 'capex',
    }),
  ],
  providers: [CapexProcessor],
  exports: [BullModule],
})
export class CapexWorkerModule {}