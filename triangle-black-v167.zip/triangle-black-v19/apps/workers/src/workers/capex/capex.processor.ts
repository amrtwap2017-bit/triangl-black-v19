import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';

@Processor('capex')
export class CapexProcessor extends WorkerHost {
  private readonly logger = new Logger(CapexProcessor.name);

  async process(job: Job): Promise<unknown> {
    this.logger.log(`Processing CAPEX job ${job.id}: ${job.name}`);

    switch (job.name) {
      case 'generate-plan':
        return this.handleGeneratePlan(job);
      case 'calculate-forecast':
        return this.handleCalculateForecast(job);
      default:
        this.logger.warn(`Unknown CAPEX job: ${job.name}`);
        return { success: false, error: 'Unknown job type' };
    }
  }

  private async handleGeneratePlan(job: Job) {
    const { hotelId, year } = job.data;
    this.logger.log(`Generating CAPEX plan for hotel ${hotelId}, year ${year}`);
    return { success: true, hotelId, year, planGenerated: true };
  }

  private async handleCalculateForecast(job: Job) {
    const { organizationId, period } = job.data;
    this.logger.log(`Calculating forecast for org ${organizationId}, period ${period}`);
    return { success: true, organizationId, period, forecastGenerated: true };
  }
}