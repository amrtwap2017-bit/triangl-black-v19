import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger, OnModuleInit } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from '../../../infrastructure/prisma/prisma.service';
import { StorageService } from '../../../infrastructure/storage/storage.service';
import {
  DocumentProcessor,
  ChecksumService,
  type DocumentProcessingResult,
  type DocumentStatus,
} from '@triangleblack/documents';

// ─── Constants ────────────────────────────────────────────────────────────────

const PROCESSING_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes
const MAX_ATTEMPTS = 3;

// ─── Processor ────────────────────────────────────────────────────────────────

@Processor('documents', {
  concurrency: 2,
})
export class DocumentProcessingProcessor extends WorkerHost implements OnModuleInit {
  private readonly logger = new Logger(DocumentProcessingProcessor.name);
  private readonly processor: DocumentProcessor;
  private readonly checksumService: ChecksumService;

  constructor(
    private readonly prisma: PrismaService,
  ) {
    super();
    this.processor = new DocumentProcessor({
      duplicateChecker: (checksum, orgId) => this.checkDuplicateInDb(checksum, orgId),
    });
    this.checksumService = new ChecksumService();
  }

  onModuleInit() {
    this.logger.log('Document processing worker initialized (concurrency: 2, timeout: 5min)');
  }

  async process(job: Job): Promise<unknown> {
    const { documentId, organizationId } = job.data;

    this.logger.log(`Processing document job ${job.id} — document: ${documentId}`);

    // Set a hard timeout
    const timeoutController = new AbortController();
    const timeout = setTimeout(() => {
      timeoutController.abort();
    }, PROCESSING_TIMEOUT_MS);

    try {
      const result = await this.processWithTimeout(documentId, organizationId, job);
      clearTimeout(timeout);
      return result;
    } catch (err) {
      clearTimeout(timeout);

      const errorMessage = err instanceof Error ? err.message : String(err);
      const isTimeout = errorMessage.includes('abort') || errorMessage.includes('timeout') || errorMessage.includes('TIMEOUT');

      // Update document status to ERROR
      try {
        await this.prisma.document.update({
          where: { id: documentId },
          data: {
            status: 'ERROR',
            processingError: isTimeout
              ? `Processing timed out after ${PROCESSING_TIMEOUT_MS / 1000}s`
              : `Processing failed: ${errorMessage}`,
          },
        });
      } catch (dbErr) {
        this.logger.error(`Failed to update document status to ERROR: ${dbErr}`);
      }

      // If we've exhausted retries, this goes to dead letter queue
      if (job.attemptsMade >= MAX_ATTEMPTS) {
        this.logger.error(`Document ${documentId} permanently failed after ${MAX_ATTEMPTS} attempts. Moving to dead letter queue.`);
      } else {
        this.logger.warn(`Document ${documentId} failed (attempt ${job.attemptsMade}/${MAX_ATTEMPTS}): ${errorMessage}`);
      }

      throw err;
    }
  }

  // ─── Processing Logic ───────────────────────────────────────────────────────

  private async processWithTimeout(
    documentId: string,
    organizationId: string,
    job: Job,
  ): Promise<DocumentProcessingResult> {
    // Load document from DB
    const document = await this.prisma.document.findUnique({
      where: { id: documentId },
    });

    if (!document) {
      this.logger.error(`Document ${documentId} not found in database`);
      throw new Error(`Document ${documentId} not found`);
    }

    if (document.organizationId !== organizationId) {
      throw new Error(`Document ${documentId} does not belong to organization ${organizationId}`);
    }

    if (document.status === 'DELETED') {
      this.logger.warn(`Document ${documentId} is deleted, skipping processing`);
      return {
        documentId,
        status: 'ERROR',
        text: '',
        chunks: [],
        classification: { category: 'OTHER', confidence: 0, matchedKeywords: [], method: 'default' },
        tables: [],
        images: [],
        checksum: { algorithm: 'sha256', hash: '', computedAt: new Date() },
        duplicateCheck: { isDuplicate: false },
        scanResult: { safe: true },
        progress: [],
        errors: ['Document is deleted'],
        warnings: [],
        processingDurationMs: 0,
        metadata: { fileName: document.title || '', mimeType: document.mimeType, fileSize: document.fileSize },
      };
    }

    // Update status to VALIDATING
    await this.updateDocumentStatus(documentId, 'VALIDATING');

    // Download file from storage
    this.logger.log(`Downloading document ${documentId} from storage: ${document.storageKey}`);
    const storageService = new StorageService();
    const buffer = await storageService.download(document.storageKey);

    // Report progress: 10%
    job.updateProgress(10);

    // Run the full pipeline
    const result = await this.processor.process({
      buffer,
      fileName: document.title || document.storageKey,
      mimeType: document.mimeType,
      documentId: document.id,
      organizationId: document.organizationId,
    });

    // Report progress: 90%
    job.updateProgress(90);

    // Update document with processing results
    const updateData: any = {
      status: result.status,
      textContent: result.text || null,
      pageCount: result.metadata.pageCount ?? result.metadata.pageCountParsed ?? null,
      checksum: result.checksum.hash,
      author: result.metadata.author || null,
      category: result.classification.category,
      processingDuration: result.processingDurationMs,
      processingError: result.errors.length > 0 ? result.errors.join('; ') : null,
      processedAt: new Date(),
    };

    // Store chunks
    if (result.chunks.length > 0) {
      updateData.chunkCount = result.chunks.length;
      // Delete existing chunks before re-creating (for reprocessing)
      await this.prisma.documentChunk.deleteMany({ where: { documentId } });
      updateData.chunks = {
        create: result.chunks.map(chunk => ({
          text: chunk.text,
          chunkIndex: chunk.index,
          startOffset: chunk.startOffset,
          endOffset: chunk.endOffset,
          tokenCount: chunk.tokenCount,
        })),
      };
    }

    await this.prisma.document.update({
      where: { id: documentId },
      data: updateData,
    });

    // Report progress: 100%
    job.updateProgress(100);

    this.logger.log(
      `Document ${documentId} processing complete: status=${result.status}, ` +
      `chunks=${result.chunks.length}, duration=${result.processingDurationMs}ms, ` +
      `errors=${result.errors.length}, category=${result.classification.category}`,
    );

    return result;
  }

  // ─── Helpers ────────────────────────────────────────────────────────────────

  private async updateDocumentStatus(documentId: string, status: DocumentStatus) {
    try {
      await this.prisma.document.update({
        where: { id: documentId },
        data: { status },
      });
    } catch (err) {
      this.logger.error(`Failed to update document ${documentId} status to ${status}: ${err}`);
    }
  }

  private async checkDuplicateInDb(checksum: string, organizationId?: string) {
    if (!organizationId) return { isDuplicate: false };

    const existing = await this.prisma.document.findFirst({
      where: {
        organizationId,
        checksum,
        deletedAt: null,
      },
      select: { id: true, title: true, checksum: true },
    });

    return {
      isDuplicate: !!existing,
      existingChecksum: existing?.checksum,
      existingDocumentId: existing?.id,
      existingFileName: existing?.title,
    };
  }
}