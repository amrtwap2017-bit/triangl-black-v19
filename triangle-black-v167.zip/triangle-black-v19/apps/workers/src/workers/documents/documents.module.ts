import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { DocumentProcessingProcessor } from './document-processing.processor';

@Module({
  imports: [
    BullModule.registerQueue({
      name: 'documents',
      defaultJobOptions: {
        timeout: 5 * 60 * 1000, // 5 minutes
        attempts: 3,
        backoff: {
          type: 'exponential',
          delay: 5000, // 5s, 25s, 125s
        },
        removeOnComplete: { count: 500 },
        removeOnFail: { count: 100 },
      },
    }),
  ],
  providers: [DocumentProcessingProcessor],
  exports: [BullModule],
})
export class DocumentWorkerModule {}