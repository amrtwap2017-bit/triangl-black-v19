import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';

@Processor('email')
export class EmailProcessor extends WorkerHost {
  private readonly logger = new Logger(EmailProcessor.name);
  private transporter: nodemailer.Transporter | null = null;

  constructor(private readonly configService: ConfigService) {
    super();
  }

  private getTransporter(): nodemailer.Transporter {
    if (!this.transporter) {
      const smtpHost = this.configService.get<string>('appConfig.smtp.host') ?? 'localhost';
      const smtpPort = this.configService.get<number>('appConfig.smtp.port') ?? 1025;
      const smtpUser = this.configService.get<string>('appConfig.smtp.user') ?? '';
      const smtpPass = this.configService.get<string>('appConfig.smtp.pass') ?? '';

      this.transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        auth: smtpUser ? { user: smtpUser, pass: smtpPass } : undefined,
      });
    }
    return this.transporter;
  }

  async process(job: Job): Promise<any> {
    const { type, to, subject, html, data } = job.data;

    this.logger.log(`Processing email job [${type}] to ${to}: ${subject}`);

    try {
      const from = this.configService.get<string>('appConfig.smtp.from') ?? 'noreply@triangleblack.com';

      const result = await this.getTransporter().sendMail({
        from,
        to,
        subject,
        html,
      });

      this.logger.log(
        `Email [${type}] sent successfully to ${to}. MessageId: ${result.messageId}`,
      );

      return {
        success: true,
        messageId: result.messageId,
        type,
        to,
      };
    } catch (error) {
      this.logger.error(
        `Email [${type}] failed to send to ${to}: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw error;
    }
  }
}