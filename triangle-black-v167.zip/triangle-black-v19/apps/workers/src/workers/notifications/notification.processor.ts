import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';

@Processor('notifications')
export class NotificationProcessor extends WorkerHost {
  private readonly logger = new Logger(NotificationProcessor.name);

  constructor(private readonly prisma: PrismaService) {
    super();
  }

  async process(job: Job): Promise<any> {
    const { type, userId, title, message, data } = job.data;

    this.logger.log(`Processing notification job [${type}] for user ${userId}`);

    try {
      switch (type) {
        case 'create-notification':
          return await this.createNotification(userId, type, title, message, data);
        default:
          throw new Error(`Unknown notification job type: ${type}`);
      }
    } catch (error) {
      this.logger.error(
        `Notification job [${type}] failed for user ${userId}: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw error;
    }
  }

  private async createNotification(
    userId: string,
    type: string,
    title: string,
    message: string,
    data: any,
  ): Promise<any> {
    const notification = await this.prisma.notification.create({
      data: {
        userId,
        type,
        title,
        message,
        data: data ?? {},
        isRead: false,
      },
    });

    this.logger.log(
      `Notification created: ${notification.id} for user ${userId} - ${title}`,
    );

    return { notificationId: notification.id, userId, type, title };
  }
}