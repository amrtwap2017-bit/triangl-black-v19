import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { PdfProcessor } from './pdf.processor';

@Module({
  imports: [
    BullModule.registerQueue({
      name: 'pdf',
    }),
  ],
  providers: [PdfProcessor],
})
export class PdfWorkerModule {}