import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';

@Processor('pdf')
export class PdfProcessor extends WorkerHost {
  private readonly logger = new Logger(PdfProcessor.name);

  constructor(private readonly prisma: PrismaService) {
    super();
  }

  async process(job: Job): Promise<any> {
    const { type, proposalId, data } = job.data;

    this.logger.log(`Processing PDF job [${type}] for proposal ${proposalId}`);

    try {
      switch (type) {
        case 'proposal-pdf':
          return await this.generateProposalPdf(proposalId, data);
        default:
          throw new Error(`Unknown PDF job type: ${type}`);
      }
    } catch (error) {
      this.logger.error(
        `PDF job [${type}] failed for proposal ${proposalId}: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw error;
    }
  }

  private async generateProposalPdf(proposalId: string, _data: any): Promise<{ pdfUrl: string }> {
    this.logger.log(`Generating PDF for proposal ${proposalId}`);

    // Placeholder: simulate PDF generation
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const pdfUrl = `https://storage.triangleblack.com/proposals/${proposalId}/proposal.pdf`;

    // Update proposal in database
    await this.prisma.proposal.update({
      where: { id: proposalId },
      data: { pdfUrl },
    });

    this.logger.log(`PDF generated and saved for proposal ${proposalId}: ${pdfUrl}`);

    return { pdfUrl };
  }
}