import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from '../../infrastructure/prisma/prisma.service';

@Processor('reports')
export class ReportsProcessor extends WorkerHost {
  private readonly logger = new Logger(ReportsProcessor.name);

  constructor(private readonly prisma: PrismaService) {
    super();
  }

  async process(job: Job): Promise<any> {
    const { type, data } = job.data;

    this.logger.log(`Processing report job [${type}]`);

    try {
      switch (type) {
        case 'daily-snapshot':
          return await this.generateDailySnapshot(data);
        case 'margin-report':
          return await this.generateMarginReport(data);
        case 'relationship-recalc':
          return await this.recalculateRelationshipScores(data);
        default:
          throw new Error(`Unknown report job type: ${type}`);
      }
    } catch (error) {
      this.logger.error(
        `Report job [${type}] failed: ${error instanceof Error ? error.message : String(error)}`,
      );
      throw error;
    }
  }

  private async generateDailySnapshot(data: any): Promise<any> {
    this.logger.log('Generating daily analytics snapshot');

    const organizationId = data?.organizationId;

    // Fetch counts for the snapshot
    const [activeProjects, openOpportunities, pendingProposals, openEmergencies] =
      await Promise.all([
        this.prisma.project.count({
          where: { status: 'IN_PROGRESS', ...(organizationId ? { organizationId } : {}) },
        }),
        this.prisma.opportunity.count({
          where: {
            status: { in: ['LEAD', 'QUALIFIED', 'PROPOSAL', 'NEGOTIATION'] },
            ...(organizationId ? { organizationId } : {}),
          },
        }),
        this.prisma.proposal.count({
          where: { status: 'DRAFT', ...(organizationId ? { organizationId } : {}) },
        }),
        this.prisma.emergency.count({
          where: { status: 'OPEN', ...(organizationId ? { organizationId } : {}) },
        }),
      ]);

    const snapshot = await this.prisma.analyticsSnapshot.create({
      data: {
        type: 'DAILY',
        organizationId: organizationId ?? null,
        data: {
          activeProjects,
          openOpportunities,
          pendingProposals,
          openEmergencies,
          generatedAt: new Date().toISOString(),
        },
      },
    });

    this.logger.log(`Daily snapshot created: ${snapshot.id}`);

    return { snapshotId: snapshot.id, stats: { activeProjects, openOpportunities, pendingProposals, openEmergencies } };
  }

  private async generateMarginReport(data: any): Promise<any> {
    this.logger.log('Generating margin report');

    const organizationId = data?.organizationId;

    const projects = await this.prisma.project.findMany({
      where: {
        status: { in: ['IN_PROGRESS', 'COMPLETED'] },
        ...(organizationId ? { organizationId } : {}),
      },
      select: {
        id: true,
        name: true,
        contractValue: true,
        actualCost: true,
        status: true,
      },
      take: 100,
    });

    const marginData = projects.map((p) => {
      const contractValue = p.contractValue ?? 0;
      const actualCost = p.actualCost ?? 0;
      const margin = contractValue > 0 ? ((contractValue - actualCost) / contractValue) * 100 : 0;

      return {
        projectId: p.id,
        projectName: p.name,
        contractValue,
        actualCost,
        margin: Math.round(margin * 100) / 100,
        status: p.status,
      };
    });

    this.logger.log(`Margin report generated for ${projects.length} projects`);

    return { projects: marginData, totalProjects: marginData.length };
  }

  private async recalculateRelationshipScores(data: any): Promise<any> {
    this.logger.log('Recalculating hotel relationship scores');

    const hotels = await this.prisma.hotel.findMany({
      where: data?.organizationId ? { organizationId: data.organizationId } : {},
      include: {
        _count: {
          select: {
            projects: true,
            proposals: true,
            partnerRequests: true,
          },
        },
      },
    });

    let updatedCount = 0;

    for (const hotel of hotels) {
      const projectCount = hotel._count.projects;
      const proposalCount = hotel._count.proposals;
      const requestCount = hotel._count.partnerRequests;

      // Simple scoring formula
      let score = 0;
      score += Math.min(projectCount * 25, 40); // Up to 40 points for projects
      score += Math.min(proposalCount * 15, 30); // Up to 30 points for proposals
      score += Math.min(requestCount * 10, 20); // Up to 20 points for requests
      score += 10; // Base 10 points for being in the system

      score = Math.min(score, 100);

      await this.prisma.hotelRelationship.upsert({
        where: {
          hotelId: hotel.id,
        },
        create: {
          hotelId: hotel.id,
          score,
          tier: this.getTier(score),
          lastContactedAt: new Date(),
        },
        update: {
          score,
          tier: this.getTier(score),
        },
      });

      updatedCount++;
    }

    this.logger.log(`Relationship scores recalculated for ${updatedCount} hotels`);

    return { updatedHotels: updatedCount };
  }

  private getTier(score: number): string {
    if (score >= 80) return 'PLATINUM';
    if (score >= 60) return 'GOLD';
    if (score >= 40) return 'SILVER';
    if (score >= 20) return 'BRONZE';
    return 'PROSPECT';
  }
}