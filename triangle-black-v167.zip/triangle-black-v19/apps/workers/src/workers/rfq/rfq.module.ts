import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { RfqProcessor } from './rfq.processor';

@Module({
  imports: [
    BullModule.registerQueue({
      name: 'rfq',
    }),
  ],
  providers: [RfqProcessor],
  exports: [BullModule],
})
export class RfqWorkerModule {}