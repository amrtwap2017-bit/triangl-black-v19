import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';

@Processor('rfq')
export class RfqProcessor extends WorkerHost {
  private readonly logger = new Logger(RfqProcessor.name);

  async process(job: Job): Promise<unknown> {
    this.logger.log(`Processing RFQ job ${job.id}: ${job.name}`);

    switch (job.name) {
      case 'publish-rfq':
        return this.handlePublishRfq(job);
      case 'evaluate-responses':
        return this.handleEvaluateResponses(job);
      case 'generate-comparison':
        return this.handleGenerateComparison(job);
      default:
        this.logger.warn(`Unknown RFQ job: ${job.name}`);
        return { success: false, error: 'Unknown job type' };
    }
  }

  private async handlePublishRfq(job: Job) {
    const { rfqId, vendorEmails } = job.data;
    this.logger.log(`Publishing RFQ ${rfqId} to ${vendorEmails?.length || 0} vendors`);
    // Email notifications would be sent here via MailService
    return { success: true, rfqId, notifiedVendors: vendorEmails?.length || 0 };
  }

  private async handleEvaluateResponses(job: Job) {
    const { rfqId } = job.data;
    this.logger.log(`Evaluating responses for RFQ ${rfqId}`);
    return { success: true, rfqId, evaluationCompleted: true };
  }

  private async handleGenerateComparison(job: Job) {
    const { rfqId } = job.data;
    this.logger.log(`Generating comparison report for RFQ ${rfqId}`);
    return { success: true, rfqId, reportGenerated: true };
  }
}