/**
 * Triangle Black v19 — Text Chunker
 *
 * Splits text into token-aware chunks with overlap for RAG pipelines.
 */

export interface TextChunk {
  content: string;
  index: number;
  startOffset: number;
  endOffset: number;
  metadata: Record<string, unknown>;
}

export class TextChunker {
  /**
   * Characters-per-token approximation (BPE for English text ≈ 4).
   * For tiktoken-like precision we'd use the actual tokenizer, but this is
   * a safe, dependency-free fallback.
   */
  private static readonly CHARS_PER_TOKEN = 4;

  // ─── Token Estimation ──────────────────────────────────────────────────

  static estimateTokens(text: string): number {
    return Math.ceil(text.length / this.CHARS_PER_TOKEN);
  }

  // ─── Chunk by Tokens ──────────────────────────────────────────────────

  static chunkByTokens(
    text: string,
    maxTokens = 512,
    overlap = 50,
  ): TextChunk[] {
    const maxChars = maxTokens * this.CHARS_PER_TOKEN;
    const overlapChars = overlap * this.CHARS_PER_TOKEN;
    const chunks: TextChunk[] = [];

    if (text.length <= maxChars) {
      return [{ content: text, index: 0, startOffset: 0, endOffset: text.length, metadata: {} }];
    }

    let offset = 0;
    let index = 0;

    while (offset < text.length) {
      let end = Math.min(offset + maxChars, text.length);

      // Try to break at a sentence or word boundary
      if (end < text.length) {
        const sentenceBreak = text.lastIndexOf('. ', end);
        const paragraphBreak = text.lastIndexOf('\n', end);
        const spaceBreak = text.lastIndexOf(' ', end);

        const bestBreak = Math.max(sentenceBreak, paragraphBreak, spaceBreak);
        if (bestBreak > offset) {
          end = bestBreak + 1; // Include the delimiter
        }
      }

      chunks.push({
        content: text.slice(offset, end).trim(),
        index,
        startOffset: offset,
        endOffset: end,
        metadata: {
          tokenEstimate: this.estimateTokens(text.slice(offset, end)),
          charLength: end - offset,
        },
      });

      offset = end - overlapChars;
      if (offset >= text.length) break;
      index++;
    }

    return chunks;
  }

  // ─── Chunk by Paragraph ───────────────────────────────────────────────

  static chunkByParagraph(text: string, maxChunkSize = 1000): TextChunk[] {
    const paragraphs = text.split(/\n\s*\n/).filter((p) => p.trim().length > 0);
    const chunks: TextChunk[] = [];
    let buffer = '';
    let bufferStart = 0;
    let index = 0;

    for (const paragraph of paragraphs) {
      if ((buffer + '\n\n' + paragraph).trim().length > maxChunkSize && buffer.length > 0) {
        chunks.push({
          content: buffer.trim(),
          index,
          startOffset: bufferStart,
          endOffset: bufferStart + buffer.length,
          metadata: { chunkMethod: 'paragraph', tokenEstimate: this.estimateTokens(buffer) },
        });
        index++;
        bufferStart = text.indexOf(paragraph, bufferStart);
        buffer = paragraph;
      } else {
        if (buffer.length === 0) {
          bufferStart = text.indexOf(paragraph);
        }
        buffer = buffer ? buffer + '\n\n' + paragraph : paragraph;
      }
    }

    if (buffer.trim().length > 0) {
      chunks.push({
        content: buffer.trim(),
        index,
        startOffset: bufferStart,
        endOffset: bufferStart + buffer.length,
        metadata: { chunkMethod: 'paragraph', tokenEstimate: this.estimateTokens(buffer) },
      });
    }

    return chunks;
  }

  // ─── Merge Small Chunks ───────────────────────────────────────────────

  static mergeSmallChunks(chunks: TextChunk[], minSize = 100): TextChunk[] {
    if (chunks.length === 0) return chunks;

    const merged: TextChunk[] = [];
    let current = { ...chunks[0] };

    for (let i = 1; i < chunks.length; i++) {
      const next = chunks[i];
      const combinedLength = current.content.length + next.content.length;

      if (current.content.length < minSize && combinedLength < minSize * 4) {
        current = {
          content: current.content + '\n\n' + next.content,
          index: current.index,
          startOffset: current.startOffset,
          endOffset: next.endOffset,
          metadata: { ...current.metadata, merged: true },
        };
      } else {
        merged.push(current);
        current = { ...next, index: merged.length };
      }
    }

    merged.push(current);

    // Re-index
    return merged.map((c, i) => ({ ...c, index: i }));
  }
}
