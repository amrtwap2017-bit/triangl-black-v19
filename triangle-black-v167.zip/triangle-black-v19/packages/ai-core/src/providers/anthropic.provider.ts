/**
 * Triangle Black v19 — Production-grade Anthropic Claude Provider
 *
 * Same interface as OpenAI. Handles system prompt separately per Anthropic API.
 * Maps tool calls between Anthropic format and unified format.
 */

import Anthropic from '@anthropic-ai/sdk';
import {
  AIProvider,
  AIMessage,
  AIResponse,
  AIOptions,
  ToolCall,
  TokenUsage,
} from './provider.interface';

// ─── Config ──────────────────────────────────────────────────────────────────

export interface AnthropicProviderConfig {
  apiKey: string;
  defaultModel?: string;
  maxTokens?: number;
  temperature?: number;
  timeoutMs?: number;
}

// ─── Provider ──────────────────────────────────────────────────────────────

const MAX_RETRIES = 3;
const BACKOFF_BASE_MS = 1000;
const DEFAULT_TIMEOUT_MS = 30_000;

export class AnthropicProvider implements AIProvider {
  readonly name = 'anthropic';
  private client: Anthropic;
  private readonly defaultModel: string;
  private readonly maxTokens: number;
  private readonly temperature: number;
  private readonly timeoutMs: number;

  constructor(config: AnthropicProviderConfig) {
    this.client = new Anthropic({
      apiKey: config.apiKey,
      timeout: config.timeoutMs ?? DEFAULT_TIMEOUT_MS,
    });
    this.defaultModel = config.defaultModel ?? 'claude-sonnet-4-20250514';
    this.maxTokens = config.maxTokens ?? 4096;
    this.temperature = config.temperature ?? 0.7;
    this.timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  }

  // ── Chat ────────────────────────────────────────────────────────────────

  async chat(messages: AIMessage[], options?: AIOptions): Promise<AIResponse> {
    const model = options?.model ?? this.defaultModel;
    const { systemText, anthropicMessages } = this.mapMessages(messages);
    const toolsParam = options?.tools?.length
      ? options.tools.map((t) => ({
          name: t.function.name,
          description: t.function.description,
          input_schema: t.function.parameters as Anthropic.Tool.InputSchema,
        }))
      : undefined;

    const startMs = Date.now();
    const response = await this.withRetry(() =>
      this.client.messages.create({
        model,
        max_tokens: options?.maxTokens ?? this.maxTokens,
        temperature: options?.temperature ?? this.temperature,
        system: systemText || undefined,
        messages: anthropicMessages,
        ...(toolsParam ? { tools: toolsParam } : {}),
      }),
    );
    const latencyMs = Date.now() - startMs;

    let content = '';
    const toolCalls: ToolCall[] = [];
    for (const block of response.content) {
      if (block.type === 'text') {
        content += block.text;
      } else if (block.type === 'tool_use') {
        toolCalls.push({
          id: block.id,
          type: 'function',
          function: { name: block.name, arguments: JSON.stringify(block.input) },
        });
      }
    }

    const usage: TokenUsage = {
      promptTokens: response.usage.input_tokens,
      completionTokens: response.usage.output_tokens,
      totalTokens: response.usage.input_tokens + response.usage.output_tokens,
    };

    return {
      content,
      toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
      usage,
      model: response.model,
      finishReason: response.stop_reason ?? 'end_turn',
      latencyMs,
    };
  }

  // ── Stream Chat ──────────────────────────────────────────────────────────

  async *streamChat(
    messages: AIMessage[],
    options?: AIOptions,
  ): AsyncGenerator<{ chunk: string; toolCalls?: ToolCall[]; done: boolean; usage?: TokenUsage }> {
    const model = options?.model ?? this.defaultModel;
    const { systemText, anthropicMessages } = this.mapMessages(messages);
    const toolsParam = options?.tools?.length
      ? options.tools.map((t) => ({
          name: t.function.name,
          description: t.function.description,
          input_schema: t.function.parameters as Anthropic.Tool.InputSchema,
        }))
      : undefined;

    const stream = this.withRetry(() =>
      this.client.messages.create({
        model,
        max_tokens: options?.maxTokens ?? this.maxTokens,
        temperature: options?.temperature ?? this.temperature,
        system: systemText || undefined,
        messages: anthropicMessages,
        ...(toolsParam ? { tools: toolsParam } : {}),
        stream: true,
      }),
    );

    let fullContent = '';
    const collectedToolCalls: ToolCall[] = [];
    let currentToolId = '';
    let currentToolName = '';
    let currentToolArgs = '';

    for await (const event of await stream) {
      if (event.type === 'content_block_delta') {
        if (event.delta.type === 'text_delta') {
          fullContent += event.delta.text;
          yield { chunk: event.delta.text, done: false };
        } else if (event.delta.type === 'input_json_delta') {
          currentToolArgs += event.delta.partial_json;
        }
      } else if (event.type === 'content_block_start') {
        if (event.content_block.type === 'tool_use') {
          currentToolId = event.content_block.id;
          currentToolName = event.content_block.name;
          currentToolArgs = '';
        }
      } else if (event.type === 'content_block_stop') {
        if (currentToolId) {
          collectedToolCalls.push({
            id: currentToolId,
            type: 'function',
            function: { name: currentToolName, arguments: currentToolArgs },
          });
          currentToolId = '';
          currentToolName = '';
          currentToolArgs = '';
        }
      } else if (event.type === 'message_delta' && event.usage) {
        yield {
          chunk: '',
          done: false,
          usage: {
            promptTokens: 0,
            completionTokens: event.usage.output_tokens,
            totalTokens: event.usage.output_tokens,
          },
        };
      }
    }

    yield {
      chunk: '',
      done: true,
      toolCalls: collectedToolCalls.length > 0 ? collectedToolCalls : undefined,
    };
  }

  // ── Embed (Anthropic does not support embeddings) ─────────────────────────

  async embed(_text: string): Promise<number[]> {
    throw new Error('[Anthropic] Embeddings not supported. Use OpenAI provider for embeddings.');
  }

  async embedBatch(_texts: string[]): Promise<number[][]> {
    throw new Error('[Anthropic] Embeddings not supported. Use OpenAI provider for embeddings.');
  }

  // ── Token Estimation ─────────────────────────────────────────────────────

  estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  // ── Retry Logic ──────────────────────────────────────────────────────────

  private async withRetry<T>(fn: () => Promise<T>): Promise<T> {
    let lastError: Error | undefined;
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        return await fn();
      } catch (err: unknown) {
        lastError = this.mapError(err);
        if (!this.isRetryable(lastError) || attempt === MAX_RETRIES - 1) {
          throw lastError;
        }
        const delay = BACKOFF_BASE_MS * Math.pow(2, attempt);
        await this.sleep(delay);
      }
    }
    throw lastError!;
  }

  private isRetryable(err: Error): boolean {
    const msg = err.message.toLowerCase();
    return (
      msg.includes('429') ||
      msg.includes('rate_limit') ||
      msg.includes('overloaded') ||
      msg.includes('500') ||
      msg.includes('502') ||
      msg.includes('503')
    );
  }

  // ── Error Mapping ────────────────────────────────────────────────────────

  private mapError(err: unknown): Error {
    if (err instanceof Anthropic.APIError) {
      return new Error(`[Anthropic] ${err.status} ${err.error?.type ?? ''}: ${err.message}`);
    }
    if (err instanceof Anthropic.APIConnectionError) {
      return new Error(`[Anthropic] Connection failed: ${err.message}`);
    }
    return err instanceof Error ? err : new Error(String(err));
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  private mapMessages(messages: AIMessage[]): {
    systemText: string;
    anthropicMessages: Anthropic.MessageParam[];
  } {
    const systemMessage = messages.find((m) => m.role === 'system');
    const systemText = systemMessage?.content ?? '';
    const nonSystem = messages.filter((m) => m.role !== 'system');

    const anthropicMessages: Anthropic.MessageParam[] = nonSystem.map((m) => {
      if (m.role === 'tool') {
        return {
          role: 'user' as const,
          content: [
            {
              type: 'tool_result' as const,
              tool_use_id: m.toolCallId!,
              content: m.content,
            },
          ],
        };
      }
      if (m.role === 'assistant' && m.toolCalls?.length) {
        return {
          role: 'assistant' as const,
          content: [
            ...(m.content ? [{ type: 'text' as const, text: m.content }] : []),
            ...m.toolCalls.map((tc) => ({
              type: 'tool_use' as const,
              id: tc.id,
              name: tc.function.name,
              input: JSON.parse(tc.function.arguments),
            })),
          ],
        };
      }
      return { role: m.role as 'user' | 'assistant', content: m.content };
    });

    return { systemText, anthropicMessages };
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
