/**
 * Triangle Black v19 — Production-grade OpenAI Provider
 *
 * Features: retry with exponential backoff, configurable timeout,
 * structured error mapping, token estimation, streaming, tool-calling.
 */

import OpenAI from 'openai';
import {
  AIProvider,
  AIMessage,
  AIResponse,
  AIOptions,
  ToolCall,
  ToolDefinition,
  TokenUsage,
} from './provider.interface';

// ─── Config ──────────────────────────────────────────────────────────────────

export interface OpenAIProviderConfig {
  apiKey: string;
  orgId?: string;
  defaultModel?: string;
  maxTokens?: number;
  temperature?: number;
  timeoutMs?: number;
}

// ─── Provider ──────────────────────────────────────────────────────────────

const MAX_RETRIES = 3;
const BACKOFF_BASE_MS = 1000;
const DEFAULT_TIMEOUT_MS = 30_000;

export class OpenAIProvider implements AIProvider {
  readonly name = 'openai';
  private client: OpenAI;
  private readonly defaultModel: string;
  private readonly maxTokens: number;
  private readonly temperature: number;
  private readonly timeoutMs: number;

  constructor(config: OpenAIProviderConfig) {
    this.client = new OpenAI({
      apiKey: config.apiKey,
      ...(config.orgId ? { organization: config.orgId } : {}),
      timeout: config.timeoutMs ?? DEFAULT_TIMEOUT_MS,
    });
    this.defaultModel = config.defaultModel ?? 'gpt-4o';
    this.maxTokens = config.maxTokens ?? 4096;
    this.temperature = config.temperature ?? 0.7;
    this.timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  }

  // ── Chat ────────────────────────────────────────────────────────────────

  async chat(messages: AIMessage[], options?: AIOptions): Promise<AIResponse> {
    const model = options?.model ?? this.defaultModel;
    const openaiMessages = this.mapMessages(messages);
    const toolsParam = options?.tools?.length
      ? options.tools.map((t) => ({ type: 'function' as const, function: t.function }))
      : undefined;

    const requestParams: OpenAI.Chat.ChatCompletionCreateParams = {
      model,
      messages: openaiMessages,
      temperature: options?.temperature ?? this.temperature,
      max_tokens: options?.maxTokens ?? this.maxTokens,
      ...(toolsParam ? { tools: toolsParam } : {}),
      ...(options?.responseFormat ? { response_format: options.responseFormat } : {}),
    };

    const startMs = Date.now();
    const response = await this.withRetry(() => this.client.chat.completions.create(requestParams));
    const latencyMs = Date.now() - startMs;

    const choice = response.choices[0];
    const toolCalls = this.extractToolCalls(choice.message.tool_calls);
    const usage = this.extractUsage(response.usage);

    return {
      content: choice.message.content ?? '',
      toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
      usage,
      model: response.model,
      finishReason: choice.finish_reason ?? 'stop',
      latencyMs,
    };
  }

  // ── Stream Chat ──────────────────────────────────────────────────────────

  async *streamChat(
    messages: AIMessage[],
    options?: AIOptions,
  ): AsyncGenerator<{ chunk: string; toolCalls?: ToolCall[]; done: boolean; usage?: TokenUsage }> {
    const model = options?.model ?? this.defaultModel;
    const openaiMessages = this.mapMessages(messages);
    const toolsParam = options?.tools?.length
      ? options.tools.map((t) => ({ type: 'function' as const, function: t.function }))
      : undefined;

    const stream = await this.withRetry(() =>
      this.client.chat.completions.create({
        model,
        messages: openaiMessages,
        temperature: options?.temperature ?? this.temperature,
        max_tokens: options?.maxTokens ?? this.maxTokens,
        ...(toolsParam ? { tools: toolsParam } : {}),
        stream: true,
      }),
    );

    let fullContent = '';
    const collectedToolCalls: ToolCall[] = [];

    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta;
      if (delta?.content) {
        fullContent += delta.content;
        yield { chunk: delta.content, done: false };
      }
      if (delta?.tool_calls) {
        for (const tc of delta.tool_calls) {
          const existing = collectedToolCalls.find((c) => c.id === tc.id);
          if (existing) {
            existing.function.arguments += tc.function.arguments;
          } else {
            collectedToolCalls.push({
              id: tc.id,
              type: 'function',
              function: { name: tc.function.name, arguments: tc.function.arguments ?? '' },
            });
          }
        }
      }
    }

    yield {
      chunk: '',
      done: true,
      toolCalls: collectedToolCalls.length > 0 ? collectedToolCalls : undefined,
    };
  }

  // ── Embed ────────────────────────────────────────────────────────────────

  async embed(text: string): Promise<number[]> {
    const response = await this.withRetry(() =>
      this.client.embeddings.create({ model: 'text-embedding-3-small', input: text, dimensions: 1536 }),
    );
    return response.data[0].embedding;
  }

  async embedBatch(texts: string[]): Promise<number[][]> {
    const BATCH_SIZE = 2048;
    const allEmbeddings: number[][] = [];
    for (let i = 0; i < texts.length; i += BATCH_SIZE) {
      const batch = texts.slice(i, i + BATCH_SIZE);
      const response = await this.withRetry(() =>
        this.client.embeddings.create({ model: 'text-embedding-3-small', input: batch, dimensions: 1536 }),
      );
      const sorted = response.data.sort((a, b) => a.index - b.index);
      allEmbeddings.push(...sorted.map((d) => d.embedding));
    }
    return allEmbeddings;
  }

  // ── Token Estimation ─────────────────────────────────────────────────────

  estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  // ── Retry Logic ──────────────────────────────────────────────────────────

  private async withRetry<T>(fn: () => Promise<T>): Promise<T> {
    let lastError: Error | undefined;
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      try {
        return await fn();
      } catch (err: unknown) {
        lastError = this.mapError(err);
        if (!this.isRetryable(lastError) || attempt === MAX_RETRIES - 1) {
          throw lastError;
        }
        const delay = BACKOFF_BASE_MS * Math.pow(2, attempt);
        await this.sleep(delay);
      }
    }
    throw lastError!;
  }

  private isRetryable(err: Error): boolean {
    const msg = err.message.toLowerCase();
    return msg.includes('429') || msg.includes('rate_limit') || msg.includes('500') || msg.includes('502') || msg.includes('503');
  }

  // ── Error Mapping ────────────────────────────────────────────────────────

  private mapError(err: unknown): Error {
    if (err instanceof OpenAI.APIError) {
      const status = err.status;
      const code = err.code;
      return new Error(
        `[OpenAI] ${code ?? 'UNKNOWN'} (HTTP ${status ?? 'N/A'}): ${err.message}`,
      );
    }
    if (err instanceof OpenAI.APIConnectionError) {
      return new Error(`[OpenAI] Connection failed: ${err.message}`);
    }
    if (err instanceof OpenAI.APIRateLimitError) {
      return new Error(`[OpenAI] Rate limited: ${err.message}`);
    }
    return err instanceof Error ? err : new Error(String(err));
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  private mapMessages(messages: AIMessage[]): OpenAI.Chat.ChatCompletionMessageParam[] {
    return messages.map((m) => {
      if (m.role === 'tool') {
        return { role: 'tool' as const, tool_call_id: m.toolCallId!, content: m.content };
      }
      if (m.role === 'assistant' && m.toolCalls?.length) {
        return {
          role: 'assistant' as const,
          content: m.content || null,
          tool_calls: m.toolCalls.map((tc) => ({
            id: tc.id,
            type: 'function' as const,
            function: { name: tc.function.name, arguments: tc.function.arguments },
          })),
        };
      }
      return { role: m.role as 'system' | 'user' | 'assistant', content: m.content };
    });
  }

  private extractToolCalls(raw?: OpenAI.Chat.ChatCompletionMessage.ToolCall[]): ToolCall[] {
    return (raw ?? []).map((tc) => ({
      id: tc.id,
      type: 'function' as const,
      function: { name: tc.function.name, arguments: tc.function.arguments },
    }));
  }

  private extractUsage(usage?: OpenAI.CompletionUsage): TokenUsage {
    return {
      promptTokens: usage?.prompt_tokens ?? 0,
      completionTokens: usage?.completion_tokens ?? 0,
      totalTokens: usage?.total_tokens ?? 0,
    };
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
