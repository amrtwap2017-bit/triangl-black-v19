/**
 * Triangle Black v19 — Enterprise Provider Factory
 *
 * Creates providers based on config. Supports: 'openai', 'anthropic', 'mock'.
 * Auto-selects based on available API keys.
 */

import { AIProvider } from './provider.interface';
import { OpenAIProvider, OpenAIProviderConfig } from './openai.provider';
import { AnthropicProvider, AnthropicProviderConfig } from './anthropic.provider';

// ─── Mock Provider ─────────────────────────────────────────────────────────

class MockProvider implements AIProvider {
  readonly name = 'mock';

  async chat(
    messages: { role: string; content: string }[],
    options?: { temperature?: number; maxTokens?: number },
  ) {
    const lastUserMsg = [...messages].reverse().find((m) => m.role === 'user');
    return {
      content: `[Mock] Responding to: "${lastUserMsg?.content?.slice(0, 80) ?? ''}"`,
      usage: { promptTokens: 10, completionTokens: 5, totalTokens: 15 },
      model: 'mock-gpt-4o',
      finishReason: 'stop',
      latencyMs: 1,
    };
  }

  async embed(text: string): Promise<number[]> {
    return new Array(1536).fill(0).map((_, i) => 1 / (i + 1));
  }

  async embedBatch(texts: string[]): Promise<number[][]> {
    return texts.map(() => new Array(1536).fill(0).map((_, i) => 1 / (i + 1)));
  }
}

// ─── Factory ────────────────────────────────────────────────────────────────

export interface ProviderConfig {
  type: 'openai' | 'anthropic' | 'mock';
  openai?: OpenAIProviderConfig;
  anthropic?: AnthropicProviderConfig;
}

export class AIProviderFactory {
  private static providers = new Map<string, AIProvider>();

  /** Create a named provider instance. */
  static createProvider(config: ProviderConfig): AIProvider {
    const key = `provider:${config.type}`;
    const provider = this.buildProvider(config);
    this.providers.set(key, provider);
    return provider;
  }

  /** Get a previously registered provider by name. */
  static getProvider(name: string): AIProvider {
    const existing = this.providers.get(name);
    if (existing) return existing;

    // Try to auto-create from env vars
    switch (name) {
      case 'openai': {
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) throw new Error('OPENAI_API_KEY not set');
        const p = new OpenAIProvider({ apiKey });
        this.providers.set(name, p);
        return p;
      }
      case 'anthropic': {
        const apiKey = process.env.ANTHROPIC_API_KEY;
        if (!apiKey) throw new Error('ANTHROPIC_API_KEY not set');
        const p = new AnthropicProvider({ apiKey });
        this.providers.set(name, p);
        return p;
      }
      case 'mock': {
        const p = new MockProvider();
        this.providers.set(name, p);
        return p;
      }
      default:
        throw new Error(`Unknown AI provider: ${name}. Supported: openai, anthropic, mock`);
    }
  }

  /** Auto-select based on available API keys. Prefers OpenAI → Anthropic → Mock. */
  static autoSelect(): AIProvider {
    if (process.env.OPENAI_API_KEY) return this.getProvider('openai');
    if (process.env.ANTHROPIC_API_KEY) return this.getProvider('anthropic');
    return this.getProvider('mock');
  }

  /** Register a custom provider instance. */
  static registerProvider(name: string, provider: AIProvider): void {
    this.providers.set(name, provider);
  }

  /** Clear all registered providers. */
  static reset(): void {
    this.providers.clear();
  }

  // ── Internal ─────────────────────────────────────────────────────────────

  private static buildProvider(config: ProviderConfig): AIProvider {
    switch (config.type) {
      case 'openai':
        return new OpenAIProvider(config.openai ?? { apiKey: process.env.OPENAI_API_KEY! });
      case 'anthropic':
        return new AnthropicProvider(config.anthropic ?? { apiKey: process.env.ANTHROPIC_API_KEY! });
      case 'mock':
        return new MockProvider();
      default:
        throw new Error(`Unknown provider type: ${(config as { type: string }).type}`);
    }
  }
}
