export class TokenManager {
  private static readonly COST_PER_1K: Record<string, { input: number; output: number }> = {
    'gpt-4o': { input: 0.0025, output: 0.01 },
    'gpt-4o-mini': { input: 0.00015, output: 0.0006 },
    'claude-3-5-sonnet': { input: 0.003, output: 0.015 },
    'claude-3-5-sonnet-20241022': { input: 0.003, output: 0.015 },
    'claude-3-haiku': { input: 0.00025, output: 0.00125 },
    'claude-3-haiku-20240307': { input: 0.00025, output: 0.00125 },
    'text-embedding-3-small': { input: 0.00002, output: 0 },
  };

  static calculateCost(model: string, promptTokens: number, completionTokens: number): number {
    const rates = this.COST_PER_1K[model] ?? this.COST_PER_1K['gpt-4o-mini'];
    return (promptTokens / 1000) * rates.input + (completionTokens / 1000) * rates.output;
  }

  static estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  static truncateToTokenLimit(text: string, maxTokens: number): string {
    const estimatedTokens = this.estimateTokens(text);
    if (estimatedTokens <= maxTokens) return text;
    const charLimit = maxTokens * 4;
    return text.substring(0, charLimit) + '... [truncated]';
  }
}