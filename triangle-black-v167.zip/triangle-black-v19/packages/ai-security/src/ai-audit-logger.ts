export interface AiAuditLogEntry {
  organizationId: string;
  userId: string;
  agentType: string;
  prompt: string;
  response: string;
  model: string;
  tokensUsed: number;
  cost: number;
  durationMs: number;
  toolCalls?: any[];
}

export class AiAuditLogger {
  static logInteraction(data: AiAuditLogEntry): void {
    // Log to database for audit trail
    // This would integrate with the AIInteraction model and a new AIUsage model
    console.log(
      `[AI-SECURITY-AUDIT] org=${data.organizationId} user=${data.userId} agent=${data.agentType} model=${data.model} tokens=${data.tokensUsed} cost=$${data.cost.toFixed(4)} duration=${data.durationMs}ms`
    );
  }
}