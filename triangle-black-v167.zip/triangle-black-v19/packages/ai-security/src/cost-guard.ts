export interface CostCheckResult {
  allowed: boolean;
  dailyRemaining: number;
  monthlyRemaining: number;
  reason?: string;
}

export class CostGuard {
  private static readonly LIMITS: Record<string, { dailyLimit: number; monthlyLimit: number }> = {
    'gpt-4o': { dailyLimit: 50, monthlyLimit: 1000 },
    'gpt-4o-mini': { dailyLimit: 20, monthlyLimit: 500 },
    'claude-3-5-sonnet': { dailyLimit: 75, monthlyLimit: 1500 },
    'claude-3-haiku': { dailyLimit: 10, monthlyLimit: 200 },
  };

  static checkLimit(
    organizationId: string,
    model: string,
    currentDailySpend: number,
    currentMonthlySpend: number
  ): CostCheckResult {
    const limits = this.LIMITS[model] || this.LIMITS['gpt-4o-mini'];
    const dailyOk = currentDailySpend < limits.dailyLimit;
    const monthlyOk = currentMonthlySpend < limits.monthlyLimit;
    return {
      allowed: dailyOk && monthlyOk,
      dailyRemaining: Math.max(0, limits.dailyLimit - currentDailySpend),
      monthlyRemaining: Math.max(0, limits.monthlyLimit - currentMonthlySpend),
      reason: !dailyOk ? 'Daily spend limit reached' : !monthlyOk ? 'Monthly spend limit reached' : undefined,
    };
  }
}