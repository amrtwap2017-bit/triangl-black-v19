export interface PiiDetection {
  hasPii: boolean;
  findings: PiiFinding[];
}

export interface PiiFinding {
  type: PiiType;
  count: number;
  sample: string;
}

export type PiiType = 'email' | 'phone' | 'creditCard' | 'iban' | 'nationalId';

export class DataLeakageDetector {
  // Detect PII and sensitive data in AI outputs
  private static readonly PII_PATTERNS: Record<PiiType, RegExp> = {
    email: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
    phone: /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g,
    creditCard: /\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/g,
    iban: /\b[A-Z]{2}\d{2}[A-Z0-9]{4,30}\b/g,
    nationalId: /\b\d{10}\b/g,
  };

  static detect(text: string): PiiDetection {
    const findings: PiiFinding[] = [];
    for (const [type, pattern] of Object.entries(this.PII_PATTERNS)) {
      const regex = new RegExp(pattern.source, pattern.flags);
      const matches = text.match(regex);
      if (matches) {
        findings.push({
          type: type as PiiType,
          count: matches.length,
          sample: matches[0].replace(/./g, (c, i) => i > 3 ? '*' : c),
        });
      }
    }
    return { hasPii: findings.length > 0, findings };
  }

  static redact(text: string): string {
    let redacted = text;
    for (const pattern of Object.values(this.PII_PATTERNS)) {
      redacted = redacted.replace(pattern, '[REDACTED]');
    }
    return redacted;
  }
}