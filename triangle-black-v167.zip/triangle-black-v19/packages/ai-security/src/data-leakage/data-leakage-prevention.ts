/**
 * Triangle Black v19 — Enterprise Data Leakage Prevention
 *
 * Detects sensitive data (PII, secrets, credentials) in AI inputs and outputs.
 * Sanitizes outputs to redact detected PII.
 */

export interface DLPFinding {
  type: string;
  value: string;
  position: number;
}

export interface DLPResult {
  safe: boolean;
  findings: DLPFinding[];
}

type PII_PATTERN = {
  type: string;
  pattern: RegExp;
  severity: 'low' | 'medium' | 'high';
};

const PII_PATTERNS: PII_PATTERN[] = [
  // Credit cards (Luhn-ready detection)
  {
    type: 'credit_card',
    pattern: /\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b/g,
    severity: 'high',
  },
  // SSN (US Social Security)
  {
    type: 'ssn',
    pattern: /\b(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b/g,
    severity: 'high',
  },
  // Email addresses
  {
    type: 'email',
    pattern: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
    severity: 'medium',
  },
  // Phone numbers (various formats)
  {
    type: 'phone',
    pattern: /(?:\+?\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{4}\b/g,
    severity: 'medium',
  },
  // API keys (OpenAI, Stripe, etc.)
  {
    type: 'api_key_openai',
    pattern: /\bsk-[A-Za-z0-9]{20,}\b/g,
    severity: 'high',
  },
  {
    type: 'api_key_generic',
    pattern: /\bkey-[A-Za-z0-9]{16,}\b/g,
    severity: 'high',
  },
  // Internal URLs
  {
    type: 'internal_url',
    pattern: /\bhttps?:\/\/(localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|192\.168\.\d+\.\d+)(?::\d+)?\b/gi,
    severity: 'high',
  },
  // JWT tokens
  {
    type: 'jwt_token',
    pattern: /\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g,
    severity: 'high',
  },
  // Passwords (common patterns)
  {
    type: 'password_field',
    pattern: /\bpassword\s*[:=]\s*["'][^"']{3,}["']/gi,
    severity: 'high',
  },
  // Database connection strings
  {
    type: 'db_connection_string',
    pattern: /\b(?:postgres|mysql|mongodb|redis):\/\/[^\s]+\b/gi,
    severity: 'high',
  },
];

export class DataLeakagePrevention {
  private static readonly HIGH_SEVERITY_TYPES = new Set(PII_PATTERNS.filter((p) => p.severity === 'high').map((p) => p.type));

  /**
   * Detect sensitive data in input.
   */
  static detectSensitiveData(input: string): DLPResult {
    const findings: DLPFinding[] = [];

    for (const pii of PII_PATTERNS) {
      const regex = new RegExp(pii.pattern.source, pii.pattern.flags);
      let match: RegExpExecArray | null;

      while ((match = regex.exec(input)) !== null) {
        findings.push({
          type: pii.type,
          value: pii.severity === 'high' ? this.maskValue(match[0]) : match[0],
          position: match.index,
        });
      }
    }

    const hasHighSeverity = findings.some((f) => this.HIGH_SEVERITY_TYPES.has(f.type));

    // Log detection
    if (findings.length > 0) {
      console.log(
        `[AI-SECURITY] DLP: ${findings.length} findings in input — types: [${findings.map((f) => f.type).join(', ')}]`,
      );
    }

    return {
      safe: !hasHighSeverity,
      findings,
    };
  }

  /**
   * Sanitize output by redacting detected PII.
   * Only redacts fields not in the allowed list.
   */
  static sanitizeOutput(output: string, allowedFields: string[] = []): string {
    let sanitized = output;

    for (const pii of PII_PATTERNS) {
      // Skip if this type is explicitly allowed
      if (allowedFields.includes(pii.type)) continue;

      sanitized = sanitized.replace(
        new RegExp(pii.pattern.source, pii.pattern.flags),
        (match) => `[REDACTED:${pii.type}]`,
      );
    }

    return sanitized;
  }

  /**
   * Detect if a query references cross-tenant data.
   */
  static detectCrossTenantData(
    query: string,
    userOrgId: string,
    context?: Record<string, unknown>,
  ): boolean {
    // Check for UUIDs in the query that don't match the user's org
    const uuidPattern = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi;
    const matches = query.match(uuidPattern) ?? [];

    for (const id of matches) {
      if (id.toLowerCase() !== userOrgId.toLowerCase()) {
        // Also check if it appears in context
        if (context && this.idInContext(id, context)) {
          continue; // It's a legitimate reference from context
        }
        console.log(`[AI-SECURITY] Cross-tenant reference detected: ${id} (user org: ${userOrgId})`);
        return true;
      }
    }

    return false;
  }

  // ── Helpers ──────────────────────────────────────────────────────────

  private static maskValue(value: string): string {
    if (value.length <= 4) return '*'.repeat(value.length);
    return value.slice(0, 2) + '*'.repeat(value.length - 4) + value.slice(-2);
  }

  private static idInContext(id: string, context: Record<string, unknown>): boolean {
    const serialized = JSON.stringify(context);
    return serialized.toLowerCase().includes(id.toLowerCase());
  }
}
