// ─── v19 Exports ───────────────────────────────────────────────────────────────

export { PromptInjectionDetector } from './prompt-injection/prompt-injection-detector';
export type { InjectionDetection } from './prompt-injection/prompt-injection-detector';

export { DataLeakagePrevention } from './data-leakage/data-leakage-prevention';
export type { DLPResult, DLPFinding } from './data-leakage/data-leakage-prevention';

export { TenantIsolation } from './isolation/tenant-isolation';

// ─── Legacy compatibility ─────────────────────────────────────────────────────

export { AiAuditLogger } from './ai-audit-logger';
export type { AiAuditLogEntry } from './ai-audit-logger';

export { CostGuard } from './cost-guard';
export type { CostCheckResult } from './cost-guard';
