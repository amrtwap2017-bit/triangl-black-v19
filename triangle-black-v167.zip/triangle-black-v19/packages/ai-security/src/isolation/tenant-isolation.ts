/**
 * Triangle Black v19 — Tenant Isolation Guard
 *
 * Enforces multi-tenant data boundaries for AI operations:
 * - Resource access validation
 * - Prisma query filter generation
 * - Tool access validation
 * - Prompt context sanitization
 */

export class TenantIsolation {
  /**
   * Enforce tenant access: check if a user can access a resource
   * belonging to a specific organization.
   */
  static enforceTenantAccess(
    userId: string,
    organizationId: string,
    resourceOrganizationId: string,
  ): boolean {
    if (organizationId !== resourceOrganizationId) {
      console.log(
        `[AI-SECURITY] Tenant access denied — user ${userId} (org: ${organizationId}) tried to access resource in org: ${resourceOrganizationId}`,
      );
      return false;
    }
    return true;
  }

  /**
   * Build a Prisma-compatible Where clause that filters by organization.
   * Ensures every database query includes tenant isolation.
   */
  static buildTenantFilter(organizationId: string): Record<string, unknown> {
    return {
      organizationId,
    };
  }

  /**
   * Build a Prisma Where clause for a specific table column name.
   */
  static buildTenantFilterForColumn(
    organizationId: string,
    columnName: string = 'organizationId',
  ): Record<string, unknown> {
    return {
      [columnName]: organizationId,
    };
  }

  /**
   * Validate if a tool would access cross-tenant data.
   * Tools that accept an organizationId parameter are checked.
   */
  static validateToolAccess(
    userId: string,
    organizationId: string,
    toolName: string,
    toolParams?: Record<string, unknown>,
  ): boolean {
    // Check if tool params contain an organizationId that differs
    if (toolParams?.organizationId && toolParams.organizationId !== organizationId) {
      console.log(
        `[AI-SECURITY] Tool cross-tenant access blocked — tool: ${toolName}, user: ${userId}, user org: ${organizationId}, target org: ${toolParams.organizationId}`,
      );
      return false;
    }

    // Check if tool params contain hotelId that might belong to another tenant
    // (additional check for hotel-specific tools)
    if (toolParams?.hotelId) {
      // In production, this would verify the hotel belongs to the org via DB lookup
      // For now, we log for monitoring
      console.log(
        `[AI-SECURITY] Tool hotel access — tool: ${toolName}, user: ${userId}, hotel: ${toolParams.hotelId}`,
      );
    }

    return true;
  }

  /**
   * Sanitize prompt context — strip any data belonging to other tenants.
   * Recursively removes fields with organizationId values different from the user's.
   */
  static sanitizePromptContext(
    context: Record<string, unknown>,
    userOrganizationId: string,
  ): Record<string, unknown> {
    return this.stripCrossTenantData(context, userOrganizationId) as Record<string, unknown>;
  }

  /**
   * Validate query for cross-tenant UUID references.
   */
  static validateQuery(query: string, organizationId: string): boolean {
    const uuidPattern = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi;
    const ids = query.match(uuidPattern) ?? [];

    for (const id of ids) {
      if (id.toLowerCase() !== organizationId.toLowerCase()) {
        console.log(
          `[AI-SECURITY] Cross-tenant ID in query: ${id} (user org: ${organizationId})`,
        );
        return false;
      }
    }

    return true;
  }

  // ── Internal ──────────────────────────────────────────────────────────

  private static stripCrossTenantData(obj: unknown, userOrgId: string): unknown {
    if (Array.isArray(obj)) {
      return obj.map((item) => this.stripCrossTenantData(item, userOrgId));
    }

    if (obj && typeof obj === 'object') {
      const result: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
        if (key === 'organizationId' && value !== userOrgId) {
          continue; // Strip other tenant's data
        }
        result[key] = this.stripCrossTenantData(value, userOrgId);
      }
      return result;
    }

    return obj;
  }
}
