export class PromptInjectionDetector {
  private static readonly PATTERNS = [
    /ignore\s+(all\s+)?previous\s+instructions/i,
    /disregard\s+(all\s+)?previous\s+(instructions|prompts)/i,
    /you\s+are\s+now\s+(a|an)\s+/i,
    /system\s*:\s*/i,
    /pretend\s+(you\s+are|to\s+be)/i,
    /act\s+as\s+(if\s+you\s+are|a|an)/i,
    /forget\s+(everything|all|your\s+instructions)/i,
    /new\s+instructions?\s*:/i,
    /\[INST\]/i,
    /<<SYS>>/i,
    /jailbreak/i,
    /DAN\s+mode/i,
    /do\s+anything\s+now/i,
    /no\s+restrictions?\s+apply/i,
  ];

  static detect(input: string): { isInjection: boolean; confidence: number; matchedPatterns: string[] } {
    const matchedPatterns = this.PATTERNS.filter(p => p.test(input)).map(p => p.source);
    const confidence = Math.min(1, matchedPatterns.length * 0.3);
    return {
      isInjection: matchedPatterns.length >= 2,
      confidence,
      matchedPatterns,
    };
  }

  static sanitize(input: string): string {
    let sanitized = input;
    for (const pattern of this.PATTERNS) {
      sanitized = sanitized.replace(pattern, '[FILTERED]');
    }
    return sanitized;
  }
}