/**
 * Triangle Black v19 — Enterprise Prompt Injection Detector
 *
 * 18+ detection patterns covering role-play, instruction override,
 * delimiter escape, code injection, multi-language, token manipulation,
 * base64 encoding, unicode tricks, and nested prompts.
 *
 * Score 0–100. Threshold: 30 = block.
 */

export interface InjectionDetection {
  safe: boolean;
  risk: 'none' | 'low' | 'medium' | 'high';
  patterns: string[];
  score: number;
}

type RiskLevel = 'none' | 'low' | 'medium' | 'high';

interface DetectionPattern {
  name: string;
  pattern: RegExp;
  weight: number;
}

const DETECTION_PATTERNS: DetectionPattern[] = [
  // ── Role-play / Identity hijacking ────────────────────────────────────
  { name: 'ignore_previous', pattern: /ignore\s+(all\s+)?previous\s+(instructions|prompts|rules)/i, weight: 10 },
  { name: 'disregard_instructions', pattern: /disregard\s+(all\s+)?previous\s+(instructions|prompts)/i, weight: 10 },
  { name: 'you_are_now', pattern: /you\s+are\s+now\s+(a|an|the)\s+/i, weight: 10 },
  { name: 'pretend_role', pattern: /pretend\s+(you\s+are|to\s+be|you're)\s+/i, weight: 8 },
  { name: 'act_as', pattern: /act\s+as\s+(if\s+you\s+are|a|an|the)\s+/i, weight: 8 },
  { name: 'forget_instructions', pattern: /forget\s+(everything|all|your\s+instructions|your\s+rules)/i, weight: 10 },

  // ── Instruction override ─────────────────────────────────────────────
  { name: 'new_instructions', pattern: /new\s+instructions?\s*[:;]/i, weight: 10 },
  { name: 'override', pattern: /override\s+(the\s+)?(system|your|previous)/i, weight: 10 },
  { name: 'ignore_rules', pattern: /ignore\s+(all\s+)?(the\s+)?rules/i, weight: 8 },
  { name: 'no_restrictions', pattern: /no\s+restrictions?\s+(apply|needed|hold)/i, weight: 9 },

  // ── Delimiter escape ─────────────────────────────────────────────────
  { name: 'triple_quote_escape', pattern: /"""[\s\S]{0,50}(ignore|disregard|system|instruction)/i, weight: 12 },
  { name: 'dash_escape', pattern: /---\s*(ignore|disregard|system|new)/i, weight: 10 },
  { name: 'code_block_escape', pattern: /```\s*(ignore|disregard|system|instruction|role)/i, weight: 12 },
  { name: 'bracket_escape', pattern: /\[INST\]|\[\/INST\]|\[\[.*?\]\]/i, weight: 15 },
  { name: 'xml_tag_escape', pattern: /<\|im_start\|>|<\|im_end\|>|<system>/i, weight: 15 },

  // ── Code injection ───────────────────────────────────────────────────
  { name: 'console_log', pattern: /console\.(log|debug|info|error|warn)\s*\(/i, weight: 6 },
  { name: 'process_env', pattern: /process\.env/i, weight: 8 },
  { name: 'require_import', pattern: /require\s*\(\s*['"][a-z]/i, weight: 6 },
  { name: 'eval_exec', pattern: /eval\s*\(|exec\s*\(|Function\s*\(/i, weight: 8 },
  { name: 'file_read', pattern: /fs\.read|readFile|readFileSync/i, weight: 7 },

  // ── Jailbreak attempts ───────────────────────────────────────────────
  { name: 'jailbreak', pattern: /jailbreak/i, weight: 15 },
  { name: 'dan_mode', pattern: /DAN\s+mode|do\s+anything\s+now/i, weight: 15 },

  // ── Token manipulation ──────────────────────────────────────────────
  { name: 'token_manipulation', pattern: /\b(summarize|translate|encode)\s+the\s+(above|following|system)/i, weight: 7 },

  // ── Base64 encoding ──────────────────────────────────────────────────
  { name: 'base64_instruction', pattern: /[A-Za-z0-9+/]{40,}={0,2}.*?(ignore|disregard|system|instruction)/i, weight: 10 },

  // ── Unicode tricks ───────────────────────────────────────────────────
  { name: 'unicode_homoglyph', pattern: /[\u0131\u0451\u0430\u0435\u043E\u0440\u0443\u044B]/, weight: 8 },

  // ── Nested prompts ───────────────────────────────────────────────────
  { name: 'nested_prompt', pattern: /prompt\s*(\d+|one|two|three).*?:\s*/i, weight: 6 },

  // ── Multi-language injection ─────────────────────────────────────────
  { name: 'arabic_injection', pattern: /[\u0600-\u06FF]{5,}.*?(تجاهل|تجاهل)/, weight: 10 },
  { name: 'chinese_injection', pattern: /[\u4e00-\u9fff]{5,}.*?(忽略| disreg)/, weight: 10 },
];

export class PromptInjectionDetector {
  private static readonly BLOCK_THRESHOLD = 30;
  private static readonly PATTERN_WEIGHTS = DETECTION_PATTERNS;

  /**
   * Detect prompt injection in user input.
   * Returns safe flag, risk level, matched pattern names, and numeric score.
   */
  static detect(input: string): InjectionDetection {
    const matched: Array<{ name: string; weight: number }> = [];

    for (const entry of this.PATTERN_WEIGHTS) {
      if (entry.pattern.test(input)) {
        matched.push({ name: entry.name, weight: entry.weight });
      }
    }

    // Calculate score — cap at 100
    const score = Math.min(
      matched.reduce((sum, m) => sum + m.weight, 0),
      100,
    );

    const risk = this.scoreToRisk(score);
    const safe = score < this.BLOCK_THRESHOLD;

    // Log all detections
    if (matched.length > 0) {
      console.log(
        `[AI-SECURITY] Prompt injection detected — score: ${score}, risk: ${risk}, patterns: [${matched.map((m) => m.name).join(', ')}]`,
      );
    }

    return {
      safe,
      risk,
      patterns: matched.map((m) => m.name),
      score,
    };
  }

  /** Sanitize input by replacing matched patterns with [FILTERED]. */
  static sanitize(input: string): string {
    let sanitized = input;
    for (const entry of this.PATTERN_WEIGHTS) {
      sanitized = sanitized.replace(entry.pattern, '[FILTERED]');
    }
    return sanitized;
  }

  private static scoreToRisk(score: number): RiskLevel {
    if (score === 0) return 'none';
    if (score < 15) return 'low';
    if (score < this.BLOCK_THRESHOLD) return 'medium';
    return 'high';
  }
}
