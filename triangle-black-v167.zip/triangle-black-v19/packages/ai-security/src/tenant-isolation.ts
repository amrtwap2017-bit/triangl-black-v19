export class TenantIsolation {
  // Ensure AI queries never cross tenant boundaries
  static validateQuery(query: string, organizationId: string): boolean {
    // Check if query contains explicit organization IDs that don't match
    const uuidPattern = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi;
    const ids = query.match(uuidPattern) || [];
    return !ids.some(id => id.toLowerCase() !== organizationId.toLowerCase());
  }

  static sanitizeContext(context: Record<string, unknown>, organizationId: string): Record<string, unknown> {
    const sanitized = { ...context };
    // Remove any cross-tenant references
    const removeKeys = (obj: any): any => {
      if (Array.isArray(obj)) return obj.map(removeKeys);
      if (obj && typeof obj === 'object') {
        const cleaned: any = {};
        for (const [key, value] of Object.entries(obj)) {
          if (key === 'organizationId' && value !== organizationId) continue;
          cleaned[key] = removeKeys(value);
        }
        return cleaned;
      }
      return obj;
    };
    return removeKeys(sanitized);
  }
}