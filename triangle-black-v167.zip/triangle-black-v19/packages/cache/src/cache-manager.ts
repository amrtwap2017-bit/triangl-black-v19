import { RedisClient } from './redis';

export interface CacheOptions {
  ttl?: number; // seconds, default 300 (5 min)
  tags?: string[];
}

export class CacheManager {
  private redis: RedisClient;

  constructor(redis: RedisClient) {
    this.redis = redis;
  }

  async get<T>(key: string): Promise<T | null> {
    const data = await this.redis.getClient().get(key);
    if (!data) return null;
    try { return JSON.parse(data); } catch { return data as unknown as T; }
  }

  async set<T>(key: string, value: T, options?: CacheOptions): Promise<void> {
    const ttl = options?.ttl ?? 300;
    const client = this.redis.getClient();
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    if (ttl > 0) {
      await client.setex(key, ttl, serialized);
    } else {
      await client.set(key, serialized);
    }
    if (options?.tags?.length) {
      await this.addTags(key, options.tags);
    }
  }

  async del(key: string): Promise<void> {
    await this.redis.getClient().del(key);
  }

  async delByPattern(pattern: string): Promise<number> {
    const client = this.redis.getClient();
    const stream = client.scanStream({ match: pattern, count: 100 });
    let deleted = 0;
    const pipeline = client.pipeline();
    return new Promise((resolve) => {
      stream.on('data', (keys: string[]) => {
        for (const key of keys) { pipeline.del(key); deleted++; }
      });
      stream.on('end', async () => {
        await pipeline.exec();
        resolve(deleted);
      });
    });
  }

  async delByTag(tag: string): Promise<number> {
    const tagKey = `tag:${tag}`;
    const members = await this.redis.getClient().smembers(tagKey);
    if (members.length === 0) return 0;
    const pipeline = this.redis.getClient().pipeline();
    for (const key of members) { pipeline.del(key); }
    pipeline.del(tagKey);
    await pipeline.exec();
    return members.length;
  }

  private async addTags(key: string, tags: string[]): Promise<void> {
    const client = this.redis.getClient();
    const pipeline = client.pipeline();
    for (const tag of tags) {
      pipeline.sadd(`tag:${tag}`, key);
    }
    await pipeline.exec();
  }

  async getOrSet<T>(key: string, factory: () => Promise<T>, options?: CacheOptions): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached !== null) return cached;
    const value = await factory();
    await this.set(key, value, options);
    return value;
  }
}