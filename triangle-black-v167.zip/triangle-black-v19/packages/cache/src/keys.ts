export const CacheKeys = {
  // Auth & Permissions
  userPermissions: (userId: string, orgId: string) => `user:${userId}:org:${orgId}:permissions`,
  userRoles: (userId: string) => `user:${userId}:roles`,
  // Hotels
  hotel: (id: string) => `hotel:${id}`,
  hotelAssets: (hotelId: string) => `hotel:${hotelId}:assets`,
  hotelRelationship: (hotelId: string) => `hotel:${hotelId}:relationship`,
  // Projects
  project: (id: string) => `project:${id}`,
  projectMargin: (id: string) => `project:${id}:margin`,
  // Vendors
  vendor: (id: string) => `vendor:${id}`,
  vendorScorecard: (id: string) => `vendor:${id}:scorecard`,
  // Analytics
  dashboardStats: (orgId: string) => `analytics:${orgId}:dashboard`,
  marginByHotel: (orgId: string) => `analytics:${orgId}:margin:by-hotel`,
  pipelineData: (orgId: string) => `analytics:${orgId}:pipeline`,
  // AI
  aiConversation: (sessionId: string) => `ai:conv:${sessionId}`,
  aiOrgMemory: (orgId: string) => `ai:org:${orgId}:memory`,
  // Opportunity Radar
  radarRecommendations: (orgId: string) => `radar:${orgId}:recommendations`,
  // Forecasts
  revenueForecast: (orgId: string, period: string) => `forecast:${orgId}:revenue:${period}`,
};

export const CacheTTL = {
  SHORT: 60,      // 1 minute
  MEDIUM: 300,    // 5 minutes
  LONG: 3600,     // 1 hour
  DAILY: 86400,   // 24 hours
  WEEKLY: 604800, // 7 days
};