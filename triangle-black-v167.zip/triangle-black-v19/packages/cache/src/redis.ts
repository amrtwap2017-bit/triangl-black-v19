import Redis from 'ioredis';

export interface RedisConfig {
  host: string;
  port: number;
  password?: string;
  db?: number;
  keyPrefix?: string;
}

export class RedisClient {
  private client: Redis;
  private isConnected = false;

  constructor(config: RedisConfig) {
    this.client = new Redis({
      host: config.host || process.env.REDIS_HOST || 'localhost',
      port: config.port || parseInt(process.env.REDIS_PORT || '6379'),
      password: config.password || process.env.REDIS_PASSWORD,
      db: config.db || 0,
      keyPrefix: config.keyPrefix || 'tb:',
      retryStrategy: (times: number) => Math.min(times * 200, 5000),
      maxRetriesPerRequest: 3,
      lazyConnect: true,
    });

    this.client.on('connect', () => { this.isConnected = true; });
    this.client.on('error', (err: Error) => { console.error('[Redis] Error:', err.message); });
    this.client.on('close', () => { this.isConnected = false; });
  }

  async connect(): Promise<void> { await this.client.connect(); }
  async disconnect(): Promise<void> { await this.client.quit(); }
  getClient(): Redis { return this.client; }
  getStatus(): { connected: boolean } { return { connected: this.isConnected }; }
}