import { CacheManager } from './cache-manager';

export class CacheStrategies {
  // Cache-aside pattern
  static async cacheAside<T>(cache: CacheManager, key: string, factory: () => Promise<T>, ttl?: number): Promise<T> {
    return cache.getOrSet(key, factory, { ttl });
  }
  
  // Write-through: always write to cache on update
  static async writeThrough<T>(cache: CacheManager, key: string, value: T, ttl?: number): Promise<void> {
    await cache.set(key, value, { ttl });
  }
  
  // Write-behind: queue cache writes (for high-throughput scenarios)
  static async writeBehind(_cache: CacheManager, _key: string, _value: unknown): Promise<void> {
    // Would integrate with queue for deferred writes
  }
}