import { registerAs } from '@nestjs/config';
import { env } from './env';

export default registerAs('ai', () => ({
  openai: {
    apiKey: env.OPENAI_API_KEY ?? '',
    defaultModel: 'gpt-4o',
    maxTokens: 4096,
    temperature: 0.7,
  },
  anthropic: {
    apiKey: env.ANTHROPIC_API_KEY ?? '',
    defaultModel: 'claude-sonnet-4-20250514',
  },
  embedding: {
    model: 'text-embedding-3-small',
    dimensions: 1536,
  },
}));
