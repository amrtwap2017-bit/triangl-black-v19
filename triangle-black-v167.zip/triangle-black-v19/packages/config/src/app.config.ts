import { registerAs } from '@nestjs/config';
import { env } from './env';

export default registerAs('app', () => ({
  name: 'TRIANGLE BLACK',
  version: '19.0.0',
  url: process.env.APP_URL ?? 'http://localhost:3000',
  apiUrl: process.env.APP_API_URL ?? 'http://localhost:3000/api/v1',
  port: env.PORT,
  isProduction: env.NODE_ENV === 'production',
  orgSlug: process.env.APP_ORG_SLUG ?? 'default',
}));
