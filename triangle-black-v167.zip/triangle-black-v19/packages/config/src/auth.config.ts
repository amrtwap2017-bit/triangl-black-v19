import { registerAs } from '@nestjs/config';
import { env } from './env';

export default registerAs('auth', () => ({
  jwt: {
    secret: env.JWT_SECRET,
    expiresIn: '15m',
    refreshSecret: env.JWT_REFRESH_SECRET,
    refreshExpiresIn: '7d',
    bcryptRounds: 12,
  },
}));
