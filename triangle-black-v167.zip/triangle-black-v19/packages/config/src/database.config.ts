import { registerAs } from '@nestjs/config';
import { env } from './env';

export default registerAs('database', () => ({
  url: env.DATABASE_URL,
  poolSize: env.DATABASE_POOL_SIZE,
  ssl:
    env.NODE_ENV === 'production'
      ? { rejectUnauthorized: false }
      : undefined,
  connectionTimeout: 30000,
  idleTimeout: 600000,
  logQueries: env.NODE_ENV === 'development',
}));
