import { z } from 'zod';

/**
 * Master environment variable schema with Zod validation.
 * Every environment variable the system depends on is declared here.
 */
export const envSchema = z.object({
  // ── Database ───────────────────────────────────────────────────────────
  DATABASE_URL: z.string().url('DATABASE_URL must be a valid connection string'),
  DATABASE_POOL_SIZE: z.coerce.number().default(10),

  // ── Authentication ──────────────────────────────────────────────────
  JWT_SECRET: z.string().min(16, 'JWT_SECRET must be at least 16 characters'),
  JWT_REFRESH_SECRET: z
    .string()
    .min(16, 'JWT_REFRESH_SECRET must be at least 16 characters'),

  // ── Encryption ───────────────────────────────────────────────────────
  ENCRYPTION_KEY: z.string().min(16, 'ENCRYPTION_KEY must be at least 16 characters'),

  // ── Redis ────────────────────────────────────────────────────────────
  REDIS_URL: z
    .string()
    .url('REDIS_URL must be a valid URL')
    .optional()
    .default('redis://localhost:6379'),

  // ── AI Providers (optional — system works without them) ─────────────
  OPENAI_API_KEY: z.string().min(1).optional(),
  ANTHROPIC_API_KEY: z.string().min(1).optional(),

  // ── Object Storage (optional — defaults to local) ───────────────────
  S3_BUCKET: z.string().optional(),
  STORAGE_ACCESS_KEY: z.string().optional(),
  STORAGE_SECRET_KEY: z.string().optional(),

  // ── Server ───────────────────────────────────────────────────────────
  PORT: z.coerce.number().default(3000),
  NODE_ENV: z
    .enum(['development', 'staging', 'production'])
    .default('development'),
  CORS_ORIGIN: z.string().default('*'),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
});

export type Env = z.infer<typeof envSchema>;

/**
 * Validate the process environment against the schema.
 * Throws with a clear message on failure — fail-fast at startup.
 */
export function validateEnv(
  raw = process.env as Record<string, string | undefined>,
): Env {
  const result = envSchema.safeParse(raw);

  if (!result.success) {
    const errors = result.error.issues
      .map((issue) => `  - ${issue.path.join('.')}: ${issue.message}`)
      .join('\n');
    throw new Error(`Environment validation failed:\n${errors}`);
  }

  return result.data;
}

/**
 * Pre-validated environment singleton.
 * Import this wherever you need config values instead of using process.env directly.
 */
export const env: Env = validateEnv();
