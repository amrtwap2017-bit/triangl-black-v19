/**
 * @triangleblack/config — Centralized Zod-validated configuration.
 *
 * Every module in the monorepo should import from this package.
 * NEVER use process.env directly outside of this package.
 */

// ── Environment Validation ────────────────────────────────────────────
export { envSchema, validateEnv, env, type Env } from './env';

// ── RegisterAs Config Factories (for @nestjs/config) ──────────────────
export { default as databaseConfig } from './database.config';
export { default as authConfig } from './auth.config';
export { default as aiConfig } from './ai.config';
export { default as redisConfig } from './redis.config';
export { default as storageConfig } from './storage.config';
export { default as queueConfig } from './queue.config';
export { default as securityConfig } from './security.config';
export { default as appConfig } from './app.config';
