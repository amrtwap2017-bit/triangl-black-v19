import { registerAs } from '@nestjs/config';
import { env } from './env';

export default registerAs('queue', () => ({
  redisUrl: env.REDIS_URL,
  defaultJobOptions: {
    removeOnComplete: 100,
    removeOnFail: 500,
    attempts: 3,
    backoff: {
      type: 'exponential' as const,
      delay: 2000,
    },
  },
  concurrency: {
    standard: 5,
    ai: 2,
  },
}));
