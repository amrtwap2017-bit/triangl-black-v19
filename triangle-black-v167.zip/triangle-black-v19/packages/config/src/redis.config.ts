import { registerAs } from '@nestjs/config';
import { env } from './env';

export default registerAs('redis', () => ({
  url: env.REDIS_URL,
  ttl: {
    short: 300,       // 5 minutes
    medium: 3600,     // 1 hour
    long: 21600,      // 6 hours
    day: 86400,       // 24 hours
  },
}));
