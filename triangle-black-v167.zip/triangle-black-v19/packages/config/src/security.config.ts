import { registerAs } from '@nestjs/config';
import { env } from './env';

export default registerAs('security', () => ({
  rateLimit: {
    ttl: 60000,   // 1 minute window
    max: 100,
  },
  encryption: {
    algorithm: 'aes-256-gcm' as const,
  },
  cors: {
    origin: env.CORS_ORIGIN,
    credentials: true,
  },
  helmet: {
    enabled: true,
  },
}));
