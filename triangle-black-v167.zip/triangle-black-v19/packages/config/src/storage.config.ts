import { registerAs } from '@nestjs/config';
import { z } from 'zod';
import { env } from './env';

export default registerAs('storage', () => ({
  driver: z
    .enum(['local', 's3'])
    .parse(process.env.STORAGE_DRIVER ?? 'local'),
  localPath: process.env.STORAGE_LOCAL_PATH ?? './uploads',
  s3: {
    bucket: env.S3_BUCKET ?? '',
    region: process.env.AWS_REGION ?? 'me-south-1',
    accessKey: env.STORAGE_ACCESS_KEY ?? '',
    secretKey: env.STORAGE_SECRET_KEY ?? '',
  },
}));
