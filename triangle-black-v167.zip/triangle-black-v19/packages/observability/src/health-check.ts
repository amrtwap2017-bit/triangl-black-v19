export interface HealthCheckResult {
  status: 'healthy' | 'degraded' | 'unhealthy';
  checks: Record<string, { status: 'up' | 'down'; latencyMs?: number; details?: string }>;
  timestamp: string;
  uptime: number;
}

export class HealthCheck {
  private startTime = Date.now();
  private checks = new Map<string, () => Promise<{ status: 'up' | 'down'; latencyMs?: number; details?: string }>>();

  register(name: string, check: () => Promise<{ status: 'up' | 'down'; latencyMs?: number; details?: string }>): void {
    this.checks.set(name, check);
  }

  async run(): Promise<HealthCheckResult> {
    const results: HealthCheckResult['checks'] = {};
    let allHealthy = true;

    for (const [name, check] of this.checks) {
      try {
        const start = Date.now();
        const result = await check();
        results[name] = { ...result, latencyMs: Date.now() - start };
        if (result.status === 'down') allHealthy = false;
      } catch (error) {
        results[name] = { status: 'down', details: (error as Error).message };
        allHealthy = false;
      }
    }

    return {
      status: allHealthy ? 'healthy' : 'degraded',
      checks: results,
      timestamp: new Date().toISOString(),
      uptime: Date.now() - this.startTime,
    };
  }
}