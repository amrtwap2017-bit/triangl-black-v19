export enum LogLevel { DEBUG, INFO, WARN, ERROR, FATAL }

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  context?: string;
  module?: string;
  userId?: string;
  organizationId?: string;
  requestId?: string;
  durationMs?: number;
  metadata?: Record<string, unknown>;
}

export class StructuredLogger {
  private context: string;

  constructor(context: string) {
    this.context = context;
  }

  private log(level: LogLevel, message: string, meta?: Record<string, unknown>): void {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      context: this.context,
      ...meta,
    };
    const output = JSON.stringify(entry);
    switch (level) {
      case LogLevel.DEBUG: console.debug(output); break;
      case LogLevel.INFO: console.log(output); break;
      case LogLevel.WARN: console.warn(output); break;
      case LogLevel.ERROR: console.error(output); break;
      case LogLevel.FATAL: console.error(output); break;
    }
  }

  debug(message: string, meta?: Record<string, unknown>) { this.log(LogLevel.DEBUG, message, meta); }
  info(message: string, meta?: Record<string, unknown>) { this.log(LogLevel.INFO, message, meta); }
  warn(message: string, meta?: Record<string, unknown>) { this.log(LogLevel.WARN, message, meta); }
  error(message: string, meta?: Record<string, unknown>) { this.log(LogLevel.ERROR, message, meta); }
  fatal(message: string, meta?: Record<string, unknown>) { this.log(LogLevel.FATAL, message, meta); }
}