export class Tracer {
  private static spans = new Map<string, { startTime: number; metadata: Record<string, unknown> }>();

  static startSpan(name: string, metadata: Record<string, unknown> = {}): string {
    const spanId = crypto.randomUUID().slice(0, 8);
    this.spans.set(spanId, { startTime: Date.now(), metadata: { ...metadata, name } });
    return spanId;
  }

  static endSpan(spanId: string): { durationMs: number; metadata: Record<string, unknown> } | null {
    const span = this.spans.get(spanId);
    if (!span) return null;
    const durationMs = Date.now() - span.startTime;
    this.spans.delete(spanId);
    return { durationMs, metadata: span.metadata };
  }

  static async trace<T>(name: string, fn: () => Promise<T>, metadata?: Record<string, unknown>): Promise<T> {
    const spanId = this.startSpan(name, metadata);
    try {
      const result = await fn();
      const span = this.endSpan(spanId);
      if (span) console.log(`[TRACE] ${name}: ${span.durationMs}ms`);
      return result;
    } catch (error) {
      const span = this.endSpan(spanId);
      if (span) console.error(`[TRACE] ${name}: FAILED after ${span.durationMs}ms`);
      throw error;
    }
  }
}