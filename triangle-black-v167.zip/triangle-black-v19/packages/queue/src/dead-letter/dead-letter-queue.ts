/**
 * Triangle Black v19 — Dead-Letter Queue
 * Persists failed jobs for inspection, manual retry, and statistical analysis.
 */

import type { Job } from 'bullmq';

// ─── Types ───────────────────────────────────────────────────────────────────

export interface DeadLetterEntry {
  /** Unique identifier for the dead-letter record */
  id: string;
  /** Original job name */
  jobName: string;
  /** Original queue name */
  queue: string;
  /** Original job payload */
  originalData: unknown;
  /** Error message */
  error: string;
  /** Stack trace if available */
  stack?: string;
  /** Number of attempts before landing in DLQ */
  attempts: number;
  /** ISO timestamp of failure */
  failedAt: string;
}

export interface DeadLetterFilter {
  jobName?: string;
  from?: Date;
  to?: Date;
}

export interface FailureStats {
  total: number;
  byError: Record<string, number>;
  byJob: Record<string, number>;
}

// ─── In-Memory Store (swap for Redis / Postgres in production) ───────────────

const store = new Map<string, DeadLetterEntry>();

// ─── Public API ──────────────────────────────────────────────────────────────

/**
 * Move a failed job to the dead-letter queue.
 */
export async function moveToDeadLetter(
  job: Job,
  error: Error,
): Promise<string> {
  const id = `dlq:${job.id ?? Date.now()}`;
  const entry: DeadLetterEntry = {
    id,
    jobName: job.name,
    queue: job.queueName,
    originalData: job.data,
    error: error.message,
    stack: error.stack,
    attempts: job.attemptsMade,
    failedAt: new Date().toISOString(),
  };

  store.set(id, entry);
  return id;
}

/**
 * Re-queue a dead-letter job for retry.
 * Removes the entry from the DLQ store.
 *
 * In production this would call `queue.add(jobName, originalData)`.
 * Here we return the entry so the caller can re-enqueue.
 */
export async function retryFromDeadLetter(
  jobId: string,
): Promise<DeadLetterEntry | null> {
  const entry = store.get(jobId);
  if (!entry) return null;

  store.delete(jobId);
  return entry;
}

/**
 * List dead-letter jobs with optional filtering and pagination.
 */
export function getDeadLetterJobs(
  queueName?: string,
  filters?: DeadLetterFilter,
  page = 1,
  pageSize = 20,
): { items: DeadLetterEntry[]; total: number; page: number; pageSize: number } {
  let entries = Array.from(store.values());

  if (queueName) {
    entries = entries.filter((e) => e.queue === queueName);
  }

  if (filters?.jobName) {
    entries = entries.filter((e) => e.jobName === filters.jobName);
  }

  if (filters?.from) {
    const fromMs = filters.from.getTime();
    entries = entries.filter((e) => new Date(e.failedAt).getTime() >= fromMs);
  }

  if (filters?.to) {
    const toMs = filters.to.getTime();
    entries = entries.filter((e) => new Date(e.failedAt).getTime() <= toMs);
  }

  // Most-recent first
  entries.sort(
    (a, b) =>
      new Date(b.failedAt).getTime() - new Date(a.failedAt).getTime(),
  );

  const total = entries.length;
  const start = (page - 1) * pageSize;
  const items = entries.slice(start, start + pageSize);

  return { items, total, page, pageSize };
}

/**
 * Purge dead-letter entries older than `olderThanDays` for a given queue.
 * Defaults to 30 days. Returns the count of purged entries.
 */
export function purgeDeadLetter(
  queueName?: string,
  olderThanDays = 30,
): number {
  const cutoff = Date.now() - olderThanDays * 86_400_000;
  let purged = 0;

  for (const [id, entry] of store) {
    const entryMs = new Date(entry.failedAt).getTime();
    if (entryMs < cutoff && (!queueName || entry.queue === queueName)) {
      store.delete(id);
      purged++;
    }
  }

  return purged;
}

/**
 * Aggregate failure statistics for a given queue.
 */
export function getFailureStats(queueName?: string): FailureStats {
  const entries = queueName
    ? Array.from(store.values()).filter((e) => e.queue === queueName)
    : Array.from(store.values());

  const byError: Record<string, number> = {};
  const byJob: Record<string, number> = {};

  for (const entry of entries) {
    const errKey = entry.error.slice(0, 120);
    byError[errKey] = (byError[errKey] ?? 0) + 1;
    byJob[entry.jobName] = (byJob[entry.jobName] ?? 0) + 1;
  }

  return { total: entries.length, byError, byJob };
}