// ─── Job Definitions ─────────────────────────────────────────────────────────
export {
  JOB_DEFINITIONS,
  QUEUE_NAMES,
  getJobDefinition,
  resolveIdempotencyKey,
  type JobDefinition,
  type JobPayload,
  type DocumentProcessingPayload,
  type DocumentOcrPayload,
  type DocumentEmbeddingPayload,
  type DocumentIndexingPayload,
  type AiChatProcessingPayload,
  type AiToolExecutionPayload,
  type RfqDeadlinePayload,
  type RfqVendorNotificationPayload,
  type MaintenanceSchedulingPayload,
  type ForecastGenerationPayload,
  type EmailSendingPayload,
  type ReportGenerationPayload,
} from './jobs/job-definitions';

export { QueueNames } from './jobs/index';

// ─── Retry Policies ──────────────────────────────────────────────────────────
export {
  getRetryPolicy,
  computeRetryDelay,
  buildBullMQRetryOptions,
  type RetryPolicy,
} from './retry/retry-policies';

// ─── Dead-Letter Queue ───────────────────────────────────────────────────────
export {
  moveToDeadLetter,
  retryFromDeadLetter,
  getDeadLetterJobs,
  purgeDeadLetter,
  getFailureStats,
  type DeadLetterEntry,
  type DeadLetterFilter,
  type FailureStats,
} from './dead-letter/dead-letter-queue';

// ─── Queue Manager (legacy — kept for backwards compat) ──────────────────────
export { QueueManager, type RetryPolicy as LegacyRetryPolicy } from './queue-manager';