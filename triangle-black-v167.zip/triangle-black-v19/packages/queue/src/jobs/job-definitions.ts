/**
 * Triangle Black v19 — Production Job Definitions
 * Complete job registry with typed payloads, queue routing, timeouts, and idempotency.
 */

// ─── Payload Types ───────────────────────────────────────────────────────────

export interface DocumentProcessingPayload {
  documentId: string;
}

export interface DocumentOcrPayload {
  documentId: string;
  pageNumbers?: number[];
}

export interface DocumentEmbeddingPayload {
  documentId: string;
}

export interface DocumentIndexingPayload {
  documentId: string;
}

export interface AiChatProcessingPayload {
  conversationId: string;
  messageId: string;
}

export interface AiToolExecutionPayload {
  toolName: string;
  params: Record<string, unknown>;
  context?: Record<string, unknown>;
}

export interface RfqDeadlinePayload {
  rfqId: string;
}

export interface RfqVendorNotificationPayload {
  rfqId: string;
  vendorId: string;
}

export interface MaintenanceSchedulingPayload {
  assetId: string;
  scheduleId: string;
}

export interface ForecastGenerationPayload {
  hotelId: string;
  period: string;
}

export interface EmailSendingPayload {
  template: string;
  to: string | string[];
  data: Record<string, unknown>;
}

export interface ReportGenerationPayload {
  type: string;
  params: Record<string, unknown>;
}

export type JobPayload =
  | DocumentProcessingPayload
  | DocumentOcrPayload
  | DocumentEmbeddingPayload
  | DocumentIndexingPayload
  | AiChatProcessingPayload
  | AiToolExecutionPayload
  | RfqDeadlinePayload
  | RfqVendorNotificationPayload
  | MaintenanceSchedulingPayload
  | ForecastGenerationPayload
  | EmailSendingPayload
  | ReportGenerationPayload;

// ─── Job Definition ──────────────────────────────────────────────────────────

export interface JobDefinition {
  /** Unique job name (used as BullMQ job name) */
  name: string;
  /** Target queue */
  queue: string;
  /** Job timeout in ms */
  timeout: number;
  /** Max retry attempts */
  attempts: number;
  /** Backoff configuration */
  backoff: { type: 'exponential' | 'fixed'; delay: number };
  /** Job priority (lower = higher priority) */
  priority: number;
  /** Optional idempotency key template — resolved at enqueue time */
  idempotencyKey?: string;
}

// ─── Job Registry ────────────────────────────────────────────────────────────

export const JOB_DEFINITIONS: Record<string, JobDefinition> = {
  DOCUMENT_PROCESSING: {
    name: 'DOCUMENT_PROCESSING',
    queue: 'documents',
    timeout: 300_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 1,
    idempotencyKey: 'doc-processing:{documentId}',
  },

  DOCUMENT_OCR: {
    name: 'DOCUMENT_OCR',
    queue: 'documents',
    timeout: 120_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 2,
    idempotencyKey: 'doc-ocr:{documentId}',
  },

  DOCUMENT_EMBEDDING: {
    name: 'DOCUMENT_EMBEDDING',
    queue: 'embeddings',
    timeout: 600_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 3,
    idempotencyKey: 'doc-embedding:{documentId}',
  },

  DOCUMENT_INDEXING: {
    name: 'DOCUMENT_INDEXING',
    queue: 'indexing',
    timeout: 120_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 4,
    idempotencyKey: 'doc-indexing:{documentId}',
  },

  AI_CHAT_PROCESSING: {
    name: 'AI_CHAT_PROCESSING',
    queue: 'ai',
    timeout: 60_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 1,
    idempotencyKey: 'ai-chat:{conversationId}:{messageId}',
  },

  AI_TOOL_EXECUTION: {
    name: 'AI_TOOL_EXECUTION',
    queue: 'ai-tools',
    timeout: 30_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 2,
  },

  RFQ_DEADLINE: {
    name: 'RFQ_DEADLINE',
    queue: 'rfq',
    timeout: 30_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 5,
    idempotencyKey: 'rfq-deadline:{rfqId}',
  },

  RFQ_VENDOR_NOTIFICATION: {
    name: 'RFQ_VENDOR_NOTIFICATION',
    queue: 'notifications',
    timeout: 10_000,
    attempts: 5,
    backoff: { type: 'exponential', delay: 1_000 },
    priority: 5,
    idempotencyKey: 'rfq-notify:{rfqId}:{vendorId}',
  },

  MAINTENANCE_SCHEDULING: {
    name: 'MAINTENANCE_SCHEDULING',
    queue: 'maintenance',
    timeout: 15_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 5,
    idempotencyKey: 'maint:{assetId}:{scheduleId}',
  },

  FORECAST_GENERATION: {
    name: 'FORECAST_GENERATION',
    queue: 'forecasts',
    timeout: 120_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 5,
    idempotencyKey: 'forecast:{hotelId}:{period}',
  },

  EMAIL_SENDING: {
    name: 'EMAIL_SENDING',
    queue: 'emails',
    timeout: 30_000,
    attempts: 5,
    backoff: { type: 'exponential', delay: 1_000 },
    priority: 10,
  },

  REPORT_GENERATION: {
    name: 'REPORT_GENERATION',
    queue: 'reports',
    timeout: 300_000,
    attempts: 3,
    backoff: { type: 'exponential', delay: 2_000 },
    priority: 5,
  },
};

/** All unique queue names derived from job definitions */
export const QUEUE_NAMES = Object.values(JOB_DEFINITIONS).reduce<Set<string>>(
  (acc, def) => {
    acc.add(def.queue);
    return acc;
  },
  new Set(),
);

/** Get a job definition by name */
export function getJobDefinition(jobName: string): JobDefinition | undefined {
  return JOB_DEFINITIONS[jobName];
}

/** Resolve an idempotency key template with actual payload values */
export function resolveIdempotencyKey(
  template: string | undefined,
  data: Record<string, unknown>,
): string | undefined {
  if (!template) return undefined;
  return template.replace(/\{(\w+)\}/g, (_, key) =>
    String(data[key] ?? 'unknown'),
  );
}