import { Queue, Worker, type Job } from 'bullmq';
import { RedisClient } from '@triangleblack/cache';

export interface JobDefinition<T = unknown> {
  name: string;
  processor: (job: { data: T; id?: string }) => Promise<unknown>;
  concurrency?: number;
  retryPolicy?: RetryPolicy;
  deadLetterQueue?: boolean;
}

export interface RetryPolicy {
  attempts: number;
  backoff: { type: 'exponential' | 'fixed'; delay: number };
}

export class QueueManager {
  private queues = new Map<string, Queue>();
  private workers = new Map<string, Worker>();
  private redisClient: RedisClient;

  constructor(redis: RedisClient) {
    this.redisClient = redis;
  }

  createQueue<T>(definition: JobDefinition<T>): void {
    const connection = this.redisClient.getClient();
    const queue = new Queue(definition.name, { connection });
    this.queues.set(definition.name, queue);

    const worker = new Worker(
      definition.name,
      async (job: Job) => {
        return definition.processor({ data: job.data as T, id: job.id });
      },
      {
        connection,
        concurrency: definition.concurrency || 5,
        limiter: { max: 100, duration: 60000 },
      },
    );

    worker.on('completed', (job: Job) => console.log(`[Queue:${definition.name}] Job ${job.id} completed`));
    worker.on('failed', (job: Job | undefined, err: Error) => console.error(`[Queue:${definition.name}] Job ${job?.id} failed: ${err.message}`));
    
    this.workers.set(definition.name, worker);
  }

  async addJob<T>(queueName: string, data: T, options?: { delay?: number; priority?: number; jobId?: string }): Promise<string> {
    const queue = this.queues.get(queueName);
    if (!queue) throw new Error(`Queue "${queueName}" not found`);
    const job = await queue.add(queueName, data, {
      delay: options?.delay,
      priority: options?.priority,
      jobId: options?.jobId,
      attempts: 3,
      backoff: { type: 'exponential', delay: 2000 },
      removeOnComplete: 100,
      removeOnFail: 50,
    });
    return job.id || '';
  }

  getQueueStatus(queueName: string) {
    const queue = this.queues.get(queueName);
    if (!queue) return null;
    return {
      name: queueName,
      isActive: this.workers.has(queueName),
    };
  }

  async shutdown(): Promise<void> {
    for (const [, queue] of this.queues) await queue.close();
    for (const [, worker] of this.workers) await worker.close();
  }
}