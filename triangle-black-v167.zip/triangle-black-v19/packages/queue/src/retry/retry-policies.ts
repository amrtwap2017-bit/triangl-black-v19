/**
 * Triangle Black v19 — Retry Policies
 * Exponential backoff with jitter to prevent thundering-herd on failures.
 */

import { JOB_DEFINITIONS, type JobDefinition } from '../jobs/job-definitions';

// ─── Policy Interface ────────────────────────────────────────────────────────

export interface RetryPolicy {
  /** Maximum number of retry attempts (not counting the first attempt) */
  attempts: number;
  backoff: {
    type: 'exponential';
    /** Base delay in ms */
    delay: number;
  };
  /** Absolute ceiling for any computed delay (ms) */
  maxRetryDelay: number;
}

// ─── Classification ──────────────────────────────────────────────────────────

/**
 * Jobs whose failure is critical — we retry fewer times with longer base
 * delays so the system doesn't amplify a persistent error.
 */
const CRITICAL_JOB_PREFIXES = [
  'DOCUMENT_PROCESSING',
  'DOCUMENT_OCR',
  'DOCUMENT_EMBEDDING',
  'DOCUMENT_INDEXING',
  'AI_CHAT_PROCESSING',
  'AI_TOOL_EXECUTION',
];

/**
 * Non-critical jobs (notifications, emails, reports) — retry more aggressively
 * because transient failures (SMTP timeout, push-service 503) are common.
 */
const NON_CRITICAL_JOB_PREFIXES = [
  'RFQ_VENDOR_NOTIFICATION',
  'EMAIL_SENDING',
  'MAINTENANCE_SCHEDULING',
];

function isCritical(jobName: string): boolean {
  return CRITICAL_JOB_PREFIXES.some((p) => jobName.startsWith(p));
}

function isNonCritical(jobName: string): boolean {
  return NON_CRITICAL_JOB_PREFIXES.some((p) => jobName.startsWith(p));
}

// ─── Jitter ──────────────────────────────────────────────────────────────────

/** Random 0–500 ms jitter to spread retry storms */
function jitter(): number {
  return Math.floor(Math.random() * 501);
}

// ─── Policy Factory ──────────────────────────────────────────────────────────

const CRITICAL_POLICY: RetryPolicy = {
  attempts: 3,
  backoff: { type: 'exponential', delay: 2_000 },
  maxRetryDelay: 30_000,
};

const NON_CRITICAL_POLICY: RetryPolicy = {
  attempts: 5,
  backoff: { type: 'exponential', delay: 1_000 },
  maxRetryDelay: 60_000,
};

const DEFAULT_POLICY: RetryPolicy = {
  attempts: 3,
  backoff: { type: 'exponential', delay: 2_000 },
  maxRetryDelay: 30_000,
};

/**
 * Returns the retry policy for a given job name.
 *
 * - Critical jobs (document pipeline, AI): 3 attempts, base 2 s, max 30 s
 * - Non-critical (notifications, emails): 5 attempts, base 1 s, max 60 s
 * - Everything else: same as critical defaults
 */
export function getRetryPolicy(jobName: string): RetryPolicy {
  if (isCritical(jobName)) return CRITICAL_POLICY;
  if (isNonCritical(jobName)) return NON_CRITICAL_POLICY;
  return DEFAULT_POLICY;
}

/**
 * Compute the actual delay (in ms) for a given attempt number.
 * Applies exponential backoff + random jitter, capped at maxRetryDelay.
 *
 * @param policy  The retry policy
 * @param attempt Zero-based attempt index (0 = first retry)
 */
export function computeRetryDelay(policy: RetryPolicy, attempt: number): number {
  const base = policy.backoff.delay;
  const exponentialDelay = base * Math.pow(2, attempt);
  const jittered = exponentialDelay + jitter();
  return Math.min(jittered, policy.maxRetryDelay);
}

/**
 * Build BullMQ-compatible retry options from a job definition.
 * Falls back to the policy if the job definition omits retry config.
 */
export function buildBullMQRetryOptions(
  jobDefinition: JobDefinition | undefined,
  jobName: string,
): { attempts: number; backoff: { type: 'exponential'; delay: number } } {
  if (jobDefinition) {
    return {
      attempts: jobDefinition.attempts,
      backoff: jobDefinition.backoff,
    };
  }

  const policy = getRetryPolicy(jobName);
  return {
    attempts: policy.attempts,
    backoff: policy.backoff,
  };
}