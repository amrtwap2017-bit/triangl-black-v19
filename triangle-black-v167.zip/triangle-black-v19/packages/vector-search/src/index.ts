export { PgVectorClient } from './pgvector/pgvector-client';
export type { PgVectorClientConfig } from './pgvector/pgvector-client';

export { SimilaritySearch } from './similarity/similarity-search';
export type { SearchResult, SearchOptions } from './similarity/similarity-search';

export { VectorStore } from './vector-store';
export type { VectorDocument } from './vector-store';

export { EmbeddingService } from './embedding-service';

export { SemanticSearch } from './semantic-search';
