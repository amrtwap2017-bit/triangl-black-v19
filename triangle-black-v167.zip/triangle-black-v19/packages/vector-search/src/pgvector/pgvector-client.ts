/**
 * Triangle Black v19 — pgvector Client
 *
 * Manages pgvector extension initialization, index creation,
 * and health checks for the vector search infrastructure.
 */

import { Pool } from 'pg';

export interface PgVectorClientConfig {
  databaseUrl: string;
}

export class PgVectorClient {
  private pool: Pool;
  private initialized = false;

  constructor(config: PgVectorClientConfig) {
    this.pool = new Pool({
      connectionString: config.databaseUrl,
      max: 10,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 5_000,
    });
  }

  /**
   * Initialize pgvector extension.
   */
  async init(): Promise<void> {
    await this.pool.query('CREATE EXTENSION IF NOT EXISTS vector');
    this.initialized = true;
    console.log('[pgvector] Extension initialized');
  }

  /**
   * Ensure an HNSW index exists on the specified table/column.
   * Uses HNSW (hierarchical navigable small world) for fast approximate nearest neighbor.
   */
  async ensureIndex(
    tableName: string,
    indexName: string,
    dimensions = 1536,
    column = 'embedding',
  ): Promise<void> {
    // Create the table if it doesn't exist
    await this.pool.query(`
      CREATE TABLE IF NOT EXISTS ${tableName} (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        organization_id UUID NOT NULL,
        content TEXT NOT NULL,
        embedding vector(${dimensions}),
        metadata JSONB DEFAULT '{}',
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Create standard B-tree indexes for filtering
    await this.pool.query(`
      CREATE INDEX IF NOT EXISTS idx_${tableName}_org ON ${tableName} (organization_id);
    `);

    // Create HNSW vector index for similarity search
    try {
      await this.pool.query(`
        CREATE INDEX IF NOT EXISTS ${indexName}
        ON ${tableName}
        USING hnsw (${column} vector_cosine_ops)
        WITH (m = 16, ef_construction = 64)
      `);
      console.log(`[pgvector] HNSW index "${indexName}" ensured on ${tableName}.${column}`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn(`[pgvector] Index creation warning: ${msg}`);
      // Index may already exist or table empty — not fatal
    }
  }

  /**
   * Health check — verify pgvector extension is working.
   */
  async healthCheck(): Promise<{ healthy: boolean; latencyMs: number; details?: string }> {
    const start = Date.now();
    try {
      const result = await this.pool.query('SELECT $1::vector <=> $2::vector AS distance', [
        '[1,0,0]',
        '[1,0,0]',
      ]);
      const latencyMs = Date.now() - start;
      return {
        healthy: true,
        latencyMs,
        details: `Distance result: ${result.rows[0].distance}`,
      };
    } catch (err: unknown) {
      const latencyMs = Date.now() - start;
      return {
        healthy: false,
        latencyMs,
        details: err instanceof Error ? err.message : String(err),
      };
    }
  }

  /**
   * Get the underlying pg Pool for direct queries.
   */
  getPool(): Pool {
    return this.pool;
  }

  /**
   * Close the connection pool.
   */
  async close(): Promise<void> {
    await this.pool.end();
    this.initialized = false;
  }

  isInitialized(): boolean {
    return this.initialized;
  }
}
