/**
 * Triangle Black v19 — Similarity Search
 *
 * CRITICAL: Every search MUST include organizationId filter.
 * NO CROSS-TENANT RETRIEVAL under any circumstances.
 */

import { Pool } from 'pg';
import { PgVectorClient } from '../pgvector/pgvector-client';

export interface SearchResult {
  id: string;
  content: string;
  similarity: number;
  metadata: Record<string, unknown>;
}

export interface SearchOptions {
  topK?: number;
  threshold?: number;
  filters?: Record<string, unknown>;
}

export class SimilaritySearch {
  private pool: Pool;

  constructor(pgvectorClient: PgVectorClient) {
    this.pool = pgvectorClient.getPool();
  }

  /**
   * Vector similarity search within a single organization.
   * CRITICAL: organizationId is ALWAYS included in the WHERE clause.
   */
  async search(
    queryVector: number[],
    tableName: string,
    organizationId: string,
    topK = 10,
    filters?: Record<string, unknown>,
    threshold = 0.5,
  ): Promise<SearchResult[]> {
    const vectorStr = `[${queryVector.join(',')}]`;

    let whereClause = `WHERE organization_id = $1 AND 1 - (embedding <=> $2::vector) > $3`;
    const params: unknown[] = [organizationId, vectorStr, threshold];
    let paramIndex = 4;

    // Add optional metadata filters
    if (filters) {
      for (const [key, value] of Object.entries(filters)) {
        whereClause += ` AND metadata->>'${key}' = $${paramIndex}`;
        params.push(String(value));
        paramIndex++;
      }
    }

    const query = `
      SELECT id, content, metadata, 1 - (embedding <=> $2::vector) as similarity
      FROM ${tableName}
      ${whereClause}
      ORDER BY embedding <=> $2::vector
      LIMIT $${paramIndex}
    `;
    params.push(topK);
    paramIndex++;

    const result = await this.pool.query(query, params);
    return result.rows.map((row: any) => ({
      id: row.id,
      content: row.content,
      similarity: parseFloat(row.similarity),
      metadata: row.metadata ?? {},
    }));
  }

  /**
   * Hybrid search combining vector similarity with keyword relevance.
   * Alpha controls the weighting: alpha = vector weight, (1-alpha) = keyword weight.
   */
  async hybridSearch(
    queryVector: number[],
    keywordResults: Array<{ id: string; relevance: number }>,
    organizationId: string,
    tableName: string,
    topK = 10,
    alpha = 0.7,
  ): Promise<SearchResult[]> {
    // Get vector results
    const vectorResults = await this.search(queryVector, tableName, organizationId, topK * 3, undefined, 0.3);

    // Build relevance map from keyword results
    const keywordMap = new Map(keywordResults.map((r) => [r.id, r.relevance]));

    // Combine scores
    const combined = vectorResults.map((result) => {
      const keywordScore = keywordMap.get(result.id) ?? 0;
      const combinedScore = alpha * result.similarity + (1 - alpha) * keywordScore;
      return { ...result, combinedScore };
    });

    // Sort by combined score and take top-K
    combined.sort((a, b) => b.combinedScore - a.combinedScore);
    return combined.slice(0, topK).map(({ combinedScore, ...rest }) => rest);
  }

  /**
   * Rerank results boosting recency and relevance.
   */
  rerank(
    results: SearchResult[],
    query: string,
    options?: { recencyBoost?: number; recencyField?: string },
  ): SearchResult[] {
    const recencyBoost = options?.recencyBoost ?? 0.1;
    const recencyField = options?.recencyField ?? 'createdAt';

    return results
      .map((result) => {
        let recencyScore = 0;

        // Boost recently created/updated items
        const createdAt = result.metadata[recencyField];
        if (createdAt) {
          const age = Date.now() - new Date(createdAt as string).getTime();
          const daysOld = age / (1000 * 60 * 60 * 24);
          recencyScore = Math.max(0, 1 - daysOld / 365) * recencyBoost;
        }

        return {
          ...result,
          similarity: result.similarity + recencyScore,
        };
      })
      .sort((a, b) => b.similarity - a.similarity);
  }
}
