# TRIANGLE BLACK v18 — Test Suite

## Test Structure

```
tests/
├── unit/                          # Unit tests (isolated, fast)
│   ├── jest.config.js
│   └── modules/
│       ├── auth/
│       │   └── auth.service.spec.ts
│       └── opportunity-radar/
│           └── opportunity-radar.service.spec.ts
├── integration/                   # Integration tests (module-level)
│   ├── jest.config.js
│   └── modules/
│       └── proposals/
│           └── proposals.controller.spec.ts
├── e2e/                          # End-to-end tests (HTTP-level)
│   ├── jest-e2e.config.js
│   └── auth.e2e-spec.ts
├── security/                     # Security-specific tests
│   ├── prompt-injection.spec.ts
│   ├── tenant-isolation.spec.ts
│   └── pii-detection.spec.ts
├── performance/                  # Performance benchmarks
│   └── performance.test.ts
└── README.md                     # This file
```

## Running Tests

### Unit Tests
```bash
# Run all unit tests
npx jest --config tests/unit/jest.config.js

# Run with coverage
npx jest --config tests/unit/jest.config.js --coverage

# Run specific test file
npx jest --config tests/unit/jest.config.js tests/unit/modules/auth/auth.service.spec.ts
```

### Integration Tests
```bash
# Run all integration tests
npx jest --config tests/integration/jest.config.js

# Run with coverage
npx jest --config tests/integration/jest.config.js --coverage
```

### E2E Tests
```bash
# Requires a running test database (PostgreSQL + Redis)
# Set TEST_DATABASE_URL environment variable

npx jest --config tests/e2e/jest-e2e.config.js --runInBand
```

### Security Tests
```bash
npx jest tests/security/ --verbose
```

### Performance Tests
```bash
npx jest tests/performance/ --verbose
```

### Run All Tests
```bash
# From project root
pnpm test                    # Unit tests
pnpm test:integration        # Integration tests
pnpm test:e2e                # E2E tests
pnpm test:security           # Security tests
pnpm test:performance        # Performance tests
pnpm test:cov                # All tests with coverage
```

## Coverage Targets

| Metric    | Target | Notes                          |
|-----------|--------|--------------------------------|
| Lines     | 75%    | Minimum for all modules        |
| Functions | 75%    |                                |
| Branches  | 70%    |                                |
| Statements| 75%    |                                |

## Test Categories

### Unit Tests
- Isolated tests with full mocking (PrismaService, JwtService, etc.)
- Focus on business logic validation
- Fast execution (< 10s total)
- No external dependencies

### Integration Tests
- Test module interactions via `@nestjs/testing`
- Mock only external services (auth guards)
- Verify controller → service wiring
- Validation pipe testing

### E2E Tests
- Full HTTP request/response testing
- Requires test database
- Tests authentication flow end-to-end
- Verifies response formats and status codes

### Security Tests
- **Prompt Injection**: Validates detection of 12+ injection patterns
- **Tenant Isolation**: Verifies multi-tenant data boundaries
- **PII Detection**: Tests email, phone, ID, and financial data detection

### Performance Tests
- API response time thresholds (500ms)
- Database query performance (100ms)
- Concurrent request handling (50+)
- Memory usage bounds

## Writing New Tests

Follow these conventions:

1. **Naming**: `*.spec.ts` for unit/integration, `*.e2e-spec.ts` for e2e
2. **Location**: Mirror the `apps/api/src/` directory structure
3. **Mocking**: Use `jest.Mocked<>` for typed mocks
4. **Assertions**: Use `expect().toBe()`, `expect().toHaveBeenCalledWith()`, etc.
5. **Cleanup**: Always clean up test data in `afterAll()` hooks
6. **Tenant Context**: All tenant-scoped tests must verify `tenantId` isolation