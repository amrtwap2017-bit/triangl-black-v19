/**
 * v19 Auth E2E Tests — Full auth flow
 *
 * Tests the complete authentication lifecycle:
 * register → login → access protected route → refresh → logout
 */

import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { AppModule } from '../../../../apps/api/src/app.module';
import { PrismaService } from '../../../../apps/api/src/infrastructure/prisma/prisma.service';
import * as request from 'supertest';

describe('Auth E2E (v19)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  const TEST_EMAIL = 'e2e-v19-test@triangleblack.com';
  const TEST_PASSWORD = 'Test@123456';
  const TEST_NAME = 'V19 E2E Test User';
  const TEST_ORG = 'V19 E2E Test Org';

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ transform: true, whitelist: true }));
    await app.init();

    prisma = moduleFixture.get<PrismaService>(PrismaService);
  });

  afterAll(async () => {
    // Cleanup test data
    try {
      await prisma.user.deleteMany({ where: { email: TEST_EMAIL } });
    } catch {
      // User may not exist
    }
    try {
      await prisma.organization.deleteMany({ where: { name: TEST_ORG } });
    } catch {
      // Org may not exist
    }
    await app.close();
  });

  describe('POST /auth/register', () => {
    it('should register a new user and return 201 with tokens', () => {
      return request(app.getHttpServer())
        .post('/auth/register')
        .send({
          email: TEST_EMAIL,
          password: TEST_PASSWORD,
          name: TEST_NAME,
          organizationName: TEST_ORG,
        })
        .expect(201)
        .expect((res) => {
          expect(res.body).toHaveProperty('accessToken');
          expect(res.body).toHaveProperty('refreshToken');
          expect(res.body).toHaveProperty('user');
          expect(res.body.user.email).toBe(TEST_EMAIL);
          expect(res.body.user.name).toBe(TEST_NAME);
          expect(res.body.user).not.toHaveProperty('passwordHash');
        });
    });

    it('should return 409 for duplicate email', () => {
      return request(app.getHttpServer())
        .post('/auth/register')
        .send({
          email: TEST_EMAIL,
          password: TEST_PASSWORD,
          name: 'Duplicate',
          organizationName: 'Another Org',
        })
        .expect(409);
    });

    it('should return 400 for weak password', () => {
      return request(app.getHttpServer())
        .post('/auth/register')
        .send({
          email: 'weak@triangleblack.com',
          password: '123',
          name: 'Weak',
          organizationName: 'Weak Org',
        })
        .expect(400);
    });
  });

  describe('POST /auth/login', () => {
    it('should return 200 with tokens for valid credentials', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: TEST_EMAIL, password: TEST_PASSWORD })
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('accessToken');
          expect(res.body).toHaveProperty('refreshToken');
          expect(res.body).toHaveProperty('user');
          expect(res.body.user.email).toBe(TEST_EMAIL);
        });
    });

    it('should return 401 for wrong password', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: TEST_EMAIL, password: 'WrongPassword1!' })
        .expect(401);
    });

    it('should return 401 for non-existent email', () => {
      return request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: 'nonexistent@nowhere.com', password: TEST_PASSWORD })
        .expect(401);
    });
  });

  describe('GET /protected-route (authenticated)', () => {
    let authToken: string;

    beforeAll(async () => {
      const res = await request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: TEST_EMAIL, password: TEST_PASSWORD });

      authToken = res.body?.accessToken;
    });

    it('should return 200 with valid token', () => {
      if (!authToken) return;
      return request(app.getHttpServer())
        .get('/auth/me')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('id');
          expect(res.body).toHaveProperty('email');
          expect(res.body).not.toHaveProperty('passwordHash');
        });
    });

    it('should return 401 without token', () => {
      return request(app.getHttpServer())
        .get('/auth/me')
        .expect(401);
    });

    it('should return 401 with expired token', () => {
      return request(app.getHttpServer())
        .get('/auth/me')
        .set('Authorization', 'Bearer expired.jwt.token.here')
        .expect(401);
    });
  });

  describe('POST /auth/refresh', () => {
    let refreshToken: string;

    beforeAll(async () => {
      const res = await request(app.getHttpServer())
        .post('/auth/login')
        .send({ email: TEST_EMAIL, password: TEST_PASSWORD });

      refreshToken = res.body?.refreshToken;
    });

    it('should return 200 with new tokens', () => {
      if (!refreshToken) return;
      return request(app.getHttpServer())
        .post('/auth/refresh')
        .send({ refreshToken })
        .expect(200)
        .expect((res) => {
          expect(res.body).toHaveProperty('accessToken');
          expect(res.body).toHaveProperty('refreshToken');
        });
    });

    it('should return 401 with expired/invalid refresh token', () => {
      return request(app.getHttpServer())
        .post('/auth/refresh')
        .send({ refreshToken: 'invalid-expired-refresh-token' })
        .expect(401);
    });
  });
});