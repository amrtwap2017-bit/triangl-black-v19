import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe, NotFoundException } from '@nestjs/common';
import { ProposalsController } from '../../../../apps/api/src/modules/proposals/proposals.controller';
import { ProposalsService } from '../../../../apps/api/src/modules/proposals/proposals.service';
import { JwtAuthGuard } from '../../../../apps/api/src/common/guards/jwt-auth.guard';

// ─── Mock Data ─────────────────────────────────────────────────────────

const mockProposal = {
  id: 'prop-1',
  proposalNumber: 'PROP-2024-001',
  title: 'HVAC Replacement Proposal',
  status: 'DRAFT',
  totalAmount: 450000,
  organizationId: 'org-1',
  hotelId: 'hotel-1',
  opportunityId: 'opp-1',
  validUntil: new Date('2025-06-01'),
  createdAt: new Date('2024-01-01'),
  updatedAt: new Date('2024-01-01'),
  versions: [
    { id: 'v-1', version: 1, changeNote: 'Initial draft', createdAt: new Date() },
  ],
};

const mockBoqItem = {
  description: 'Chiller Unit 500TR',
  quantity: 2,
  unitPrice: 45000,
  total: 90000,
};

const createMockService = () => ({
  findAll: jest.fn(),
  findOne: jest.fn(),
  create: jest.fn(),
  update: jest.fn(),
  remove: jest.fn(),
  generateBoq: jest.fn(),
  generatePdf: jest.fn(),
  createVersion: jest.fn(),
  getVersions: jest.fn(),
});

// ─── Test Suite ─────────────────────────────────────────────────────────

describe('ProposalsController (v19 Integration)', () => {
  let app: INestApplication;
  let service: ReturnType<typeof createMockService>;

  beforeAll(async () => {
    service = createMockService();
    service.findAll.mockResolvedValue({
      data: [mockProposal],
      total: 1,
      page: 1,
      limit: 20,
    });
    service.findOne.mockResolvedValue(mockProposal);
    service.create.mockResolvedValue({ ...mockProposal, id: 'prop-new' });
    service.update.mockResolvedValue({ ...mockProposal, status: 'SUBMITTED' });
    service.remove.mockResolvedValue({ deleted: true });
    service.generateBoq.mockResolvedValue({ items: [mockBoqItem], total: 90000 });
    service.generatePdf.mockResolvedValue({ url: 'https://s3.example.com/proposal.pdf' });
    service.createVersion.mockResolvedValue({ id: 'v-2', version: 2 });
    service.getVersions.mockResolvedValue([mockProposal.versions[0]]);

    const module: TestingModule = await Test.createTestingModule({
      controllers: [ProposalsController],
      providers: [{ provide: ProposalsService, useValue: service }],
    })
      .overrideGuard(JwtAuthGuard)
      .useValue({
        canActivate: (context: { switchToHttp: () => { getRequest: () => Record<string, unknown> } }) => {
          const req = context.switchToHttp().getRequest();
          req.user = { id: 'user-1', organizationId: 'org-1', email: 'admin@corp.com' };
          return true;
        },
      })
      .compile();

    app = module.createNestApplication();
    app.useGlobalPipes(new ValidationPipe({ transform: true, whitelist: true }));
    await app.init();
  });

  afterAll(async () => {
    await app.close();
  });

  it('should be defined', () => {
    expect(app).toBeDefined();
  });

  // ─── CRUD Operations ───────────────────────────────────────────────

  describe('CRUD operations', () => {
    it('GET /proposals returns paginated list', async () => {
      const result = await service.findAll('org-1', { page: 1, limit: 20, tenantId: 'org-1' });
      expect(result.data).toHaveLength(1);
      expect(result.data[0].id).toBe('prop-1');
    });

    it('POST /proposals creates with valid data', async () => {
      const dto = {
        title: 'New Proposal',
        hotelId: 'hotel-1',
        opportunityId: 'opp-1',
        validUntil: new Date('2025-12-01'),
      };

      await service.create(dto, 'org-1', 'user-1');
      expect(service.create).toHaveBeenCalledWith(
        expect.objectContaining({ title: 'New Proposal' }),
        'org-1',
        'user-1',
      );
    });

    it('GET /proposals/:id returns single proposal', async () => {
      const result = await service.findOne('prop-1');
      expect(result.id).toBe('prop-1');
      expect(result.proposalNumber).toBe('PROP-2024-001');
    });

    it('PATCH /proposals/:id updates proposal', async () => {
      await service.update('prop-1', { status: 'SUBMITTED' });
      expect(service.update).toHaveBeenCalledWith('prop-1', { status: 'SUBMITTED' });
    });

    it('DELETE /proposals/:id soft deletes proposal', async () => {
      const result = await service.remove('prop-1');
      expect(result).toHaveProperty('deleted', true);
    });
  });

  // ─── PDF Generation ────────────────────────────────────────────────

  describe('PDF generation', () => {
    it('should generate PDF for a proposal', async () => {
      const result = await service.generatePdf('prop-1');
      expect(result).toHaveProperty('url');
      expect(result.url).toContain('.pdf');
    });
  });

  // ─── BOQ Generation ────────────────────────────────────────────────

  describe('BOQ generation', () => {
    it('should generate BOQ for a proposal', async () => {
      const result = await service.generateBoq('prop-1', {
        scopeDescription: 'Replace all chillers',
        hotelId: 'hotel-1',
      });

      expect(result).toHaveProperty('items');
      expect(result.items).toHaveLength(1);
      expect(result.items[0].description).toBe('Chiller Unit 500TR');
    });
  });

  // ─── Version Management ────────────────────────────────────────────

  describe('version management', () => {
    it('should create a new version', async () => {
      const result = await service.createVersion('prop-1', { changeNote: 'Updated pricing' });
      expect(result.version).toBe(2);
    });

    it('should list version history', async () => {
      const result = await service.getVersions('prop-1');
      expect(result).toHaveLength(1);
      expect(result[0].version).toBe(1);
    });
  });
});