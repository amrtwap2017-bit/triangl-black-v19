/**
 * PII (Personally Identifiable Information) Detection Tests
 * 
 * Tests for detecting and masking PII in AI inputs and outputs.
 */

describe('PII Detection', () => {
  describe('Email Detection', () => {
    const detectEmails = (text: string): string[] => {
      const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
      return text.match(emailRegex) || [];
    };

    const maskEmails = (text: string): string => {
      return text.replace(
        /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g,
        '[REDACTED-EMAIL]'
      );
    };

    it('should detect email addresses', () => {
      const text = 'Contact john.doe@hilton.com or admin@marriott.com for details';
      const emails = detectEmails(text);
      expect(emails).toHaveLength(2);
      expect(emails).toContain('john.doe@hilton.com');
    });

    it('should mask emails in output', () => {
      const text = 'Send the proposal to finance@triangleblack.com by Friday';
      const masked = maskEmails(text);
      expect(masked).toBe('Send the proposal to [REDACTED-EMAIL] by Friday');
      expect(masked).not.toContain('finance@triangleblack.com');
    });
  });

  describe('Phone Number Detection', () => {
    const detectPhoneNumbers = (text: string): string[] => {
      const phoneRegex = /(?:\+?966|0)?(?:5\d{8}|\d{3}[-.\s]?\d{4}[-.\s]?\d{4})/g;
      return text.match(phoneRegex) || [];
    };

    const maskPhoneNumbers = (text: string): string => {
      return text.replace(
        /(?:\+?966|0)?(?:5\d{8}|\d{3}[-.\s]?\d{4}[-.\s]?\d{4})/g,
        '[REDACTED-PHONE]'
      );
    };

    it('should detect Saudi phone numbers', () => {
      const text = 'Call the engineer at +966501234567 or 0559876543';
      const phones = detectPhoneNumbers(text);
      expect(phones.length).toBeGreaterThanOrEqual(1);
    });

    it('should mask phone numbers', () => {
      const text = 'The hotel manager can be reached at +966551234567';
      const masked = maskPhoneNumbers(text);
      expect(masked).not.toContain('+966551234567');
      expect(masked).toContain('[REDACTED-PHONE]');
    });
  });

  describe('Credit Card / Financial Data', () => {
    const detectCardNumbers = (text: string): string[] => {
      const cardRegex = /\b(?:\d[ -]*?){13,19}\b/g;
      return text.match(cardRegex) || [];
    };

    it('should detect potential credit card numbers', () => {
      const text = 'Payment card: 4111 1111 1111 1111';
      const cards = detectCardNumbers(text);
      expect(cards.length).toBeGreaterThan(0);
    });
  });

  describe('ID Number Detection', () => {
    const detectSaudiIds = (text: string): string[] => {
      const idRegex = /\b1\d{9}\b/g;
      return text.match(idRegex) || [];
    };

    it('should detect Saudi national ID numbers', () => {
      const text = 'Employee ID: 1234567890 is the national ID for the manager';
      const ids = detectSaudiIds(text);
      // 10-digit numbers starting with 1
      expect(ids.length).toBeGreaterThanOrEqual(0);
    });
  });

  describe('Comprehensive PII Scan', () => {
    const scanForPII = (text: string): { type: string; count: number }[] => {
      const results: { type: string; count: number }[] = [];

      const emails = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g);
      if (emails) results.push({ type: 'email', count: emails.length });

      const phones = text.match(/(?:\+?966|0)?5\d{8}/g);
      if (phones) results.push({ type: 'phone', count: phones.length });

      const ids = text.match(/\b1\d{9}\b/g);
      if (ids) results.push({ type: 'national_id', count: ids.length });

      return results;
    };

    it('should detect multiple PII types in a single text', () => {
      const text = `
        Hotel Manager: Ahmed Al-Rashid
        Email: ahmed@hilton-riyadh.com
        Phone: +966509876543
        National ID: 1098765432
        Notes: Contact for emergency maintenance at the Hilton property.
      `;

      const pii = scanForPII(text);

      expect(pii.length).toBeGreaterThanOrEqual(2);
      const emailPII = pii.find(p => p.type === 'email');
      expect(emailPII).toBeDefined();
      expect(emailPII!.count).toBeGreaterThanOrEqual(1);
    });

    it('should not flag text without PII', () => {
      const text = 'Replace the chiller unit in Building A by next Tuesday. Budget is SAR 150,000.';
      const pii = scanForPII(text);
      expect(pii.length).toBe(0);
    });
  });
});