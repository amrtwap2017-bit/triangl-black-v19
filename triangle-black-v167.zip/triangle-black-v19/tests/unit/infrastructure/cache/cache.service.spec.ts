import { Test, TestingModule } from '@nestjs/testing';
import { CacheService } from '../../../../apps/api/src/infrastructure/cache/cache.service';

// ─── Test Suite ─────────────────────────────────────────────────────────

describe('CacheService (v19 Unit)', () => {
  let service: CacheService;

  beforeEach(async () => {
    // Disable Redis in tests — forces in-memory fallback
    process.env.REDIS_HOST = '';
    jest.restoreAllMocks();

    const module: TestingModule = await Test.createTestingModule({
      providers: [CacheService],
    }).compile();

    service = module.get<CacheService>(CacheService);
  });

  afterEach(async () => {
    await service.onModuleDestroy();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // ─── set and get ────────────────────────────────────────────────────

  describe('set and get', () => {
    it('should set and get a value', async () => {
      await service.set('test-key', { name: 'Triangle Black', version: 19 });

      const result = await service.get<{ name: string; version: number }>('test-key');
      expect(result).toEqual({ name: 'Triangle Black', version: 19 });
    });

    it('should set and get a string value', async () => {
      await service.set('string-key', 'hello world');

      const result = await service.get<string>('string-key');
      expect(result).toBe('hello world');
    });

    it('should set and get a numeric value', async () => {
      await service.set('number-key', 42);

      const result = await service.get<number>('number-key');
      expect(result).toBe(42);
    });

    it('should overwrite existing key', async () => {
      await service.set('key', 'first');
      await service.set('key', 'second');

      const result = await service.get<string>('key');
      expect(result).toBe('second');
    });
  });

  // ─── get missing key ────────────────────────────────────────────────

  describe('get missing key', () => {
    it('should return null for missing key', async () => {
      const result = await service.get('nonexistent-key');
      expect(result).toBeNull();
    });
  });

  // ─── delete ─────────────────────────────────────────────────────────

  describe('delete', () => {
    it('should remove a key', async () => {
      await service.set('delete-me', 'value');
      await service.del('delete-me');

      const result = await service.get('delete-me');
      expect(result).toBeNull();
    });

    it('should not throw when deleting non-existent key', async () => {
      await expect(service.del('never-existed')).resolves.not.toThrow();
    });
  });

  // ─── TTL Expiration ─────────────────────────────────────────────────

  describe('TTL expiration', () => {
    it('should expire entries after TTL', async () => {
      // Use very short TTL for testing
      await service.set('short-lived', 'data', 1); // 1 second

      const before = await service.get<string>('short-lived');
      expect(before).toBe('data');

      // Wait for expiration + cleanup buffer
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Manually trigger cleanup (normally runs every 60s)
      const after = await service.get<string>('short-lived');
      expect(after).toBeNull();
    });

    it('should persist entries with no TTL', async () => {
      await service.set('permanent', 'data', 0);

      await new Promise(resolve => setTimeout(resolve, 100));
      const result = await service.get<string>('permanent');
      expect(result).toBe('data');
    });
  });

  // ─── Pattern Invalidation ──────────────────────────────────────────

  describe('pattern invalidation', () => {
    it('should delete keys matching a pattern', async () => {
      await service.set('hotel:org-1:hotel-1', 'data1');
      await service.set('hotel:org-1:hotel-2', 'data2');
      await service.set('hotel:org-1:hotel-3', 'data3');
      await service.set('vendor:org-1:vendor-1', 'data4');

      await service.delByPattern('hotel:org-1');

      expect(await service.get('hotel:org-1:hotel-1')).toBeNull();
      expect(await service.get('hotel:org-1:hotel-2')).toBeNull();
      expect(await service.get('hotel:org-1:hotel-3')).toBeNull();
      // Vendor key should remain
      expect(await service.get('vendor:org-1:vendor-1')).toBe('data4');
    });
  });

  // ─── Cache-Aside Pattern ──────────────────────────────────────────

  describe('getOrSet (cache-aside)', () => {
    it('should return cached value on cache hit', async () => {
      await service.set('cache-aside-key', 'from-cache');

      let fetchCalled = false;
      const result = await service.get<string>('cache-aside-key') ?? await (async () => {
        fetchCalled = true;
        const value = 'from-db';
        await service.set('cache-aside-key', value);
        return value;
      })();

      expect(result).toBe('from-cache');
      expect(fetchCalled).toBe(false);
    });

    it('should fetch and cache on cache miss', async () => {
      let fetchCalled = false;
      const result = await service.get<string>('cache-aside-miss') ?? await (async () => {
        fetchCalled = true;
        const value = 'freshly-fetched';
        await service.set('cache-aside-miss', value);
        return value;
      })();

      expect(result).toBe('freshly-fetched');
      expect(fetchCalled).toBe(true);
    });
  });

  // ─── Redis Fallback ────────────────────────────────────────────────

  describe('Redis fallback to in-memory', () => {
    it('should fall back to in-memory when Redis is unavailable', async () => {
      // Already testing with in-memory (no Redis env vars)
      await service.set('fallback-key', 'in-memory-value');
      const result = await service.get<string>('fallback-key');
      expect(result).toBe('in-memory-value');
    });
  });

  // ─── Reset ──────────────────────────────────────────────────────────

  describe('reset', () => {
    it('should clear all cache entries', async () => {
      await service.set('key1', 'v1');
      await service.set('key2', 'v2');
      await service.set('key3', 'v3');

      await service.reset();

      expect(await service.get('key1')).toBeNull();
      expect(await service.get('key2')).toBeNull();
      expect(await service.get('key3')).toBeNull();
    });
  });
});