import { Test, TestingModule } from '@nestjs/testing';
import { Logger } from '@nestjs/common';
import { QueueService } from '../../../../apps/api/src/infrastructure/queue/queue.service';

// ─── Mock BullMQ ───────────────────────────────────────────────────────

const mockJobs = new Map<string, { id: string; data: Record<string, unknown>; state: string; attemptsMade: number; opts: Record<string, unknown> }>();

class MockQueue {
  private queueName: string;
  constructor(queueName: string) {
    this.queueName = queueName;
  }
  async add(_name: string, data: Record<string, unknown>, opts: Record<string, unknown>) {
    const id = (opts as Record<string, unknown>).jobId as string || `job-${Date.now()}`;
    mockJobs.set(id, { id, data, state: 'waiting', attemptsMade: 0, opts });
    return { id, getState: async () => 'waiting', attemptsMade: 0 };
  }
  async getJob(id: string) {
    return mockJobs.get(id) || null;
  }
  async getJobCounts() {
    let waiting = 0, active = 0, completed = 0, failed = 0, delayed = 0;
    for (const job of mockJobs.values()) {
      if (job.state === 'waiting') waiting++;
      else if (job.state === 'active') active++;
      else if (job.state === 'completed') completed++;
      else if (job.state === 'failed') failed++;
      else if (job.state === 'delayed') delayed++;
    }
    return { waiting, active, completed, failed, delayed };
  }
  async close() { /* no-op */ }
}

// We need to mock the BullMQ module
jest.mock('bullmq', () => ({
  Queue: MockQueue,
  Worker: jest.fn().mockImplementation((_name, _processor, _opts) => ({
    on: jest.fn(),
    close: jest.fn().mockResolvedValue(undefined),
  })),
}));

// ─── Test Suite ─────────────────────────────────────────────────────────

describe('QueueService (v19 Unit)', () => {
  let service: QueueService;

  beforeEach(async () => {
    mockJobs.clear();
    jest.restoreAllMocks();

    const module: TestingModule = await Test.createTestingModule({
      providers: [QueueService],
    }).compile();

    service = module.get<QueueService>(QueueService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // ─── addJob ─────────────────────────────────────────────────────────

  describe('addJob', () => {
    it('should create job with correct queue name', async () => {
      const jobId = await service.addJob('document-processing', { documentId: 'doc-1', organizationId: 'org-1' });

      expect(jobId).toBeTruthy();
      expect(typeof jobId).toBe('string');
    });

    it('should generate idempotency key when no name provided', async () => {
      const jobId = await service.addJob('email', { to: 'user@example.com' });

      expect(jobId).toBeTruthy();
      // Auto-generated ID should exist
      expect(typeof jobId).toBe('string');
    });

    it('should use provided job name as idempotency key', async () => {
      const jobId = await service.addJob(
        'document-processing',
        { documentId: 'doc-1' },
        { name: 'dedup-key-123' },
      );

      expect(jobId).toBe('dedup-key-123');
    });

    it('should pass delay option to the job', async () => {
      const jobId = await service.addJob(
        'notifications',
        { message: 'Hello' },
        { delay: 5000, name: 'delayed-job' },
      );

      const job = mockJobs.get(jobId);
      expect(job).toBeDefined();
      expect(job!.opts).toHaveProperty('delay', 5000);
    });

    it('should default to 3 retry attempts', async () => {
      await service.addJob('processing', { data: 'test' }, { name: 'retry-job' });

      const job = mockJobs.get('retry-job');
      expect(job).toBeDefined();
      expect(job!.opts).toHaveProperty('attempts', 3);
    });
  });

  // ─── getJobStatus ───────────────────────────────────────────────────

  describe('getJobStatus', () => {
    it('should return correct status for existing job', async () => {
      const jobId = await service.addJob('test', { data: 'test' }, { name: 'status-job' });

      const job = mockJobs.get(jobId);
      expect(job).toBeDefined();
      expect(job!.state).toBe('waiting');
    });

    it('should return null for non-existent job', async () => {
      const queue = (service as unknown as { getQueue: (name: string) => MockQueue }).getQueue('test');
      const job = await queue.getJob('nonexistent-job');
      expect(job).toBeNull();
    });
  });

  // ─── getQueueStats ──────────────────────────────────────────────────

  describe('getQueueStats', () => {
    it('should return accurate counts', async () => {
      await service.addJob('stats-queue', { a: 1 }, { name: 'job-a' });
      await service.addJob('stats-queue', { b: 2 }, { name: 'job-b' });

      const queue = (service as unknown as { getQueue: (name: string) => MockQueue }).getQueue('stats-queue');
      const counts = await queue.getJobCounts();

      expect(counts.waiting).toBe(2);
      expect(counts.active).toBe(0);
      expect(counts.failed).toBe(0);
    });
  });

  // ─── Retry ──────────────────────────────────────────────────────────

  describe('retryJob', () => {
    it('should re-queue a failed job', async () => {
      // Simulate a failed job
      const jobId = await service.addJob('retry-test', { data: 'fail' }, { name: 'failed-job' });
      const job = mockJobs.get(jobId);
      job!.state = 'failed';
      job!.attemptsMade = 1;

      // Re-queue by adding new job with same data
      await service.addJob('retry-test', job!.data, { name: `${jobId}-retry-1` });

      const retryJob = mockJobs.get(`${jobId}-retry-1`);
      expect(retryJob).toBeDefined();
      expect(retryJob!.state).toBe('waiting');
    });
  });

  // ─── Cancel Job ─────────────────────────────────────────────────────

  describe('cancelJob', () => {
    it('should cancel a pending job', async () => {
      const jobId = await service.addJob('cancel-test', { data: 'test' }, { name: 'cancel-job' });
      const job = mockJobs.get(jobId);
      expect(job).toBeDefined();

      // Cancel by removing from mock
      mockJobs.delete(jobId);
      expect(mockJobs.get(jobId)).toBeUndefined();
    });
  });

  // ─── Timeout Handling ──────────────────────────────────────────────

  describe('job timeout handling', () => {
    it('should support job timeout configuration', async () => {
      const timeoutMs = 30000;
      await service.addJob('timeout-test', { data: 'slow' }, { name: 'timeout-job' });

      const job = mockJobs.get('timeout-job');
      expect(job).toBeDefined();
      // Timeout would be handled by BullMQ at the worker level
    });
  });

  // ─── Dead Letter Queue ─────────────────────────────────────────────

  describe('dead letter queue on max retries', () => {
    it('should configure max attempts for dead letter behavior', async () => {
      await service.addJob('dlq-test', { data: 'unstable' }, {
        name: 'max-retry-job',
        attempts: 5,
        backoff: 1000,
      });

      const job = mockJobs.get('max-retry-job');
      expect(job).toBeDefined();
      expect(job!.opts).toHaveProperty('attempts', 5);
      expect(job!.opts).toHaveProperty('backoff');
    });
  });

  // ─── Exponential Backoff ───────────────────────────────────────────

  describe('exponential backoff timing', () => {
    it('should configure exponential backoff', async () => {
      await service.addJob('backoff-test', { data: 'flaky' }, {
        name: 'backoff-job',
        attempts: 3,
        backoff: 2000,
      });

      const job = mockJobs.get('backoff-job');
      expect(job).toBeDefined();
      // Service wraps backoff in { type: 'exponential', delay: N }
      const backoff = job!.opts.backoff as { type: string; delay: number };
      expect(backoff.type).toBe('exponential');
      expect(backoff.delay).toBe(2000);
    });

    it('should increase delay with each retry (1x, 2x, 4x...)', () => {
      const baseDelay = 1000;
      const delays = Array.from({ length: 4 }, (_, i) => baseDelay * Math.pow(2, i));
      expect(delays).toEqual([1000, 2000, 4000, 8000]);
    });
  });

  // ─── Module Cleanup ────────────────────────────────────────────────

  describe('onModuleDestroy', () => {
    it('should close all queue connections', async () => {
      await service.addJob('cleanup-test', { data: 'test' });
      await service.onModuleDestroy();
      // Should not throw
    });
  });
});