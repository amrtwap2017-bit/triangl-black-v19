import { Test, TestingModule } from '@nestjs/testing';
import { JwtService } from '@nestjs/jwt';
import { SecurityService } from '../../../../apps/api/src/infrastructure/security/security.service';

// ─── Test Suite ─────────────────────────────────────────────────────────

describe('SecurityService (v19 Unit)', () => {
  let service: SecurityService;
  let jwtService: { sign: jest.Mock; verify: jest.Mock };

  beforeEach(async () => {
    jwtService = {
      sign: jest.fn().mockReturnValue('signed-jwt-token'),
      verify: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SecurityService,
        { provide: JwtService, useValue: jwtService },
      ],
    }).compile();

    service = module.get<SecurityService>(SecurityService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // ─── SQL Injection Detection ────────────────────────────────────────

  describe('SQL injection detection', () => {
    it('should detect SELECT injection', () => {
      expect(service.detectSqlInjection('SELECT * FROM users')).toBe(true);
    });

    it('should detect INSERT injection', () => {
      expect(service.detectSqlInjection("INSERT INTO users VALUES ('admin')")).toBe(true);
    });

    it('should detect UPDATE injection', () => {
      expect(service.detectSqlInjection("UPDATE users SET role='admin'")).toBe(true);
    });

    it('should detect DELETE injection', () => {
      expect(service.detectSqlInjection('DELETE FROM users WHERE 1=1')).toBe(true);
    });

    it('should detect DROP injection', () => {
      expect(service.detectSqlInjection('DROP TABLE hotels')).toBe(true);
    });

    it('should detect UNION injection', () => {
      expect(service.detectSqlInjection("1' UNION SELECT * FROM passwords --")).toBe(true);
    });

    it('should detect URL-encoded injection', () => {
      expect(service.detectSqlInjection('%27 OR 1=1 --')).toBe(true);
    });

    it('should not flag normal text as SQL injection', () => {
      expect(service.detectSqlInjection('What is our procurement policy?')).toBe(false);
    });

    it('should not flag legitimate queries', () => {
      expect(service.detectSqlInjection('Show me all hotels in Riyadh')).toBe(false);
    });
  });

  // ─── XSS Detection ─────────────────────────────────────────────────

  describe('XSS detection', () => {
    it('should detect <script> tag', () => {
      expect(service.detectXss('<script>alert("xss")</script>')).toBe(true);
    });

    it('should detect javascript: protocol', () => {
      expect(service.detectXss('javascript:alert(1)')).toBe(true);
    });

    it('should detect onclick event handler', () => {
      expect(service.detectXss('<div onclick="alert(1)">click</div>')).toBe(true);
    });

    it('should detect <iframe> tag', () => {
      expect(service.detectXss('<iframe src="evil.com"></iframe>')).toBe(true);
    });

    it('should detect <object> tag', () => {
      expect(service.detectXss('<object data="evil.swf"></object>')).toBe(true);
    });

    it('should detect <embed> tag', () => {
      expect(service.detectXss('<embed src="evil.swf">')).toBe(true);
    });

    it('should detect <form> tag', () => {
      expect(service.detectXss('<form action="evil.com"><input>')).toBe(true);
    });

    it('should detect CSS expression', () => {
      expect(service.detectXss('width: expression(alert(1))')).toBe(true);
    });

    it('should detect SVG onload', () => {
      expect(service.detectXss('<svg onload="alert(1)">')).toBe(true);
    });

    it('should detect document.cookie access', () => {
      expect(service.detectXss('document.cookie')).toBe(true);
    });

    it('should not flag normal text as XSS', () => {
      expect(service.detectXss('Generate a BOQ for HVAC replacement')).toBe(false);
    });
  });

  // ─── Input Sanitization ────────────────────────────────────────────

  describe('input sanitization', () => {
    it('should remove HTML tags', () => {
      const result = service.sanitizeInput('<p>Hello</p><script>alert(1)</script>');
      expect(result).toBe('Helloalert(1)');
    });

    it('should normalize whitespace', () => {
      const result = service.sanitizeInput('Hello    world   test');
      expect(result).toBe('Hello world test');
    });

    it('should trim leading/trailing whitespace', () => {
      const result = service.sanitizeInput('  hello world  ');
      expect(result).toBe('hello world');
    });

    it('should return empty string for empty input', () => {
      expect(service.sanitizeInput('')).toBe('');
    });

    it('should return empty string for null/undefined input', () => {
      expect(service.sanitizeInput(null as unknown as string)).toBe('');
    });
  });

  // ─── Rate Limiting ─────────────────────────────────────────────────

  describe('rate limiting', () => {
    it('should block excessive requests (auth.login: 5/min)', () => {
      const config = service.getRateLimitConfig('auth.login');
      expect(config).toEqual({ ttl: 60, limit: 5 });
    });

    it('should allow normal requests within limit', () => {
      const config = service.getRateLimitConfig('auth.login');
      expect(config.limit).toBeGreaterThan(0);
    });

    it('should have stricter limits for auth endpoints', () => {
      const authConfig = service.getRateLimitConfig('auth.login');
      const generalConfig = service.getRateLimitConfig('api.general');
      expect(authConfig.limit).toBeLessThan(generalConfig.limit);
    });

    it('should return default config for unknown endpoints', () => {
      const config = service.getRateLimitConfig('unknown.endpoint');
      expect(config).toEqual({ ttl: 60, limit: 100 });
    });

    it('should match prefix-based configs', () => {
      const searchConfig = service.getRateLimitConfig('api.search.advanced');
      expect(searchConfig).toEqual({ ttl: 60, limit: 30 });
    });
  });

  // ─── CSRF Token Validation ─────────────────────────────────────────

  describe('CSRF protection', () => {
    it('should generate signed tokens for CSRF', () => {
      // CSRF tokens are JWTs signed with a secret
      const payload = { sub: 'user-1', type: 'csrf', nonce: 'random-nonce' };
      const token = service.generateAccessToken(payload as never);
      expect(jwtService.sign).toHaveBeenCalled();
      expect(typeof token).toBe('string');
    });

    it('should verify CSRF token signature', async () => {
      jwtService.verify.mockReturnValue({ sub: 'user-1', type: 'csrf' });

      const result = await service.verifyToken('valid-csrf-token');
      expect(result).toBeTruthy();
      expect(jwtService.verify).toHaveBeenCalledWith('valid-csrf-token', expect.any(Object));
    });

    it('should reject tampered CSRF tokens', async () => {
      jwtService.verify.mockImplementation(() => { throw new Error('Invalid signature'); });

      const result = await service.verifyToken('tampered-token');
      expect(result).toBeNull();
    });
  });

  // ─── Security Headers ─────────────────────────────────────────────

  describe('security headers', () => {
    it('should define expected security header keys', () => {
      const requiredHeaders = [
        'x-content-type-options',
        'x-frame-options',
        'x-xss-protection',
        'content-security-policy',
        'strict-transport-security',
      ];

      // Verify the concept of security headers exists
      requiredHeaders.forEach(header => {
        expect(typeof header).toBe('string');
      });
    });
  });

  // ─── File Type Validation ─────────────────────────────────────────

  describe('file type validation', () => {
    it('should validate allowed MIME types', () => {
      const allowed = ['application/pdf', 'image/png', 'image/jpeg'];
      expect(service.validateFileType('application/pdf', allowed)).toBe(true);
      expect(service.validateFileType('image/png', allowed)).toBe(true);
    });

    it('should reject disallowed MIME types', () => {
      const allowed = ['application/pdf', 'image/png'];
      expect(service.validateFileType('application/x-shockwave-flash', allowed)).toBe(false);
      expect(service.validateFileType('text/html', allowed)).toBe(false);
    });

    it('should handle case-insensitive MIME types', () => {
      const allowed = ['application/pdf'];
      expect(service.validateFileType('Application/PDF', allowed)).toBe(true);
    });
  });
});