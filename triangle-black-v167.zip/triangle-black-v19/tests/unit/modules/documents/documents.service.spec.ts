import { Test, TestingModule } from '@nestjs/testing';
import { NotFoundException } from '@nestjs/common';
import { DocumentsService } from '../../../../apps/api/src/modules/documents/documents.service';
import { PrismaService } from '../../../../apps/api/src/infrastructure/prisma/prisma.service';
import { StorageService } from '../../../../apps/api/src/infrastructure/storage/storage.service';

// ─── Mock Data ─────────────────────────────────────────────────────────

const mockFile: Express.Multer.File = {
  fieldname: 'file',
  originalname: 'proposal.pdf',
  encoding: '7bit',
  mimetype: 'application/pdf',
  destination: '/tmp',
  filename: 'proposal-abc.pdf',
  path: '/tmp/proposal-abc.pdf',
  size: 1024 * 500,
  stream: null as never,
  buffer: Buffer.alloc(0),
};

const mockDocument = {
  id: 'doc-1',
  organizationId: 'org-1',
  projectId: 'proj-1',
  contractId: null,
  category: 'PROPOSAL',
  title: 'HVAC Proposal',
  titleAr: 'مقترح التكييف',
  mimeType: 'application/pdf',
  fileSize: 512000,
  storageKey: 'documents/org-1/proposal-abc.pdf',
  status: 'ACTIVE',
  uploadedById: 'user-1',
  createdAt: new Date(),
  updatedAt: new Date(),
  checksum: 'sha256:abc123',
};

const createMockPrisma = () => ({
  document: {
    create: jest.fn(),
    findMany: jest.fn(),
    findUnique: jest.fn(),
    count: jest.fn(),
    delete: jest.fn(),
    update: jest.fn(),
    groupBy: jest.fn(),
  },
  documentVersion: {
    findMany: jest.fn(),
    create: jest.fn(),
  },
});

const createMockStorage = () => ({
  upload: jest.fn(),
  getSignedUrl: jest.fn(),
  delete: jest.fn(),
});

// ─── Test Suite ─────────────────────────────────────────────────────────

describe('DocumentsService (v19 Unit)', () => {
  let service: DocumentsService;
  let prisma: ReturnType<typeof createMockPrisma>;
  let storage: ReturnType<typeof createMockStorage>;

  beforeEach(async () => {
    prisma = createMockPrisma();
    storage = createMockStorage();

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DocumentsService,
        { provide: PrismaService, useValue: prisma },
        { provide: StorageService, useValue: storage },
      ],
    }).compile();

    service = module.get<DocumentsService>(DocumentsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  // ─── Upload ─────────────────────────────────────────────────────────

  describe('upload', () => {
    it('should store file and create document record', async () => {
      storage.upload.mockResolvedValue('documents/org-1/proposal-abc.pdf');
      prisma.document.create.mockResolvedValue(mockDocument);

      const result = await service.upload(mockFile, {
        organizationId: 'org-1',
        projectId: 'proj-1',
        title: 'HVAC Proposal',
        titleAr: 'مقترح التكييف',
        category: 'PROPOSAL',
      });

      expect(storage.upload).toHaveBeenCalledWith(mockFile, 'documents/org-1');
      expect(prisma.document.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            organizationId: 'org-1',
            title: 'HVAC Proposal',
            mimeType: 'application/pdf',
            fileSize: 512000,
            status: 'ACTIVE',
          }),
        }),
      );
      expect(result).toEqual(mockDocument);
    });

    it('should validate file size (50MB limit)', () => {
      const oversizedFile = { ...mockFile, size: 60 * 1024 * 1024 };
      const maxSize = 50 * 1024 * 1024;
      expect(oversizedFile.size).toBeGreaterThan(maxSize);
    });

    it('should validate MIME type', () => {
      const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg'];
      const validMime = 'application/pdf';
      const invalidMime = 'application/x-shockwave-flash';
      expect(allowedTypes).toContain(validMime);
      expect(allowedTypes).not.toContain(invalidMime);
    });
  });

  // ─── findAll ────────────────────────────────────────────────────────

  describe('findAll', () => {
    it('should filter by organizationId (tenant isolation)', async () => {
      const docs = [mockDocument];
      prisma.document.findMany.mockResolvedValue(docs);
      prisma.document.count.mockResolvedValue(1);

      const result = await service.findAll('org-1', { page: 1, limit: 20, sortBy: 'createdAt', sortOrder: 'desc' });

      expect(prisma.document.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({ organizationId: 'org-1', status: 'ACTIVE' }),
        }),
      );
      expect(result.meta.total).toBe(1);
    });

    it('should apply pagination correctly', async () => {
      prisma.document.findMany.mockResolvedValue([mockDocument]);
      prisma.document.count.mockResolvedValue(50);

      const result = await service.findAll('org-1', { page: 2, limit: 10, sortBy: 'createdAt', sortOrder: 'desc' });

      expect(prisma.document.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          skip: 10,
          take: 10,
        }),
      );
      expect(result.meta.page).toBe(2);
      expect(result.meta.totalPages).toBe(5);
    });

    it('should apply filters for projectId, contractId, category', async () => {
      prisma.document.findMany.mockResolvedValue([]);
      prisma.document.count.mockResolvedValue(0);

      await service.findAll('org-1', { page: 1, limit: 20, sortBy: 'createdAt', sortOrder: 'desc' }, {
        projectId: 'proj-1',
        contractId: 'contract-1',
        category: 'PROPOSAL',
      });

      expect(prisma.document.findMany).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            organizationId: 'org-1',
            status: 'ACTIVE',
            projectId: 'proj-1',
            contractId: 'contract-1',
            category: 'PROPOSAL',
          }),
        }),
      );
    });
  });

  // ─── findOne ────────────────────────────────────────────────────────

  describe('findOne', () => {
    it('should return document for valid id', async () => {
      prisma.document.findUnique.mockResolvedValue({ ...mockDocument, versions: [] });

      const result = await service.findOne('doc-1');
      expect(result).toBeDefined();
      expect(prisma.document.findUnique).toHaveBeenCalledWith(
        expect.objectContaining({ where: { id: 'doc-1' } }),
      );
    });

    it('should throw NotFoundException for non-existent document', async () => {
      prisma.document.findUnique.mockResolvedValue(null);

      await expect(service.findOne('nonexistent')).rejects.toThrow(NotFoundException);
    });
  });

  // ─── delete ─────────────────────────────────────────────────────────

  describe('remove', () => {
    it('should delete document (hard delete)', async () => {
      prisma.document.delete.mockResolvedValue(mockDocument);

      const result = await service.remove('doc-1');
      expect(result.success).toBe(true);
      expect(prisma.document.delete).toHaveBeenCalledWith({ where: { id: 'doc-1' } });
    });

    it('should throw NotFoundException when document not found', async () => {
      prisma.document.delete.mockRejectedValue(new Error('Record not found'));

      await expect(service.remove('nonexistent')).rejects.toThrow(NotFoundException);
    });
  });

  // ─── Version History ────────────────────────────────────────────────

  describe('createVersion', () => {
    it('should track version history', async () => {
      prisma.document.findUnique.mockResolvedValue(mockDocument);
      prisma.documentVersion.findMany.mockResolvedValue([]);
      prisma.documentVersion.create.mockResolvedValue({
        id: 'v-1',
        documentId: 'doc-1',
        version: 1,
        storageKey: 'documents/org-1/proposal-abc.pdf',
        changeNote: 'Initial version',
        changedBy: 'user-1',
      });

      const result = await service.createVersion('doc-1', 'Initial version', 'user-1');

      expect(result.version).toBe(1);
      expect(prisma.documentVersion.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            documentId: 'doc-1',
            version: 1,
            changeNote: 'Initial version',
          }),
        }),
      );
    });

    it('should throw NotFoundException for non-existent document on versioning', async () => {
      prisma.document.findUnique.mockResolvedValue(null);

      await expect(service.createVersion('nonexistent')).rejects.toThrow(NotFoundException);
    });
  });

  // ─── Download URL ──────────────────────────────────────────────────

  describe('getDownloadUrl', () => {
    it('should return signed URL for document', async () => {
      prisma.document.findUnique.mockResolvedValue(mockDocument);
      storage.getSignedUrl.mockResolvedValue('https://s3.example.com/signed-url');

      const result = await service.getDownloadUrl('doc-1');
      expect(result.url).toBe('https://s3.example.com/signed-url');
      expect(storage.getSignedUrl).toHaveBeenCalledWith('documents/org-1/proposal-abc.pdf');
    });
  });
});