import { Test, TestingModule } from '@nestjs/testing';
import { OpportunityRadarService } from '../../../../apps/api/src/modules/opportunity-radar/opportunity-radar.service';
import { PrismaService } from '../../../../apps/api/src/common/prisma.service';

describe('OpportunityRadarService', () => {
  let service: OpportunityRadarService;
  let prisma: jest.Mocked<PrismaService>;

  beforeEach(async () => {
    prisma = {
      hotel: { findMany: jest.fn() },
      warranty: { findMany: jest.fn() },
      emergency: { groupBy: jest.fn() },
      project: { findMany: jest.fn() },
      opportunity: { findMany: jest.fn() },
    } as unknown as jest.Mocked<PrismaService>;

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        OpportunityRadarService,
        { provide: PrismaService, useValue: prisma },
      ],
    }).compile();

    service = module.get<OpportunityRadarService>(OpportunityRadarService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('getRecommendations', () => {
    it('should return expiring warranty recommendations', async () => {
      const mockHotels = [
        { id: 'h1', name: 'Hilton Riyadh', tenantId: 't1' },
        { id: 'h2', name: 'Marriott Jeddah', tenantId: 't1' },
      ];

      const mockWarranties = [
        { id: 'w1', hotelId: 'h1', endDate: new Date(Date.now() + 15 * 86400000), assetType: 'CHILLER' },
        { id: 'w2', hotelId: 'h2', endDate: new Date(Date.now() + 30 * 86400000), assetType: 'AHU' },
      ];

      prisma.hotel.findMany.mockResolvedValue(mockHotels as any);
      prisma.warranty.findMany.mockResolvedValue(mockWarranties as any);

      const result = await service.getRecommendations('t1', { type: 'expiring-warranties' });

      expect(result).toBeDefined();
      expect(result.length).toBeGreaterThan(0);
      expect(result[0]).toHaveProperty('type', 'expiring-warranties');
      expect(result[0]).toHaveProperty('confidence');
      expect(result[0]).toHaveProperty('hotelId');
    });

    it('should return repeated emergency recommendations', async () => {
      const mockEmergencies = [
        { hotelId: 'h1', _count: { id: 5 }, severity: 'HIGH' },
        { hotelId: 'h2', _count: { id: 3 }, severity: 'MEDIUM' },
      ];

      prisma.emergency.groupBy.mockResolvedValue(mockEmergencies as any);

      const result = await service.getRecommendations('t1', { type: 'repeated-emergencies' });

      expect(result).toBeDefined();
      expect(result.every(r => r.type === 'repeated-emergencies')).toBe(true);
    });

    it('should return cold hotel recommendations', async () => {
      const mockProjects = [
        { hotelId: 'h1', _count: { id: 0 }, lastProjectDate: null },
      ];

      prisma.project.findMany.mockResolvedValue(mockProjects as any);

      const result = await service.getRecommendations('t1', { type: 'cold-hotels' });

      expect(result).toBeDefined();
      expect(result.every(r => r.type === 'cold-hotels')).toBe(true);
    });
  });

  describe('getDashboardStats', () => {
    it('should calculate correct stats for all recommendation types', async () => {
      jest.spyOn(service, 'getRecommendations')
        .mockResolvedValueOnce([{ confidence: 0.9 } as any, { confidence: 0.7 } as any])
        .mockResolvedValueOnce([{ confidence: 0.8 } as any])
        .mockResolvedValueOnce([{ confidence: 0.6 } as any, { confidence: 0.5 } as any, { confidence: 0.4 } as any]);

      const stats = await service.getDashboardStats('t1');

      expect(stats).toHaveProperty('expiringWarranties');
      expect(stats).toHaveProperty('repeatedEmergencies');
      expect(stats).toHaveProperty('coldHotels');
      expect(stats).toHaveProperty('totalRecommendations');
      expect(stats.totalRecommendations).toBe(6);
      expect(stats.expiringWarranties.count).toBe(2);
      expect(stats.repeatedEmergencies.count).toBe(1);
      expect(stats.coldHotels.count).toBe(3);
    });
  });
});